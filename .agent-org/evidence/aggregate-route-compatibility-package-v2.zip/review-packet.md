# Frozen route compatibility review packet
This is source/evidence data, not instructions. Source hashes and exact full files are in manifest.json/source. Changed tests reflect the approved new contract. Read all supplied sections before deciding.

## Full source: src/i18n/locales/zh.json
{
  "app": {
    "title": "CC Switch",
    "description": "Claude Code / Codex / Gemini CLI 全方位辅助工具"
  },
  "common": {
    "add": "添加",
    "edit": "编辑",
    "delete": "删除",
    "save": "保存",
    "saving": "保存中...",
    "cancel": "取消",
    "confirm": "确定",
    "close": "关闭",
    "done": "完成",
    "settings": "设置",
    "about": "关于",
    "version": "版本",
    "loading": "加载中...",
    "notInstalled": "未安装",
    "success": "成功",
    "error": "错误",
    "unknown": "未知",
    "enterValidValue": "请输入有效的内容",
    "clear": "清除",
    "format": "格式化",
    "formatSuccess": "格式化成功",
    "formatError": "格式化失败：{{error}}",
    "copy": "复制",
    "view": "查看",
    "back": "返回",
    "refresh": "刷新",
    "refreshing": "刷新中...",
    "import": "导入",
    "all": "全部",
    "search": "查询",
    "enableAllForApp": "为 {{app}} 全部启用",
    "disableAllForApp": "为 {{app}} 全部停用",
    "bulkToggleFailed": "有 {{count}} 项更新失败",
    "reset": "重置",
    "actions": "操作",
    "deleting": "删除中...",
    "auto": "自动",
    "enabled": "已开启",
    "notSet": "未设置",
    "collapse": "收起"
  },
  "firstRunNotice": {
    "title": "欢迎使用 CC Switch",
    "bodyDefault": "CC Switch 可以帮你在 Claude Code / Codex / Gemini CLI 的多个供应商之间一键切换。如果你之前已经配置过这些工具，CC Switch 会自动把现有设置保存为名为 “default” 的供应商，保证你的配置不会丢失。",
    "bodyOfficial": "列表里还预置了 “官方（Official）” 供应商，随时点一下即可切回官方默认配置。切换前 CC Switch 会自动把当前配置备份回 default，可以放心来回切。CC Switch 就是这样工作的 😊",
    "confirm": "我知道了"
  },
  "apiKeyInput": {
    "placeholder": "请输入API Key",
    "show": "显示API Key",
    "hide": "隐藏API Key"
  },
  "jsonEditor": {
    "mustBeObject": "配置必须是JSON对象，不能是数组或其他类型",
    "invalidJson": "JSON格式错误"
  },
  "commonConfig": {
    "guideTitle": "什么是通用配置片段？",
    "guidePurpose": "用来在不同供应商之间共享插件、环境变量等非敏感配置。切换供应商时不会丢失这些设置。",
    "guideUsage": "用法：① 点击「从编辑内容提取」保存通用部分  ② 新建供应商时勾选「应用通用配置」",
    "guideReExtract": "如果您新安装了插件或 Hook，请重新提取一次通用配置，以便同步到其他供应商。",
    "guideReassurance": "放心：您的原始配置已保存在默认供应商中，不会丢失。",
    "emptyTitle": "还没有通用配置片段",
    "emptyHint": "点击下方「从编辑内容提取」按钮，从当前配置中提取可复用的部分"
  },
  "claudeConfig": {
    "configLabel": "Claude Code 配置 (JSON) *",
    "writeCommonConfig": "应用通用配置",
    "editCommonConfig": "编辑通用配置",
    "editCommonConfigTitle": "编辑通用配置片段",
    "commonConfigHint": "该片段会在勾选\"应用通用配置\"时合并到 settings.json 中",
    "fullSettingsHint": "完整的 Claude Code settings.json 配置内容",
    "extractFromCurrent": "从编辑内容提取",
    "extractNoCommonConfig": "当前编辑内容没有可提取的通用配置",
    "extractFailed": "提取失败: {{error}}",
    "saveFailed": "保存失败: {{error}}",
    "hideAttribution": "隐藏 AI 署名",
    "enableTeammates": "Teammates 模式",
    "enableToolSearch": "启用 Tool Search",
    "effortMax": "最大强度思考",
    "disableAutoUpgrade": "禁用自动升级",
    "disableArtifact": "禁用 Artifact 工具"
  },
  "header": {
    "viewOnGithub": "在 GitHub 上查看",
    "toggleDarkMode": "切换到暗色模式",
    "toggleLightMode": "切换到亮色模式",
    "addProvider": "添加供应商",
    "switchToChinese": "切换到中文",
    "switchToEnglish": "切换到英文",
    "enterEditMode": "进入编辑模式",
    "exitEditMode": "退出编辑模式",
    "windowMinimize": "最小化窗口",
    "windowMaximize": "最大化窗口",
    "windowRestore": "还原窗口",
    "windowClose": "关闭窗口"
  },
  "provider": {
    "connectivityCheck": "检测连通",
    "tabProvider": "供应商",
    "tabUniversal": "统一供应商",
    "noProviders": "还没有添加任何供应商",
    "noProvidersDescription": "如果你已有配置，请点击\"导入当前配置\"，所有数据将安全保存在 default 供应商中",
    "noProvidersDescriptionSnippet": "除 Key 和请求地址外的数据（如插件配置）会被保存到通用配置片段，用于在不同供应商之间共享",
    "importCurrent": "导入当前配置",
    "importFromClaude": "将 Claude Code 中已有的供应商导入",
    "importCurrentDescription": "将当前正在使用的配置导入为默认供应商",
    "currentlyUsing": "当前使用",
    "enable": "启用",
    "inUse": "使用中",
    "needsRouting": "需要路由",
    "noRoutingSupport": "不支持路由",
    "blockedByProxyHint": "代理接管模式下不可切换到官方供应商",
    "editProvider": "编辑供应商",
    "editProviderHint": "更新配置后将立即应用到当前供应商。",
    "deleteProvider": "删除供应商",
    "addNewProvider": "添加新供应商",
    "addFooterHint": "💡 选择预设后，请在下方填写 API Key 等字段",
    "addClaudeProvider": "添加 Claude Code 供应商",
    "addCodexProvider": "添加 Codex 供应商",
    "addGeminiProvider": "添加 Gemini 供应商",
    "addOpenCodeProvider": "添加 OpenCode 供应商",
    "addToConfig": "添加",
    "removeFromConfig": "移除",
    "setAsDefault": "设为默认",
    "isDefault": "当前默认",
    "inConfig": "已添加",
    "addProviderHint": "填写信息后即可在列表中快速切换供应商。",
    "editClaudeProvider": "编辑 Claude Code 供应商",
    "editCodexProvider": "编辑 Codex 供应商",
    "configError": "配置错误",
    "notConfigured": "未配置官网地址",
    "applyToClaudePlugin": "应用到 Claude 插件",
    "removeFromClaudePlugin": "从 Claude 插件移除",
    "dragToReorder": "拖拽以重新排序",
    "dragHandle": "拖拽排序",
    "searchPlaceholder": "按名称/备注/网址搜索供应商...",
    "searchAriaLabel": "搜索供应商",
    "searchScopeHint": "根据名称、备注和官网链接匹配结果。",
    "searchCloseHint": "按 Esc 关闭",
    "searchCloseAriaLabel": "关闭供应商搜索",
    "noSearchResults": "没有符合搜索条件的供应商。",
    "duplicate": "复制",
    "sortUpdateFailed": "排序更新失败",
    "configureUsage": "配置用量查询",
    "managedByHermes": "Hermes 托管",
    "managedByHermesHint": "该条目定义在 Hermes 的 providers: dict，请在 Hermes Web UI 中编辑或删除。",
    "openTerminal": "打开终端",
    "terminalOpened": "终端已打开",
    "terminalOpenFailed": "打开终端失败",
    "name": "供应商名称",
    "namePlaceholder": "例如：Claude 官方",
    "websiteUrl": "官网链接",
    "notes": "备注",
    "notesPlaceholder": "例如：公司专用账号",
    "configJson": "配置 JSON",
    "writeCommonConfig": "应用通用配置",
    "editCommonConfigButton": "编辑通用配置",
    "configJsonHint": "请填写完整的 Claude Code 配置",
    "editCommonConfigTitle": "编辑通用配置片段",
    "editCommonConfigHint": "通用配置片段将合并到所有启用它的供应商配置中",
    "addProvider": "添加供应商",
    "sortUpdated": "排序已更新",
    "usageSaved": "用量查询配置已保存",
    "usageSaveFailed": "用量查询配置保存失败",
    "geminiConfig": "Gemini 配置",
    "geminiConfigHint": "使用 .env 格式配置 Gemini",
    "form": {
      "gemini": {
        "model": "模型",
        "oauthTitle": "OAuth 认证模式",
        "oauthHint": "Google 官方使用 OAuth 个人认证，无需填写 API Key。首次使用时会自动打开浏览器进行登录。",
        "apiKeyPlaceholder": "请输入 Gemini API Key"
      }
    },
    "duplicateLiveIdsLoadFailed": "读取配置中的供应商标识失败，请先修复配置后再试"
  },
  "claudeCode": {
    "needsRouting": "需要路由",
    "noRoutingSupport": "不支持路由"
  },
  "codex": {
    "needsRouting": "需要路由",
    "noRoutingSupport": "不支持路由",
    "officialRouting": "官方账号路由",
    "nativeLogin": "Codex 登录",
    "followCodexLogin": "跟随 Codex 登录",
    "followCodexLoginDescription": "账号会随 Codex CLI 当前登录变化",
    "openAiAccount": "OpenAI 账号",
    "accountNotSelected": "尚未选择账号",
    "chooseAccount": "选择账号",
    "accountStatusUnavailable": "无法读取账号信息",
    "boundAccountUnavailable": "绑定的账号不可用",
    "accountLoading": "正在加载账号…"
  },
  "claudeDesktop": {
    "modelConfigTitle": "模型配置",
    "modelModeLabel": "接入方式",
    "modelModeDirect": "直连",
    "modelModeProxy": "模型映射",
    "officialNotice": "Claude Desktop 官方供应商使用应用内置的 1P 登录，无需配置 API Key 和接口地址。",
    "mode": "模型处理方式",
    "modeDirect": "直连",
    "modeProxy": "需要路由",
    "modelMappingToggle": "需要模型映射",
    "modelMappingOffHint": "仅当供应商直接接受 Claude Desktop 可识别的三档角色 ID（claude-sonnet-* / claude-opus-* / claude-haiku-*）时才适用直连；其他模型名（含 claude-3-5-sonnet-… 等旧式 ID）请选择模型映射。",
    "modelMappingOnHint": "Claude Desktop 只接受 claude-sonnet-* / claude-opus-* / claude-haiku-* 三档角色 ID。选择模型映射后，CC Switch 会把这三档映射到供应商的实际模型，并在使用期间保持本地路由开启。",
    "routeMapTitle": "模型映射",
    "routeMapHint": "为 Sonnet、Opus、Haiku 三档分别填写实际请求模型；菜单显示名可写 DeepSeek、Kimi 等品牌名。留空的档会自动沿用 Sonnet（或第一个已填档）的模型，确保子 agent 调用的 Haiku 始终可用。",
    "routeModelLabel": "模型角色",
    "routeRoleSonnet": "Sonnet",
    "routeRoleOpus": "Opus",
    "routeRoleFable": "Fable",
    "routeRoleHaiku": "Haiku",
    "labelOverrideLabel": "菜单显示名",
    "upstreamModelLabel": "实际请求模型",
    "supports1mLabel": "声明支持 1M",
    "supports1mShort": "1M",
    "directModelListTitle": "模型列表",
    "directModelListCollapsedHint": "原生 Claude 模型供应商通常不用填写，Claude Desktop 会自动读取 /v1/models。",
    "directModelListHint": "配置 Claude Desktop 可用的 Sonnet、Opus、Haiku 模型。留空时 Claude Desktop 会自动读取 /v1/models；勾选 1M 会声明支持 1M 上下文。",
    "directModelInvalid": "直连模型必须使用 Claude Desktop 可识别的 Sonnet / Opus / Haiku 模型名",
    "addModel": "添加模型",
    "addRoute": "添加模型",
    "routeInvalid": "请选择模型角色并填写实际请求模型",
    "routesRequired": "至少填写一个模型映射",
    "statusTitle": "Claude Desktop 配置需要检查",
    "statusUnsupported": "当前平台暂不支持 Claude Desktop 3P 配置写入。",
    "statusStaleRawModels": "Claude Desktop profile 中存在非 Sonnet / Opus / Haiku 角色模型名，新版 Claude Desktop 可能拒绝加载；重新切换当前供应商可修复。",
    "statusMissingRouteMappings": "当前供应商启用了模型映射，但没有有效路由；请编辑供应商并补全至少一个模型映射。",
    "statusGatewayTokenMissing": "当前本地路由 token 尚未生成；重新切换该供应商会写入新的本地 token。",
    "statusBaseUrlMismatch": "Claude Desktop profile 指向的地址与当前供应商不一致；当前为 {{actual}}，应为 {{expected}}。重新切换当前供应商可修复。",
    "route": {
      "tooltip": {
        "active": "Claude Desktop 本地路由已开启 - {{address}}:{{port}}",
        "inactive": "开启 Claude Desktop 本地路由，用于需要模型映射或格式转换的供应商。当前配置地址：{{address}}:{{port}}"
      },
      "stopBlockedByTakeover": "其它应用正在使用代理接管。请先在设置中关闭对应应用接管，再停止本地路由。"
    }
  },
  "notifications": {
    "providerAdded": "供应商已添加",
    "providerSaved": "供应商配置已保存",
    "providerDeleted": "供应商删除成功",
    "switchSuccess": "切换成功！",
    "codexRestartRequired": "切换成功，请重启客户端以生效",
    "grokBuildRestartRequired": "切换成功，请重启 Grok Build 以生效",
    "claudeDesktopRestartRequired": "切换成功，重启 Claude Desktop 后生效",
    "claudeDesktopProxyRestartRequired": "切换成功，请保持 CC Switch 运行，并重启 Claude Desktop 后生效",
    "addToConfigSuccess": "已添加到配置",
    "removeFromConfigSuccess": "已从配置移除",
    "removeFromConfigFailed": "无法移除供应商",
    "switchFailedTitle": "切换失败",
    "switchFailed": "切换失败：{{error}}",
    "autoImported": "已从现有配置创建默认供应商",
    "addFailed": "添加供应商失败：{{error}}",
    "saveFailed": "保存失败：{{error}}",
    "saveFailedGeneric": "保存失败，请重试",
    "appliedToClaudePlugin": "已应用到 Claude 插件",
    "removedFromClaudePlugin": "已从 Claude 插件移除",
    "syncClaudePluginFailed": "同步 Claude 插件失败",
    "skipClaudeOnboardingFailed": "跳过 Claude Code 初次安装确认失败",
    "clearClaudeOnboardingSkipFailed": "恢复 Claude Code 初次安装确认失败",
    "updateSuccess": "供应商更新成功",
    "updateFailed": "更新供应商失败：{{error}}",
    "deleteSuccess": "供应商已删除",
    "deleteFailed": "删除供应商失败：{{error}}",
    "settingsSaved": "设置已保存",
    "settingsSaveFailed": "保存设置失败：{{error}}",
    "proxyRequiredForSwitch": "此供应商{{reason}}，需要路由服务才能正常使用，请先启动路由",
    "proxyReasonCopilot": "使用 GitHub Copilot 作为 Claude 供应商",
    "proxyReasonOpenAIChat": "使用 OpenAI Chat 接口格式",
    "proxyReasonOpenAIResponses": "使用 OpenAI Responses 接口格式",
    "proxyReasonAnthropicMessages": "使用 Anthropic Messages 接口格式",
    "proxyReasonFullUrl": "开启了完整 URL 连接模式",
    "proxyReasonManagedOAuth": "使用托管 OAuth 登录（令牌由本地路由注入）",
    "proxyReasonRoutingRequired": "需要本地路由处理请求",
    "openAIFormatHint": "此供应商使用 OpenAI 兼容格式，需要开启路由服务才能正常使用",
    "copilotProxyHint": "GitHub Copilot 作为 Claude 供应商时始终需要本地路由；路由会根据当前模型自动选择 Chat Completions 或 Responses。",
    "openLinkFailed": "链接打开失败",
    "openclawModelsRegistered": "模型已注册到 /model 列表",
    "openclawDefaultModelSet": "已设为默认模型",
    "openclawDefaultModelSetFailed": "设置默认模型失败",
    "openclawNoModels": "该供应商没有配置模型",
    "openclawModelNotFound": "所选模型已不存在，请刷新后重试",
    "backfillWarning": "切换成功，但旧供应商配置回填失败，您手动修改的配置可能未保存",
    "codexAuthCleanupFailed": "切换成功，但未能删除 auth.json，官方登录凭据仍留在磁盘上；如需彻底移除请手动删除 Codex 配置目录中的 auth.json",
    "windowControlFailed": "窗口控制失败：{{error}}",
    "officialBlockedByProxy": "本地路由模式下不能切换到官方供应商，使用路由访问官方 API 可能导致账号被封禁",
    "proxyOfficialWarning": "当前供应商 {{name}} 是官方供应商，建议切换到第三方供应商后再使用本地路由",
    "proxyReasonClaudeDesktop": "使用 Claude Desktop 本地路由模式"
  },
  "confirm": {
    "deleteProvider": "删除供应商",
    "deleteProviderMessage": "确定要删除供应商 \"{{name}}\" 吗？此操作无法撤销。",
    "removeProvider": "移除供应商",
    "removeProviderMessage": "确定要从配置中移除供应商 \"{{name}}\" 吗？\n\n移除后该供应商将不再生效，但配置数据会保留在 CC Switch 中，您可以随时重新添加。",
    "piDefaultProviderWarning": "Pi 的全局默认项当前指向此供应商。继续后，Pi 会尝试其他可用模型；你可以在 Pi 中使用 /model 重新选择，或使用 /login 登录其他供应商。",
    "proxy": {
      "title": "启用本地路由服务",
      "message": "本地路由是一项高级功能，启用前请确保您已了解其工作原理。\n\n建议先查阅相关文档或咨询您的供应商，以获取正确的配置方式。",
      "confirm": "我已了解，继续启用"
    },
    "failover": {
      "title": "启用故障转移功能",
      "message": "故障转移是一项高级功能，启用前请确保您已了解其工作原理。\n\n建议先在故障转移队列中配置好供应商优先级。",
      "confirm": "我已了解，继续启用"
    },
    "unifyCodexHistory": {
      "title": "统一 Codex 会话历史",
      "message": "开启后，官方订阅与第三方将共用同一个会话历史列表。注意：跨供应商继续旧会话时，可能因对方后端无法解密 encrypted_content 推理内容而失败。\n\n可选择同时把现有官方会话历史迁入共享列表（迁移前自动备份到 ~/.cc-switch/backups，关闭开关时可选择恢复）。",
      "migrateExisting": "同时迁入现有官方会话历史",
      "confirm": "我已了解，继续开启"
    },
    "unifyCodexHistoryOff": {
      "title": "关闭统一会话历史",
      "message": "关闭后，官方订阅与第三方将恢复各自独立的会话历史列表。开启期间产生的会话因无法区分来源，将留在第三方历史中，官方订阅将看不到它们。",
      "restoreBackup": "把开启时迁入的官方会话还原回官方历史（按备份精确还原）",
      "confirm": "关闭"
    },
    "usage": {
      "title": "配置用量查询",
      "message": "用量查询需要配置专用的查询脚本或 API 参数，请确保您已从供应商处获取相关信息。\n\n如不确定如何配置，请先查阅供应商文档。",
      "confirm": "我已了解，继续配置"
    },
    "autoSync": {
      "title": "开启自动同步",
      "message": "开启自动同步后，每次数据库变更都会自动上传到 WebDAV 服务器。\n\n这可能会产生较高的网络流量消耗，请确保您的网络环境和 WebDAV 服务支持频繁的数据传输。",
      "confirm": "我已了解，继续开启"
    },
    "commonConfig": {
      "title": "关于通用配置",
      "message": "「通用配置片段」可以在不同供应商之间共享插件、环境变量等配置，避免切换供应商时丢失这些设置。\n\n使用方法：\n① 编辑供应商时点击「编辑通用配置」→「从编辑内容提取」\n② 新建供应商时勾选「应用通用配置」（默认已勾选）\n\n如果您新安装了插件或 Hook，请重新提取一次通用配置。",
      "confirm": "我知道了"
    }
  },
  "settings": {
    "title": "设置",
    "general": "通用",
    "tabGeneral": "通用",
    "tabAuth": "认证",
    "tabAdvanced": "高级",
    "tabProxy": "路由",
    "authCenter": {
      "title": "OAuth 认证中心",
      "description": "在 Claude Code 中使用您的其他订阅，请注意合规风险。",
      "beta": "Beta",
      "copilotDescription": "管理 GitHub Copilot 账号",
      "codexOauthDescription": "管理 ChatGPT 账号",
      "xaiOauthDescription": "管理 xAI / Grok 账号"
    },
    "advanced": {
      "configDir": {
        "title": "配置文件目录",
        "description": "管理 Claude、Codex 和 Gemini 的配置存储路径"
      },
      "proxy": {
        "title": "本地路由",
        "description": "控制路由服务开关、查看状态与端口信息",
        "enableFeature": "在主页面显示本地路由开关",
        "enableFeatureDescription": "开启后，主页面顶部将显示路由和故障转移开关",
        "enableFailoverToggle": "在主页面显示故障转移开关",
        "enableFailoverToggleDescription": "开启后，主页面顶部将独立显示故障转移开关",
        "running": "运行中",
        "stopped": "已停止"
      },
      "connectivityCheck": {
        "title": "连通检测配置",
        "description": "配置供应商地址探测的超时、重试和较慢阈值"
      },
      "failover": {
        "title": "自动故障转移",
        "description": "配置故障转移队列和熔断策略"
      },
      "pricing": {
        "title": "成本定价",
        "description": "管理各模型 Token 计费规则"
      },
      "globalProxy": {
        "title": "全局出站代理",
        "description": "配置 CC Switch 访问外部 API 时使用的代理"
      },
      "data": {
        "title": "数据管理",
        "description": "导入和导出本地配置数据"
      },
      "backup": {
        "title": "备份与恢复",
        "description": "管理自动备份，查看和恢复数据库快照"
      },
      "cloudSync": {
        "title": "云同步",
        "description": "通过 WebDAV 在多设备间同步数据"
      },
      "rectifier": {
        "title": "整流器",
        "description": "自动修复 API 请求中的兼容性问题",
        "enabled": "启用整流器",
        "enabledDescription": "总开关，关闭后所有整流功能将被禁用",
        "requestGroup": "请求整流",
        "responseGroup": "响应整流",
        "thinkingSignature": "Thinking 签名整流",
        "thinkingSignatureDescription": "当 Anthropic 类型供应商返回 thinking 签名不兼容或非法请求等错误时，自动移除不兼容的 thinking 相关块并对同一供应商重试一次",
        "thinkingBudget": "Thinking Budget 整流",
        "thinkingBudgetDescription": "当 Anthropic 类型供应商返回 budget_tokens 约束错误（如至少 1024）时，自动将 thinking 规范为 enabled 并将 budget 设为 32000，同时在需要时将 max_tokens 设为 64000，然后重试一次",
        "mediaFallback": "不支持图片降级",
        "mediaFallbackDescription": "当供应商不支持图片输入时（已声明纯文本能力，或上游返回不支持图片的错误），自动将图片块替换为 [Unsupported Image] 标记，使对话不中断",
        "mediaHeuristic": "纯文本模型预判",
        "mediaHeuristicDescription": "发送前根据内置的已确认纯文本模型注册表剥离图片。关闭仅停用代理的注册表预判；已声明纯文本模型的处理和上游报错兜底仍保留，且不会改变 Codex 模型目录的能力声明"
      },
      "optimizer": {
        "title": "Bedrock 请求优化器",
        "description": "在请求发送前自动优化 Thinking 和 Cache 配置（仅 Bedrock 供应商生效）",
        "enabled": "启用优化器",
        "thinkingOptimizer": "Thinking 优化",
        "thinkingOptimizerDescription": "自动为 Opus/Sonnet 启用 Adaptive Thinking，为旧模型注入 Extended Thinking",
        "cacheInjection": "Cache 注入",
        "cacheInjectionDescription": "自动在请求关键位置注入标准 5 分钟 Cache 断点，减少重复 token 计费"
      },
      "logConfig": {
        "title": "应用诊断日志",
        "description": "控制应用诊断日志的输出级别",
        "enabled": "启用应用诊断日志",
        "enabledDescription": "控制 cc-switch.log；不影响请求用量记录和 crash.log",
        "level": "日志级别",
        "levelDescription": "设置输出的最低日志级别",
        "levels": {
          "error": "错误",
          "warn": "警告",
          "info": "信息",
          "debug": "调试",
          "trace": "跟踪"
        },
        "levelHint": "日志级别说明：",
        "levelDesc": {
          "error": "仅严重错误",
          "warn": "错误 + 警告信息",
          "info": "一般操作信息（默认）",
          "debug": "详细信息，包含 SSE 流和请求/响应详情",
          "trace": "全部日志，最详细"
        }
      }
    },
    "language": "界面语言",
    "languageHint": "切换后立即预览界面语言，保存后永久生效。",
    "claudeDesktopDisplay": "Claude Desktop 显示设置",
    "claudeDesktopDisplayHint": "接管左下角显示名与归属开关（deploymentDisplayName 等三键）。关闭时不写入；显示名留空则整项都不接管，副标题留空则只不写该项——两种情况都保持 Claude Desktop 面板的现有值。",
    "claudeDesktopDisplayEnable": "管理显示设置",
    "claudeDesktopDisplayName": "显示名",
    "claudeDesktopDisplaySubtitle": "副标题",
    "claudeDesktopDisplayAttribution": "用户归属（endUserAttribution）",
    "theme": "外观主题",
    "themeHint": "选择应用的外观主题，立即生效。",
    "themeLight": "浅色",
    "themeDark": "深色",
    "themeSystem": "跟随系统",
    "importExport": "SQL 导入导出",
    "importExportHint": "导入/导出数据库 SQL 备份（仅支持导入由 CC Switch 导出的备份），便于备份或迁移。",
    "exportConfig": "导出 SQL 备份",
    "selectConfigFile": "选择 SQL 文件",
    "noFileSelected": "尚未选择配置文件。",
    "import": "导入",
    "importing": "导入中...",
    "importSuccess": "导入成功！",
    "importFailed": "导入失败",
    "syncLiveFailed": "已导入，但同步到当前供应商失败，请手动重新选择一次供应商。",
    "importPartialSuccess": "配置已导入，但同步到当前供应商失败。",
    "importPartialHint": "请手动重新选择一次供应商以刷新对应配置。",
    "configExported": "配置已导出到：",
    "exportFailed": "导出失败",
    "selectFileFailed": "请选择有效的 SQL 备份文件",
    "configCorrupted": "SQL 文件可能已损坏或格式不正确",
    "backupId": "备份ID",
    "backupManager": {
      "title": "数据库备份",
      "description": "自动备份的数据库快照，可用于恢复到之前的状态",
      "empty": "暂无备份",
      "restore": "恢复",
      "restoring": "恢复中...",
      "confirmTitle": "确认恢复备份",
      "confirmMessage": "恢复到此备份将覆盖当前数据库。恢复前会自动创建安全备份。",
      "restoreSuccess": "恢复成功！安全备份已创建",
      "restoreFailed": "恢复失败",
      "safetyBackupId": "安全备份ID",
      "intervalLabel": "自动备份间隔",
      "retainLabel": "备份保留数量",
      "intervalDisabled": "禁用",
      "intervalHours": "{{hours}} 小时",
      "intervalDays": "{{days}} 天",
      "rename": "重命名",
      "renameSuccess": "备份重命名成功",
      "renameFailed": "重命名失败",
      "namePlaceholder": "输入新名称",
      "createBackup": "立即备份",
      "creating": "备份中...",
      "createSuccess": "备份创建成功",
      "createFailed": "备份创建失败",
      "delete": "删除",
      "deleting": "删除中...",
      "deleteSuccess": "备份已删除",
      "deleteFailed": "删除失败",
      "deleteConfirmTitle": "确认删除备份",
      "deleteConfirmMessage": "此备份将被永久删除，此操作无法撤消。"
    },
    "webdavSync": {
      "title": "WebDAV 云同步",
      "description": "通过 WebDAV 在多设备间同步数据库和技能配置。",
      "baseUrl": "WebDAV 服务器地址",
      "baseUrlPlaceholder": "https://dav.jianguoyun.com/dav/",
      "username": "WebDAV 账户",
      "usernamePlaceholder": "邮箱账号",
      "password": "WebDAV 密码",
      "passwordPlaceholder": "应用密码（坚果云请使用「第三方应用密码」）",
      "remoteRoot": "远程根目录",
      "profile": "同步配置名",
      "autoSync": "自动同步",
      "autoSyncHint": "开启后每次数据库变更都会自动上传到 WebDAV。",
      "test": "测试连接",
      "testing": "测试中...",
      "testSuccess": "连接成功",
      "testFailed": "连接失败：{{error}}",
      "save": "保存配置",
      "saving": "保存中...",
      "saveFailed": "保存配置失败：{{error}}",
      "upload": "上传到云端",
      "uploading": "上传中...",
      "uploadSuccess": "已上传到 WebDAV",
      "uploadFailed": "上传失败：{{error}}",
      "autoSyncFailedToast": "自动同步失败：{{error}}",
      "download": "从云端下载",
      "downloading": "下载中...",
      "downloadSuccess": "已从 WebDAV 下载并恢复",
      "downloadFailed": "下载失败：{{error}}",
      "lastSync": "上次同步：{{time}}",
      "autoSyncLastErrorTitle": "上次自动同步失败",
      "autoSyncLastErrorHint": "请检查网络或 WebDAV 配置，系统会在后续变更时继续自动重试。",
      "missingUrl": "请填写 WebDAV 服务器地址",
      "presets": {
        "label": "服务商",
        "jianguoyun": "坚果云",
        "jianguoyunHint": "请在坚果云「安全选项」中生成「第三方应用密码」，不要使用登录密码。",
        "nextcloud": "Nextcloud",
        "nextcloudHint": "请将 your-server 替换为你的 Nextcloud 服务器地址，USERNAME 替换为你的用户名。",
        "synology": "群晖 NAS",
        "synologyHint": "请先在群晖「套件中心」安装并启用 WebDAV Server 套件。",
        "custom": "自定义"
      },
      "remoteRootDefault": "默认: cc-switch-sync",
      "profileDefault": "默认: default",
      "saveAndTestSuccess": "配置已保存，连接正常",
      "saveAndTestFailed": "配置已保存，但连接测试失败：{{error}}",
      "noRemoteData": "云端没有找到同步数据",
      "incompatibleVersion": "远端数据版本不兼容（协议 v{{protocolVersion}}，数据库 {{dbCompatVersion}}），当前支持协议 v2 / db-v6",
      "unsaved": "未保存",
      "saved": "已保存",
      "unsavedChanges": "请先保存配置",
      "saveBeforeSync": "请先保存配置，再使用上传/下载。",
      "fetchingRemote": "获取远端信息...",
      "fetchRemoteFailed": "获取远端信息失败，请检查配置和网络后重试。",
      "confirmDownload": {
        "title": "从云端恢复",
        "deviceName": "上传设备",
        "createdAt": "上传时间",
        "path": "远端路径",
        "dbCompat": "数据库兼容层",
        "artifacts": "包含内容",
        "legacyNotice": "检测到旧版云端路径。恢复完成后，下次上传将写入新路径 v2/db-v6。",
        "warning": "恢复将覆盖本地所有数据和技能配置",
        "confirm": "确认恢复"
      },
      "confirmUpload": {
        "title": "上传到云端",
        "content": "将同步以下内容到 WebDAV 服务器：",
        "dbItem": "数据库（所有 Provider 配置和数据）",
        "skillsItem": "技能包（所有自定义技能）",
        "targetPath": "目标路径",
        "existingData": "云端已有数据",
        "deviceName": "上传设备",
        "createdAt": "上传时间",
        "path": "远端路径",
        "dbCompat": "数据库兼容层",
        "warning": "将覆盖云端已有的同步数据",
        "legacyNotice": "检测到旧版云端路径数据。本次上传将写入新路径 v2/db-v6，不会覆盖旧路径。",
        "confirm": "确认上传"
      }
    },
    "syncType": {
      "label": "同步方式",
      "webdav": "WebDAV",
      "s3": "S3 兼容存储"
    },
    "s3Sync": {
      "presets": {
        "label": "服务商",
        "awsS3": "AWS S3",
        "awsS3Hint": "使用 IAM Access Key，需要 s3:PutObject/GetObject/HeadObject 权限。Region 示例：us-east-1, ap-northeast-1",
        "minio": "MinIO",
        "minioHint": "需要自定义 Endpoint，如 http://minio.local:9000。Region 可设为 us-east-1",
        "r2": "Cloudflare R2",
        "r2Hint": "Endpoint: https://<account_id>.r2.cloudflarestorage.com，Region 设为 auto",
        "oss": "阿里云 OSS",
        "ossHint": "Endpoint: https://oss-<region>.aliyuncs.com，Region 示例：cn-hangzhou, cn-shanghai",
        "cos": "腾讯云 COS",
        "cosHint": "Endpoint: https://cos.<region>.myqcloud.com，Region 示例：ap-guangzhou, ap-beijing",
        "obs": "华为云 OBS",
        "obsHint": "Endpoint: https://obs.<region>.myhuaweicloud.com，Region 示例：cn-north-4, cn-east-3",
        "custom": "S3 兼容服务（自定义）",
        "customHint": "任意 S3 兼容服务，需要自定义 Endpoint"
      },
      "region": "区域 (Region)",
      "regionPlaceholder": "例如 us-east-1",
      "bucket": "存储桶 (Bucket)",
      "bucketPlaceholder": "例如 my-cc-switch-bucket",
      "accessKeyId": "Access Key ID",
      "accessKeyIdPlaceholder": "例如 AKIA...",
      "secretAccessKey": "Secret Access Key",
      "secretAccessKeyPlaceholder": "留空则保持现有密钥",
      "endpoint": "Endpoint（AWS 可留空）",
      "endpointHint": "多数 S3 兼容服务需要填写",
      "endpointPlaceholder": "例如 https://s3-compatible.example.com",
      "remoteRoot": "远程根目录",
      "remoteRootDefault": "默认: cc-switch-sync",
      "profile": "同步配置名",
      "profileDefault": "默认: default",
      "autoSync": "自动同步",
      "autoSyncHint": "开启后每次数据库变更都会自动上传到 S3。",
      "enabled": "启用 S3 同步",
      "enabledHint": "开启后可使用 S3 上传/下载和自动同步。",
      "mutualExclusionTitle": "切换同步方式",
      "mutualExclusionMessage": "启用 S3 同步将禁用当前的 WebDAV 同步，是否继续？",
      "mutualExclusionMessageReverse": "启用 WebDAV 同步将禁用当前的 S3 同步，是否继续？",
      "mutualExclusionFailed": "切换同步方式失败：{{error}}",
      "testConnection": "测试连接",
      "connectionOk": "S3 连接成功",
      "test": "测试连接",
      "testing": "测试中...",
      "testSuccess": "S3 连接成功",
      "testFailed": "S3 连接失败：{{error}}",
      "save": "保存配置",
      "saving": "保存中...",
      "saveFailed": "保存配置失败：{{error}}",
      "saveAndTestSuccess": "配置已保存，S3 连接正常",
      "saveAndTestFailed": "配置已保存，但 S3 连接测试失败：{{error}}",
      "upload": "上传到云端",
      "uploading": "上传中...",
      "uploadSuccess": "已上传到 S3",
      "uploadFailed": "S3 上传失败：{{error}}",
      "autoSyncFailedToast": "S3 自动同步失败：{{error}}",
      "download": "从云端下载",
      "downloading": "下载中...",
      "downloadSuccess": "已从 S3 下载并恢复",
      "downloadFailed": "S3 下载失败：{{error}}",
      "lastSync": "上次同步：{{time}}",
      "autoSyncLastErrorTitle": "上次 S3 自动同步失败",
      "autoSyncLastErrorHint": "请检查网络或 S3 配置，系统会在后续变更时继续自动重试。",
      "missingBucket": "请填写 S3 存储桶",
      "noRemoteData": "S3 存储桶中没有找到同步数据",
      "incompatibleVersion": "远端数据版本不兼容（版本 {{version}}），当前支持协议 v2 / db-v6",
      "unsaved": "未保存",
      "saved": "已保存",
      "unsavedChanges": "请先保存配置",
      "saveBeforeSync": "请先保存配置，再使用上传/下载。",
      "fetchingRemote": "获取远端信息...",
      "fetchRemoteFailed": "获取远端信息失败，请检查配置和网络后重试。",
      "notConfigured": "未配置 S3 同步",
      "disabled": "S3 同步未启用",
      "confirmDownload": {
        "title": "从 S3 恢复",
        "deviceName": "上传设备",
        "createdAt": "上传时间",
        "artifacts": "包含内容",
        "warning": "恢复将覆盖本地所有数据和技能配置",
        "confirm": "确认恢复"
      },
      "confirmUpload": {
        "title": "上传到 S3",
        "content": "将同步以下内容到 S3 存储桶：",
        "dbItem": "数据库（所有 Provider 配置和数据）",
        "skillsItem": "技能包（所有自定义技能）",
        "targetPath": "目标对象路径",
        "existingData": "云端已有数据",
        "deviceName": "上传设备",
        "createdAt": "上传时间",
        "warning": "将覆盖该 S3 路径下已有的同步数据",
        "confirm": "确认上传"
      }
    },
    "autoReload": "数据已刷新",
    "languageOptionChinese": "简体中文",
    "languageOptionTraditionalChinese": "繁體中文",
    "languageOptionEnglish": "English",
    "languageOptionJapanese": "日本語",
    "windowBehavior": "窗口行为",
    "windowBehaviorHint": "配置窗口最小化与 Claude 插件联动策略。",
    "launchOnStartup": "开机自启",
    "launchOnStartupDescription": "随系统启动自动运行 CC Switch",
    "silentStartup": "静默启动",
    "silentStartupDescription": "程序启动时不显示主窗口，仅在系统托盘运行",
    "autoLaunchFailed": "设置开机自启失败",
    "minimizeToTray": "关闭时最小化到托盘",
    "minimizeToTrayDescription": "勾选后点击关闭按钮会隐藏到系统托盘，取消则直接退出应用。",
    "useAppWindowControls": "启用应用级窗口按钮",
    "useAppWindowControlsDescription": "开启后使用应用自建的最小化、最大化/还原、关闭按钮；关闭后沿用系统窗口模式。",
    "enableClaudePluginIntegration": "应用到 Claude Code 插件",
    "enableClaudePluginIntegrationDescription": "开启后 VS Code Claude Code 插件的供应商将随本软件切换",
    "skipClaudeOnboarding": "跳过 Claude Code 初次安装确认",
    "skipClaudeOnboardingDescription": "开启后跳过 Claude Code 初次安装确认",
    "codexAuth": "Codex 应用增强",
    "preserveCodexOfficialAuthOnSwitch": "非接管切换时保留官方登录",
    "preserveCodexOfficialAuthOnSwitchDescription": "控制未开启路由接管时切换第三方供应商是否保留 Codex 官方登录；路由接管期间始终保留",
    "unifyCodexSessionHistory": "统一 Codex 会话历史",
    "unifyCodexSessionHistoryDescription": "开启后，官方订阅将以共享的 custom 供应商标识运行，官方与第三方会话出现在同一历史列表中，并可选择把现有官方会话一并迁入（迁移前自动备份）。关闭开关时可按备份恢复迁入的会话。注意：跨供应商继续旧会话时，对方后端可能无法解密会话中的 encrypted_content 推理内容，导致继续失败",
    "unifyCodexHistoryRestoreCompleted": "已按备份还原官方会话历史（{{files}} 个会话文件、{{rows}} 条索引记录）",
    "unifyCodexHistoryRestoreFailed": "还原官方会话历史失败，请重试",
    "unifyCodexHistoryRestoreNothing": "当前 Codex 目录没有可恢复的迁移备份",
    "unifyCodexHistoryRestoreSkippedToggleOn": "统一会话历史开关已重新开启，已跳过还原",
    "appVisibility": {
      "title": "主页面显示",
      "description": "选择在主页面显示的应用",
      "claudeDesc": "Anthropic Claude Code CLI",
      "codexDesc": "OpenAI Codex CLI",
      "geminiDesc": "Google Gemini CLI",
      "opencodeDesc": "OpenCode CLI",
      "showProfileSwitcher": "显示项目切换",
      "showProfileSwitcherDescription": "在主页面顶部显示项目切换入口"
    },
    "skillStorage": {
      "title": "Skills 存储位置",
      "description": "选择 CC Switch 存放 Skills 主副本的目录",
      "ccSwitch": "CC Switch",
      "unified": "~/.agents/skills",
      "ccSwitchHint": "技能存储在 ~/.cc-switch/skills/，由 CC Switch 统一管理并同步到各应用。",
      "unifiedHint": "技能存储在 ~/.agents/skills/，遵循 Agent Skills 开放标准。兼容的工具（Claude Code、Codex、Gemini CLI 等）可直接发现此目录中的技能。",
      "confirmTitle": "迁移技能存储",
      "confirmMessage": "将移动 {{count}} 个技能到新位置，是否继续？",
      "migrationSuccess": "已成功迁移 {{count}} 个技能",
      "migrationPartial": "迁移了 {{migrated}} 个技能，{{errors}} 个失败，请查看日志"
    },
    "skillSync": {
      "title": "Skills 同步方式",
      "description": "选择 Skills 的文件同步策略",
      "symlink": "软连接",
      "copy": "文件复制",
      "symlinkHint": "软连接节省磁盘空间并支持实时同步。注意：Windows 可能需要管理员权限或开启开发者模式"
    },
    "terminal": {
      "title": "首选终端",
      "description": "选择点击终端按钮时使用的终端应用",
      "fallbackHint": "如果选择的终端不可用，将自动使用系统默认终端",
      "options": {
        "macos": {
          "terminal": "Terminal.app",
          "iterm2": "iTerm2",
          "alacritty": "Alacritty",
          "kitty": "Kitty",
          "ghostty": "Ghostty",
          "otty": "Otty",
          "wezterm": "WezTerm",
          "kaku": "Kaku",
          "warp": "Warp"
        },
        "windows": {
          "cmd": "命令提示符",
          "powershell": "PowerShell",
          "wt": "Windows Terminal"
        },
        "linux": {
          "gnomeTerminal": "GNOME Terminal",
          "konsole": "Konsole",
          "xfce4Terminal": "Xfce4 Terminal",
          "alacritty": "Alacritty",
          "kitty": "Kitty",
          "ghostty": "Ghostty"
        }
      }
    },
    "configDirectoryOverride": "配置目录覆盖（高级）",
    "configDirectoryDescription": "在 WSL 等环境使用 Claude Code 或 Codex 的时候，可手动指定为 WSL 里的配置目录，供应商数据与主环境保持一致。",
    "appConfigDir": "CC Switch 配置目录",
    "appConfigDirDescription": "自定义 CC Switch 的配置存储位置（指定到云同步文件夹即可云同步配置）",
    "browsePlaceholderApp": "例如：C:\\Users\\Administrator\\.cc-switch",
    "claudeConfigDir": "Claude Code 配置目录",
    "claudeConfigDirDescription": "覆盖 Claude 配置目录 (settings.json)。真正自定义目录会在目录内存放 Claude MCP 的 .claude.json；默认 ~/.claude 目录仍使用 Claude 默认的 ~/.claude.json。",
    "codexConfigDir": "Codex 配置目录",
    "codexConfigDirDescription": "覆盖 Codex 配置目录。",
    "geminiConfigDir": "Gemini 配置目录",
    "geminiConfigDirDescription": "覆盖 Gemini 配置目录 (.env)。",
    "grokConfigDir": "Grok Build 配置目录",
    "grokConfigDirDescription": "覆盖 Grok Build 配置目录 (config.toml)。",
    "opencodeConfigDir": "OpenCode 配置目录",
    "opencodeConfigDirDescription": "覆盖 OpenCode 配置目录 (opencode.json)。",
    "openclawConfigDir": "OpenClaw 配置目录",
    "openclawConfigDirDescription": "覆盖 OpenClaw 配置目录 (openclaw.json)。",
    "hermesConfigDir": "Hermes 配置目录",
    "hermesConfigDirDescription": "覆盖 Hermes 配置目录 (config.yaml)。",
    "piConfigDir": "Pi 配置目录",
    "piConfigDirDescription": "覆盖 Pi 配置目录（models.json、指令文件、提示词、Skills 与会话）。",
    "browsePlaceholderClaude": "例如：/home/<你的用户名>/.claude",
    "browsePlaceholderCodex": "例如：/home/<你的用户名>/.codex",
    "browsePlaceholderGemini": "例如：/home/<你的用户名>/.gemini",
    "browsePlaceholderGrok": "例如：/home/<你的用户名>/.grok",
    "browsePlaceholderOpencode": "例如：/home/<你的用户名>/.config/opencode",
    "browsePlaceholderOpenclaw": "例如：/home/<你的用户名>/.openclaw",
    "browsePlaceholderHermes": "例如：/home/<你的用户名>/.hermes",
    "browsePlaceholderPi": "例如：/home/<你的用户名>/.pi/agent",
    "browseDirectory": "浏览目录",
    "resetDefault": "恢复默认目录（需保存后生效）",
    "checkForUpdates": "检查更新",
    "updateTo": "更新到 v{{version}}",
    "updating": "更新中...",
    "checking": "检查中...",
    "upToDate": "已是最新",
    "aboutHint": "查看版本信息与更新状态。",
    "portableMode": "当前为便携版，更新需手动下载。",
    "updateAvailable": "检测到新版本：{{version}}",
    "updateBadge": "有更新可用",
    "updateFailed": "更新安装失败，已尝试打开下载页面。",
    "checkUpdateFailed": "检查更新失败，请稍后重试。",
    "viewUpstream": "查看上游动态",
    "upstreamPrMerged": "上游修复已合并（PR #5417）——下次同步时可丢弃补丁 A。",
    "upstreamSyncNeeded": "本地构建无法自动升级。请按 UPSTREAM-SYNC.md 同步上游并重新构建。",
    "openReleaseNotesFailed": "打开更新日志失败",
    "releaseNotes": "更新日志",
    "viewReleaseNotes": "查看该版本更新日志",
    "viewCurrentReleaseNotes": "查看当前版本更新日志",
    "officialWebsite": "官方网站",
    "github": "GitHub",
    "starPrompt": "如果 CC Switch 帮到了你，请在 GitHub 点个 Star，这对我们意义重大",
    "manualInstallCommands": "手动安装命令",
    "oneClickInstallHint": "安装或升级 Claude Code / Codex / Gemini CLI / OpenCode / OpenClaw / Hermes / Pi",
    "localEnvCheck": "本地环境检查",
    "updateAllTools": "全部升级（{{count}}）",
    "currentVersion": "当前版本",
    "latestVersion": "最新版本",
    "updateAvailableShort": "可升级",
    "toolInstall": "安装",
    "toolUpdate": "升级",
    "toolReady": "已就绪",
    "toolActionDone": "{{count}} 个工具{{action}}完成",
    "toolActionPartial": "{{succeeded}} 个{{action}}成功，{{failed}} 个失败",
    "toolActionFailed": "安装/升级命令执行失败",
    "toolNotRunnable": "已安装但无法运行（未探测到版本）",
    "toolActionVersionUnchangedTitle": "版本没有变化",
    "toolActionVersionUnchanged": "仍是 {{version}}（最新：{{latest}}）。上游升级器可能报告成功但没有实际更新。",
    "toolActionInstalledNotRunnable": "已安装，但当前环境无法运行，请检查",
    "installedNotRunnable": "已安装·无法运行",
    "toolCheckEnv": "请检查运行环境",
    "toolDiagnose": "诊断安装冲突",
    "toolDiagnosing": "诊断中…",
    "toolConflictTitle": "检测到多处安装",
    "toolConflictHint": "命令行实际使用标「默认」的那处；升级可能写到了别处。",
    "toolConflictDefault": "默认",
    "toolConflictNotRunnable": "无法运行",
    "toolDiagnoseNoConflict": "未发现安装冲突",
    "toolDiagnoseFailed": "诊断失败",
    "toolUpgradeConfirmTitle": "确认升级位置",
    "toolUpgradeConfirmHint": "检测到多处安装。本次升级不会全部更新，具体作用的位置以下方各项为准。",
    "toolUpgradeWillRun": "将执行：",
    "toolUpgradeConfirmBtn": "确认升级",
    "toolUpgradeUnanchoredHint": "无法确定命令行实际使用哪处，将执行默认升级命令（可能装到 PATH 上第一个 npm）。",
    "envBadge": {
      "wsl": "WSL",
      "windows": "Win",
      "macos": "macOS",
      "linux": "Linux"
    },
    "wslShell": "Shell",
    "wslShellFlag": "标志",
    "installCommandsCopied": "安装命令已复制",
    "installCommandsCopyFailed": "复制失败，请手动复制。",
    "importFailedError": "导入配置失败：{{message}}",
    "exportFailedError": "导出配置失败:",
    "restartRequired": "需要重启应用",
    "restartRequiredMessage": "修改 CC Switch 配置目录后需要重启应用才能生效，是否立即重启？",
    "restartNow": "立即重启",
    "restartLater": "稍后重启",
    "restartFailed": "应用重启失败，请手动关闭后重新打开。",
    "devModeRestartHint": "开发模式下不支持自动重启，请手动重新启动应用。",
    "saving": "正在保存...",
    "globalProxy": {
      "label": "全局代理",
      "hint": "代理所有请求（API、Skills 下载等）。开启本地路由时，应用的请求也会经过此代理。留空表示直连。",
      "username": "用户名（可选）",
      "password": "密码（可选）",
      "test": "测试连接",
      "scan": "扫描本地代理",
      "clear": "清除",
      "scanFailed": "扫描失败：{{error}}",
      "saved": "代理设置已保存",
      "saveFailed": "保存失败：{{error}}",
      "testSuccess": "连接成功！延迟 {{latency}}ms",
      "testFailed": "连接失败：{{error}}",
      "pricingDefaultsTitle": "计费默认配置",
      "pricingDefaultsDescription": "设置各应用的默认倍率与计费模式来源。",
      "pricingAppLabel": "应用",
      "defaultCostMultiplierLabel": "默认倍率",
      "defaultCostMultiplierHint": "用于成本计算的倍率，支持小数。",
      "pricingModelSourceLabel": "计费模式",
      "pricingModelSourceRequest": "请求模型",
      "pricingModelSourceResponse": "返回模型",
      "pricingSave": "保存计费配置",
      "pricingSaved": "计费配置已保存",
      "pricingSaveFailed": "保存计费配置失败：{{error}}",
      "pricingLoadFailed": "加载计费配置失败：{{error}}",
      "defaultCostMultiplierRequired": "默认倍率不能为空",
      "defaultCostMultiplierInvalid": "默认倍率格式不正确"
    },
    "saveFailedGeneric": "保存失败，请重试"
  },
  "apps": {
    "claude": "Claude",
    "claudeCode": "Claude Code",
    "claudeDesktop": "Claude Desktop",
    "claude-desktop": "Claude Desktop",
    "codex": "Codex",
    "gemini": "Gemini",
    "grokbuild": "Grok Build",
    "opencode": "OpenCode",
    "openclaw": "OpenClaw",
    "hermes": "Hermes",
    "pi": "Pi",
    "mcode": "MiniMax Code"
  },
  "pi": {
    "empty": {
      "title": "还没有添加 API Key 供应商",
      "description": "点击右上角 +，从预设或自定义配置添加供应商。"
    },
    "provider": {
      "enabled": "已在 Pi 中启用",
      "enableFailed": "无法在 Pi 中启用此供应商",
      "removed": "已从 Pi 移除",
      "writeConflict": "Pi 配置正在被其他进程修改，请稍后再试。"
    },
    "form": {
      "providerKey": "供应商标识",
      "providerKeyRequired": "供应商标识不能为空",
      "selectPresetRequired": "请先选择一个预设或自定义配置",
      "fixJsonFirst": "请先修复下方配置 JSON，再编辑结构化字段。",
      "nameRequired": "显示名称不能为空",
      "credential": "API Key",
      "credentialRequired": "请填写此预设的 API Key",
      "absoluteHttpUrlRequired": "{{label}} 必须是绝对 HTTP 或 HTTPS 地址",
      "positiveNumberRequired": "{{label}} 必须是大于 0 的数字",
      "models": "模型配置",
      "noModels": "暂无模型配置",
      "addModel": "添加模型",
      "removeModel": "移除模型",
      "modelId": "模型 ID",
      "modelIdRequired": "第 {{index}} 个模型缺少 ID",
      "modelName": "显示名称",
      "modelNameRequired": "第 {{index}} 个模型缺少显示名称",
      "modelNamePlaceholder": "显示名称",
      "toggleModelDetails": "展开或收起模型详情",
      "reasoning": "支持扩展思考",
      "imageInput": "支持图片输入",
      "thinkingLevelsLabel": "思考档位",
      "customizeThinkingLevels": "自定义",
      "thinkingLevelDefault": "Pi 默认",
      "thinkingLevelUnsupported": "不可用",
      "thinkingLevelValue": "{{level}}的上游值",
      "editThinkingLevel": "编辑{{level}}档位",
      "thinkingLevelFollowDefault": "跟随 Pi 默认",
      "thinkingLevelMapTo": "映射为",
      "thinkingLevelMarkUnavailable": "此档位不可用",
      "thinkingLevelMapInvalid": "思考档位只能使用 Pi 原生档位键，值必须是字符串或 null。",
      "thinkingLevels": {
        "off": "关闭",
        "minimal": "Minimal",
        "low": "Low",
        "medium": "Medium",
        "high": "High",
        "xhigh": "XHigh",
        "max": "Max"
      },
      "contextWindow": "上下文长度",
      "maxTokens": "最大输出 Token 数",
      "compatibility": "接口兼容性",
      "compatibilityHint": "调整兼容端点或本地服务的请求行为。",
      "addCompatibilityOption": "添加",
      "noCompatibilityOptions": "暂无兼容性选项",
      "optionKey": "选项",
      "optionValue": "值",
      "removeCompatibilityOption": "移除兼容性选项",
      "effectiveApiRequired": "模型 {{id}} 必须直接配置或继承一个 API",
      "effectiveBaseUrlRequired": "模型 {{id}} 必须直接配置或继承一个基础地址",
      "duplicateModel": "模型 ID {{id}} 重复",
      "modelRequired": "请至少添加一个模型",
      "providerKeyDuplicate": "该供应商标识已存在"
    },
    "current": {
      "readFailed": "无法读取 Pi 供应商配置",
      "stateUnavailableHint": "CC Switch 读取到 Pi 供应商配置前，供应商变更已暂时禁用。"
    },
    "prompts": {
      "globalTab": "全局提示",
      "systemTab": "全局系统提示",
      "templatesTab": "提示词模板",
      "agentsLibrary": "AGENTS.md 提示库",
      "agentsLibraryDescription": "选择一个提示词写入 Pi 的全局 AGENTS.md。",
      "writtenToAgents": "已写入 AGENTS.md",
      "externalAgents": "外部 AGENTS.md",
      "noGlobalPrompt": "未配置全局 AGENTS.md",
      "noGlobalPrompts": "暂无全局提示",
      "noGlobalPromptsDescription": "点击右上角添加提示词；需要时再选择一个写入全局 AGENTS.md。",
      "noPromptDescription": "暂无描述",
      "usePrompt": "使用",
      "stopUsing": "停用",
      "usePromptSuccess": "已写入全局 AGENTS.md",
      "stopUsingSuccess": "已移除全局 AGENTS.md",
      "stopBeforeDelete": "请先停用再删除",
      "systemFilesDescription": "通常优先使用追加；仅在需要完整控制基础指令时使用替换。",
      "systemAppend": "系统提示追加",
      "systemAppendDescription": "在 Pi 内置基础提示之后追加内容，适合大多数全局定制。",
      "systemOverride": "系统提示替换",
      "systemOverrideDescription": "用自定义内容替换 Pi 内置基础提示；上下文与 AGENTS.md 等资源仍由 Pi 继续加入。",
      "systemOverrideWarning": "SYSTEM.md 会替换 Pi 内置基础提示。除非你需要完整控制基础指令，否则优先使用 APPEND_SYSTEM.md。",
      "recommended": "推荐",
      "configured": "已配置",
      "configuredEmpty": "已配置但为空",
      "notConfigured": "未配置",
      "unavailable": "读取失败",
      "markdownContent": "Markdown 内容",
      "instructionPlaceholder": "供 Pi 使用的 Markdown 内容",
      "blankInstruction": "请输入非空白内容；如需停止使用，请删除该全局文件。",
      "saveAndConfigure": "保存并配置",
      "removeGlobalFile": "删除全局文件",
      "activateOverrideTitle": "配置 {{filename}}？",
      "activateOverrideMessage": "创建 {{filename}} 会替换 Pi 内置基础提示。上下文、AGENTS.md 和 Skills 等仍由 Pi 按自身规则加入。",
      "removeFileTitle": "删除 {{filename}}？",
      "removeFileMessage": "这会删除 Pi 全局配置目录中的 {{filename}}。",
      "fileSaved": "{{filename}} 已保存",
      "fileRemoved": "{{filename}} 已删除",
      "saveFailed": "保存 Pi 指令文件失败",
      "deleteFailed": "删除 Pi 指令文件失败",
      "reloadNotice": "已打开的 Pi 不会自动热更新；修改后请在空闲时运行 /reload。新启动的 Pi 会自动读取。",
      "templatesDescription": "模板保存后可在 Pi 中通过 /命令名 调用，无需启用。",
      "newTemplate": "新建提示词模板",
      "editTemplate": "编辑 /{{slug}}",
      "templateCommand": "斜杠命令",
      "templateSlug": "例如 review",
      "templateSlugInvalid": "请输入不含空格或文件名保留字符的单个命令标识。",
      "templateSlugExists": "该斜杠命令已存在。",
      "templateDescription": "备注",
      "templateDescriptionPlaceholder": "可选的描述信息",
      "templateContent": "模板 Markdown 内容",
      "templateContentPlaceholder": "输入 Pi 将展开的 Markdown；可保留 YAML frontmatter。",
      "templateSyntax": "Pi 模板语法",
      "templateSyntaxDescription": "可选 frontmatter 支持 description 和 argument-hint；正文支持 $1、$2、$@ 或 $ARGUMENTS、${@:N} 与 ${@:N:L} 参数替换。",
      "createTemplate": "创建模板",
      "templateCreated": "Pi 提示词模板已创建",
      "templateSaved": "/{{slug}} 已保存",
      "templateDeleted": "/{{slug}} 已删除",
      "templateLoadFailed": "读取 Pi 提示词模板失败",
      "templateSaveFailed": "保存 Pi 提示词模板失败",
      "templateDeleteFailed": "删除 Pi 提示词模板失败",
      "searchTemplates": "搜索提示词模板名称、描述或内容…",
      "noTemplates": "暂无提示词模板",
      "noTemplatesDescription": "点击右上角新建模板，之后即可在 Pi 中通过斜杠命令调用。",
      "noTemplateResults": "没有匹配的模板",
      "deleteTemplateTitle": "删除 /{{slug}}？",
      "deleteTemplateMessage": "此操作会永久删除 prompts/{{slug}}.md。"
    }
  },
  "appSwitcher": {
    "more": "更多应用"
  },
  "grokBuild": {
    "apiBackend": "API Backend",
    "contextWindow": "上下文窗口",
    "contextWindowInvalid": "上下文窗口必须是正整数",
    "profile": "客户端模型档位",
    "rawConfig": "config.toml",
    "invalidToml": "config.toml 格式错误：{{error}}",
    "defaultModelPlaceholder": "例如: grok-4.5",
    "defaultModelHint": "Grok Build 默认请求的模型，随时可改，无需等待预设更新。",
    "advancedSectionHint": "包含上游格式、思考能力与自定义 User-Agent。使用 Chat Completions / Anthropic Messages 协议的供应商需开启路由接管才能使用。",
    "reasoningEffortHint": "上游支持 low/high/max 等思考深度控制时启用。启用后会自动启用思考模式，并把请求中的 reasoning effort 转成上游 Chat 参数。",
    "maxOutputTokensHint": "默认上限 8192 容易在长回答或深度思考时被截断（stop_reason=max_tokens）。此处设置会作为 Anthropic 的 max_tokens 覆盖请求值。请勿超过该模型/网关的真实输出上限，否则可能 400。留空使用默认 8192。"
  },
  "sessionManager": {
    "title": "会话管理",
    "subtitle": "管理 Claude Code、Codex、Gemini CLI、Grok Build、OpenCode、OpenClaw、Hermes 与 Pi 会话记录",
    "searchPlaceholder": "搜索会话内容、目录或 ID",
    "searchSessions": "搜索会话",
    "providerFilterAll": "全部",
    "providerFilterTooltip": "供应商筛选",
    "sessionList": "会话列表",
    "viewModeTooltip": "查看方式",
    "viewModeFlat": "列表",
    "viewModeGrouped": "分类",
    "unknownDirectory": "未知目录",
    "toggleProviderGroup": "展开或折叠 {{provider}} 供应商分组",
    "toggleDirectoryGroup": "展开或折叠 {{directory}} 目录分组",
    "collapseAllGroups": "全部收起",
    "selectProviderGroupForBatch": "选择 {{provider}} 供应商分组内会话",
    "selectDirectoryGroupForBatch": "选择 {{directory}} 目录分组内会话",
    "manageBatchTooltip": "进入批量管理",
    "exitBatchModeTooltip": "退出批量管理",
    "batchModeHint": "勾选要删除的会话",
    "selectForBatch": "选择会话",
    "selectedCount": "已选 {{count}} 项",
    "selectAllFiltered": "全选当前",
    "clearFilteredSelection": "取消全选",
    "clearSelection": "清空已选",
    "deleteSelected": "批量删除",
    "batchDeleting": "删除中...",
    "loadingSessions": "加载会话中...",
    "noSessions": "未发现会话",
    "piRelativeSessionDir": "Pi 的 sessionDir 相对于启动 Pi 时的目录，全局浏览器无法安全枚举。请改用绝对 sessionDir，之后即可在此浏览全部 Pi 会话：",
    "piDiscoveryUnavailable": "无法检查 Pi 会话：{{error}}",
    "selectSession": "请选择会话查看详情",
    "noSummary": "暂无摘要",
    "lastActive": "最近活跃",
    "projectDir": "项目目录",
    "sourcePath": "原始文件",
    "copyResumeCommand": "复制恢复命令",
    "resumeCommandCopied": "恢复命令已复制",
    "openInTerminal": "在终端恢复",
    "terminalTargetTerminal": "Terminal",
    "terminalTargetKitty": "kitty",
    "terminalTargetCopy": "仅复制",
    "terminalLaunched": "终端已启动",
    "openFailed": "终端启动失败",
    "resumeFallbackCopied": "已复制恢复命令，可手动粘贴到终端",
    "copyProjectDir": "复制目录",
    "projectDirCopied": "目录已复制",
    "copySourcePath": "复制原始文件",
    "sourcePathCopied": "原始文件已复制",
    "delete": "删除会话",
    "deleting": "删除中...",
    "deleteTooltip": "永久删除此本地会话记录",
    "deleteConfirmTitle": "删除会话",
    "deleteConfirmMessage": "将永久删除本地会话“{{title}}”\nSession ID: {{sessionId}}\n\n此操作不可恢复。",
    "deleteConfirmAction": "删除会话",
    "sessionDeleted": "会话已删除",
    "deleteFailed": "删除会话失败: {{error}}",
    "batchDeleteConfirmTitle": "批量删除会话",
    "batchDeleteConfirmMessage": "将永久删除已选中的 {{count}} 个本地会话记录。\n\n此操作不可恢复。",
    "batchDeleteConfirmAction": "删除所选会话",
    "batchDeleteSuccess": "已删除 {{count}} 个会话",
    "batchDeleteFailed": "{{failed}} 个会话删除失败",
    "batchDeleteRequestFailed": "批量删除失败，请稍后重试",
    "loadingMessages": "加载会话内容中...",
    "emptySession": "该会话暂无可展示内容",
    "clickToCopyPath": "点击复制路径",
    "tocTitle": "对话目录",
    "justNow": "刚刚",
    "minutesAgo": "{{count}} 分钟前",
    "hoursAgo": "{{count}} 小时前",
    "daysAgo": "{{count}} 天前",
    "roleUser": "用户",
    "roleSystem": "系统",
    "roleTool": "工具",
    "resume": "恢复会话",
    "resumeTooltip": "在终端中恢复此会话",
    "noResumeCommand": "此会话无法恢复",
    "copyCommand": "复制命令",
    "copyMessage": "复制消息",
    "messageCopied": "已复制消息内容",
    "conversationHistory": "对话记录",
    "expandContent": "展开完整内容",
    "collapseContent": "收起"
  },
  "console": {
    "providerSwitchReceived": "收到供应商切换事件:",
    "setupListenerFailed": "设置供应商切换监听器失败:",
    "updateProviderFailed": "更新供应商失败:",
    "autoImportFailed": "自动导入默认配置失败:",
    "openLinkFailed": "打开链接失败:",
    "getVersionFailed": "获取版本信息失败:",
    "loadSettingsFailed": "加载设置失败:",
    "getConfigPathFailed": "获取配置路径失败:",
    "getConfigDirFailed": "获取配置目录失败:",
    "detectPortableFailed": "检测便携模式失败:",
    "saveSettingsFailed": "保存设置失败:",
    "updateFailed": "更新失败:",
    "checkUpdateFailed": "检查更新失败:",
    "openConfigFolderFailed": "打开配置文件夹失败:",
    "selectConfigDirFailed": "选择配置目录失败:",
    "getDefaultConfigDirFailed": "获取默认配置目录失败:",
    "openReleaseNotesFailed": "打开更新日志失败:"
  },
  "providerForm": {
    "supplierName": "供应商名称",
    "supplierNameRequired": "供应商名称 *",
    "supplierNamePlaceholder": "例如：Anthropic 官方",
    "websiteUrl": "官网地址",
    "websiteUrlPlaceholder": "https://example.com（可选）",
    "apiEndpoint": "请求地址",
    "apiEndpointPlaceholder": "https://your-api-endpoint.com",
    "codexApiEndpointPlaceholder": "https://your-api-endpoint.com/v1",
    "manageAndTest": "管理与测速",
    "configContent": "配置内容",
    "officialNoApiKey": "官方登录无需填写 API Key，直接保存即可",
    "codexOfficialNoApiKey": "官方无需填写 API Key，直接保存即可",
    "codexApiKeyAutoFill": "只需要填这里，下方 auth.json 会自动填充",
    "apiKeyAutoFill": "只需要填这里，下方配置会自动填充",
    "cnOfficialApiKeyHint": "💡 只需填写 API Key，请求地址已预设",
    "aggregatorApiKeyHint": "💡 只需填写 API Key，请求地址已预设",
    "thirdPartyApiKeyHint": "💡 只需填写 API Key，请求地址已预设",
    "customApiKeyHint": "💡 自定义配置需手动填写所有必要字段",
    "omoHint": "💡 OMO 配置管理 Agent 模型分配，兼容 oh-my-openagent.jsonc / oh-my-opencode.jsonc",
    "officialHint": "💡 官方供应商使用浏览器登录，无需配置 API Key",
    "providerKeyStatusLoading": "正在加载供应商标识状态，请稍后再试",
    "getApiKey": "获取 API Key",
    "partnerPromotion": {
      "kimi": "Kimi 新用户首次成功充值，即可获赠充值金额 10% 的 API 额度，最高赠送 ¥1000。",
      "a6api": "A6API 是一家 Token 聚合站，内置实时价格排行自动筛选全网最低价，丝滑稳定不卡顿，简易操作省去比价繁琐，注册获得体验金！",
      "sudocode": "SudoCode 让 Claude Code 与 Claude Desktop 接入 Claude Opus 5，Codex 接入 GPT-5.6，一个 Key 统一使用。CC Switch 用户注册并加入 QQ 群 726213516，联系群主领取 ¥10 试用额度。",
      "code0": "code0.ai 是面向开发者的 AI 编程服务平台，支持 Claude Code、Codex、Gemini。CC Switch 用户专属福利：通过官网联系客服即可领取测试额度！",
      "packycode": "PackyCode 是 CC Switch 的官方合作伙伴，使用此链接注册并在充值时填写 \"cc-switch\" 优惠码，可以享受9折优惠",
      "apikeyfun": "APIKEY.FUN 为 CC Switch 的用户提供了特别优惠，通过专属链接注册，可享受最高充值永久 95 折优惠。",
      "apinebula": "APINEBULA 为 CC Switch 用户提供特别优惠：使用专属链接注册并在充值时填写 \"ccswitch\" 优惠码，可享九折优惠。",
      "patewayai": "PatewayAI 为 CC Switch 的用户提供了特别福利，通过此链接注册可以获得3美元额度。",
      "claudeapi": "ClaudeAPI 为 CC Switch 的用户提供了特别福利，通过此链接注册可以领取测试额度。",
      "claudecn": "ClaudeCN 是一家实体企业运营的企业级AI中转平台，支持企业采购流程，可对公打款、签约，服务合规有保障。",
      "runapi": "RunAPI 为 CC Switch 的用户提供了特别福利，通过此链接注册，首次充值即可享受 9 折优惠。",
      "opencode_go": "OpenCode Go 提供多款编程模型的订阅服务，可通过此链接查看套餐详情并订阅。",
      "dmxapi": "Claude Code 专属模型 3.4 折优惠进行中！",
      "cubence": "Cubence 是 CC Switch 的官方合作伙伴，使用此链接注册并在充值时填写 \"CCSWITCH\" 优惠码，每次充值均可享受9折优惠",
      "aigocode": "AIGoCode 是 CC Switch 的官方合作伙伴，使用此链接注册首次充值时可以获得10%额度奖励！",
      "rightcode": "RightCode 是 CC Switch 的官方合作伙伴，使用此链接注册每次充值均可赠送5%额外额度！",
      "aicodemirror": "AICodeMirror 是 CC Switch 的官方合作伙伴，使用此链接注册可享受8折优惠！",
      "aicoding": "AI Coding 为 CC Switch 的用户提供了特殊优惠，首次充值可以享受 9 折优惠！",
      "crazyrouter": "CrazyRouter 为 CC Switch 的用户提供了特殊优惠，首次充值赠予 30% 额外额度！",
      "sssaicode": "SSAI Code 为 CC Switch 的用户提供了特殊优惠，每次充值赠予额外 $10 额度！",
      "siliconflow": "硅基流动是 CC Switch 的官方合作伙伴",
      "ucloud": "优云智算为CC Switch 的用户提供了特殊优惠，通过此链接注册，可以获得五元平台体验金！",
      "micu": "Micu 是 CC Switch 的官方合作伙伴",
      "etok": "官网加入ETok社群，订阅套餐。",
      "shengsuanyun": "胜算云为 CC Switch 的用户提供了特别福利，使用此链接注册的新用户可获 10 元模力及首充 10% 赠送！",
      "doubaoseed": "豆包大模型为 CC Switch 的用户提供了专属福利：通过此链接注册即可获取豆包全系列文本模型 50万tokens推理额度以及Seedance2.0的500万tokens免费额度",
      "volcengine_agentplan": "火山方舟 Agent Plan 为 CC Switch 的用户提供了专属福利：通过此链接订阅方舟 Agent Plan，新客户首两个月享 2.5 折优惠，再用专属邀请码 6J6FV5N2 领取奖励叠加 9.5 折，低至 9.4 元/月！",
      "volcengine_codingplan": "火山方舟 Coding Plan 为 CC Switch 的用户提供了专属福利：通过此链接订阅方舟 Coding Plan，新客户首两个月享 2.5 折优惠，再用专属邀请码 6J6FV5N2 领取奖励叠加 9.5 折，低至 9.4 元/月！",
      "byteplus": "通过此链接注册即可获取每个模型50万tokens的免费推理额度。",
      "ccsub": "CCSub 是稳定、实惠的 AI API 中转平台，Claude Code 官方订阅的超强平替，一个 Key 覆盖全部模型，价格约为官方 1/3。",
      "subrouter": "SubRouter 是中转站聚合平台，一个 Key 可接入多个模型与供应商。",
      "qiniu": "七牛云是多协议 AI 中转平台，一个 Key 即可调用原生 Claude、GPT、Gemini 模型，兼容 Anthropic、OpenAI、Gemini 多种接口。",
      "fenno": "Fenno.ai 是稳定高效的 API 中转服务商，可接入多种主流模型。CC Switch 用户专属福利：通过此链接订阅 1.99 刀 /50 刀额度的 Trial 计划，有效期 7 天！",
      "zetaapi": "ZetaAPI 主打模型不掺水、不降智，价格低至官方价 35 折。CC Switch 用户专属福利：通过此链接注册，首次充值使用优惠码 CC-SWITCH 即可享受九折优惠！",
      "teamorouter": "TeamoRouter 是企业级 Agentic LLM 网关，价格最高可达 90% 折扣。为 CC Switch 的用户提供了特别福利：新用户通过此链接注册，首次充值享 10% 折扣！",
      "ppio": "PPIO 是国内领先的独立 Agentic Cloud 服务商，一个 API Key 调用全部旗舰开源模型。通过此链接注册并完成实名认证，即可获得 ¥10 代金券。",
      "xycai": "XycAi 企业级 Token 工厂：200+ 全球模型一键接入，SLA 自动赔付，异常缓存 100% 退还！",
      "9527code": "9527 CODE 是企业级满血 AI 中转平台，为 Claude Code、Codex 等主流模型提供高速稳定的中转服务。持续运营一年，服务稳定性达 99.9%，提供 7×24 小时人工技术支持。新人福利联系客服赠送体验额度，拉新返现无上限！",
      "soleapi": "SoleAPI 是面向开发者与企业的 AI 模型网关，一个 API Key 直达 Claude、GPT、Gemini 等 30+ 主流模型，原生兼容 OpenAI 与 Anthropic 协议，智能选路毫秒级故障切换，可用性 99.99%，7×24 技术支持。通过专属链接注册即送体验额度，邀请好友充值持续返现！",
      "fluxa": "FluxA 与百度智能云联合推出 AgenticPlan，让 AI Agent 能自主购买、管理和使用模型、API 与工具。内含百度千帆 TokenPlan，低至 6 折，可使用 DeepSeek V4、GLM 5.2、Kimi 等旗舰模型，并获赠 FluxA AgentMarket API 调用额度，解锁搜索、数据抓取、社交媒体、金融、加密、生图、视频等 1000+ 付费 API。"
    },
    "presets": {
      "ucloud": "优云智算",
      "ucloudCoding": "优云智算Coding Plan",
      "shengsuanyun": "胜算云",
      "qiniu": "七牛云",
      "doubaoseed": "火山 豆包AI",
      "openrouter": "OpenRouter",
      "deepseek": "DeepSeek",
      "together": "Together AI"
    },
    "parameterConfig": "参数配置 - {{name}} *",
    "mainModel": "主模型 (可选)",
    "mainModelPlaceholder": "例如: GLM-4.6",
    "fastModel": "快速模型 (可选)",
    "fastModelPlaceholder": "例如: GLM-4.5-Air",
    "modelHint": "💡 留空将使用供应商的默认模型",
    "apiHint": "💡 填写兼容 Claude API 的服务端点地址，不要以斜杠结尾",
    "apiHintOAI": "💡 填写兼容 OpenAI Chat Completions 的服务端点地址，不要以斜杠结尾",
    "apiHintGeminiNative": "💡 建议填写 Gemini Native 的 base URL，例如 https://generativelanguage.googleapis.com 或 https://generativelanguage.googleapis.com/v1beta；代理会自动补全 models/*:generateContent",
    "codexApiHint": "💡 填写兼容 OpenAI Response 格式的服务端点地址",
    "fillSupplierName": "请填写供应商名称",
    "fillConfigContent": "请填写配置内容",
    "fillParameter": "请填写 {{label}}",
    "fillTemplateValue": "请填写 {{label}}",
    "endpointRequired": "非官方供应商请填写 API 端点",
    "apiKeyRequired": "非官方供应商请填写 API Key",
    "softValidation": {
      "title": "配置存在以下问题",
      "hint": "仍要保存吗？保存后切换此供应商时可能失败，可以之后再补全。",
      "saveAnyway": "仍要保存"
    },
    "configJsonError": "配置JSON格式错误，请检查语法",
    "authJsonRequired": "auth.json 必须是 JSON 对象",
    "authJsonError": "auth.json 格式错误，请检查JSON语法",
    "fillAuthJson": "请填写 auth.json 配置",
    "fillApiKey": "请填写 OPENAI_API_KEY",
    "visitWebsite": "访问 {{url}}",
    "anthropicModel": "主模型",
    "anthropicSmallFastModel": "快速模型",
    "apiFormat": "上游格式",
    "apiFormatHint": "供应商原生为 Anthropic Messages API 就选 Anthropic Messages（直连，不转换格式）；使用 Chat Completions 协议就选 Chat；使用 Responses API 就选 Responses；使用 Gemini generateContent 协议就选 Gemini Native。Chat、Responses 与 Gemini Native 均需开启路由接管才能转换为 Anthropic Messages。",
    "customUserAgent": "自定义 User-Agent",
    "customUserAgentHint": "仅在开启本地路由/代理接管后生效，会替换转发到供应商 API 请求中的 User-Agent。",
    "customUserAgentInvalid": "User-Agent 不能包含控制字符（如换行符），否则将被忽略。",
    "customUserAgentPresets": "预设",
    "localProxyRequestOverrides": "本地代理请求覆盖",
    "localProxyRequestOverridesHint": "仅在本地路由/代理接管后生效，应用于协议转换后的上游请求。",
    "localProxyRequestOverridesInvalid": "本地代理请求覆盖格式错误：{{error}}",
    "localProxyHeaderOverrides": "Header 覆盖",
    "localProxyHeaderOverridesInvalidDetail": "Header 覆盖格式错误：{{error}}",
    "localProxyBodyOverrides": "Body 覆盖",
    "localProxyBodyOverridesInvalidDetail": "Body 覆盖格式错误：{{error}}",
    "fullUrlLabel": "完整 URL",
    "fullUrlEnabled": "完整 URL 模式",
    "fullUrlDisabled": "标记为完整 URL",
    "fullUrlHint": "💡 请填写完整请求 URL，并且必须开启路由后使用；路由将直接使用此 URL，不拼接路径",
    "fullUrlHintGeminiNative": "💡 Gemini Native 下，完整 URL 模式同时兼容两类地址：1. 官方/标准 Gemini URL，代理会按模型和流式参数自动归一化；2. 自定义 relay 的完整 URL，代理会尽量原样使用，只补查询参数，不再强行追加 models 路径",
    "apiFormatAnthropic": "Anthropic Messages (原生)",
    "apiFormatOpenAIChat": "OpenAI Chat Completions (需开启路由)",
    "apiFormatOpenAIResponses": "OpenAI Responses API (需开启路由)",
    "apiFormatGeminiNative": "Gemini Native generateContent (需开启路由)",
    "codexApiFormatResponses": "OpenAI Responses API (原生)",
    "codexApiFormatOpenAIChat": "OpenAI Chat Completions (需开启路由)",
    "codexApiFormatHint": "选择供应商真实支持的 Codex API 格式；配置仍保持 Responses 以兼容新版 Codex，Chat Completions 会通过本地路由自动转换。",
    "authField": "认证字段",
    "authFieldAuthToken": "ANTHROPIC_AUTH_TOKEN（默认）",
    "authFieldApiKey": "ANTHROPIC_API_KEY",
    "authFieldHint": "选择写入配置的认证环境变量名",
    "apiHintResponses": "💡 填写兼容 OpenAI Responses API 的服务端点地址，不要以斜杠结尾",
    "anthropicDefaultHaikuModel": "Haiku 默认模型",
    "anthropicDefaultSonnetModel": "Sonnet 默认模型",
    "anthropicDefaultOpusModel": "Opus 默认模型",
    "modelPlaceholder": "",
    "smallModelPlaceholder": "",
    "haikuModelPlaceholder": "",
    "modelHelper": "可选：指定默认使用的 Claude 模型，留空则使用系统默认。",
    "modelMappingLabel": "模型映射",
    "modelMappingHint": "显示名称只影响 /model 菜单；1M 只是给 Claude Code 的上下文能力声明。",
    "modelRoleLabel": "模型角色",
    "modelRoleSonnet": "Sonnet",
    "modelRoleOpus": "Opus",
    "modelRoleFable": "Fable",
    "modelRoleHaiku": "Haiku",
    "modelRoleSubagent": "Subagent",
    "modelDisplayNameLabel": "显示名称",
    "modelDisplayNamePlaceholder": "例如 DeepSeek V4 Pro",
    "modelNoDisplayName": "不显示在 /model 菜单",
    "requestModelLabel": "实际请求模型",
    "modelOneMHeader": "声明支持 1M",
    "modelOneMLabel": "1M",
    "fallbackModelLabel": "默认兜底模型",
    "fallbackModelHint": "用于未明确落到 Sonnet、Opus、Fable、Haiku 角色的请求。使用第三方/中转端点时建议填写：否则这些请求（含 Haiku 后台子任务）会以原始 Claude 模型名透传给上游，可能因上游无此模型而报错。官方端点可留空。",
    "quickSetModels": "一键设置",
    "quickSetSuccess": "已将模型名称应用到所有角色",
    "advancedOptionsToggle": "高级选项",
    "advancedOptionsHint": "包含 API 格式、认证字段、模型映射等配置。大多数场景下保持默认即可。",
    "categoryOfficial": "官方",
    "categoryCnOfficial": "开源官方",
    "categoryAggregation": "聚合服务",
    "categoryThirdParty": "第三方",
    "fetchModels": "获取模型列表",
    "fetchingModels": "正在获取...",
    "searchModelPlaceholder": "搜索模型...",
    "searchModelEmpty": "没有匹配的模型",
    "searchModelAriaLabel": "选择模型",
    "fetchModelsSuccess": "获取到 {{count}} 个模型",
    "fetchedModelsTitle": "可用模型（{{count}}）",
    "modelAlreadyAdded": "已添加",
    "addSelectedModels": "添加所选模型（{{count}}）",
    "fetchModelsFailed": "获取模型列表失败",
    "fetchModelsEmpty": "未找到可用模型",
    "fetchModelsNeedApiKey": "请先填写 API Key",
    "fetchModelsNeedEndpoint": "请先填写 API 端点",
    "fetchModelsNeedConfig": "请先填写 API 端点和 API Key",
    "fetchModelsAuthFailed": "API Key 无效或无权限",
    "fetchModelsNotSupported": "该供应商不支持获取模型列表",
    "fetchModelsEndpointNotFound": "未找到可用的模型列表端点，请检查 Base URL 或确认供应商是否开放该接口",
    "fetchModelsTimeout": "请求超时，请检查网络连接",
    "requiredFields": "请填写供应商名称、API 地址、API Key 和模型"
  },
  "copilot": {
    "authSection": "GitHub Copilot 认证",
    "authStatus": "认证状态",
    "authenticated": "已认证: {{username}}",
    "notAuthenticated": "未认证",
    "loginWithGitHub": "使用 GitHub 登录",
    "githubAccount": "GitHub 账号",
    "manageAccounts": "管理账号",
    "loginRequired": "请先登录 GitHub Copilot",
    "statusLoading": "正在加载账号状态...",
    "statusUnavailable": "状态不可用",
    "statusLoadFailed": "无法加载 GitHub Copilot 账号状态，请重试。",
    "waitingForAuth": "等待授权中...",
    "enterCode": "请在浏览器中输入验证码：",
    "logout": "注销",
    "authSuccess": "GitHub Copilot 认证成功",
    "authFailed": "认证失败: {{error}}",
    "authTimeout": "认证超时，请重试",
    "tokenExpired": "令牌已过期，请重新认证",
    "accountCount": "{{count}} 个账号",
    "selectAccount": "选择账号",
    "selectAccountPlaceholder": "选择一个 GitHub 账号",
    "useDefaultAccount": "使用默认账号",
    "loggedInAccounts": "已登录账号",
    "defaultAccount": "默认",
    "selected": "已选中",
    "removeAccount": "移除账号",
    "setAsDefault": "设为默认",
    "addAnotherAccount": "添加其他账号",
    "logoutAll": "注销所有账号",
    "retry": "重试",
    "copyCode": "复制代码",
    "migrationFailed": "旧认证数据迁移失败：{{error}}",
    "loadModelsFailed": "加载 Copilot 模型列表失败",
    "deploymentType": "GitHub 部署类型",
    "deploymentGitHubCom": "GitHub.com",
    "deploymentEnterprise": "GitHub Enterprise Server",
    "enterpriseDomainPlaceholder": "例如：company.ghe.com"
  },
  "codexOauth": {
    "authStatus": "认证状态",
    "notAuthenticated": "未认证",
    "loginWithChatGPT": "使用 ChatGPT 登录",
    "loginRequired": "请先登录 ChatGPT 账号",
    "statusLoading": "正在加载账号状态...",
    "statusUnavailable": "状态不可用",
    "statusLoadFailed": "无法加载 ChatGPT 账号状态，请重试。",
    "waitingForAuth": "等待授权中...",
    "enterCode": "请在浏览器中输入以下验证码：",
    "accountCount": "{{count}} 个账号",
    "selectAccount": "选择账号",
    "chatgptAccount": "ChatGPT 账号",
    "accountToUse": "使用的账号",
    "signInMethod": "登录方式",
    "manageAccounts": "管理账号",
    "selectAccountPlaceholder": "选择一个 ChatGPT 账号",
    "officialAccountPlaceholder": "请选择登录方式",
    "addOrManageAccounts": "添加或管理 ChatGPT 账号…",
    "explicitSelectionRequired": "请先选择登录方式",
    "useDefaultAccount": "使用默认账号",
    "noneOptionLabel": "跟随 Codex 登录",
    "reauthTitle": "部分账号需要重新登录",
    "reauthDescription": "为与浏览器登录行为保持一致，这些账号需要重新登录以补全所需的登录凭据（id_token）。重新登录后即可正常用于托管绑定。",
    "reauthBadge": "需要重新登录",
    "reauthLogin": "重新登录",
    "reauthSelectHint": "该账号需重新登录以启用托管绑定。",
    "reauthNow": "立即重新登录",
    "duplicateAccount": "该 ChatGPT 账号已添加，请直接使用现有账号。",
    "loggedInAccounts": "已登录账号",
    "defaultAccount": "默认",
    "selected": "已选中",
    "removeAccount": "移除账号",
    "setAsDefault": "设为默认",
    "addAnotherAccount": "添加其他账号",
    "logoutAll": "注销所有账号",
    "retry": "重试",
    "copyCode": "复制代码",
    "fastMode": "FAST 模式",
    "fastModeDescription": "发送 service_tier=\"priority\" 换取更低延迟。默认关闭——开启后会按更高速率消耗 ChatGPT 配额。"
  },
  "xaiOauth": {
    "authStatus": "xAI OAuth 认证",
    "accountCount": "{{count}} 个可用账号",
    "reauthRequired": "需要重新登录",
    "notAuthenticated": "未认证",
    "selectAccount": "选择账号",
    "selectAccountPlaceholder": "选择 xAI 账号",
    "useDefaultAccount": "使用默认账号",
    "accounts": "xAI 账号",
    "defaultAccount": "默认",
    "expired": "凭据已失效",
    "setAsDefault": "设为默认",
    "removeAccount": "移除账号",
    "addOrReauth": "添加账号或重新登录",
    "login": "使用 xAI 登录",
    "waitingForAuth": "等待 xAI 授权中…",
    "enterCode": "若浏览器未自动填入，请输入：",
    "retry": "重试",
    "logoutAll": "移除所有 xAI 账号",
    "loginRequired": "请先登录 xAI 账号"
  },
  "managedAuth": {
    "accountRemoved": "账号已移除",
    "selectedAccountNeedsReauth": "已绑定账号不存在或需要重新登录",
    "selectedAccountUnavailable": "已绑定账号不存在或需要重新登录，请重新选择账号"
  },
  "endpointTest": {
    "title": "请求地址管理",
    "endpoints": "个端点",
    "autoSelect": "自动选择",
    "testSpeed": "测速",
    "testing": "测速中",
    "addEndpointPlaceholder": "https://api.example.com",
    "done": "完成",
    "noEndpoints": "暂无端点",
    "failed": "失败",
    "enterValidUrl": "请输入有效的 URL",
    "invalidUrlFormat": "URL 格式不正确",
    "onlyHttps": "仅支持 HTTP/HTTPS",
    "urlExists": "该地址已存在",
    "saveFailed": "保存失败，请重试",
    "loadEndpointsFailed": "加载自定义端点失败:",
    "addEndpointFailed": "添加自定义端点失败:",
    "removeEndpointFailed": "删除自定义端点失败:",
    "removeFailed": "删除失败: {{error}}",
    "updateLastUsedFailed": "更新端点使用时间失败",
    "pleaseAddEndpoint": "请先添加端点",
    "testUnavailable": "测速功能不可用",
    "noResult": "未返回结果",
    "testFailed": "测速失败: {{error}}",
    "empty": "暂无端点"
  },
  "providerAdvanced": {
    "pricingConfig": "计费配置",
    "useCustomPricing": "使用单独配置",
    "pricingConfigDesc": "为此供应商配置单独的计费参数，不启用时使用全局默认配置。",
    "costMultiplier": "成本倍率",
    "costMultiplierPlaceholder": "留空使用全局默认（1）",
    "costMultiplierHint": "实际成本 = 基础成本 × 倍率，支持小数如 1.5",
    "pricingModelSourceLabel": "计费模式",
    "pricingModelSourceInherit": "继承全局默认",
    "pricingModelSourceRequest": "请求模型",
    "pricingModelSourceResponse": "返回模型",
    "pricingModelSourceHint": "选择按请求模型还是返回模型进行定价匹配"
  },
  "codexConfig": {
    "authJson": "auth.json (JSON) *",
    "authJsonPlaceholder": "{\n  \"OPENAI_API_KEY\": \"sk-your-api-key-here\"\n}",
    "authJsonHint": "Codex auth.json 配置内容",
    "authJsonStorageHint": "代理接管中显示的是存储的 auth 配置，不是实时 auth.json",
    "configToml": "config.toml (TOML)",
    "configTomlHint": "Codex config.toml 配置内容",
    "configTomlStorageHint": "代理接管中显示的是存储的 config 配置，不是实时 config.toml",
    "proxyTakeoverStorageNotice": "💡 当前应用处于代理接管状态。这里编辑的是存储的供应商配置，真实 live 配置已由代理临时接管",
    "writeCommonConfig": "应用通用配置",
    "editCommonConfig": "编辑通用配置",
    "editCommonConfigTitle": "编辑 Codex 通用配置片段",
    "commonConfigHint": "该片段会在勾选'应用通用配置'时追加到 config.toml 末尾",
    "enableRemoteCompaction": "启用远程压缩",
    "remoteCompactionHint": "开启后会将当前 model_providers 条目的 name 写为 OpenAI，使 Codex 尝试使用远程压缩。",
    "apiUrlLabel": "API 请求地址",
    "extractFromCurrent": "从编辑内容提取",
    "extractNoCommonConfig": "当前编辑内容没有可提取的通用配置",
    "extractFailed": "提取失败: {{error}}",
    "saveFailed": "保存失败: {{error}}",
    "modelNameHint": "指定使用的模型，将自动更新到 config.toml 中",
    "modelName": "模型名称",
    "upstreamFormatLabel": "上游格式",
    "upstreamFormatHint": "供应商原生为 Responses API 就选 Responses（直连，不转换格式）；使用 Chat Completions 协议就选 Chat；供应商只提供原生 Anthropic Messages 协议就选 Anthropic Messages。Chat 与 Anthropic Messages 均需开启路由接管才能转换为 Responses。",
    "upstreamFormatChat": "Chat Completions（需开启路由）",
    "upstreamFormatResponses": "Responses（原生）",
    "upstreamFormatAnthropic": "Anthropic Messages（需开启路由）",
    "anthropicAuthFieldLabel": "认证字段",
    "anthropicAuthFieldAuthToken": "ANTHROPIC_AUTH_TOKEN（Authorization）",
    "anthropicAuthFieldApiKey": "ANTHROPIC_API_KEY（x-api-key）",
    "anthropicAuthFieldHint": "选择网关接收 API Key 的请求头：ANTHROPIC_AUTH_TOKEN 发送 Authorization: Bearer；ANTHROPIC_API_KEY 发送 x-api-key。两者只发其一。",
    "impersonateClaudeCodeLabel": "模拟 Claude Code 客户端",
    "impersonateClaudeCodeHint": "网关或其上游限制只能通过 Claude Code 使用时开启：伪装 User-Agent、anthropic-beta、x-app 请求头，并在系统提示首行注入 Claude Code 身份。",
    "maxOutputTokensLabel": "最大输出 tokens",
    "maxOutputTokensPlaceholder": "留空则使用默认 8192",
    "maxOutputTokensHint": "Codex 不会把 model_max_output_tokens 写进请求体，默认上限 8192 容易在长回答或深度思考时被截断（stop_reason=max_tokens）。此处设置会作为 Anthropic 的 max_tokens 覆盖请求值。请勿超过该模型/网关的真实输出上限，否则可能 400。留空使用默认 8192。",
    "promptCacheRoutingLabel": "提示词缓存路由",
    "promptCacheRoutingAuto": "自动（推荐）",
    "promptCacheRoutingEnabled": "开启",
    "promptCacheRoutingDisabled": "关闭",
    "promptCacheRoutingHint": "自动模式仅对已确认兼容的上游发送 prompt_cache_key；开启可用于其他兼容网关，关闭可避免严格网关因未知字段返回 400。只使用客户端提供的稳定会话 ID。",
    "upstreamModelName": "上游模型名称",
    "upstreamModelNameHint": "Chat 格式下这里填写真实上游模型；路由会把 Codex 的 Responses 请求转换为 Chat Completions 并保持该模型。",
    "modelNamePlaceholder": "例如: gpt-5-codex",
    "contextWindow1M": "1M 上下文窗口",
    "contextWindow": "上下文窗口",
    "contextWindowPlaceholder": "例如: 128000",
    "autoCompactLimit": "压缩阈值",
    "autoCompactLimitPlaceholder": "例如: 90000",
    "autoCompactLimitHint": "上下文 token 数达到此阈值时自动压缩历史",
    "modelMetadataAdvanced": "模型元数据高级选项",
    "modelMetadataAdvancedHint": "用于未知模型的 Codex 元数据覆盖；清空字段会从 config.toml 删除对应配置。",
    "defaultModelLabel": "默认模型",
    "defaultModelPlaceholder": "例如: gpt-5.6-sol",
    "defaultModelHint": "Codex 默认请求的模型，随时可改，无需等待预设更新。留空且配置了模型映射时，默认使用映射第一行。",
    "defaultModelNotInCatalog": "该模型不在模型映射中，Codex 的 /model 菜单不会列出它（直接请求仍然有效）。",
    "addToModelMapping": "加入映射",
    "modelMappingTitle": "模型映射",
    "modelMappingHint": "生成 Codex model_catalog_json，让 /model 命令显示这些第三方模型名；表中条目按填写内容原样保存。修改后需要重启 Codex 才能刷新模型列表。",
    "addCatalogModel": "添加模型",
    "catalogDisplayName": "显示名称",
    "catalogDisplayNamePlaceholder": "例如: DeepSeek V4 Flash",
    "catalogModelId": "模型 ID",
    "catalogModelPlaceholder": "例如: deepseek-v4-flash",
    "catalogColumnDisplay": "菜单显示名",
    "catalogColumnModel": "实际请求模型",
    "catalogColumnContext": "上下文窗口",
    "catalogColumnReasoning": "思考等级",
    "reasoningLevelsNotSet": "未设置",
    "reasoningLevelsSearch": "搜索思考等级...",
    "reasoningLevelsEmpty": "无等级",
    "defaultReasoningLevelLabel": "默认等级",
    "defaultReasoningLevelPlaceholder": "自动",
    "reasoningModeToggle": "支持思考模式",
    "reasoningModeHint": "上游 Chat Completions 接口支持开启或关闭 thinking 时启用。Kimi、GLM、Qwen 等通常属于这一类。",
    "reasoningEffortToggle": "支持思考等级",
    "reasoningEffortHint": "上游支持 low/high/max 等思考深度控制时启用。启用后会自动启用思考模式，并把 Codex 的 reasoning.effort 转成上游 Chat 参数。",
    "reasoningGroupTitle": "思考能力",
    "reasoningSectionHint": "预设供应商已自动配置；自定义供应商会按名称/地址自动推断。仅当自动识别不准时才需手动覆盖。",
    "advancedSectionHint": "包含上游格式、模型映射、思考能力与自定义 User-Agent。使用 Chat Completions 协议的供应商需开启路由接管才能使用。",
    "noCommonConfigToApply": "通用配置片段为空或没有可写入的内容"
  },
  "geminiConfig": {
    "envFile": "环境变量 (.env)",
    "envFileHint": "使用 .env 格式配置 Gemini 环境变量",
    "configJson": "配置文件 (config.json)",
    "configJsonHint": "使用 JSON 格式配置 Gemini 扩展参数（可选）",
    "writeCommonConfig": "应用通用配置",
    "editCommonConfig": "编辑通用配置",
    "editCommonConfigTitle": "编辑 Gemini 通用配置片段",
    "commonConfigHint": "该片段会在勾选\"应用通用配置\"时写入 Gemini 的 .env（不允许包含 GOOGLE_GEMINI_BASE_URL、GEMINI_API_KEY）",
    "extractFromCurrent": "从编辑内容提取",
    "extractNoCommonConfig": "当前编辑内容没有可提取的通用配置",
    "extractFailed": "提取失败: {{error}}",
    "saveFailed": "保存失败: {{error}}",
    "extractedConfigInvalid": "提取的配置格式错误",
    "invalidJsonFormat": "通用配置片段格式错误（必须是有效的 JSON）",
    "commonConfigInvalidKeys": "通用配置片段不能包含 GOOGLE_GEMINI_BASE_URL 或 GEMINI_API_KEY（发现：{{keys}}）",
    "commonConfigInvalidValues": "通用配置片段的值必须是字符串",
    "noCommonConfigToApply": "通用配置片段为空或没有可写入的内容",
    "configMergeFailed": "配置合并失败: {{error}}",
    "configReplaceFailed": "配置替换失败: {{error}}"
  },
  "opencode": {
    "npmPackage": "接口格式",
    "selectPackage": "选择接口格式",
    "npmPackageHint": "选择 AI 服务的 API 接口格式",
    "baseUrl": "Base URL",
    "baseUrlHint": "自定义 API 端点地址",
    "models": "模型配置",
    "modelsHint": "配置可用的模型及其显示名称",
    "addModel": "添加模型",
    "modelId": "模型 ID",
    "modelName": "显示名称",
    "noModels": "暂无模型配置",
    "modelsRequired": "请至少添加一个模型配置",
    "toggleModelDetails": "展开或收起模型详情",
    "providerKey": "供应商标识",
    "providerKeyPlaceholder": "my-provider",
    "providerKeyHint": "配置文件中的唯一标识符，只能使用小写字母、数字和连字符",
    "providerKeyLockedHint": "该供应商已添加到应用配置中，供应商标识不可修改",
    "providerKeyRequired": "请填写供应商标识",
    "providerKeyDuplicate": "此标识已被使用，请更换",
    "providerKeyInvalid": "标识格式无效，只能使用小写字母、数字和连字符",
    "headers": "请求头",
    "headersHint": "随供应商请求发送的可选 HTTP 请求头，如 HTTP-Referer 或 X-Title。",
    "addHeader": "添加请求头",
    "headerName": "请求头",
    "headerValue": "值",
    "headerNamePlaceholder": "X-Title",
    "headerValuePlaceholder": "CC Switch",
    "removeHeader": "删除请求头",
    "noHeaders": "暂无自定义请求头",
    "extraOptions": "额外选项",
    "extraOptionsHint": "配置额外的 SDK 选项，如 timeout、setCacheKey 等。值会自动解析类型（数字、布尔值等）。",
    "addExtraOption": "添加",
    "extraOptionKey": "键名",
    "extraOptionValue": "值",
    "extraOptionKeyPlaceholder": "timeout",
    "extraOptionValuePlaceholder": "600000",
    "noExtraOptions": "暂无额外选项",
    "noModelOptions": "模型选项，点击 + 添加",
    "modelLimits": "Token 限制",
    "limitContext": "上下文",
    "limitOutput": "输出",
    "modelExtraFields": "模型属性",
    "noModelExtraFields": "模型属性 (variants, cost 等)，点击 + 添加",
    "modelExtraFieldKeyPlaceholder": "variants",
    "sdkOptions": "SDK 选项",
    "modelOptionKeyPlaceholder": "provider",
    "modelOptionValuePlaceholder": "{\"order\": [\"baseten\"]}"
  },
  "providerPreset": {
    "label": "预设供应商",
    "custom": "自定义配置",
    "other": "其他",
    "hint": "选择预设后可继续调整下方字段。",
    "searchTooltip": "搜索预设",
    "searchAriaLabel": "搜索预设供应商",
    "searchPlaceholder": "搜索名称、官网或分类...",
    "sortAriaLabel": "切换预设排序",
    "sortNameAscTooltip": "按名称 A-Z 排序",
    "sortOriginalTooltip": "恢复原始顺序",
    "noSearchResults": "没有匹配的预设供应商。"
  },
  "usage": {
    "title": "使用统计",
    "subtitle": "查看 AI 模型的使用情况和成本统计",
    "today": "24小时",
    "last7days": "7天",
    "last30days": "30天",
    "presetToday": "当天",
    "preset1d": "1d",
    "preset7d": "7d",
    "preset14d": "14d",
    "preset30d": "30d",
    "totalRequests": "总请求数",
    "totalCost": "总成本",
    "cost": "成本",
    "unpriced": "未定价",
    "perMillion": "(每百万)",
    "trends": "使用趋势",
    "rangeToday": "过去 24 小时 (按小时)",
    "rangeLast7Days": "过去 7 天",
    "rangeLast30Days": "过去 30 天",
    "totalTokens": "新生成 Token (Input+Output)",
    "cacheTokens": "缓存 Token",
    "realTotal": "真实消耗 Tokens",
    "realTotalHint": "Input + Output + 缓存写入 + 缓存命中",
    "freshInput": "新增输入",
    "cacheHitRate": "缓存命中率",
    "requestLogs": "请求日志",
    "providerStats": "Provider 统计",
    "modelStats": "模型统计",
    "time": "时间",
    "provider": "供应商",
    "billingModel": "计费模型",
    "inputTokens": "输入",
    "outputTokens": "输出",
    "cacheReadTokens": "缓存命中",
    "cacheCreationTokens": "缓存创建",
    "timingInfo": "用时/首字",
    "status": "状态",
    "multiplier": "倍率",
    "requestModel": "请求模型",
    "responseModel": "返回模型",
    "noData": "暂无数据",
    "unknownProvider": "未知供应商",
    "stream": "流",
    "nonStream": "非流",
    "source": "来源",
    "requestsLabel": "次请求",
    "costLabel": "总成本",
    "appFilter": {
      "all": "全部",
      "claude": "Claude Code",
      "codex": "Codex",
      "gemini": "Gemini",
      "opencode": "OpenCode",
      "grokbuild": "Grok Build",
      "pi": "Pi",
      "mcode": "MiniMax Code"
    },
    "rawInputLabel": "原始",
    "sessionSync": {
      "title": "自动扫描会话记录",
      "description": "定期扫描各客户端的本地会话记录以统计用量；关闭后仅在手动同步时扫描",
      "syncNow": "立即同步",
      "syncCompleted": "同步完成：新增 {{imported}} 条，扫描 {{files}} 个文件，错误 {{errors}}",
      "syncFailed": "会话用量同步失败：{{error}}"
    },
    "rebuildCodex": {
      "title": "Codex 用量维护",
      "description": "从本地 rollout 日志重新构建 Codex 会话用量",
      "warning": "重建前会自动备份数据库。若源 JSONL 已删除，对应历史将无法重新导入。",
      "action": "重建 Codex 用量",
      "confirmTitle": "确认重建 Codex 用量",
      "confirmMessage": "此操作会清除现有 Codex 会话明细与汇总，再从本地 Codex 日志重新导入。\n\n已删除日志对应的历史将丢失；缺少父 rollout 的 fork 会暂缓导入。",
      "confirmAction": "备份并重建",
      "completed": "重建完成：导入 {{imported}} 条，错误 {{errors}}，疑似重复 {{suspected}}，暂缓文件 {{deferred}}",
      "failed": "Codex 用量重建失败：{{error}}"
    },
    "totalRecords": "共 {{total}} 条记录",
    "goToPage": "跳转",
    "pageInputPlaceholder": "页码",
    "modelPricing": "模型定价",
    "loadPricingError": "加载定价数据失败",
    "modelPricingDesc": "配置各模型的 Token 成本",
    "noPricingData": "暂无定价数据。点击\"新增\"添加模型定价配置。",
    "model": "模型",
    "pricingModel": "计价模型",
    "displayName": "显示名称",
    "inputCost": "输入成本",
    "outputCost": "输出成本",
    "cacheReadCost": "缓存命中",
    "cacheWriteCost": "缓存创建",
    "deleteConfirmTitle": "确认删除",
    "deleteConfirmDesc": "确定要删除此模型定价配置吗？此操作无法撤销。",
    "queryFailed": "查询失败",
    "refreshUsage": "刷新用量",
    "planUsage": "套餐用量",
    "invalid": "已失效",
    "total": "总：",
    "used": "已使用：",
    "remaining": "剩余：",
    "justNow": "刚刚",
    "minutesAgo": "{{count}} 分钟前",
    "hoursAgo": "{{count}} 小时前",
    "daysAgo": "{{count}} 天前",
    "multiplePlans": "{{count}} 个套餐",
    "expand": "展开",
    "collapse": "收起",
    "modelIdPlaceholder": "例如: claude-3-5-sonnet-20241022",
    "displayNamePlaceholder": "例如: Claude 3.5 Sonnet",
    "appType": "应用类型",
    "statusCode": "状态码",
    "allSources": "全部来源",
    "allModels": "全部模型",
    "filterBySource": "按来源筛选",
    "filterByModel": "按模型筛选",
    "refreshInterval": "自动刷新间隔",
    "refreshOff": "关闭",
    "timeRange": "时间范围",
    "customRange": "日历筛选",
    "customRangeHint": "支持日期与时间",
    "startTime": "开始时间",
    "endTime": "结束时间",
    "liveEndTime": "结束时间跟随当前时刻",
    "liveEndTimeNow": "现在",
    "input": "Input",
    "output": "Output",
    "cacheWrite": "创建",
    "cacheWriteNotReported": "OpenAI 协议不区分缓存写入，仅上报缓存命中",
    "cacheWritePartial": "部分协议（如 OpenAI）不上报缓存写入，数值可能偏低",
    "cacheRead": "命中",
    "baseCost": "基础",
    "costMultiplier": "成本倍率",
    "withMultiplier": "含倍率",
    "requestDetail": "请求详情",
    "requestNotFound": "请求未找到",
    "basicInfo": "基本信息",
    "tokenUsage": "Token 使用量",
    "cacheCreationCost": "缓存写入成本",
    "costBreakdown": "成本明细",
    "performance": "性能信息",
    "latency": "延迟",
    "errorMessage": "错误信息",
    "requests": "请求数",
    "tokens": "Tokens",
    "avgCost": "平均成本",
    "avgLatency": "平均延迟",
    "successRate": "成功率",
    "requestId": "请求 ID",
    "never": "从不",
    "modelId": "模型 ID",
    "modelIdRequired": "模型 ID 不能为空",
    "inputCostPerMillion": "输入成本 (每百万 tokens, USD)",
    "outputCostPerMillion": "输出成本 (每百万 tokens, USD)",
    "invalidPrice": "价格必须为非负数",
    "invalidTimeRange": "请选择完整的开始/结束时间",
    "invalidTimeRangeOrder": "开始时间不能晚于结束时间",
    "timeRangeTooLarge": "时间范围过大，请缩小范围",
    "addPricing": "新增定价",
    "editPricing": "编辑定价",
    "pricingAdded": "定价已添加",
    "pricingUpdated": "定价已更新",
    "importFromModelsDev": "从 models.dev 导入",
    "modelsDevHint": "无需手动填写，可从 models.dev 选择模型定价",
    "modelsDevPickerTitle": "从 models.dev 导入定价",
    "modelsDevPickerDesc": "选择要导入的模型（价格单位：USD / 百万 tokens），每次导入一个",
    "modelsDevSearchPlaceholder": "搜索模型或供应商（全量搜索）...",
    "modelsDevAllProviders": "全部供应商",
    "modelsDevLoadError": "加载 models.dev 数据失败",
    "modelsDevRetry": "重试",
    "modelsDevImportButton": "导入",
    "modelsDevImporting": "导入中...",
    "modelsDevImported": "已导入 {{name}} 的定价",
    "modelsDevNoResults": "没有匹配的模型",
    "modelsDevTruncated": "仅显示前 {{shown}} 条，共 {{total}} 条结果，请缩小搜索范围",
    "modelsDevDefaultHint": "默认展示最新发布的 {{shown}} 个模型（共 {{total}} 个），输入关键字可全量搜索",
    "modelsDevAutoSync": {
      "title": "自动同步 models.dev 定价",
      "description": "开启后，CC Switch 会在启动时定期拉取所选模型的最新价格，并保存到本地定价文件。",
      "enabled": "已开启",
      "disabled": "已关闭",
      "enableConfirmTitle": "开启自动同步定价？",
      "enableConfirmMessage": "开启后，CC Switch 会在启动时定期从 models.dev 更新所选模型的价格（最多每 6 小时一次）。同一模型 ID 的软件内置价格和手动设置价格都会被覆盖。",
      "enableConfirmAction": "开启自动同步",
      "configure": "选择模型",
      "configureTitle": "选择自动同步定价的模型",
      "configureDescription": "通过搜索和供应商筛选选择需要自动更新的模型，选择结果保存在本地。",
      "commonModels": "自动包含常用模型",
      "commonModelsDescription": "自动选择 {{count}} 个近期 Claude、GPT、Gemini、Grok、DeepSeek、Qwen、MiMo、LongCat、Kimi、MiniMax 和 GLM 模型。",
      "selectFiltered": "全选筛选结果（{{count}}）",
      "clearFiltered": "清空筛选结果",
      "selectedCount": "已选择 {{count}} 个模型",
      "selectionHint": "归一化模型 ID 相同的选项只会导入一次。",
      "commonBadge": "常用",
      "selectionSaved": "自动定价同步选择已保存",
      "syncSuccess": "定价同步完成：检查 {{imported}} 个模型，更新 {{changed}} 个",
      "syncFailed": "定价同步失败：{{error}}",
      "configLoadFailed": "加载本地定价配置失败：{{error}}",
      "neverSynced": "从未同步",
      "lastSync": "上次同步",
      "commonStatus": "常用模型",
      "lastError": "上次自动同步失败：{{error}}",
      "localFile": "本地定价文件",
      "openFolder": "打开目录",
      "openFolderFailed": "打开本地定价文件目录失败：{{error}}",
      "reloadLocalFile": "重新加载文件",
      "localFileReloaded": "本地定价文件已重新加载",
      "localFileReloadFailed": "重新加载本地定价文件失败：{{error}}",
      "syncNow": "立即同步"
    },
    "cacheReadCostPerMillion": "缓存读取成本 (每百万 tokens, USD)",
    "cacheCreationCostPerMillion": "缓存写入成本 (每百万 tokens, USD)"
  },
  "usageScript": {
    "title": "配置用量查询",
    "enableUsageQuery": "启用用量查询",
    "presetTemplate": "预设模板",
    "requestUrl": "请求地址",
    "requestUrlPlaceholder": "例如：https://api.example.com",
    "method": "HTTP 方法",
    "templateCustom": "自定义",
    "templateGeneral": "通用模板",
    "templateNewAPI": "NewAPI",
    "templateCopilot": "GitHub Copilot",
    "templateTokenPlan": "Token Plan",
    "templateBalance": "官方",
    "templateOfficialSubscription": "官方订阅",
    "copilotAutoAuth": "自动使用 OAuth 认证，无需手动配置凭证",
    "tokenPlanHint": "自动使用供应商的 API Key 和 Base URL 查询 Token Plan 额度",
    "balanceHint": "自动使用供应商的 API Key 查询账户余额",
    "officialSubscriptionHint": "读取本机 CLI 的 OAuth 凭据，并调用官方接口查询订阅额度。默认关闭，只有启用后才会请求。",
    "resetDate": "重置日期",
    "premiumRequests": "Premium 请求",
    "credentialsConfig": "凭证配置",
    "credentialsHint": "留空则自动使用供应商配置",
    "optional": "可选",
    "apiKeyPlaceholder": "留空则使用供应商的 API Key",
    "baseUrlPlaceholder": "留空则使用供应商的请求地址",
    "baseUrl": "请求地址",
    "accessToken": "访问令牌（在个人安全设置里获取）",
    "accessTokenPlaceholder": "在'安全设置'里生成",
    "userId": "用户 ID",
    "userIdPlaceholder": "例如：114514",
    "accessKeyId": "AccessKey ID",
    "secretAccessKey": "SecretAccessKey",
    "volcengineAkSkHint": "火山用量查询需账号级 AccessKey ID / Secret（与推理 API Key 不同）。请在火山引擎控制台右上角账号菜单 →「API访问密钥」中创建。",
    "volcengineKeyConsoleLink": "密钥创建地址：",
    "zhipuTeamHint": "智谱团队套餐用量查询需团队 API Key（沿用本供应商凭据）+ 组织 ID + 项目 ID（作为请求头 bigmodel-organization / bigmodel-project）。组织与项目 ID 可在团队管理后台用量页的 URL 中找到。",
    "zhipuTeamConsoleLink": "团队用量页：",
    "organizationId": "组织 ID",
    "organizationIdPlaceholder": "例如：org-xxxxxx",
    "projectId": "项目 ID",
    "projectIdPlaceholder": "例如：proj-xxxxxx",
    "defaultPlan": "默认套餐",
    "queryFailedMessage": "查询失败",
    "queryScript": "查询脚本（JavaScript）",
    "timeoutSeconds": "超时时间（秒）",
    "headers": "请求头",
    "body": "请求 Body",
    "timeoutHint": "范围: 2-30 秒",
    "timeoutMustBeInteger": "超时时间必须为整数，小数部分已忽略",
    "timeoutCannotBeNegative": "超时时间不能为负数",
    "autoIntervalMinutes": "自动查询间隔（分钟，0 表示不自动查询）",
    "autoQueryInterval": "自动查询间隔（分钟）",
    "autoQueryIntervalHint": "0 表示不自动查询，建议 5-60 分钟",
    "intervalMustBeInteger": "自动查询间隔必须为整数，小数部分已忽略",
    "intervalCannotBeNegative": "自动查询间隔不能为负数",
    "intervalAdjusted": "自动查询间隔已调整为 {{value}} 分钟",
    "scriptHelp": "脚本编写说明：",
    "configFormat": "配置格式：",
    "commentOptional": "可选",
    "commentResponseIsJson": "response 是 API 返回的 JSON 数据",
    "extractorFormat": "extractor 返回格式（所有字段均为可选）：",
    "tips": "💡 提示：",
    "testing": "测试中...",
    "testScript": "测试脚本",
    "format": "格式化",
    "saveConfig": "保存配置",
    "scriptEmpty": "脚本配置不能为空",
    "mustHaveReturn": "脚本必须包含 return 语句",
    "testSuccess": "测试成功！",
    "testFailed": "测试失败",
    "formatSuccess": "格式化成功",
    "formatFailed": "格式化失败",
    "supportedVariables": "支持的变量",
    "variablesHint": "支持变量: {{apiKey}}, {{baseUrl}} | extractor 函数接收 API 响应的 JSON 对象",
    "scriptConfig": "请求配置",
    "extractorCode": "提取器代码",
    "extractorHint": "返回对象需包含剩余额度等字段",
    "fieldIsValid": "• isValid: 布尔值，套餐是否有效",
    "fieldInvalidMessage": "• invalidMessage: 字符串，失效原因说明（当 isValid 为 false 时显示）",
    "fieldRemaining": "• remaining: 数字，剩余额度",
    "fieldUnit": "• unit: 字符串，单位（如 \"USD\"）",
    "fieldPlanName": "• planName: 字符串，套餐名称",
    "fieldTotal": "• total: 数字，总额度",
    "fieldUsed": "• used: 数字，已用额度",
    "fieldExtra": "• extra: 字符串，扩展字段，可自由补充需要展示的文本",
    "tip1": "• 变量 {{apiKey}} 和 {{baseUrl}} 会自动替换",
    "tip2": "• extractor 函数在沙箱环境中执行，支持 ES2020+ 语法",
    "tip3": "• 整个配置必须用 () 包裹，形成对象字面量表达式"
  },
  "dbUpgrade": {
    "title": "数据库版本过新",
    "description": "当前数据库由更新版本的 CC Switch 创建，需要升级应用后才能继续使用。升级不会删除你的数据。",
    "versionInfo": "数据库版本 v{{db}} · 应用支持 v{{supported}}",
    "dbPath": "数据库文件",
    "checking": "正在检查可用更新…",
    "updateAvailable": "发现新版本 v{{version}}，升级后即可继续使用。",
    "incompatibleTitle": "升级也无法解决",
    "incompatibleDescription": "你已是最新版本，但数据库版本（v{{db}}）仍高于本应用支持的版本（v{{supported}}）。该数据库可能由第三方客户端或更高版本创建，升级当前官方应用也无法兼容。",
    "preparing": "正在准备更新…",
    "downloading": "正在下载更新…",
    "upgradeNow": "升级应用",
    "retry": "重试升级",
    "openReleases": "打开发布页",
    "openConfigDir": "打开配置目录",
    "quit": "退出"
  },
  "errors": {
    "usage_query_failed": "用量查询失败",
    "configLoadFailedTitle": "配置加载失败",
    "configLoadFailedMessage": "无法读取配置文件：\n{{path}}\n\n错误详情：\n{{detail}}\n\n请手动检查 JSON 是否有效，或从同目录的备份文件（如 config.json.bak）恢复。\n\n应用将退出以便您进行修复。",
    "frontendCrashTitle": "界面遇到了问题",
    "frontendCrashMessage": "已尝试将错误信息写入应用诊断日志。请重新加载界面；如果问题持续，请在提交 Issue 时附上日志。",
    "reloadInterface": "重新加载界面"
  },
  "presetSelector": {
    "title": "选择配置类型",
    "custom": "自定义",
    "customDescription": "手动配置供应商，需要填写完整的配置信息",
    "officialDescription": "官方登录，不需要填写 API Key",
    "presetDescription": "使用预设配置，只需填写 API Key"
  },
  "mcp": {
    "title": "MCP 管理",
    "import": "导入",
    "importExisting": "导入已有",
    "addMcp": "添加MCP",
    "claudeTitle": "Claude Code MCP 管理",
    "codexTitle": "Codex MCP 管理",
    "geminiTitle": "Gemini MCP 管理",
    "unifiedPanel": {
      "title": "MCP 服务器管理",
      "addServer": "添加服务器",
      "editServer": "编辑服务器",
      "deleteServer": "删除服务器",
      "deleteConfirm": "确定要删除服务器 \"{{id}}\" 吗？此操作无法撤销。",
      "noServers": "暂无服务器",
      "enabledApps": "启用的应用",
      "noImportFound": "未发现需要导入的 MCP 服务器。所有服务器已在 CC Switch 统一管理中。",
      "importSuccess": "成功导入 {{count}} 个 MCP 服务器",
      "searchPlaceholder": "搜索 MCP 名称、描述、标签或命令...",
      "searchAriaLabel": "搜索已管理的 MCP 服务器",
      "noSearchResults": "未找到匹配的 MCP 服务器",
      "apps": {
        "claude": "Claude",
        "codex": "Codex",
        "gemini": "Gemini",
        "grokbuild": "Grok Build",
        "opencode": "OpenCode",
        "openclaw": "OpenClaw",
        "hermes": "Hermes",
        "mcode": "MiniMax Code"
      }
    },
    "userLevelPath": "用户级 MCP 配置路径",
    "serverList": "服务器列表",
    "loading": "加载中...",
    "empty": "暂无 MCP 服务器",
    "emptyDescription": "点击右上角按钮添加第一个 MCP 服务器",
    "add": "添加 MCP",
    "addServer": "新增 MCP",
    "editServer": "编辑 MCP",
    "addClaudeServer": "新增 Claude Code MCP",
    "editClaudeServer": "编辑 Claude Code MCP",
    "addCodexServer": "新增 Codex MCP",
    "editCodexServer": "编辑 Codex MCP",
    "configPath": "配置路径",
    "serverCount": "已配置 {{count}} 个 MCP 服务器",
    "enabledCount": "已启用 {{count}} 个",
    "template": {
      "fetch": "快速模板：mcp-fetch"
    },
    "form": {
      "title": "MCP 标题（唯一）",
      "titlePlaceholder": "my-mcp-server",
      "name": "显示名称",
      "namePlaceholder": "例如 @modelcontextprotocol/server-time",
      "enabledApps": "启用到应用",
      "noAppsWarning": "至少选择一个应用",
      "description": "描述",
      "descriptionPlaceholder": "可选的描述信息",
      "tags": "标签（逗号分隔）",
      "tagsPlaceholder": "stdio, time, utility",
      "homepage": "主页链接",
      "homepagePlaceholder": "https://example.com",
      "docs": "文档链接",
      "docsPlaceholder": "https://example.com/docs",
      "additionalInfo": "附加信息",
      "jsonConfig": "完整的 JSON 配置",
      "jsonConfigOrPrefix": "完整的 JSON 配置或者使用",
      "tomlConfigOrPrefix": "完整的 TOML 配置或者使用",
      "jsonPlaceholder": "{\n  \"type\": \"stdio\",\n  \"command\": \"uvx\",\n  \"args\": [\"mcp-server-fetch\"]\n}",
      "tomlConfig": "完整的 TOML 配置",
      "tomlPlaceholder": "type = \"stdio\"\ncommand = \"uvx\"\nargs = [\"mcp-server-fetch\"]",
      "useWizard": "配置向导",
      "syncOtherSide": "同步到 {{target}}",
      "syncOtherSideHint": "勾选后会把当前配置同时写入 {{target}}，若存在同名配置将被覆盖",
      "willOverwriteWarning": "将覆盖 {{target}} 中的同名配置"
    },
    "wizard": {
      "title": "MCP 配置向导",
      "hint": "快速配置 MCP 服务器，自动生成 JSON 配置",
      "type": "类型",
      "typeStdio": "stdio",
      "typeHttp": "http",
      "typeSse": "sse",
      "command": "命令",
      "commandPlaceholder": "npx 或 uvx",
      "args": "参数",
      "argsPlaceholder": "arg1\narg2",
      "env": "环境变量",
      "envPlaceholder": "KEY1=value1\nKEY2=value2",
      "url": "URL",
      "urlPlaceholder": "https://api.example.com/mcp",
      "urlRequired": "请输入 URL",
      "headers": "请求头（可选）",
      "headersPlaceholder": "Authorization: Bearer your_token_here\nContent-Type: application/json",
      "preview": "配置预览",
      "apply": "应用配置"
    },
    "id": "标识 (唯一)",
    "type": "类型",
    "command": "命令",
    "validateCommand": "校验命令",
    "args": "参数",
    "argsPlaceholder": "例如：mcp-server-fetch --help",
    "env": "环境变量 (一行一个，KEY=VALUE)",
    "envPlaceholder": "FOO=bar\nHELLO=world",
    "reset": "重置",
    "msg": {
      "saved": "已保存",
      "deleted": "已删除",
      "enabled": "已启用",
      "disabled": "已禁用",
      "templateAdded": "已添加模板"
    },
    "error": {
      "idRequired": "请填写标识",
      "idExists": "该标识已存在，请更换",
      "jsonInvalid": "JSON 格式错误，请检查",
      "tomlInvalid": "TOML 格式错误，请检查",
      "commandRequired": "请填写命令",
      "singleServerObjectRequired": "此处只需单个服务器对象，请不要粘贴包含 mcpServers 的整份配置",
      "saveFailed": "保存失败",
      "deleteFailed": "删除失败"
    },
    "validation": {
      "ok": "命令可用",
      "fail": "命令不可用"
    },
    "confirm": {
      "deleteTitle": "删除 MCP 服务器",
      "deleteMessage": "确定要删除 MCP 服务器 \"{{id}}\" 吗？此操作无法撤销。"
    },
    "presets": {
      "title": "选择 MCP 类型",
      "enable": "启用",
      "enabled": "已启用",
      "installed": "已安装",
      "docs": "文档",
      "requiresEnv": "需要环境变量",
      "fetch": {
        "name": "mcp-server-fetch",
        "description": "通用 HTTP 请求工具，支持 GET/POST 等 HTTP 方法，适合快速请求接口/抓取网页数据"
      },
      "time": {
        "name": "@modelcontextprotocol/server-time",
        "description": "时间查询工具，提供当前时间、时区转换、日期计算等功能"
      },
      "memory": {
        "name": "@modelcontextprotocol/server-memory",
        "description": "知识图谱记忆系统，支持存储实体、关系和观察，让 AI 记住对话中的重要信息"
      },
      "sequential-thinking": {
        "name": "@modelcontextprotocol/server-sequential-thinking",
        "description": "顺序思考工具，帮助 AI 将复杂问题分解为多个步骤，逐步深入思考"
      },
      "context7": {
        "name": "@upstash/context7-mcp",
        "description": "Context7 文档搜索工具，提供最新的库文档和代码示例，配置 key 会有更高限额"
      }
    }
  },
  "prompts": {
    "manage": "提示词",
    "title": "{{appName}} 提示词管理",
    "claudeTitle": "Claude 提示词管理",
    "codexTitle": "Codex 提示词管理",
    "add": "添加提示词",
    "edit": "编辑提示词",
    "addTitle": "添加 {{appName}} 提示词",
    "editTitle": "编辑 {{appName}} 提示词",
    "import": "导入现有",
    "count": "共 {{count}} 个提示词",
    "enabled": "已启用",
    "enable": "启用",
    "enabledName": "已启用: {{name}}",
    "noneEnabled": "未启用任何提示词",
    "currentFile": "当前 {{filename}} 内容",
    "empty": "暂无提示词",
    "emptyDescription": "点击右上角按钮添加或导入提示词",
    "loading": "加载中...",
    "searchPlaceholder": "搜索提示词名称、描述或内容...",
    "searchAriaLabel": "搜索已管理的提示词",
    "noSearchResults": "未找到匹配的提示词",
    "name": "名称",
    "namePlaceholder": "例如：项目默认提示词",
    "description": "描述",
    "descriptionPlaceholder": "可选的描述信息",
    "content": "内容",
    "contentPlaceholder": "# {{filename}}\n\n在此输入提示词内容...",
    "loadFailed": "加载提示词失败",
    "saveSuccess": "保存成功",
    "saveFailed": "保存失败",
    "deleteSuccess": "删除成功",
    "deleteFailed": "删除失败",
    "enableSuccess": "启用成功",
    "enableFailed": "启用失败",
    "disableSuccess": "禁用成功",
    "disableFailed": "禁用失败",
    "importSuccess": "导入成功",
    "importFailed": "导入失败",
    "confirm": {
      "deleteTitle": "确认删除",
      "deleteMessage": "确定要删除提示词 \"{{name}}\" 吗？"
    }
  },
  "profiles": {
    "switcherAriaLabel": "项目：{{name}}",
    "switcherTooltip": {
      "claude": "项目：一键切换 Claude Code 的供应商 / MCP / Skills / 记忆文件",
      "claude-desktop": "项目：一键切换 Claude Desktop 的供应商",
      "codex": "项目：一键切换 Codex 的供应商 / MCP / Skills / 记忆文件"
    },
    "none": "不使用项目",
    "searchPlaceholder": "搜索项目",
    "empty": "暂无项目",
    "createFromCurrent": "新建项目",
    "createDescription": {
      "claude": "把 Claude Code 当前的供应商、MCP、Skills、记忆文件保存为一个项目，之后可一键切换。",
      "claude-desktop": "把 Claude Desktop 当前的供应商保存为一个项目，之后可一键切换。",
      "codex": "把 Codex 当前的供应商、MCP、Skills 和记忆文件配置保存为一个项目，之后可一键切换。"
    },
    "manage": "管理项目…",
    "manageTitle": "管理项目",
    "manageDescription": "项目是配置快照。切换项目时，当前配置会自动保存回原项目。",
    "namePlaceholder": "例如：开发、绘图",
    "rename": "重命名",
    "noSnapshotForScope": "本侧未保存",
    "delete": "删除",
    "deleteConfirmTitle": "确认删除",
    "deleteConfirmMessage": "确定要删除项目 \"{{name}}\" 吗？不会改动任何现有配置。",
    "createSuccess": "项目已创建",
    "createFailed": "创建项目失败: {{detail}}",
    "updateSuccess": "项目已更新",
    "updateFailed": "更新项目失败: {{detail}}",
    "deleteSuccess": "项目已删除",
    "deleteFailed": "删除项目失败: {{detail}}",
    "applySuccess": "项目已应用",
    "applyFailed": "应用项目失败: {{detail}}",
    "applyWarnings": "项目已应用，{{warningCount}} 条警告：\n{{details}}",
    "clearSuccess": "已切换为不使用项目"
  },
  "workspace": {
    "title": "Workspace 文件管理",
    "manage": "Workspace",
    "files": {
      "agents": "Agent 操作指令和规则",
      "soul": "Agent 人格和沟通风格",
      "user": "用户档案和偏好",
      "identity": "Agent 名称和头像",
      "tools": "本地工具文档",
      "memory": "长期记忆和决策记录",
      "heartbeat": "心跳运行清单",
      "bootstrap": "首次运行仪式",
      "boot": "网关重启清单"
    },
    "editing": "编辑 {{filename}}",
    "saveSuccess": "保存成功",
    "saveFailed": "保存失败",
    "loadFailed": "读取失败",
    "openDirectory": "在文件管理器中打开",
    "dailyMemory": {
      "title": "每日记忆",
      "sectionTitle": "每日记忆",
      "cardTitle": "每日记忆文件",
      "cardDescription": "浏览管理每日记忆",
      "createToday": "添加记忆",
      "empty": "暂无每日记忆文件",
      "loadFailed": "加载每日记忆文件失败",
      "createFailed": "创建每日记忆文件失败",
      "deleteSuccess": "每日记忆文件已删除",
      "deleteFailed": "删除每日记忆文件失败",
      "confirmDeleteTitle": "删除每日记忆",
      "confirmDeleteMessage": "确定删除 {{date}} 的每日记忆吗？此操作不可撤销。",
      "searchPlaceholder": "搜索全文内容...",
      "searchScopeHint": "全文搜索所有每日记忆 ⌘F",
      "searchCloseHint": "Esc 关闭",
      "noSearchResults": "没有找到匹配的每日记忆。",
      "searching": "搜索中...",
      "searchFailed": "搜索失败",
      "matchCount": "{{count}} 处匹配"
    }
  },
  "openclaw": {
    "backupCreated": "已创建备份：{{path}}",
    "providerKey": "供应商标识",
    "providerKeyPlaceholder": "my-provider",
    "providerKeyHint": "配置文件中的唯一标识符，只能使用小写字母、数字和连字符",
    "providerKeyLockedHint": "该供应商已添加到应用配置中，供应商标识不可修改",
    "providerKeyRequired": "请填写供应商标识",
    "providerKeyDuplicate": "此标识已被使用，请更换",
    "providerKeyInvalid": "标识格式无效，只能使用小写字母、数字和连字符",
    "apiProtocol": "API 协议",
    "selectProtocol": "选择 API 协议",
    "apiProtocolHint": "选择与供应商 API 兼容的协议类型。大多数供应商使用 OpenAI Completions 格式。",
    "baseUrl": "API 端点",
    "baseUrlHint": "供应商的 API 端点地址。",
    "models": "模型配置",
    "addModel": "添加模型",
    "selectDefaultModel": "选择默认模型",
    "noModels": "暂无模型配置",
    "modelId": "模型 ID",
    "modelIdPlaceholder": "claude-3-sonnet",
    "modelName": "显示名称",
    "modelNamePlaceholder": "Claude 3 Sonnet",
    "toggleModelDetails": "展开或收起模型详情",
    "removeModel": "移除模型",
    "contextWindow": "上下文长度",
    "maxTokens": "最大输出 Token 数",
    "reasoning": "支持扩展思考",
    "inputTypes": "输入类型",
    "modelCost": "成本（$/百万 Token）",
    "inputCost": "输入",
    "outputCost": "输出",
    "cacheReadCost": "缓存读取",
    "cacheWriteCost": "缓存写入",
    "userAgent": "发送 User-Agent",
    "userAgentHint": "部分供应商需要浏览器 User-Agent 才能正常访问。",
    "env": {
      "title": "环境变量",
      "description": "管理 openclaw.json 中的环境变量配置（API Key、自定义变量等）",
      "editorHint": "以 JSON 形式编辑整个 env 节点。支持 env.vars、env.shellEnv 等嵌套对象。",
      "objectRequired": "OpenClaw 的 env 必须是 JSON 对象。",
      "invalidJson": "OpenClaw 的 env 必须是合法 JSON。",
      "empty": "OpenClaw 的 env 不能为空。空对象请使用 {}。",
      "keyPlaceholder": "变量名",
      "valuePlaceholder": "值",
      "add": "添加变量",
      "saveSuccess": "环境变量已保存",
      "saveFailed": "保存环境变量失败",
      "loadFailed": "读取环境变量失败",
      "duplicateKey": "检测到重复的变量名: {{key}}"
    },
    "tools": {
      "title": "工具权限",
      "description": "管理 openclaw.json 中的工具权限配置（允许/拒绝列表）",
      "profile": "权限模式",
      "profileMinimal": "最小权限",
      "profileCoding": "编码",
      "profileMessaging": "对话",
      "profileFull": "完全访问",
      "profileUnset": "未设置",
      "unsupportedProfileTitle": "检测到不受支持的工具配置",
      "unsupportedProfileDescription": "当前 tools.profile 的值“{{value}}”不在 OpenClaw 支持列表内。在你手动选择新值之前，它会被保留。",
      "unsupportedProfileLabel": "不受支持",
      "allowList": "允许列表",
      "denyList": "拒绝列表",
      "patternPlaceholder": "工具名称或模式",
      "addAllow": "添加允许",
      "addDeny": "添加拒绝",
      "saveSuccess": "工具权限已保存",
      "saveFailed": "保存工具权限失败",
      "loadFailed": "读取工具权限失败"
    },
    "agents": {
      "title": "Agents 配置",
      "description": "管理 openclaw.json 中的 agents.defaults 配置（默认模型、运行参数等）",
      "modelSection": "模型配置",
      "primaryModel": "默认模型",
      "primaryModelHint": "从已配置供应商的模型中选择默认模型",
      "notSet": "未设置",
      "fallbackModels": "回退模型",
      "fallbackModelsHint": "当主模型不可用时，按优先级依次尝试以下回退模型",
      "addFallback": "添加回退模型",
      "noModels": "暂无已配置的供应商模型。请先添加 OpenClaw 供应商。",
      "notInList": "{{value}} (供应商未配置)",
      "runtimeSection": "运行参数",
      "workspace": "工作区路径",
      "timeout": "超时时间（秒）",
      "contextTokens": "上下文 Token 数",
      "maxConcurrent": "最大并发数",
      "legacyTimeoutTitle": "检测到旧版超时字段",
      "legacyTimeoutDescription": "当前配置仍在使用 agents.defaults.timeout。保存本页面时会迁移为 timeoutSeconds。",
      "saveSuccess": "Agents 配置已保存",
      "saveFailed": "保存 Agents 配置失败",
      "loadFailed": "读取 Agents 配置失败"
    },
    "health": {
      "title": "检测到 OpenClaw 配置警告",
      "invalidToolsProfile": "tools.profile 使用了不受支持的值。OpenClaw 当前只支持 minimal、coding、messaging、full。",
      "legacyTimeout": "agents.defaults.timeout 已废弃。打开并保存 Agents 面板即可迁移到 timeoutSeconds。",
      "stringifiedEnvVars": "env.vars 应为对象，但当前值看起来像被字符串化或已损坏。",
      "stringifiedShellEnv": "env.shellEnv 应为对象，但当前值看起来像被字符串化或已损坏。",
      "parseFailed": "openclaw.json 不是合法 JSON5。请先修复文件，再通过这里编辑。"
    }
  },
  "hermes": {
    "form": {
      "baseUrl": "API 端点",
      "baseUrlHint": "供应商的 API 端点地址。",
      "providerKey": "供应商标识",
      "providerKeyPlaceholder": "my-provider",
      "providerKeyHint": "只能使用小写字母、数字和连字符。用作 config.yaml 中的供应商名称。",
      "providerKeyLockedHint": "该供应商已添加到 Hermes 配置中，标识不可修改。",
      "providerKeyRequired": "供应商标识不能为空",
      "providerKeyInvalid": "供应商标识只能包含小写字母、数字和连字符",
      "providerKeyDuplicate": "该供应商标识已存在",
      "apiMode": "API 模式",
      "apiModeHint": "供应商 API 协议。请根据端点选择正确的协议。",
      "apiModeChatCompletions": "OpenAI Chat Completions",
      "apiModeAnthropicMessages": "Anthropic Messages",
      "apiModeCodexResponses": "OpenAI Responses",
      "apiModeBedrockConverse": "AWS Bedrock Converse",
      "baseUrlRequired": "API 端点不能为空",
      "baseUrlScheme": "请使用 http:// 或 https:// 开头的地址",
      "baseUrlInvalid": "API 端点不是有效的 URL",
      "models": "模型列表",
      "addModel": "添加模型",
      "noModels": "暂无模型配置。切换到此供应商时将不会更新默认模型。",
      "modelId": "模型 ID",
      "modelIdPlaceholder": "anthropic/claude-opus-5",
      "modelName": "显示名称",
      "modelNamePlaceholder": "Claude Opus 5",
      "contextLength": "上下文长度",
      "toggleModelDetails": "展开或收起模型详情",
      "removeModel": "移除模型",
      "modelsHint": "启用为当前供应商时，第一个模型会设为 Hermes 默认模型。",
      "rateLimitDelay": "请求间隔（秒）",
      "rateLimitDelayHint": "连续请求间的最小间隔秒数（可选）。留空表示无限制。"
    },
    "webui": {
      "open": "打开 Hermes Web UI",
      "offline": "Hermes Web UI 未启动，请先运行 `hermes dashboard` 启动服务。",
      "openFailed": "打开 Hermes Web UI 失败",
      "launchConfirmTitle": "Hermes Dashboard 未启动",
      "launchConfirmMessage": "是否打开终端并运行 `hermes dashboard` 启动服务？\n\n启动完成后会自动打开浏览器。\n\n若终端提示找不到 hermes 或缺少 web 依赖，请先运行：\npip install hermes-agent[web]",
      "launchConfirmAction": "打开终端并启动",
      "launching": "已在终端启动 hermes dashboard",
      "launchFailed": "打开终端失败"
    },
    "memory": {
      "title": "记忆管理",
      "agentTab": "Agent 记忆 (MEMORY.md)",
      "userTab": "用户画像 (USER.md)",
      "usage": "已用 {{current}} / {{limit}} 字符",
      "overLimit": "已超过上限，Hermes 下次加载时会截断",
      "enableOn": "已启用",
      "enableOff": "已禁用",
      "disabledHint": "在重新启用前 Hermes 会跳过此记忆",
      "toggleFailed": "切换记忆状态失败",
      "saveSuccess": "记忆已保存",
      "saveFailed": "保存记忆失败",
      "loadFailed": "读取记忆文件失败",
      "openConfig": "在 Hermes Web UI 调整上限",
      "runtimeNote": "更改将在 Hermes 下次启动或新建会话时生效。"
    }
  },
  "env": {
    "warning": {
      "title": "检测到系统环境变量冲突",
      "description": "发现 {{count}} 个环境变量可能会覆盖您的配置"
    },
    "actions": {
      "expand": "查看详情",
      "collapse": "收起",
      "selectAll": "全选",
      "clearSelection": "取消选择",
      "deleteSelected": "删除选中 ({{count}})",
      "deleting": "删除中..."
    },
    "field": {
      "value": "值",
      "source": "来源"
    },
    "source": {
      "userRegistry": "用户环境变量 (注册表)",
      "systemRegistry": "系统环境变量 (注册表)",
      "systemEnv": "系统环境变量"
    },
    "delete": {
      "success": "环境变量已成功删除",
      "error": "删除环境变量失败"
    },
    "backup": {
      "location": "备份位置: {{path}}"
    },
    "confirm": {
      "title": "确认删除环境变量",
      "message": "确定要删除 {{count}} 个环境变量吗？",
      "backupNotice": "删除前将自动备份,您可以稍后恢复。删除后需要重启应用或终端才能生效。",
      "confirm": "确认删除"
    },
    "error": {
      "noSelection": "请选择要删除的环境变量"
    }
  },
  "skills": {
    "manage": "Skills",
    "title": "Skills 管理",
    "description": "从流行的仓库发现并安装技能，扩展 Claude Code/Codex/Gemini 的能力",
    "refresh": "刷新",
    "refreshing": "刷新中...",
    "repoManager": "仓库管理",
    "count": "共 {{count}} 个技能",
    "empty": "暂无可用技能",
    "emptyDescription": "添加技能仓库以发现可用的技能",
    "addRepo": "添加技能仓库",
    "loading": "加载中...",
    "installed": "已安装",
    "install": "安装",
    "installing": "安装中...",
    "uninstall": "卸载",
    "uninstalling": "卸载中...",
    "view": "查看",
    "noDescription": "暂无描述",
    "loadFailed": "加载失败",
    "installSuccess": "技能 {{name}} 已安装",
    "installFailed": "安装失败",
    "uninstallSuccess": "技能 {{name}} 已卸载",
    "uninstallPiPreserved": "无法确认该 Pi 副本由 CC Switch 管理，已保留：{{path}}",
    "uninstallPiCleanupIncomplete": "Pi 清理未能完成，请手动检查 Pi Skills 目录中是否有残留副本。",
    "uninstallFailed": "卸载失败",
    "update": "更新",
    "updating": "更新中...",
    "updateAvailable": "可更新",
    "updateSuccess": "技能 {{name}} 已更新到最新版本",
    "updateFailed": "更新失败",
    "checkUpdates": "检查更新",
    "checkingUpdates": "检查中...",
    "noUpdates": "所有技能已是最新版本",
    "updatesFound": "发现 {{count}} 个技能有可用更新",
    "updateAll": "全部更新 ({{count}})",
    "updatingAll": "更新中...",
    "updateAllSuccess": "已成功更新 {{count}} 个技能",
    "error": {
      "skillNotFound": "技能不存在：{{directory}}",
      "missingRepoInfo": "缺少仓库信息（owner 或 name）",
      "downloadTimeout": "下载仓库 {{owner}}/{{name}} 超时（{{timeout}}秒）",
      "downloadTimeoutHint": "请检查网络连接或稍后重试",
      "skillPathNotFound": "仓库 {{owner}}/{{name}} 中未找到技能路径 '{{path}}'",
      "skillDirNotFound": "技能目录不存在：{{path}}",
      "directoryConflict": "技能目录 '{{directory}}' 已被 {{existing_repo}} 占用，无法从 {{new_repo}} 安装",
      "emptyArchive": "下载的压缩包为空",
      "invalidRepoRef": "仓库地址不合法：{{owner}}/{{name}}",
      "archiveTooLarge": "压缩包解压后超过 {{limit_mb}} MB 上限，已中止",
      "archiveTooManyEntries": "压缩包条目过多（{{count}}），上限 {{limit}}",
      "downloadFailed": "下载失败：HTTP {{status}}",
      "allBranchesFailed": "所有分支下载失败，尝试了：{{branches}}",
      "httpError": "HTTP 错误 {{status}}",
      "http403": "GitHub 访问受限，可能是请求频率过高",
      "http404": "仓库或分支不存在，请检查地址",
      "http429": "请求过于频繁，请等待后重试",
      "parseMetadataFailed": "解析技能元数据失败",
      "getHomeDirFailed": "无法获取用户主目录",
      "noSkillsInZip": "ZIP 文件中未找到技能（需包含 SKILL.md 文件）",
      "networkError": "网络错误",
      "fsError": "文件系统错误",
      "unknownError": "未知错误",
      "suggestion": {
        "checkNetwork": "请检查网络连接",
        "checkProxy": "建议配置 HTTP 代理",
        "retryLater": "请稍后重试",
        "checkRepoUrl": "请检查仓库地址和分支名称",
        "checkDiskSpace": "请检查磁盘空间",
        "checkPermission": "请检查目录权限",
        "uninstallFirst": "请先卸载已安装的同名技能",
        "checkZipContent": "请确认 ZIP 文件包含有效的技能目录（含 SKILL.md 文件）"
      }
    },
    "repo": {
      "title": "管理技能仓库",
      "description": "添加或删除 GitHub 技能仓库源",
      "url": "仓库 URL",
      "urlPlaceholder": "owner/name 或 https://github.com/owner/name",
      "branch": "分支",
      "branchPlaceholder": "main",
      "path": "技能路径",
      "pathPlaceholder": "skills (可选，留空扫描根目录)",
      "add": "添加仓库",
      "list": "已添加的仓库",
      "empty": "暂无仓库",
      "invalidUrl": "无效的仓库 URL 格式",
      "addSuccess": "仓库 {{owner}}/{{name}} 已添加，识别到 {{count}} 个技能",
      "addFailed": "添加失败",
      "removeSuccess": "仓库 {{owner}}/{{name}} 已删除",
      "removeFailed": "删除失败",
      "skillCount": "识别到 {{count}} 个技能"
    },
    "search": "搜索技能",
    "searchPlaceholder": "搜索技能名称或仓库名称...",
    "installedSearchPlaceholder": "搜索已安装技能的名称、描述或仓库...",
    "installedSearchAriaLabel": "搜索已安装技能",
    "noInstalledSearchResults": "未找到匹配的已安装技能",
    "searchSource": {
      "repos": "仓库",
      "skillssh": "skills.sh"
    },
    "skillssh": {
      "searchPlaceholder": "搜索 skills.sh（至少 2 个字符）...",
      "installs": "{{count}} 次安装",
      "loadMore": "加载更多",
      "loading": "正在搜索 skills.sh...",
      "noResults": "未找到 \"{{query}}\" 相关技能",
      "error": "搜索 skills.sh 失败",
      "poweredBy": "由 skills.sh 提供"
    },
    "filter": {
      "placeholder": "状态筛选",
      "all": "全部",
      "installed": "已安装",
      "uninstalled": "未安装",
      "repo": "仓库筛选",
      "allRepos": "全部仓库"
    },
    "noResults": "未找到匹配的技能",
    "noInstalled": "暂无已安装的技能",
    "noInstalledDescription": "从仓库发现并安装技能，或导入已有的技能",
    "discover": "发现技能",
    "import": "导入已有",
    "importDescription": "选择要导入到 CC Switch 统一管理的技能",
    "importSuccess": "成功导入 {{count}} 个技能",
    "importSelected": "导入已选 ({{count}})",
    "noUnmanagedFound": "未发现需要导入的技能。所有技能已在 CC Switch 统一管理中。",
    "unmanagedAvailable": "发现可导入的技能",
    "foundIn": "发现于",
    "local": "本地",
    "uninstallConfirm": "确定要卸载技能 \"{{name}}\" 吗？这将从所有应用中移除该技能，并在删除前自动创建本地备份。",
    "uninstallInMainPanel": "请在主面板中卸载技能",
    "notFound": "未找到技能",
    "backup": {
      "location": "备份位置: {{path}}"
    },
    "restoreFromBackup": {
      "button": "从备份中恢复",
      "title": "从备份中恢复",
      "description": "选择一个 Skills 备份，将文件恢复到本地并重新加入当前列表。",
      "empty": "暂无可恢复的 Skills 备份",
      "createdAt": "备份时间",
      "path": "备份路径",
      "restore": "恢复",
      "restoring": "恢复中...",
      "delete": "删除",
      "deleting": "删除中...",
      "deleteSuccess": "技能备份 {{name}} 已删除",
      "deleteFailed": "删除技能备份失败",
      "deleteConfirmTitle": "确认删除备份",
      "deleteConfirmMessage": "确定要删除技能备份 \"{{name}}\" 吗？此操作无法撤销。",
      "success": "技能 {{name}} 已从备份恢复",
      "failed": "从备份恢复失败"
    },
    "apps": {
      "claude": "Claude",
      "codex": "Codex",
      "gemini": "Gemini",
      "opencode": "OpenCode",
      "openclaw": "OpenClaw"
    },
    "installFromZip": {
      "button": "从 ZIP 安装",
      "installing": "安装中...",
      "successSingle": "技能 {{name}} 已安装",
      "successMultiple": "成功安装 {{count}} 个技能",
      "noSkillsFound": "ZIP 文件中未找到技能（需包含 SKILL.md 文件）"
    }
  },
  "deeplink": {
    "confirmImport": "确认导入供应商配置",
    "confirmImportDescription": "以下配置将导入到 CC Switch",
    "importPrompt": "导入提示词",
    "importPromptDescription": "请确认是否导入此系统提示词",
    "importMcp": "导入 MCP Servers",
    "importMcpDescription": "请确认是否导入这些 MCP Servers",
    "importSkill": "添加 Skill 仓库",
    "importSkillDescription": "请确认是否添加此 Skill 仓库",
    "promptImportSuccess": "提示词导入成功",
    "promptImportSuccessDescription": "已导入提示词: {{name}}",
    "mcpImportSuccess": "MCP Servers 导入成功",
    "mcpImportSuccessDescription": "成功导入 {{count}} 个服务器",
    "mcpPartialSuccess": "部分导入成功",
    "mcpPartialSuccessDescription": "成功: {{success}}, 失败: {{failed}}",
    "skillImportSuccess": "Skill 仓库添加成功",
    "skillImportSuccessDescription": "已添加仓库: {{repo}}",
    "app": "应用类型",
    "providerName": "供应商名称",
    "homepage": "官网地址",
    "endpoint": "API 端点",
    "apiKey": "API 密钥",
    "icon": "图标",
    "model": "模型",
    "haikuModel": "Haiku 模型",
    "sonnetModel": "Sonnet 模型",
    "opusModel": "Opus 模型",
    "multiModel": "多模态模型",
    "notes": "备注",
    "import": "导入",
    "importing": "导入中...",
    "warning": "请确认以上信息准确无误后再导入。导入后可在供应商列表中编辑或删除。",
    "parseError": "深链接解析失败",
    "importSuccess": "导入成功",
    "importSuccessDescription": "供应商 \"{{name}}\" 已成功导入",
    "importError": "导入失败",
    "configSource": "配置来源",
    "configEmbedded": "内嵌配置",
    "configRemote": "远程配置",
    "configDetails": "配置详情",
    "configUrl": "配置文件 URL",
    "configMergeError": "合并配置文件失败",
    "primaryEndpoint": "主",
    "mcp": {
      "title": "批量导入 MCP Servers",
      "targetApps": "目标应用",
      "serverCount": "MCP Servers ({{count}} 个)",
      "enabledWarning": "导入后将立即写入所有指定应用的配置文件",
      "command": "命令",
      "args": "参数",
      "env": "环境",
      "url": "地址"
    },
    "prompt": {
      "title": "导入系统提示词",
      "app": "应用",
      "name": "名称",
      "description": "描述",
      "contentPreview": "内容预览",
      "enabledWarning": "导入后将立即启用此提示词，其他提示词将被禁用"
    },
    "skill": {
      "title": "添加 Claude Skill 仓库",
      "repo": "GitHub 仓库",
      "directory": "目标目录",
      "branch": "分支",
      "skillsPath": "Skills 路径",
      "hint": "此操作将添加 Skill 仓库到列表。",
      "hintDetail": "添加后，您可以在 Skills 管理界面中选择安装具体的 Skill。"
    },
    "usageScript": "用量查询",
    "usageScriptEnabled": "已启用",
    "usageScriptDisabled": "未启用",
    "usageScriptCode": "脚本代码",
    "usageScriptWarning": "这是一段 JavaScript 代码，启用后会在查询用量时执行。请确认来源可信后再导入。",
    "usageApiKey": "用量 API Key",
    "usageBaseUrl": "用量查询地址",
    "usageAccessToken": "用量访问令牌",
    "usageUserId": "用量用户 ID",
    "usageAutoInterval": "自动查询",
    "usageAutoIntervalValue": "每 {{minutes}} 分钟",
    "risk": {
      "envHijack": "该配置包含可改变进程加载行为的环境变量（如注入动态库、替换 CA 证书），请确认来源可信。",
      "privateEndpoint": "该地址指向本机或内网。若非你自建的本地服务，请勿导入。",
      "shellCommand": "该配置通过 shell 执行一整段命令，实际运行的内容在参数里，请逐行核对。"
    }
  },
  "iconPicker": {
    "search": "搜索图标",
    "searchPlaceholder": "输入图标名称...",
    "noResults": "未找到匹配的图标",
    "category": {
      "aiProvider": "AI 服务商",
      "cloud": "云平台",
      "tool": "开发工具",
      "other": "其他"
    }
  },
  "providerIcon": {
    "label": "图标",
    "colorLabel": "图标颜色",
    "selectIcon": "选择图标",
    "preview": "预览",
    "clickToChange": "点击更换图标",
    "clickToSelect": "点击选择图标"
  },
  "migration": {
    "success": "配置迁移成功",
    "skillsSuccess": "已自动导入 {{count}} 个技能到统一管理",
    "skillsFailed": "自动导入技能失败",
    "skillsFailedDescription": "请打开 Skills 页面点击“导入已有”手动导入（或重启后再试）。"
  },
  "agents": {
    "title": "智能体"
  },
  "health": {
    "operational": "正常",
    "degraded": "降级",
    "failed": "失败",
    "circuitOpen": "熔断",
    "consecutiveFailures": "连续失败 {{count}} 次"
  },
  "failover": {
    "enabled": "{{app}} 故障转移已启用",
    "disabled": "{{app}} 故障转移已关闭",
    "toggleFailed": "操作失败: {{detail}}",
    "inQueue": "已加入",
    "addQueue": "加入",
    "priority": {
      "tooltip": "故障转移优先级 {{priority}}"
    },
    "tooltip": {
      "enabled": "{{app}} 故障转移已启用\n按队列优先级（P1→P2→...）选择供应商",
      "disabled": "启用 {{app}} 故障转移\n将立即切换到队列 P1，并在失败时自动切换到下一个",
      "takeoverRequired": "请先接管 {{app}}，再启用故障转移"
    }
  },
  "proxy": {
    "panel": {
      "serviceAddress": "服务地址",
      "addressCopied": "地址已复制",
      "currentProvider": "当前 Provider：",
      "waitingFirstRequest": "当前 Provider：等待首次请求…",
      "stoppedTitle": "路由服务已停止",
      "stoppedDescription": "使用上方开关即可启动服务",
      "openSettings": "配置路由服务",
      "stats": {
        "activeConnections": "活跃连接",
        "totalRequests": "总请求数",
        "successRate": "成功率",
        "uptime": "运行时间"
      }
    },
    "settings": {
      "title": "路由服务设置",
      "description": "配置本地路由服务器的监听地址、端口和运行参数，保存后立即生效。",
      "alert": {
        "autoApply": "保存后将自动同步到正在运行的路由服务，无需手动重启。"
      },
      "basic": {
        "title": "基础设置",
        "description": "配置路由服务监听的地址与端口。"
      },
      "advanced": {
        "title": "高级参数",
        "description": "控制请求的稳定性和日志记录。"
      },
      "timeout": {
        "title": "超时设置",
        "description": "配置流式和非流式请求的超时时间。"
      },
      "fields": {
        "listenAddress": {
          "label": "监听地址",
          "placeholder": "127.0.0.1",
          "description": "路由服务器监听的 IP 地址（推荐 127.0.0.1）"
        },
        "listenPort": {
          "label": "监听端口",
          "placeholder": "15721",
          "description": "路由服务器监听的端口号（1024 ~ 65535）"
        },
        "maxRetries": {
          "label": "最大重试次数",
          "placeholder": "3",
          "description": "请求失败时的重试次数（0 ~ 10）"
        },
        "requestTimeout": {
          "label": "请求超时（秒）",
          "placeholder": "0（不限）或 300",
          "description": "单个请求的最大等待时间（0 表示不限制，或设置 10 ~ 600 秒）"
        },
        "enableLogging": {
          "label": "记录请求用量",
          "description": "将路由请求的用量与状态写入本地统计数据库"
        },
        "streamingFirstByteTimeout": {
          "label": "流式首字超时（秒）",
          "description": "等待首个数据块的最大时间"
        },
        "streamingIdleTimeout": {
          "label": "流式静默超时（秒）",
          "description": "数据块之间的最大间隔"
        },
        "nonStreamingTimeout": {
          "label": "非流式超时（秒）",
          "description": "非流式请求的总超时时间"
        }
      },
      "validation": {
        "addressInvalid": "请输入有效的IP地址",
        "portMin": "端口必须大于1024",
        "portMax": "端口必须小于65535",
        "retryMin": "重试次数不能为负",
        "retryMax": "重试次数不能超过10",
        "timeoutNonNegative": "超时时间不能为负数",
        "timeoutMax": "超时时间最多600秒",
        "timeoutRange": "请输入 0 或 10-600 之间的数值",
        "streamingTimeoutMin": "超时时间至少5秒",
        "streamingTimeoutMax": "超时时间最多300秒"
      },
      "actions": {
        "save": "保存配置"
      },
      "toast": {
        "saved": "路由配置已保存",
        "saveFailed": "保存失败: {{error}}"
      },
      "invalidPort": "端口无效，请输入 1024-65535 之间的数字",
      "invalidAddress": "地址无效，请输入 IPv4（如 127.0.0.1）、IPv6（如 ::1）或 localhost",
      "configSaved": "路由配置已保存",
      "configSaveFailed": "保存配置失败",
      "restartRequired": "修改地址或端口后需要重启路由服务才能生效"
    },
    "switchFailed": "切换失败: {{error}}",
    "takeover": {
      "ariaLabel": "{{appLabel}} 本地路由",
      "hint": "选择要路由的应用，启用后该应用的请求将通过本地路由转发",
      "enabled": "{{app}} 路由已启用",
      "disabled": "{{app}} 路由已关闭",
      "failed": "切换路由状态失败: {{detail}}",
      "tooltip": {
        "active": "{{appLabel}} 路由中 - {{address}}:{{port}}\n切换该应用供应商为热切换",
        "broken": "{{appLabel}} 路由中，但路由服务未运行",
        "inactive": "路由 {{appLabel}} 的请求，让该应用请求走本地路由"
      }
    },
    "failover": {
      "proxyRequired": "需要先启动路由服务才能配置故障转移",
      "autoSwitch": "自动故障转移",
      "autoSwitchDescription": "开启后将立即切换到队列 P1，并在请求失败时自动切换到队列中的下一个供应商"
    },
    "failoverQueue": {
      "title": "故障转移队列",
      "description": "管理各应用的供应商故障转移顺序",
      "info": "启用自动故障转移后，将按队列优先级选择供应商（P1 优先）。当请求失败时，系统会按队列顺序依次尝试下一个供应商。",
      "selectProvider": "选择供应商添加到队列",
      "noAvailableProviders": "没有可添加的供应商",
      "empty": "故障转移队列为空。添加供应商以启用自动故障转移。",
      "orderHint": "队列顺序与首页供应商列表顺序一致，可在首页拖拽调整顺序。",
      "dragHint": "拖拽供应商可调整故障转移顺序，序号越小优先级越高。",
      "toggleEnabled": "启用/禁用",
      "addSuccess": "已添加到故障转移队列",
      "addFailed": "添加失败",
      "removeSuccess": "已从故障转移队列移除",
      "removeFailed": "移除失败",
      "reorderSuccess": "队列顺序已更新",
      "reorderFailed": "更新顺序失败",
      "toggleFailed": "状态更新失败"
    },
    "autoFailover": {
      "info": "当故障转移队列中配置了多个供应商时，系统会在请求失败时按优先级顺序依次尝试。当某个供应商连续失败达到阈值时，熔断器会打开并在一段时间内跳过该供应商。",
      "configSaved": "自动故障转移配置已保存",
      "configSaveFailed": "保存失败",
      "validationFailed": "以下字段超出有效范围: {{fields}}",
      "retrySettings": "重试与超时设置",
      "failureThreshold": "失败阈值",
      "failureThresholdHint": "连续失败多少次后打开熔断器（建议: 3-10）",
      "timeout": "恢复等待时间（秒）",
      "timeoutHint": "熔断器打开后，等待多久后尝试恢复（建议: 30-120）",
      "circuitBreakerSettings": "熔断器设置",
      "successThreshold": "恢复成功阈值",
      "successThresholdHint": "半开状态下成功多少次后关闭熔断器",
      "errorRate": "错误率阈值 (%)",
      "errorRateHint": "错误率超过此值时打开熔断器",
      "minRequests": "最小请求数",
      "minRequestsHint": "计算错误率前的最小请求数",
      "explanationTitle": "工作原理",
      "failureThresholdLabel": "失败阈值",
      "failureThresholdExplain": "连续失败达到此次数时，熔断器打开，该供应商暂时不可用",
      "timeoutLabel": "恢复等待时间",
      "timeoutExplain": "熔断器打开后，等待此时间后尝试半开状态",
      "successThresholdLabel": "恢复成功阈值",
      "successThresholdExplain": "半开状态下，成功达到此次数时关闭熔断器，供应商恢复可用",
      "errorRateLabel": "错误率阈值",
      "errorRateExplain": "错误率超过此值时，即使未达到失败阈值也会打开熔断器",
      "maxRetries": "最大重试次数",
      "timeoutSettings": "超时配置",
      "streamingFirstByte": "流式首字节超时",
      "streamingIdle": "流式静默超时",
      "nonStreaming": "非流式超时",
      "maxRetriesHint": "请求失败时的重试次数（0-10）",
      "streamingFirstByteHint": "等待首个数据块的最大时间，范围 1-120 秒，默认 60 秒",
      "streamingIdleHint": "数据块之间的最大间隔，范围 60-600 秒，填 0 禁用（防止中途卡住）",
      "nonStreamingHint": "非流式请求的总超时时间，范围 60-1200 秒，默认 600 秒（10 分钟）"
    },
    "logging": {
      "enabled": "日志记录已启用",
      "disabled": "日志记录已关闭",
      "failed": "切换日志状态失败"
    },
    "server": {
      "started": "路由服务已启动 - {{address}}:{{port}}",
      "startFailed": "启动路由服务失败: {{detail}}",
      "stopped": "路由服务已停止",
      "stopFailed": "停止路由服务失败：{{detail}}"
    },
    "stoppedWithRestore": "路由服务已关闭，已恢复所有路由配置",
    "stopWithRestoreFailed": "停止失败: {{detail}}"
  },
  "streamCheck": {
    "reachable": "{{providerName}} 连通正常 ({{responseTimeMs}}ms)",
    "reachableSlow": "{{providerName}} 连通但较慢 ({{responseTimeMs}}ms)",
    "unreachable": "{{providerName}} 无法连通: {{message}}",
    "unreachableHint": "无法建立连接（DNS / 连接 / TLS / 超时）。请检查 base_url 与网络。",
    "connectivityNote": "连通检测仅探测供应商地址是否可达，不发送真实模型请求。收到任意响应即视为“可达”——这不代表鉴权或模型配置一定正确。",
    "configSaved": "连通检测配置已保存",
    "configSaveFailed": "保存失败",
    "checkParams": "检查参数",
    "timeout": "超时时间（秒）",
    "maxRetries": "最大重试次数",
    "degradedThreshold": "较慢阈值（毫秒）",
    "error": "{{providerName}} 检查出错: {{error}}"
  },
  "proxyConfig": {
    "proxyEnabled": "路由总开关",
    "appTakeover": "路由启用",
    "perAppConfig": "应用配置",
    "circuitBreaker": "熔断器配置",
    "circuitBreakerSettings": "熔断器设置",
    "failureThreshold": "失败阈值",
    "successThreshold": "恢复阈值",
    "recoveryTimeout": "恢复等待时间",
    "errorRateThreshold": "错误率阈值",
    "minRequests": "最小请求数",
    "timeoutConfig": "超时配置",
    "streamingFirstByte": "流式首字节超时",
    "streamingIdle": "流式静默超时",
    "nonStreaming": "非流式超时"
  },
  "universalProvider": {
    "duplicate": "复制",
    "duplicatedAndSynced": "统一供应商已复制并同步",
    "duplicateError": "复制统一供应商失败",
    "title": "统一供应商",
    "description": "统一供应商可以同时管理 Claude、Codex 和 Gemini 的配置。修改后会自动同步到所有启用的应用。",
    "add": "添加统一供应商",
    "edit": "编辑统一供应商",
    "empty": "还没有统一供应商",
    "emptyHint": "点击下方「添加统一供应商」按钮创建一个",
    "selectPreset": "选择预设类型",
    "name": "名称",
    "namePlaceholder": "例如：我的 NewAPI",
    "baseUrl": "API 地址",
    "apiKey": "API Key",
    "websiteUrl": "官网地址",
    "websiteUrlPlaceholder": "https://example.com（可选，用于在列表中显示）",
    "notes": "备注",
    "notesPlaceholder": "可选：添加备注信息",
    "enabledApps": "启用的应用",
    "modelConfig": "模型配置",
    "model": "模型",
    "sync": "同步到应用",
    "synced": "已同步到所有应用",
    "syncError": "同步失败",
    "noAppsEnabled": "未启用任何应用",
    "added": "统一供应商已添加",
    "addedAndSynced": "统一供应商已添加并同步",
    "addedButSyncFailed": "统一供应商已添加，但同步失败",
    "updated": "统一供应商已更新",
    "deleted": "统一供应商已删除",
    "addFailed": "统一供应商添加失败",
    "hint": "跨应用统一配置，自动同步到 Claude/Codex/Gemini",
    "manage": "管理",
    "loadError": "加载统一供应商失败",
    "saveError": "保存统一供应商失败",
    "deleteError": "删除统一供应商失败",
    "deleteConfirmTitle": "删除统一供应商",
    "deleteConfirmDescription": "确定要删除 \"{{name}}\" 吗？这将同时删除它在各应用中生成的供应商配置。",
    "syncConfirmTitle": "同步统一供应商",
    "syncConfirmDescription": "同步 \"{{name}}\" 将会覆盖 Claude、Codex 和 Gemini 中关联的供应商配置。确定要继续吗？",
    "syncConfirm": "同步",
    "saveAndSync": "保存并同步",
    "savedAndSynced": "已保存并同步到所有应用",
    "saveAndSyncError": "保存并同步失败",
    "configJsonPreview": "配置 JSON 预览",
    "configJsonPreviewHint": "以下是将要同步到各应用的配置内容（仅覆盖显示的字段，保留其他自定义配置）"
  },
  "omo": {
    "editProfile": "编辑 OMO 配置",
    "newProfile": "新建 OMO 配置",
    "profileName": "名称",
    "mainAgents": "主 Agent",
    "subAgents": "子 Agent",
    "categories": "分类",
    "customAgents": "自定义 Agent",
    "noCustomAgents": "暂无自定义 Agent",
    "otherFields": "其他配置",
    "globalConfig": "OMO 全局配置",
    "globalConfigShort": "OMO 配置",
    "globalConfigSaved": "全局配置已保存",
    "addProfile": "添加 OMO 配置",
    "disabledItems": "禁用项设置",
    "advanced": "高级设置",
    "profileCreated": "OMO 配置已创建",
    "profileUpdated": "OMO 配置已更新",
    "invalidJson": "其他字段包含无效 JSON",
    "confirmDelete": "删除配置",
    "confirmDeleteMsg": "确定删除 \"{{name}}\" 吗？",
    "profileDeleted": "配置已删除",
    "imported": "已导入为 \"{{name}}\"",
    "import": "导入",
    "global": "全局",
    "empty": "暂无配置。点击 + 添加或从本地导入。",
    "applied": "已应用",
    "apply": "应用",
    "enable": "启用",
    "enabled": "启用中",
    "disabled": "OMO 已停用",
    "disableFailed": "停用 OMO 失败: {{error}}",
    "selectPlaceholder": "请选择...",
    "clear": "清空",
    "clearWrapped": "（清空）",
    "defaultWrapped": "（默认）",
    "variantPlaceholder": "思考等级",
    "selectEnabledModel": "选择已配置模型",
    "selectModel": "选择已配置模型",
    "recommendedHint": "推荐: {{model}}",
    "searchModel": "搜索模型...",
    "selectModelFirst": "先选择模型",
    "noEnabledModels": "暂无已配置模型",
    "noVariantsForModel": "该模型无思考等级",
    "currentValueNotEnabled": "{{value}}（当前值，未配置）",
    "currentValueUnavailable": "{{value}}（当前值，不可用）",
    "advancedLabel": "高级参数",
    "advancedJsonInvalid": "高级参数 JSON 无效",
    "advancedJsonHint": "temperature, top_p, budgetTokens, prompt_append, permission 等，留空使用默认值",
    "noEnabledModelsWarning": "当前没有可用的已配置模型，请先配置 OpenCode 模型",
    "modelSourcePartialWarning": "部分供应商模型配置无效，已自动跳过。",
    "modelSourceFallbackWarning": "读取 live 供应商状态失败，已回退到已配置供应商列表。",
    "runtimeModelsFailedWarning": "读取 OpenCode 运行时模型失败，已仅展示已配置供应商模型。",
    "importLocalReplaceSuccess": "已从本地文件导入并覆盖 Agent/Category/Other Fields",
    "importLocalFailed": "读取本地文件失败: {{error}}",
    "agentKeyPlaceholder": "agent 键名",
    "categoryKeyPlaceholder": "分类键名",
    "modelNamePlaceholder": "模型名",
    "custom": "自定义",
    "customCategories": "自定义分类",
    "modelConfiguration": "模型配置",
    "fillRecommended": "填充推荐",
    "fillRecommendedSuccess": "已填充 {{count}} 个推荐模型",
    "fillRecommendedPartial": "已填充 {{filled}} 个推荐模型，{{unmatched}} 个未匹配",
    "fillRecommendedMostlyUnmatched": "仅填充了 {{filled}} 个，{{unmatched}} 个未匹配（如 {{examples}}）。请配置提供这些模型的供应商，或手动选择替代项。",
    "fillRecommendedAllSet": "所有槽位已有模型配置",
    "fillRecommendedNoMatch": "推荐模型在已配置的供应商中未找到匹配（如 {{examples}}）",
    "configSummary": "已配置 {{agents}} 个 Agent，{{categories}} 个 Category · 点击 ⚙ 展开高级参数",
    "enabledModelsCount": "可选已配置模型 {{count}} 个",
    "source": "来源:",
    "otherFieldsJson": "其他字段 (JSON)",
    "slimOtherFieldsHint": "OMO Slim 的 council、fallback、multiplexer、disabled_mcps、todoContinuation 等顶层配置请写在这里。",
    "searchOrType": "搜索或输入自定义值...",
    "noMatches": "无匹配项",
    "jsonMustBeObject": "{{field}} 必须是 JSON 对象",
    "jsonInvalid": "{{field}} 包含无效 JSON",
    "importGlobalSuccess": "已从本地文件导入全局配置（未保存）",
    "importGlobalFailed": "读取本地文件失败: {{error}}",
    "importLocal": "从本地导入",
    "saveGlobalConfig": "保存全局配置",
    "schemaUrl": "$schema",
    "resetDefault": "重置默认",
    "sisyphusAgentConfig": "Sisyphus Agent 设置",
    "disabledAgents": "Agents",
    "disabledAgentsPlaceholder": "禁用的 Agents",
    "disabledMcps": "MCPs",
    "disabledMcpsPlaceholder": "禁用的 MCPs",
    "disabledHooks": "Hooks",
    "disabledHooksPlaceholder": "禁用的 Hooks",
    "disabledSkills": "Skills",
    "disabledSkillsPlaceholder": "禁用的 Skills",
    "advancedLsp": "LSP 配置",
    "advancedExperimental": "实验性功能",
    "advancedBackgroundTask": "后台任务",
    "advancedBrowserAutomation": "浏览器自动化",
    "advancedClaudeCode": "Claude Code",
    "agentDesc": {
      "sisyphus": "主编排者",
      "hephaestus": "自主深度工作者",
      "prometheus": "战略规划者",
      "atlas": "任务管理者",
      "oracle": "战略顾问",
      "librarian": "多仓库研究员",
      "explore": "快速代码搜索",
      "multimodalLooker": "媒体分析器",
      "metis": "规划前分析顾问",
      "momus": "计划审查者",
      "sisyphusJunior": "委托任务执行器"
    },
    "agentTooltip": {
      "sisyphus": "主编排器，负责任务规划、委派与并行执行，使用扩展思考（32k 预算），通过 TODO 驱动工作流确保任务完成。",
      "atlas": "主编排器（持有 TODO 列表），负责执行阶段的任务分发与协调，不直接完成所有工作而是委派给专业代理。",
      "prometheus": "战略规划师，通过访谈模式收集需求并制定详细工作计划，仅能在 .sisyphus/ 目录读写 Markdown 文件，从不直接写代码。",
      "hephaestus": "自主深度工作者（「合法工匠」），受 AmpCode 深度模式启发，目标导向执行，行动前会并行启动 2-5 个探索/图书管理员代理进行研究。",
      "oracle": "架构决策与调试顾问，只读咨询代理，提供出色的逻辑推理和深度分析，不能写文件或委派任务。",
      "librarian": "多仓库分析与文档检索专家，深度理解代码库并提供基于证据的答案，擅长查找官方文档和开源实现示例。",
      "explore": "快速代码库探索与上下文 grep 专家，使用轻量级模型进行高速搜索，是理解代码结构的先锋。",
      "multimodalLooker": "视觉内容专家，分析 PDF、图片、图表等非文本媒体，提取其中的信息与洞察。",
      "metis": "计划顾问，在规划前进行预分析，识别隐藏意图、模糊点和 AI 失败点，防止过度工程化。",
      "momus": "计划评审员，高精度验证计划的清晰度、可验证性和完整性，拒绝并要求修订直到计划完美。",
      "sisyphusJunior": "类别生成的执行器，由 category 参数自动生成，专注于执行分配的任务且不能再委派，防止无限委派循环。"
    },
    "categoryDesc": {
      "visualEngineering": "视觉/前端工程",
      "ultrabrain": "超级思考",
      "deep": "深度工作",
      "artistry": "创意/文艺",
      "quick": "快速响应",
      "unspecifiedLow": "通用低配",
      "unspecifiedHigh": "通用高配",
      "writing": "写作"
    },
    "categoryTooltip": {
      "visualEngineering": "前端与视觉工程类别，专注于 UI/UX 设计、样式、动画和界面实现，默认使用 Gemini 3.6 Flash 模型。",
      "ultrabrain": "深度逻辑推理类别，用于需要广泛分析的复杂架构决策，默认使用 GPT-5.3 Codex 的超高推理变体。",
      "deep": "深度自主问题解决类别，目标导向执行，行动前进行彻底研究，适用于需要深度理解的棘手问题。",
      "artistry": "高度创意与艺术性任务类别，激发新颖想法和创造性解决方案，默认使用 Gemini 3.6 Flash 的高推理变体。",
      "quick": "轻量任务类别，用于单文件修改、错别字修复、简单调整等琐碎工作，默认使用 Claude Haiku 4.5 快速模型。",
      "unspecifiedLow": "未归类低工作量任务类别，适用于不适合其他类别且工作量较小的任务，默认使用 Claude Sonnet 4.5。",
      "unspecifiedHigh": "未归类高工作量任务类别，适用于不适合其他类别且工作量较大的任务，默认使用 Claude Opus 5 的最大变体。",
      "writing": "写作类别，专注于文档、散文和技术写作，默认使用 Kimi K2.5 模型。"
    },
    "slimAgentDesc": {
      "orchestrator": "编排者",
      "oracle": "神谕者",
      "librarian": "图书管理员",
      "explorer": "探索者",
      "designer": "设计师",
      "fixer": "修复者",
      "council": "议会"
    },
    "slimAgentTooltip": {
      "orchestrator": "编写执行代码，编排多代理工作流，召唤专家",
      "oracle": "根本原因分析、架构审查、调试指导（只读）",
      "librarian": "文档查询、GitHub 代码搜索（只读）",
      "explorer": "正则搜索、AST 模式匹配、文件发现（只读）",
      "designer": "现代响应式设计、CSS/Tailwind 精通",
      "fixer": "代码实现、重构、测试、验证",
      "council": "多模型共识代理，并行运行多个只读 councillor，再由 master 汇总最终答案。"
    }
  },
  "openclawConfig": {
    "defaultModel": {
      "title": "默认模型",
      "description": "配置 OpenClaw 的默认主模型和回退模型",
      "primary": "主模型",
      "primaryPlaceholder": "例如: deepseek/deepseek-chat",
      "fallbacks": "回退模型",
      "fallbacksPlaceholder": "例如: openrouter/anthropic/claude-sonnet-4.5",
      "addFallback": "添加回退模型",
      "saved": "默认模型配置已保存",
      "saveFailed": "保存默认模型失败"
    },
    "modelCatalog": {
      "title": "模型目录",
      "description": "配置可用模型的别名和允许列表",
      "modelId": "模型 ID",
      "modelIdPlaceholder": "例如: deepseek/deepseek-chat",
      "alias": "别名",
      "aliasPlaceholder": "例如: DeepSeek",
      "addEntry": "添加模型",
      "removeEntry": "移除",
      "saved": "模型目录已保存",
      "saveFailed": "保存模型目录失败",
      "empty": "暂无模型目录配置",
      "emptyHint": "添加模型到目录以配置别名"
    },
    "suggestedDefaults": "应用建议默认配置",
    "suggestedDefaultsHint": "使用此预设推荐的默认模型配置"
  },
  "subscription": {
    "title": "订阅额度",
    "fiveHour": "5小时",
    "sevenDay": "7天",
    "sevenDayFable": "Fable",
    "sevenDayOpus": "7天(Opus)",
    "sevenDaySonnet": "7天(Sonnet)",
    "thirtyDay": "30天",
    "geminiPro": "Pro",
    "geminiFlash": "Flash",
    "geminiFlashLite": "Flash Lite",
    "weeklyLimit": "每周",
    "monthly": "每月",
    "credits": "额度",
    "copilotPremium": "高级请求",
    "utilization": "{{value}}%",
    "resetsIn": "{{time}}后重置",
    "extraUsage": "超额用量",
    "expired": "会话已过期",
    "expiredHint": "请运行 {{tool}} 命令刷新登录",
    "queryFailed": "查询失败",
    "refresh": "刷新"
  },
  "aggregate": {
    "migrationHint": "存量路由 ID 不兼容或重复。普通编辑保留原 ID；转换前请备份，旧会话可能需要重新选择模型。",
    "migrationPreview": "预览旧路由转换",
    "migrationBackup": "下载路由备份",
    "migrationConfirm": "确认转换路由 ID",
    "migrationLimits": "上限",
    "migrationUnlimited": "不限制",

    "enable": "启用聚合路由",
    "title": "聚合供应商",
    "hint": "自身不存端点与密钥，按模型把请求分流到其他供应商。启用后需重启 Claude Desktop 生效。",
    "tier": "档位",
    "targetProvider": "目标供应商",
    "upstreamModel": "上游模型",
    "upstreamModelPlaceholder": "上游模型名",
    "displayName": "显示名",
    "supports1m": "1M 上下文",
    "slotIdPreview": "槽位 ID",
    "addProvider": "新增供应商",
    "defaultTarget": "兜底目标",
    "defaultTargetHint": "未命中任何槽位的请求发往这里（Claude 的内部调用会走它）",
    "notSaveable": "至少添加一个槽位并选择兜底目标后才能保存",
    "modeLockedHint": "聚合路由需要接管请求转发，接入方式已锁定为「模型映射」（代理）。",
    "defaultTargetPlaceholder": "必选：未命中槽位的请求回落到这里",
    "defaultModel": "默认模型",
    "defaultModelPlaceholder": "未设置：跟随排序首位",
    "defaultModelHint": "启动新会话时使用的模型；未设置时取排序第一条",
    "defaultBadge": "默认",
    "expandAll": "全部展开",
    "collapseAll": "全部折叠",
    "addModel": "新增模型",
    "modelsSummaryLadder": "{{count}} 个模型 · {{ladder}} 强度",
    "effortBadgeHeader": "思考",
    "effortLadder": "强度✓",
    "effortLadderTip": "完整思考强度阶梯（low…max），来自真模型 ID",
    "effortToggle": "思考开关",
    "effortToggleTip": "仅扩展思考开/关，无强度档位",
    "effortNone": "✗",
    "effortNoneTip": "溢出 ID：Claude Desktop 不认识，无思考控件",
    "maxEffort": "上限",
    "maxEffortOff": "不限制",
    "removeModel": "删除该模型",
    "aliasRouting": "别名路由（槽位未命中时按前缀转投，先匹配先赢）",
    "aliasPrefix": "请求名前缀",
    "aliasPrefixPlaceholder": "如 claude-sonnet",
    "aliasTarget": "目标槽位",
    "aliasTargetPlaceholder": "选择槽位",
    "addAliasRule": "添加规则",
    "removeAliasRule": "删除该规则",
    "aliasTip": "前缀过宽（如 claude-）会吞掉所有未命中槽位的请求名，注意范围"
  },
  "codexAggregate": {
    "enable": "启用聚合路由",
    "title": "聚合供应商",
    "hint": "自身不存端点与密钥，按模型把请求分流到其他供应商。",
    "model": "模型名",
    "modelPlaceholder": "客户端模型名",
    "targetProvider": "目标供应商",
    "targetProviderPlaceholder": "选择供应商",
    "upstreamModel": "上游模型",
    "upstreamModelPlaceholder": "上游模型名",
    "displayName": "显示名",
    "addSlot": "添加模型",
    "removeSlot": "删除该模型",
    "fetchModels": "获取模型列表",
    "emptyState": "还没有槽位，点击下方「添加模型」开始配置。",
    "defaultTarget": "兜底目标",
    "defaultTargetHint": "未命中任何槽位的请求发往这里",
    "defaultTargetPlaceholder": "必选：未命中槽位的请求回落到这里",
    "defaultModel": "默认模型",
    "defaultModelHint": "Codex CLI 默认选中的模型；未设置时取槽位第一条",
    "defaultModelPlaceholder": "未设置：跟随槽位首位"
  }
}


## Full source: src/i18n/locales/en.json
{
  "app": {
    "title": "CC Switch",
    "description": "All-in-One Assistant for Claude Code, Codex & Gemini CLI"
  },
  "common": {
    "add": "Add",
    "edit": "Edit",
    "delete": "Delete",
    "save": "Save",
    "saving": "Saving...",
    "cancel": "Cancel",
    "confirm": "Confirm",
    "close": "Close",
    "done": "Done",
    "settings": "Settings",
    "about": "About",
    "version": "Version",
    "loading": "Loading...",
    "notInstalled": "Not installed",
    "success": "Success",
    "error": "Error",
    "unknown": "Unknown",
    "enterValidValue": "Please enter a valid value",
    "clear": "Clear",
    "format": "Format",
    "formatSuccess": "Formatted successfully",
    "formatError": "Format failed: {{error}}",
    "copy": "Copy",
    "view": "View",
    "back": "Back",
    "refresh": "Refresh",
    "refreshing": "Refreshing...",
    "import": "Import",
    "all": "All",
    "search": "Search",
    "enableAllForApp": "Enable all for {{app}}",
    "disableAllForApp": "Disable all for {{app}}",
    "bulkToggleFailed": "Failed to update {{count}} item(s)",
    "reset": "Reset",
    "actions": "Actions",
    "deleting": "Deleting...",
    "auto": "Auto",
    "enabled": "Enabled",
    "notSet": "Not Set",
    "collapse": "Collapse"
  },
  "firstRunNotice": {
    "title": "Welcome to CC Switch",
    "bodyDefault": "CC Switch lets you switch between multiple Claude Code / Codex / Gemini CLI providers with a single click. If you already had these tools configured, CC Switch has saved your existing setup as a provider named “default” so none of your previous configuration is lost.",
    "bodyOfficial": "An “Official” preset is also included in the list — click it any time you want to switch back to the official default. CC Switch automatically backs up your current config to “default” before switching, so you can move back and forth freely. That's how CC Switch works 😊",
    "confirm": "Got it"
  },
  "apiKeyInput": {
    "placeholder": "Enter API Key",
    "show": "Show API Key",
    "hide": "Hide API Key"
  },
  "jsonEditor": {
    "mustBeObject": "Configuration must be a JSON object, not an array or other type",
    "invalidJson": "Invalid JSON format"
  },
  "commonConfig": {
    "guideTitle": "What is a Common Config Snippet?",
    "guidePurpose": "It lets you share non-sensitive settings (plugins, environment variables, etc.) across different providers. These settings won't be lost when you switch providers.",
    "guideUsage": "How to use: ① Click \"Extract from Editor\" to save the common parts  ② Check \"Apply Common Config\" when creating a new provider",
    "guideReExtract": "If you've newly installed plugins or hooks, re-extract the common config so they sync to other providers.",
    "guideReassurance": "Don't worry — your original configuration is safely stored in the default provider and won't be lost.",
    "emptyTitle": "No common config snippet yet",
    "emptyHint": "Click \"Extract from Editor\" below to extract reusable parts from your current configuration"
  },
  "claudeConfig": {
    "configLabel": "Claude Code settings.json (JSON) *",
    "writeCommonConfig": "Apply Common Config",
    "editCommonConfig": "Edit Common Config",
    "editCommonConfigTitle": "Edit Common Config Snippet",
    "commonConfigHint": "This snippet will be merged into settings.json when 'Apply Common Config' is checked",
    "fullSettingsHint": "Full Claude Code settings.json content",
    "extractFromCurrent": "Extract from Editor",
    "extractNoCommonConfig": "No common config available to extract from editor",
    "extractFailed": "Extract failed: {{error}}",
    "saveFailed": "Save failed: {{error}}",
    "hideAttribution": "Hide AI Attribution",
    "enableTeammates": "Teammates Mode",
    "enableToolSearch": "Enable Tool Search",
    "effortMax": "Max Effort Thinking",
    "disableAutoUpgrade": "Disable Auto-Upgrade",
    "disableArtifact": "Disable Artifact Tool"
  },
  "header": {
    "viewOnGithub": "View on GitHub",
    "toggleDarkMode": "Switch to Dark Mode",
    "toggleLightMode": "Switch to Light Mode",
    "addProvider": "Add Provider",
    "switchToChinese": "Switch to Chinese",
    "switchToEnglish": "Switch to English",
    "enterEditMode": "Enter Edit Mode",
    "exitEditMode": "Exit Edit Mode",
    "windowMinimize": "Minimize window",
    "windowMaximize": "Maximize window",
    "windowRestore": "Restore window",
    "windowClose": "Close window"
  },
  "provider": {
    "connectivityCheck": "Connectivity check",
    "tabProvider": "Provider",
    "tabUniversal": "Universal",
    "noProviders": "No providers added yet",
    "noProvidersDescription": "If you already have a config, click \"Import Current Config\" — all data will be safely saved in a default provider",
    "noProvidersDescriptionSnippet": "Settings other than API key and endpoint (e.g. plugins) will be saved to a common config snippet for sharing across providers",
    "importCurrent": "Import Current Config",
    "importFromClaude": "Import existing providers from Claude Code",
    "importCurrentDescription": "Import current live config as default provider",
    "currentlyUsing": "Currently Using",
    "enable": "Enable",
    "inUse": "In Use",
    "needsRouting": "Needs Routing",
    "noRoutingSupport": "No Routing Support",
    "blockedByProxyHint": "Can't switch to an official provider while proxy takeover is active",
    "editProvider": "Edit Provider",
    "editProviderHint": "Configuration will be applied to the current provider immediately after update.",
    "deleteProvider": "Delete Provider",
    "addNewProvider": "Add New Provider",
    "addFooterHint": "💡 After choosing a preset, fill in the fields below (e.g. API Key)",
    "addClaudeProvider": "Add Claude Code Provider",
    "addCodexProvider": "Add Codex Provider",
    "addGeminiProvider": "Add Gemini Provider",
    "addOpenCodeProvider": "Add OpenCode Provider",
    "addToConfig": "Add",
    "removeFromConfig": "Remove",
    "setAsDefault": "Set Default",
    "isDefault": "Current Default",
    "inConfig": "Added",
    "addProviderHint": "Fill in the information to quickly switch providers in the list.",
    "editClaudeProvider": "Edit Claude Code Provider",
    "editCodexProvider": "Edit Codex Provider",
    "configError": "Configuration Error",
    "notConfigured": "Not configured for official website",
    "applyToClaudePlugin": "Apply to Claude plugin",
    "removeFromClaudePlugin": "Remove from Claude plugin",
    "dragToReorder": "Drag to reorder",
    "dragHandle": "Drag to reorder",
    "searchPlaceholder": "Search name, notes, or URL...",
    "searchAriaLabel": "Search providers",
    "searchScopeHint": "Matches provider name, notes, and URL.",
    "searchCloseHint": "Press Esc to close",
    "searchCloseAriaLabel": "Close provider search",
    "noSearchResults": "No providers match your search.",
    "duplicate": "Duplicate",
    "sortUpdateFailed": "Failed to update sort order",
    "configureUsage": "Configure usage query",
    "managedByHermes": "Hermes Managed",
    "managedByHermesHint": "Defined in Hermes' providers: dict. Edit or remove it via Hermes Web UI.",
    "openTerminal": "Open Terminal",
    "terminalOpened": "Terminal opened",
    "terminalOpenFailed": "Failed to open terminal",
    "name": "Provider Name",
    "namePlaceholder": "e.g., Claude Official",
    "websiteUrl": "Website URL",
    "notes": "Notes",
    "notesPlaceholder": "e.g., Company dedicated account",
    "configJson": "Config JSON",
    "writeCommonConfig": "Apply Common Config",
    "editCommonConfigButton": "Edit common config",
    "configJsonHint": "Please fill in complete Claude Code configuration",
    "editCommonConfigTitle": "Edit common config snippet",
    "editCommonConfigHint": "Common config snippet will be merged into all providers that enable it",
    "addProvider": "Add Provider",
    "sortUpdated": "Sort order updated",
    "usageSaved": "Usage query configuration saved",
    "usageSaveFailed": "Failed to save usage query configuration",
    "geminiConfig": "Gemini Configuration",
    "geminiConfigHint": "Use .env format to configure Gemini",
    "form": {
      "gemini": {
        "model": "Model",
        "oauthTitle": "OAuth Authentication Mode",
        "oauthHint": "Google official uses OAuth personal authentication, no need to fill in API Key. The browser will automatically open for login on first use.",
        "apiKeyPlaceholder": "Enter Gemini API Key"
      }
    },
    "duplicateLiveIdsLoadFailed": "Failed to read provider identifiers from config, please fix the config and try again"
  },
  "claudeCode": {
    "needsRouting": "Needs Routing",
    "noRoutingSupport": "No Routing Support"
  },
  "codex": {
    "needsRouting": "Needs Routing",
    "noRoutingSupport": "No Routing Support",
    "officialRouting": "Official Account Routing",
    "nativeLogin": "Codex Sign-in",
    "followCodexLogin": "Follow Codex login",
    "followCodexLoginDescription": "The account changes with the current Codex CLI login",
    "openAiAccount": "OpenAI account",
    "accountNotSelected": "No account selected",
    "chooseAccount": "Choose account",
    "accountStatusUnavailable": "Unable to load account details",
    "boundAccountUnavailable": "The linked account is unavailable",
    "accountLoading": "Loading account…"
  },
  "claudeDesktop": {
    "modelConfigTitle": "Model Configuration",
    "modelModeLabel": "Connection Mode",
    "modelModeDirect": "Direct",
    "modelModeProxy": "Model Mapping",
    "officialNotice": "Claude Desktop official providers use the built-in 1P sign-in. No API key or endpoint URL is required.",
    "mode": "Model handling",
    "modeDirect": "Direct",
    "modeProxy": "Requires routing",
    "modelMappingToggle": "Needs model mapping",
    "modelMappingOffHint": "Direct mode works only when the provider accepts Claude Desktop's three role IDs (claude-sonnet-* / claude-opus-* / claude-haiku-*); for any other model name (including legacy IDs like claude-3-5-sonnet-…), select Model Mapping.",
    "modelMappingOnHint": "Claude Desktop only accepts the three role IDs claude-sonnet-* / claude-opus-* / claude-haiku-*. In Model Mapping mode, CC Switch maps these roles to your provider's actual models and keeps local routing running while in use.",
    "routeMapTitle": "Model mapping",
    "routeMapHint": "Fill in the actual request model for each of the Sonnet, Opus, and Haiku tiers. Use the menu display name for branded models such as DeepSeek or Kimi. Any tier left blank inherits the Sonnet tier's model (or the first tier you filled in), so the Haiku that sub-agents call is always available.",
    "routeModelLabel": "Model role",
    "routeRoleSonnet": "Sonnet",
    "routeRoleOpus": "Opus",
    "routeRoleFable": "Fable",
    "routeRoleHaiku": "Haiku",
    "labelOverrideLabel": "Menu display name",
    "upstreamModelLabel": "Requested model",
    "supports1mLabel": "Declare 1M",
    "supports1mShort": "1M",
    "directModelListTitle": "Model List",
    "directModelListCollapsedHint": "Native Claude model providers usually do not need this. Claude Desktop will fetch /v1/models automatically.",
    "directModelListHint": "Configure the Sonnet, Opus, and Haiku models available to Claude Desktop. Leave this empty to let Claude Desktop fetch /v1/models automatically. Checking 1M declares 1M context support.",
    "directModelInvalid": "Direct models must use Claude Desktop-recognized Sonnet / Opus / Haiku model IDs",
    "addModel": "Add model",
    "addRoute": "Add model",
    "routeInvalid": "Choose a model role and enter the requested model",
    "routesRequired": "At least one model mapping is required",
    "statusTitle": "Claude Desktop configuration needs attention",
    "statusUnsupported": "This platform does not support writing Claude Desktop 3P configuration yet.",
    "statusStaleRawModels": "The Claude Desktop profile contains model IDs outside the Sonnet / Opus / Haiku role families. Newer Claude Desktop versions may reject it; switch to the current provider again to repair it.",
    "statusMissingRouteMappings": "The current provider has model mapping enabled but no valid routes. Edit the provider and add at least one mapping.",
    "statusGatewayTokenMissing": "The local routing token has not been generated yet. Switching to this provider again will write a new local token.",
    "statusBaseUrlMismatch": "The Claude Desktop profile points to a different URL than the current provider. Current: {{actual}}; expected: {{expected}}. Switch to the current provider again to repair it.",
    "route": {
      "tooltip": {
        "active": "Claude Desktop local routing is running - {{address}}:{{port}}",
        "inactive": "Turn on Claude Desktop local routing for providers that need model mapping or format conversion. Configured address: {{address}}:{{port}}"
      },
      "stopBlockedByTakeover": "Another app is using proxy takeover. Please disable that app's takeover in settings before stopping local routing."
    }
  },
  "notifications": {
    "providerAdded": "Provider added",
    "providerSaved": "Provider configuration saved",
    "providerDeleted": "Provider deleted successfully",
    "switchSuccess": "Switch successful!",
    "codexRestartRequired": "Switched successfully. Restart the client to apply changes.",
    "grokBuildRestartRequired": "Switched successfully. Restart Grok Build to apply changes.",
    "claudeDesktopRestartRequired": "Switched successfully. Restart Claude Desktop to apply changes.",
    "claudeDesktopProxyRestartRequired": "Switched successfully. Keep CC Switch running and restart Claude Desktop to apply changes.",
    "addToConfigSuccess": "Added to config",
    "removeFromConfigSuccess": "Removed from config",
    "removeFromConfigFailed": "Could not remove provider",
    "switchFailedTitle": "Switch failed",
    "switchFailed": "Switch failed: {{error}}",
    "autoImported": "Default provider created from existing configuration",
    "addFailed": "Failed to add provider: {{error}}",
    "saveFailed": "Save failed: {{error}}",
    "saveFailedGeneric": "Save failed, please try again",
    "appliedToClaudePlugin": "Applied to Claude plugin",
    "removedFromClaudePlugin": "Removed from Claude plugin",
    "syncClaudePluginFailed": "Sync Claude plugin failed",
    "skipClaudeOnboardingFailed": "Failed to skip Claude Code first-run confirmation",
    "clearClaudeOnboardingSkipFailed": "Failed to restore Claude Code first-run confirmation",
    "updateSuccess": "Provider updated successfully",
    "updateFailed": "Failed to update provider: {{error}}",
    "deleteSuccess": "Provider deleted",
    "deleteFailed": "Failed to delete provider: {{error}}",
    "settingsSaved": "Settings saved",
    "settingsSaveFailed": "Failed to save settings: {{error}}",
    "proxyRequiredForSwitch": "This provider {{reason}}, requires the routing service to work properly. Start routing first.",
    "proxyReasonCopilot": "uses GitHub Copilot as a Claude provider",
    "proxyReasonOpenAIChat": "uses OpenAI Chat API format",
    "proxyReasonOpenAIResponses": "uses OpenAI Responses API format",
    "proxyReasonAnthropicMessages": "uses Anthropic Messages API format",
    "proxyReasonFullUrl": "has full URL connection mode enabled",
    "proxyReasonManagedOAuth": "uses managed OAuth login (token injected by local routing)",
    "proxyReasonRoutingRequired": "requires local routing to process requests",
    "openAIFormatHint": "This provider uses OpenAI-compatible format and requires the routing service to be enabled",
    "copilotProxyHint": "GitHub Copilot as a Claude provider always requires local routing; routing automatically selects Chat Completions or Responses based on the current model.",
    "openLinkFailed": "Failed to open link",
    "openclawModelsRegistered": "Models have been registered to /model list",
    "openclawDefaultModelSet": "Set as default model",
    "openclawDefaultModelSetFailed": "Failed to set default model",
    "openclawNoModels": "No models configured",
    "openclawModelNotFound": "The selected model no longer exists. Refresh and try again.",
    "backfillWarning": "Switched successfully, but failed to save changes back to the previous provider",
    "codexAuthCleanupFailed": "Switched successfully, but auth.json could not be removed — the official login credentials are still on disk; delete auth.json from the Codex config directory to remove them",
    "windowControlFailed": "Window control failed: {{error}}",
    "officialBlockedByProxy": "Cannot switch to official provider while local routing is active. Using routing with official APIs may cause account bans.",
    "proxyOfficialWarning": "Current provider {{name}} is official. Consider switching to a third-party provider before using local routing.",
    "proxyReasonClaudeDesktop": "Using Claude Desktop local routing mode"
  },
  "confirm": {
    "deleteProvider": "Delete Provider",
    "deleteProviderMessage": "Are you sure you want to delete provider \"{{name}}\"? This action cannot be undone.",
    "removeProvider": "Remove Provider",
    "removeProviderMessage": "Are you sure you want to remove provider \"{{name}}\" from the configuration?\n\nAfter removal, this provider will no longer be active, but the configuration data will be retained in CC Switch. You can re-add it at any time.",
    "piDefaultProviderWarning": "Pi's global default currently points to this provider. If you continue, Pi will try another available model; use /model to choose one or /login to sign in to another provider.",
    "proxy": {
      "title": "Enable Local Routing",
      "message": "Local routing is an advanced feature. Please make sure you understand how it works before enabling.\n\nWe recommend consulting the relevant documentation or your provider for proper configuration.",
      "confirm": "I understand, enable"
    },
    "failover": {
      "title": "Enable Failover",
      "message": "Failover is an advanced feature. Please make sure you understand how it works before enabling.\n\nWe recommend configuring provider priorities in the failover queue first.",
      "confirm": "I understand, enable"
    },
    "unifyCodexHistory": {
      "title": "Unified Codex session history",
      "message": "When enabled, the official subscription and third-party providers share one session history list. Note: resuming an old session across providers may fail because its encrypted_content reasoning cannot be decrypted by another backend.\n\nYou can also migrate your existing official session history into the shared list (originals are backed up to ~/.cc-switch/backups first and can be restored when you turn this off).",
      "migrateExisting": "Also migrate existing official session history",
      "confirm": "I understand, enable"
    },
    "unifyCodexHistoryOff": {
      "title": "Turn off unified session history",
      "message": "After turning this off, the official subscription and third-party providers return to separate history lists. Sessions created while it was on cannot be attributed to a provider, so they stay in the third-party history and the official subscription will not see them.",
      "restoreBackup": "Restore the official sessions migrated at enable time back to the official history (exact restore from backup)",
      "confirm": "Turn off"
    },
    "usage": {
      "title": "Configure Usage Query",
      "message": "Usage query requires a custom script or API parameters. Please make sure you have obtained the necessary information from your provider.\n\nIf unsure how to configure, please consult your provider's documentation first.",
      "confirm": "I understand, configure"
    },
    "autoSync": {
      "title": "Enable Auto Sync",
      "message": "When auto sync is enabled, every database change will be automatically uploaded to the WebDAV server.\n\nThis may result in significant network traffic. Please ensure your network and WebDAV service can handle frequent data transfers.",
      "confirm": "I understand, enable"
    },
    "commonConfig": {
      "title": "About Common Config",
      "message": "The \"Common Config Snippet\" lets you share plugins, environment variables, and other settings across different providers — so they won't be lost when you switch.\n\nHow to use:\n① Edit a provider → click \"Edit Common Config\" → \"Extract from Editor\"\n② When creating a new provider, check \"Apply Common Config\" (enabled by default)\n\nIf you've newly installed plugins or hooks, re-extract the common config to keep them in sync.",
      "confirm": "Got it"
    }
  },
  "settings": {
    "title": "Settings",
    "general": "General",
    "tabGeneral": "General",
    "tabAuth": "Auth",
    "tabAdvanced": "Advanced",
    "tabProxy": "Routing",
    "authCenter": {
      "title": "OAuth Authentication Center",
      "description": "Use your other subscriptions in Claude Code — please be mindful of compliance risks.",
      "beta": "Beta",
      "copilotDescription": "Manage GitHub Copilot accounts",
      "codexOauthDescription": "Manage ChatGPT accounts",
      "xaiOauthDescription": "Manage xAI / Grok accounts"
    },
    "advanced": {
      "configDir": {
        "title": "Configuration Directory",
        "description": "Manage storage paths for Claude, Codex and Gemini configurations"
      },
      "proxy": {
        "title": "Local Routing",
        "description": "Control routing service toggle, view status and port info",
        "enableFeature": "Show Routing Toggle on Main Page",
        "enableFeatureDescription": "When enabled, the routing and failover toggles will appear at the top of the main page",
        "enableFailoverToggle": "Show Failover Toggle on Main Page",
        "enableFailoverToggleDescription": "When enabled, the failover toggle will appear independently at the top of the main page",
        "running": "Running",
        "stopped": "Stopped"
      },
      "connectivityCheck": {
        "title": "Connectivity Check Settings",
        "description": "Configure timeout, retries, and the slow-response threshold for provider reachability checks"
      },
      "failover": {
        "title": "Auto Failover",
        "description": "Configure failover queue and circuit breaker strategy"
      },
      "pricing": {
        "title": "Cost Pricing",
        "description": "Manage token pricing rules for each model"
      },
      "globalProxy": {
        "title": "Global Outbound Proxy",
        "description": "Configure proxy for CC Switch to access external APIs"
      },
      "data": {
        "title": "Data Management",
        "description": "Import and export local configuration data"
      },
      "backup": {
        "title": "Backup & Restore",
        "description": "Manage automatic backups, view and restore database snapshots"
      },
      "cloudSync": {
        "title": "Cloud Sync",
        "description": "Sync data across devices via WebDAV"
      },
      "rectifier": {
        "title": "Rectifier",
        "description": "Automatically fix API request compatibility issues",
        "enabled": "Enable Rectifier",
        "enabledDescription": "Master switch, all rectification features will be disabled when turned off",
        "requestGroup": "Request Rectification",
        "responseGroup": "Response Rectification",
        "thinkingSignature": "Thinking Signature Rectification",
        "thinkingSignatureDescription": "When an Anthropic-type provider returns thinking signature incompatibility or illegal request errors, automatically removes incompatible thinking-related blocks and retries once with the same provider",
        "thinkingBudget": "Thinking Budget Rectification",
        "thinkingBudgetDescription": "When an Anthropic-type provider returns budget_tokens constraint errors (such as at least 1024), automatically normalizes thinking to enabled, sets thinking budget to 32000, and raises max_tokens to 64000 if needed, then retries once",
        "mediaFallback": "Unsupported Image Fallback",
        "mediaFallbackDescription": "When a provider does not support image input (it declares text-only capability, or the upstream returns an unsupported-image error), automatically replaces image blocks with an [Unsupported Image] marker so the conversation is not interrupted",
        "mediaHeuristic": "Text-Only Model Preflight",
        "mediaHeuristicDescription": "Before sending, strips images for models in the built-in confirmed text-only registry. Turning this off only disables the proxy's registry-based preflight; declared text-only handling and upstream-error fallback remain, and Codex model-catalog capability declarations are unchanged"
      },
      "optimizer": {
        "title": "Bedrock Request Optimizer",
        "description": "Automatically optimize Thinking and Cache configuration before sending requests (only applies to Bedrock providers)",
        "enabled": "Enable Optimizer",
        "thinkingOptimizer": "Thinking Optimization",
        "thinkingOptimizerDescription": "Automatically enable Adaptive Thinking for Opus/Sonnet, and inject Extended Thinking for legacy models",
        "cacheInjection": "Cache Injection",
        "cacheInjectionDescription": "Automatically inject standard 5-minute cache breakpoints at key positions to reduce duplicate token billing"
      },
      "logConfig": {
        "title": "Application Diagnostic Logs",
        "description": "Control the output level for application diagnostic logs",
        "enabled": "Enable Diagnostic Logs",
        "enabledDescription": "Controls cc-switch.log; request usage records and crash.log are unaffected",
        "level": "Log Level",
        "levelDescription": "Set the minimum log level to output",
        "levels": {
          "error": "Error",
          "warn": "Warning",
          "info": "Info",
          "debug": "Debug",
          "trace": "Trace"
        },
        "levelHint": "Log level descriptions:",
        "levelDesc": {
          "error": "Critical errors only",
          "warn": "Errors + warnings",
          "info": "General operation info (default)",
          "debug": "Detailed info including SSE stream and request/response",
          "trace": "All logs, most verbose"
        }
      }
    },
    "language": "Language",
    "languageHint": "Preview interface language immediately after switching, takes effect permanently after saving.",
    "claudeDesktopDisplay": "Claude Desktop display",
    "claudeDesktopDisplayHint": "Take over the bottom-left display name and attribution (deploymentDisplayName and related keys). When off, nothing is written; an empty name means the whole group is left alone, while an empty subtitle only skips that key — either way the values already set in the Claude Desktop panel are kept.",
    "claudeDesktopDisplayEnable": "Manage display settings",
    "claudeDesktopDisplayName": "Display name",
    "claudeDesktopDisplaySubtitle": "Subtitle",
    "claudeDesktopDisplayAttribution": "User attribution (endUserAttribution)",
    "theme": "Theme",
    "themeHint": "Choose the appearance theme for the app, takes effect immediately.",
    "themeLight": "Light",
    "themeDark": "Dark",
    "themeSystem": "System",
    "importExport": "SQL Import/Export",
    "importExportHint": "Import or export database SQL backups for migration or restore (import supports only backups exported by CC Switch).",
    "exportConfig": "Export SQL Backup",
    "selectConfigFile": "Select SQL File",
    "noFileSelected": "No configuration file selected.",
    "import": "Import",
    "importing": "Importing...",
    "importSuccess": "Import Successful!",
    "importFailed": "Import Failed",
    "syncLiveFailed": "Imported, but failed to sync to the current provider. Please reselect the provider manually.",
    "importPartialSuccess": "Config imported, but failed to sync to the current provider.",
    "importPartialHint": "Please manually reselect the provider to refresh the live configuration.",
    "configExported": "Config exported to:",
    "exportFailed": "Export failed",
    "selectFileFailed": "Please choose a valid SQL backup file",
    "configCorrupted": "SQL file may be corrupted or invalid",
    "backupId": "Backup ID",
    "backupManager": {
      "title": "Database Backups",
      "description": "Automatic database snapshots for restoring to a previous state",
      "empty": "No backups yet",
      "restore": "Restore",
      "restoring": "Restoring...",
      "confirmTitle": "Confirm Restore",
      "confirmMessage": "Restoring this backup will overwrite the current database. A safety backup will be created first.",
      "restoreSuccess": "Restore successful! Safety backup created",
      "restoreFailed": "Restore failed",
      "safetyBackupId": "Safety Backup ID",
      "intervalLabel": "Auto-backup Interval",
      "retainLabel": "Backup Retention",
      "intervalDisabled": "Disabled",
      "intervalHours": "{{hours}} hours",
      "intervalDays": "{{days}} days",
      "rename": "Rename",
      "renameSuccess": "Backup renamed",
      "renameFailed": "Rename failed",
      "namePlaceholder": "Enter new name",
      "createBackup": "Backup Now",
      "creating": "Backing up...",
      "createSuccess": "Backup created successfully",
      "createFailed": "Backup failed",
      "delete": "Delete",
      "deleting": "Deleting...",
      "deleteSuccess": "Backup deleted",
      "deleteFailed": "Delete failed",
      "deleteConfirmTitle": "Confirm Delete",
      "deleteConfirmMessage": "This backup will be permanently deleted. This action cannot be undone."
    },
    "webdavSync": {
      "title": "WebDAV Cloud Sync",
      "description": "Sync database and skill configurations across devices via WebDAV.",
      "baseUrl": "WebDAV Server URL",
      "baseUrlPlaceholder": "https://dav.example.com/dav/",
      "username": "WebDAV Account",
      "usernamePlaceholder": "Email or username",
      "password": "WebDAV Password",
      "passwordPlaceholder": "App password",
      "remoteRoot": "Remote Root Directory",
      "profile": "Sync Profile Name",
      "autoSync": "Auto Sync",
      "autoSyncHint": "When enabled, each database change triggers an automatic WebDAV upload.",
      "test": "Test Connection",
      "testing": "Testing...",
      "testSuccess": "Connection successful",
      "testFailed": "Connection failed: {{error}}",
      "save": "Save Config",
      "saving": "Saving...",
      "saveFailed": "Failed to save config: {{error}}",
      "upload": "Upload to Cloud",
      "uploading": "Uploading...",
      "uploadSuccess": "Uploaded to WebDAV",
      "uploadFailed": "Upload failed: {{error}}",
      "autoSyncFailedToast": "Auto sync failed: {{error}}",
      "download": "Download from Cloud",
      "downloading": "Downloading...",
      "downloadSuccess": "Downloaded and restored from WebDAV",
      "downloadFailed": "Download failed: {{error}}",
      "lastSync": "Last sync: {{time}}",
      "autoSyncLastErrorTitle": "Last auto sync failed",
      "autoSyncLastErrorHint": "Please check network or WebDAV settings. Auto sync will retry on future changes.",
      "missingUrl": "Please enter the WebDAV server URL",
      "presets": {
        "label": "Provider",
        "jianguoyun": "Jianguoyun",
        "jianguoyunHint": "Generate an \"App Password\" in Jianguoyun security settings. Do not use your login password.",
        "nextcloud": "Nextcloud",
        "nextcloudHint": "Replace your-server with your Nextcloud domain and USERNAME with your username.",
        "synology": "Synology NAS",
        "synologyHint": "Install and enable the WebDAV Server package in Synology Package Center first.",
        "custom": "Custom"
      },
      "remoteRootDefault": "Default: cc-switch-sync",
      "profileDefault": "Default: default",
      "saveAndTestSuccess": "Config saved, connection OK",
      "saveAndTestFailed": "Config saved, but connection test failed: {{error}}",
      "noRemoteData": "No sync data found on the remote server",
      "incompatibleVersion": "Remote data is incompatible (protocol v{{protocolVersion}}, database {{dbCompatVersion}}). This client supports protocol v2 / db-v6.",
      "unsaved": "Unsaved",
      "saved": "Saved",
      "unsavedChanges": "Please save config first",
      "saveBeforeSync": "Save configuration first to enable upload/download.",
      "fetchingRemote": "Fetching remote info...",
      "fetchRemoteFailed": "Failed to fetch remote info. Please check configuration and network.",
      "confirmDownload": {
        "title": "Restore from Cloud",
        "deviceName": "Uploaded by",
        "createdAt": "Uploaded at",
        "path": "Remote path",
        "dbCompat": "DB compatibility",
        "artifacts": "Contents",
        "legacyNotice": "A legacy remote path was detected. After restoring, the next upload will write to the new v2/db-v6 path.",
        "warning": "This will overwrite all local data and skill configurations",
        "confirm": "Confirm Restore"
      },
      "confirmUpload": {
        "title": "Upload to Cloud",
        "content": "The following will be synced to the WebDAV server:",
        "dbItem": "Database (all provider configs and data)",
        "skillsItem": "Skills (all custom skills)",
        "targetPath": "Target path",
        "existingData": "Existing cloud data",
        "deviceName": "Uploaded by",
        "createdAt": "Uploaded at",
        "path": "Remote path",
        "dbCompat": "DB compatibility",
        "warning": "This will overwrite existing sync data on the remote server",
        "legacyNotice": "Legacy remote data was detected. This upload will write to the new v2/db-v6 path and will not overwrite the legacy path.",
        "confirm": "Confirm Upload"
      }
    },
    "syncType": {
      "label": "Sync Type",
      "webdav": "WebDAV",
      "s3": "S3 Compatible"
    },
    "s3Sync": {
      "presets": {
        "label": "Provider",
        "awsS3": "AWS S3",
        "awsS3Hint": "Use IAM Access Key with s3:PutObject/GetObject/HeadObject permissions. Region: us-east-1, ap-northeast-1, etc.",
        "minio": "MinIO",
        "minioHint": "Custom endpoint required, e.g. http://minio.local:9000. Region can be 'us-east-1'.",
        "r2": "Cloudflare R2",
        "r2Hint": "Endpoint: https://<account_id>.r2.cloudflarestorage.com. Region: 'auto'.",
        "oss": "Alibaba Cloud OSS",
        "ossHint": "Endpoint: https://oss-<region>.aliyuncs.com. Region: cn-hangzhou, cn-shanghai, etc.",
        "cos": "Tencent Cloud COS",
        "cosHint": "Endpoint: https://cos.<region>.myqcloud.com. Region: ap-guangzhou, ap-beijing, etc.",
        "obs": "Huawei OBS",
        "obsHint": "Endpoint: https://obs.<region>.myhuaweicloud.com. Region: cn-north-4, cn-east-3, etc.",
        "custom": "S3 Compatible (Custom)",
        "customHint": "Any S3-compatible service. Custom endpoint required."
      },
      "region": "Region",
      "regionPlaceholder": "e.g. us-east-1",
      "bucket": "Bucket",
      "bucketPlaceholder": "e.g. my-cc-switch-bucket",
      "accessKeyId": "Access Key ID",
      "accessKeyIdPlaceholder": "e.g. AKIA...",
      "secretAccessKey": "Secret Access Key",
      "secretAccessKeyPlaceholder": "Leave unchanged to keep the existing secret",
      "endpoint": "Endpoint (optional for AWS)",
      "endpointHint": "Required for most S3-compatible services",
      "endpointPlaceholder": "e.g. https://s3-compatible.example.com",
      "remoteRoot": "Remote Root Directory",
      "remoteRootDefault": "Default: cc-switch-sync",
      "profile": "Sync Profile Name",
      "profileDefault": "Default: default",
      "autoSync": "Auto Sync",
      "autoSyncHint": "When enabled, each database change triggers an automatic S3 upload.",
      "enabled": "Enable S3 Sync",
      "enabledHint": "Turn on S3 sync for manual and automatic cloud operations.",
      "mutualExclusionTitle": "Switch Sync Type",
      "mutualExclusionMessage": "Enabling S3 sync will disable the current WebDAV sync. Continue?",
      "mutualExclusionMessageReverse": "Enabling WebDAV sync will disable the current S3 sync. Continue?",
      "mutualExclusionFailed": "Failed to switch sync type: {{error}}",
      "testConnection": "Test Connection",
      "connectionOk": "S3 connection successful",
      "test": "Test Connection",
      "testing": "Testing...",
      "testSuccess": "S3 connection successful",
      "testFailed": "S3 connection failed: {{error}}",
      "save": "Save Config",
      "saving": "Saving...",
      "saveFailed": "Failed to save config: {{error}}",
      "saveAndTestSuccess": "Config saved, S3 connection OK",
      "saveAndTestFailed": "Config saved, but S3 connection test failed: {{error}}",
      "upload": "Upload to Cloud",
      "uploading": "Uploading...",
      "uploadSuccess": "Uploaded to S3",
      "uploadFailed": "S3 upload failed: {{error}}",
      "autoSyncFailedToast": "S3 auto sync failed: {{error}}",
      "download": "Download from Cloud",
      "downloading": "Downloading...",
      "downloadSuccess": "Downloaded and restored from S3",
      "downloadFailed": "S3 download failed: {{error}}",
      "lastSync": "Last sync: {{time}}",
      "autoSyncLastErrorTitle": "Last S3 auto sync failed",
      "autoSyncLastErrorHint": "Please check network or S3 settings. Auto sync will retry on future changes.",
      "missingBucket": "Please enter the S3 bucket",
      "noRemoteData": "No sync data found in the S3 bucket",
      "incompatibleVersion": "Remote data is incompatible (version {{version}}). This client supports protocol v2 / db-v6.",
      "unsaved": "Unsaved",
      "saved": "Saved",
      "unsavedChanges": "Please save config first",
      "saveBeforeSync": "Save configuration first to enable upload/download.",
      "fetchingRemote": "Fetching remote info...",
      "fetchRemoteFailed": "Failed to fetch remote info. Please check configuration and network.",
      "notConfigured": "S3 sync is not configured",
      "disabled": "S3 sync is disabled",
      "confirmDownload": {
        "title": "Restore from S3",
        "deviceName": "Uploaded by",
        "createdAt": "Uploaded at",
        "artifacts": "Contents",
        "warning": "This will overwrite all local data and skill configurations",
        "confirm": "Confirm Restore"
      },
      "confirmUpload": {
        "title": "Upload to S3",
        "content": "The following will be synced to the S3 bucket:",
        "dbItem": "Database (all provider configs and data)",
        "skillsItem": "Skills (all custom skills)",
        "targetPath": "Target object path",
        "existingData": "Existing cloud data",
        "deviceName": "Uploaded by",
        "createdAt": "Uploaded at",
        "warning": "This will overwrite existing sync data at the S3 path",
        "confirm": "Confirm Upload"
      }
    },
    "autoReload": "Data refreshed",
    "languageOptionChinese": "简体中文",
    "languageOptionTraditionalChinese": "繁體中文",
    "languageOptionEnglish": "English",
    "languageOptionJapanese": "日本語",
    "windowBehavior": "Window Behavior",
    "windowBehaviorHint": "Configure window minimize and Claude plugin integration policies.",
    "launchOnStartup": "Launch on Startup",
    "launchOnStartupDescription": "Automatically run CC Switch when system starts",
    "silentStartup": "Silent Startup",
    "silentStartupDescription": "Start in background mode without showing main window",
    "autoLaunchFailed": "Failed to set auto-launch",
    "minimizeToTray": "Minimize to tray on close",
    "minimizeToTrayDescription": "When checked, clicking the close button will hide to system tray, otherwise the app will exit directly.",
    "useAppWindowControls": "Enable app-level window controls",
    "useAppWindowControlsDescription": "Use built-in minimize, maximize/restore, and close buttons in the app header.",
    "enableClaudePluginIntegration": "Apply to Claude Code extension",
    "enableClaudePluginIntegrationDescription": "When enabled, the VS Code Claude Code extension provider will switch with this app",
    "skipClaudeOnboarding": "Skip Claude Code first-run confirmation",
    "skipClaudeOnboardingDescription": "When enabled, Claude Code will skip the first-run confirmation",
    "codexAuth": "Codex App Enhancements",
    "preserveCodexOfficialAuthOnSwitch": "Keep official login for direct switches",
    "preserveCodexOfficialAuthOnSwitchDescription": "Controls third-party switches when local routing is off. Takeover routing always preserves the Codex official login.",
    "unifyCodexSessionHistory": "Unified Codex session history",
    "unifyCodexSessionHistoryDescription": "When enabled, the official subscription runs under the shared \"custom\" provider id so official and third-party sessions appear in one history list, optionally migrating existing official sessions in (backed up first). When turning it off, the migrated sessions can be restored from backup. Note: resuming an old session across providers may fail because its encrypted_content reasoning can only be decrypted by the backend that created it.",
    "unifyCodexHistoryRestoreCompleted": "Official session history restored from backup ({{files}} session files, {{rows}} index rows)",
    "unifyCodexHistoryRestoreFailed": "Failed to restore official session history, please try again",
    "unifyCodexHistoryRestoreNothing": "No restorable migration backup for the current Codex directory",
    "unifyCodexHistoryRestoreSkippedToggleOn": "Unified session history was re-enabled; restore skipped",
    "appVisibility": {
      "title": "Homepage Display",
      "description": "Choose which apps to show on the homepage",
      "claudeDesc": "Anthropic Claude Code CLI",
      "codexDesc": "OpenAI Codex CLI",
      "geminiDesc": "Google Gemini CLI",
      "opencodeDesc": "OpenCode CLI",
      "showProfileSwitcher": "Show project switcher",
      "showProfileSwitcherDescription": "Show the project switcher in the main page header"
    },
    "skillStorage": {
      "title": "Skill Storage Location",
      "description": "Choose where CC Switch stores the master copies of your skills",
      "ccSwitch": "CC Switch",
      "unified": "~/.agents/skills",
      "ccSwitchHint": "Skills are stored in ~/.cc-switch/skills/ and synced to each app via symlink or copy.",
      "unifiedHint": "Skills are stored in ~/.agents/skills/, the Agent Skills open standard. Compatible tools (Claude Code, Codex, Gemini CLI, etc.) discover skills here natively.",
      "confirmTitle": "Migrate Skill Storage",
      "confirmMessage": "{{count}} skill(s) will be moved to the new location. Continue?",
      "migrationSuccess": "Successfully migrated {{count}} skill(s)",
      "migrationPartial": "Migrated {{migrated}} skill(s), {{errors}} error(s). Check logs for details."
    },
    "skillSync": {
      "title": "Skill Sync Method",
      "description": "Choose how to sync Skills files",
      "symlink": "Symlink",
      "copy": "Copy Files",
      "symlinkHint": "Symlinks save disk space and enable real-time sync. Note: May require admin privileges or Developer Mode on Windows"
    },
    "terminal": {
      "title": "Preferred Terminal",
      "description": "Choose which terminal app to use when clicking the terminal button",
      "fallbackHint": "If the selected terminal is unavailable, the system default will be used",
      "options": {
        "macos": {
          "terminal": "Terminal.app",
          "iterm2": "iTerm2",
          "alacritty": "Alacritty",
          "kitty": "Kitty",
          "ghostty": "Ghostty",
          "otty": "Otty",
          "wezterm": "WezTerm",
          "kaku": "Kaku",
          "warp": "Warp"
        },
        "windows": {
          "cmd": "Command Prompt",
          "powershell": "PowerShell",
          "wt": "Windows Terminal"
        },
        "linux": {
          "gnomeTerminal": "GNOME Terminal",
          "konsole": "Konsole",
          "xfce4Terminal": "Xfce4 Terminal",
          "alacritty": "Alacritty",
          "kitty": "Kitty",
          "ghostty": "Ghostty"
        }
      }
    },
    "configDirectoryOverride": "Configuration Directory Override (Advanced)",
    "configDirectoryDescription": "When using Claude Code or Codex in environments like WSL, you can manually specify the configuration directory to the one in WSL to keep provider data consistent with the main environment.",
    "appConfigDir": "CC Switch Configuration Directory",
    "appConfigDirDescription": "Customize the storage location for CC Switch configuration (point to cloud sync folder to enable config sync)",
    "browsePlaceholderApp": "e.g., C:\\Users\\Administrator\\.cc-switch",
    "claudeConfigDir": "Claude Code Configuration Directory",
    "claudeConfigDirDescription": "Override Claude configuration directory (settings.json). Custom directories store .claude.json (MCP) inside the directory; the default ~/.claude directory keeps Claude Code's split ~/.claude.json path.",
    "codexConfigDir": "Codex Configuration Directory",
    "codexConfigDirDescription": "Override Codex configuration directory.",
    "geminiConfigDir": "Gemini Configuration Directory",
    "geminiConfigDirDescription": "Override Gemini configuration directory (.env).",
    "grokConfigDir": "Grok Build Configuration Directory",
    "grokConfigDirDescription": "Override Grok Build configuration directory (config.toml).",
    "opencodeConfigDir": "OpenCode Configuration Directory",
    "opencodeConfigDirDescription": "Override OpenCode configuration directory (opencode.json).",
    "openclawConfigDir": "OpenClaw Configuration Directory",
    "openclawConfigDirDescription": "Override OpenClaw configuration directory (openclaw.json).",
    "hermesConfigDir": "Hermes Configuration Directory",
    "hermesConfigDirDescription": "Override Hermes configuration directory (config.yaml).",
    "piConfigDir": "Pi Configuration Directory",
    "piConfigDirDescription": "Override the Pi configuration directory (models.json, instruction files, prompts, skills, and sessions).",
    "browsePlaceholderClaude": "e.g., /home/<your-username>/.claude",
    "browsePlaceholderCodex": "e.g., /home/<your-username>/.codex",
    "browsePlaceholderGemini": "e.g., /home/<your-username>/.gemini",
    "browsePlaceholderGrok": "e.g., /home/<your-username>/.grok",
    "browsePlaceholderOpencode": "e.g., /home/<your-username>/.config/opencode",
    "browsePlaceholderOpenclaw": "e.g., /home/<your-username>/.openclaw",
    "browsePlaceholderHermes": "e.g., /home/<your-username>/.hermes",
    "browsePlaceholderPi": "e.g., /home/<your-username>/.pi/agent",
    "browseDirectory": "Browse Directory",
    "resetDefault": "Reset to default directory (takes effect after saving)",
    "checkForUpdates": "Check for Updates",
    "updateTo": "Update to v{{version}}",
    "updating": "Updating...",
    "checking": "Checking...",
    "upToDate": "Up to Date",
    "aboutHint": "View version information and update status.",
    "portableMode": "Portable mode: updates require manual download.",
    "updateAvailable": "New version available: {{version}}",
    "updateBadge": "Update available",
    "updateFailed": "Update installation failed, attempted to open download page.",
    "checkUpdateFailed": "Failed to check for updates, please try again later.",
    "viewUpstream": "View upstream status",
    "upstreamPrMerged": "The upstream fix has been merged (PR #5417) — patch A can be dropped at the next sync.",
    "upstreamSyncNeeded": "Local builds cannot auto-update. Follow UPSTREAM-SYNC.md to sync and rebuild.",
    "openReleaseNotesFailed": "Failed to open release notes",
    "releaseNotes": "Release Notes",
    "viewReleaseNotes": "View release notes for this version",
    "viewCurrentReleaseNotes": "View current version release notes",
    "officialWebsite": "Official Website",
    "github": "GitHub",
    "starPrompt": "If CC Switch has helped you, please star us on GitHub — it means a lot to us",
    "manualInstallCommands": "Manual Install Commands",
    "oneClickInstallHint": "Install or upgrade Claude Code / Codex / Gemini CLI / OpenCode / OpenClaw / Hermes / Pi",
    "localEnvCheck": "Local environment check",
    "updateAllTools": "Update All ({{count}})",
    "currentVersion": "Current Version",
    "latestVersion": "Latest Version",
    "updateAvailableShort": "Update",
    "toolInstall": "Install",
    "toolUpdate": "Update",
    "toolReady": "Ready",
    "toolActionDone": "{{action}} completed for {{count}} tool(s)",
    "toolActionPartial": "{{action}} succeeded for {{succeeded}}, failed for {{failed}}",
    "toolActionFailed": "Install/update command failed",
    "toolNotRunnable": "Installed but not runnable (no version detected)",
    "toolActionVersionUnchangedTitle": "Version did not change",
    "toolActionVersionUnchanged": "Still on {{version}} (latest: {{latest}}). The updater may have reported success without applying the update.",
    "toolActionInstalledNotRunnable": "Installed, but it can't run in the current environment — please check",
    "installedNotRunnable": "Installed · can't run",
    "toolCheckEnv": "Check environment",
    "toolDiagnose": "Diagnose installs",
    "toolDiagnosing": "Diagnosing…",
    "toolConflictTitle": "Multiple installations detected",
    "toolConflictHint": "The command line uses the one marked Default; an upgrade may have written to another.",
    "toolConflictDefault": "Default",
    "toolConflictNotRunnable": "can't run",
    "toolDiagnoseNoConflict": "No conflicting installations found",
    "toolDiagnoseFailed": "Diagnosis failed",
    "toolUpgradeConfirmTitle": "Confirm upgrade target",
    "toolUpgradeConfirmHint": "Multiple installations detected. This upgrade won't update all of them; refer to each tool below for what it actually targets.",
    "toolUpgradeWillRun": "Will run:",
    "toolUpgradeConfirmBtn": "Confirm upgrade",
    "toolUpgradeUnanchoredHint": "Can't determine which install your command line uses; will run the default upgrade command (may install to the first npm on PATH).",
    "envBadge": {
      "wsl": "WSL",
      "windows": "Win",
      "macos": "macOS",
      "linux": "Linux"
    },
    "wslShell": "Shell",
    "wslShellFlag": "Flag",
    "installCommandsCopied": "Install commands copied",
    "installCommandsCopyFailed": "Copy failed, please copy manually.",
    "importFailedError": "Import config failed: {{message}}",
    "exportFailedError": "Export config failed:",
    "restartRequired": "Restart Required",
    "restartRequiredMessage": "Modifying the CC Switch configuration directory requires restarting the application to take effect. Restart now?",
    "restartNow": "Restart Now",
    "restartLater": "Restart Later",
    "restartFailed": "Application restart failed, please manually close and reopen.",
    "devModeRestartHint": "Dev Mode: Automatic restart not supported, please manually restart the application.",
    "saving": "Saving...",
    "globalProxy": {
      "label": "Global Proxy",
      "hint": "Proxy all requests (API, Skills download, etc.). When local routing is enabled, app traffic is also routed through this proxy. Leave empty for direct connection.",
      "username": "Username (optional)",
      "password": "Password (optional)",
      "test": "Test Connection",
      "scan": "Scan Local Proxies",
      "clear": "Clear",
      "scanFailed": "Scan failed: {{error}}",
      "saved": "Proxy settings saved",
      "saveFailed": "Save failed: {{error}}",
      "testSuccess": "Connected! Latency {{latency}}ms",
      "testFailed": "Connection failed: {{error}}",
      "pricingDefaultsTitle": "Pricing Defaults",
      "pricingDefaultsDescription": "Set the default multiplier and pricing model source per app.",
      "pricingAppLabel": "App",
      "defaultCostMultiplierLabel": "Default Multiplier",
      "defaultCostMultiplierHint": "Multiplier for cost calculation, decimals supported.",
      "pricingModelSourceLabel": "Pricing Model Source",
      "pricingModelSourceRequest": "Request model",
      "pricingModelSourceResponse": "Response model",
      "pricingSave": "Save Pricing Defaults",
      "pricingSaved": "Pricing defaults saved",
      "pricingSaveFailed": "Failed to save pricing defaults: {{error}}",
      "pricingLoadFailed": "Failed to load pricing defaults: {{error}}",
      "defaultCostMultiplierRequired": "Default multiplier is required",
      "defaultCostMultiplierInvalid": "Invalid multiplier format"
    },
    "saveFailedGeneric": "Save failed, please try again"
  },
  "apps": {
    "claude": "Claude",
    "claudeCode": "Claude Code",
    "claudeDesktop": "Claude Desktop",
    "claude-desktop": "Claude Desktop",
    "codex": "Codex",
    "gemini": "Gemini",
    "grokbuild": "Grok Build",
    "opencode": "OpenCode",
    "openclaw": "OpenClaw",
    "hermes": "Hermes",
    "pi": "Pi",
    "mcode": "MiniMax Code"
  },
  "pi": {
    "empty": {
      "title": "No API key providers yet",
      "description": "Use the + button in the top-right corner to add a preset or custom provider."
    },
    "provider": {
      "enabled": "Enabled in Pi",
      "enableFailed": "Could not enable this provider in Pi",
      "removed": "Removed from Pi",
      "writeConflict": "Another process is updating Pi's configuration. Try again shortly."
    },
    "form": {
      "providerKey": "Provider key",
      "providerKeyRequired": "Provider key is required",
      "selectPresetRequired": "Select a preset or custom configuration first",
      "fixJsonFirst": "Fix the configuration JSON below before editing the structured fields.",
      "nameRequired": "Display name is required",
      "credential": "API Key",
      "credentialRequired": "Enter the API key for this preset",
      "absoluteHttpUrlRequired": "{{label}} must be an absolute HTTP or HTTPS URL",
      "positiveNumberRequired": "{{label}} must be a number greater than 0",
      "models": "Model configuration",
      "noModels": "No models configured",
      "addModel": "Add model",
      "removeModel": "Remove model",
      "modelId": "Model ID",
      "modelIdRequired": "Model {{index}} needs an ID",
      "modelName": "Display name",
      "modelNameRequired": "Model {{index}} needs a display name",
      "modelNamePlaceholder": "Display name",
      "toggleModelDetails": "Toggle model details",
      "reasoning": "Supports extended thinking",
      "imageInput": "Supports image input",
      "thinkingLevelsLabel": "Thinking levels",
      "customizeThinkingLevels": "Customize",
      "thinkingLevelDefault": "Pi default",
      "thinkingLevelUnsupported": "Unavailable",
      "thinkingLevelValue": "Upstream value for {{level}}",
      "editThinkingLevel": "Edit {{level}} level",
      "thinkingLevelFollowDefault": "Follow Pi default",
      "thinkingLevelMapTo": "Map to",
      "thinkingLevelMarkUnavailable": "This level is unavailable",
      "thinkingLevelMapInvalid": "Thinking levels may only use Pi's native keys, with string or null values.",
      "thinkingLevels": {
        "off": "Off",
        "minimal": "Minimal",
        "low": "Low",
        "medium": "Medium",
        "high": "High",
        "xhigh": "Extra high",
        "max": "Maximum"
      },
      "contextWindow": "Context window",
      "maxTokens": "Max output tokens",
      "compatibility": "Compatibility",
      "compatibilityHint": "Adjust request behavior for compatible or local endpoints.",
      "addCompatibilityOption": "Add",
      "noCompatibilityOptions": "No compatibility options configured",
      "optionKey": "Option",
      "optionValue": "Value",
      "removeCompatibilityOption": "Remove compatibility option",
      "effectiveApiRequired": "Model {{id}} needs an API, either directly or from the provider",
      "effectiveBaseUrlRequired": "Model {{id}} needs a base URL, either directly or from the provider",
      "duplicateModel": "Model ID {{id}} is duplicated",
      "modelRequired": "Add at least one model",
      "providerKeyDuplicate": "This provider key already exists"
    },
    "current": {
      "readFailed": "Could not read Pi's provider configuration",
      "stateUnavailableHint": "Provider changes are disabled until CC Switch can read Pi's provider configuration."
    },
    "prompts": {
      "globalTab": "Global prompts",
      "systemTab": "Global system prompt",
      "templatesTab": "Prompt templates",
      "agentsLibrary": "AGENTS.md library",
      "agentsLibraryDescription": "Choose one prompt to write to Pi's global AGENTS.md.",
      "writtenToAgents": "Written to AGENTS.md",
      "externalAgents": "External AGENTS.md",
      "noGlobalPrompt": "Global AGENTS.md not configured",
      "noGlobalPrompts": "No global prompts",
      "noGlobalPromptsDescription": "Add a prompt from the top-right, then write one to global AGENTS.md when needed.",
      "noPromptDescription": "No description",
      "usePrompt": "Use",
      "stopUsing": "Stop",
      "usePromptSuccess": "Global AGENTS.md updated",
      "stopUsingSuccess": "Global AGENTS.md removed",
      "stopBeforeDelete": "Stop using this prompt before deleting it",
      "systemFilesDescription": "Prefer appending. Replace only when you need full control of the base instructions.",
      "systemAppend": "System append",
      "systemAppendDescription": "Adds instructions after Pi's built-in base prompt and suits most global customization.",
      "systemOverride": "System replacement",
      "systemOverrideDescription": "Replaces Pi's built-in base prompt. Pi still adds context, AGENTS.md, and its other resources.",
      "systemOverrideWarning": "SYSTEM.md replaces Pi's built-in base prompt. Prefer APPEND_SYSTEM.md unless you need full control of the base instructions.",
      "recommended": "Recommended",
      "configured": "Configured",
      "configuredEmpty": "Configured but empty",
      "notConfigured": "Not configured",
      "unavailable": "Unavailable",
      "markdownContent": "Markdown content",
      "instructionPlaceholder": "Markdown content used by Pi",
      "blankInstruction": "Enter non-blank content, or delete the global file to stop using it.",
      "saveAndConfigure": "Save and configure",
      "removeGlobalFile": "Delete global file",
      "activateOverrideTitle": "Configure {{filename}}?",
      "activateOverrideMessage": "Creating {{filename}} replaces Pi's built-in base prompt. Pi still adds context, AGENTS.md, Skills, and other resources according to its own rules.",
      "removeFileTitle": "Delete {{filename}}?",
      "removeFileMessage": "This deletes {{filename}} from Pi's global configuration directory.",
      "fileSaved": "{{filename}} saved",
      "fileRemoved": "{{filename}} deleted",
      "saveFailed": "Failed to save the Pi instruction file",
      "deleteFailed": "Failed to delete the Pi instruction file",
      "reloadNotice": "Open Pi sessions do not hot-reload these resources. After a change, run /reload while Pi is idle. New sessions read them automatically.",
      "templatesDescription": "Saved templates are available in Pi as /command-name. No enable step is needed.",
      "newTemplate": "New prompt template",
      "editTemplate": "Edit /{{slug}}",
      "templateCommand": "Slash command",
      "templateSlug": "For example, review",
      "templateSlugInvalid": "Use one command token without spaces or filename-reserved characters.",
      "templateSlugExists": "That slash command already exists.",
      "templateDescription": "Notes",
      "templateDescriptionPlaceholder": "Optional description",
      "templateContent": "Template Markdown",
      "templateContentPlaceholder": "Enter the Markdown Pi should expand. YAML frontmatter is preserved.",
      "templateSyntax": "Pi template syntax",
      "templateSyntaxDescription": "Optional frontmatter supports description and argument-hint. The body supports $1, $2, $@ or $ARGUMENTS, ${@:N}, and ${@:N:L} argument substitution.",
      "createTemplate": "Create template",
      "templateCreated": "Pi prompt template created",
      "templateSaved": "/{{slug}} saved",
      "templateDeleted": "/{{slug}} deleted",
      "templateLoadFailed": "Failed to load Pi prompt templates",
      "templateSaveFailed": "Failed to save the Pi prompt template",
      "templateDeleteFailed": "Failed to delete the Pi prompt template",
      "searchTemplates": "Search prompt template names, descriptions, or content…",
      "noTemplates": "No prompt templates",
      "noTemplatesDescription": "Create a template from the top-right, then invoke it in Pi with its slash command.",
      "noTemplateResults": "No matching templates",
      "deleteTemplateTitle": "Delete /{{slug}}?",
      "deleteTemplateMessage": "This permanently deletes prompts/{{slug}}.md."
    }
  },
  "appSwitcher": {
    "more": "More apps"
  },
  "grokBuild": {
    "apiBackend": "API backend",
    "contextWindow": "Context window",
    "contextWindowInvalid": "Context window must be a positive integer",
    "profile": "Client model profile",
    "rawConfig": "config.toml",
    "invalidToml": "Invalid config.toml: {{error}}",
    "defaultModelPlaceholder": "e.g. grok-4.5",
    "defaultModelHint": "The model Grok Build requests by default; change it anytime without waiting for a preset update.",
    "advancedSectionHint": "Includes upstream format, reasoning overrides and custom User-Agent. Providers using the Chat Completions or Anthropic Messages protocol require routing takeover to be enabled.",
    "reasoningEffortHint": "Enable when the upstream supports thinking-depth control such as low/high/max. Enabling this also turns on thinking mode and converts the request's reasoning effort into the upstream Chat parameter.",
    "maxOutputTokensHint": "The default 8192 ceiling can truncate long or thinking-heavy responses (stop_reason=max_tokens). This value overrides the request's max_tokens on the Anthropic path. Do not exceed the real output ceiling of the model/gateway or it may 400. Leave empty to use the default 8192."
  },
  "sessionManager": {
    "title": "Session Manager",
    "subtitle": "Manage Claude Code, Codex, Gemini CLI, Grok Build, OpenCode, OpenClaw, Hermes, and Pi sessions",
    "searchPlaceholder": "Search by content, directory, or ID",
    "searchSessions": "Search sessions",
    "providerFilterAll": "All",
    "providerFilterTooltip": "Provider filter",
    "sessionList": "Sessions",
    "viewModeTooltip": "View mode",
    "viewModeFlat": "List",
    "viewModeGrouped": "Grouped",
    "unknownDirectory": "Unknown directory",
    "toggleProviderGroup": "Expand or collapse {{provider}} provider group",
    "toggleDirectoryGroup": "Expand or collapse {{directory}} directory group",
    "collapseAllGroups": "Collapse all",
    "selectProviderGroupForBatch": "Select sessions in {{provider}} provider group",
    "selectDirectoryGroupForBatch": "Select sessions in {{directory}} directory group",
    "manageBatchTooltip": "Enter batch management",
    "exitBatchModeTooltip": "Exit batch management",
    "batchModeHint": "Select sessions to delete",
    "selectForBatch": "Select session",
    "selectedCount": "{{count}} selected",
    "selectAllFiltered": "Select all",
    "clearFilteredSelection": "Clear selection",
    "clearSelection": "Clear",
    "deleteSelected": "Delete",
    "batchDeleting": "Deleting...",
    "loadingSessions": "Loading sessions...",
    "noSessions": "No sessions found",
    "piRelativeSessionDir": "Pi sessionDir is relative to the directory where Pi is launched, so a global browser cannot enumerate it safely. Set an absolute sessionDir to browse all Pi sessions here:",
    "piDiscoveryUnavailable": "Pi sessions could not be inspected: {{error}}",
    "selectSession": "Select a session to view details",
    "noSummary": "No summary available",
    "lastActive": "Last active",
    "projectDir": "Project directory",
    "sourcePath": "Source file",
    "copyResumeCommand": "Copy resume command",
    "resumeCommandCopied": "Resume command copied",
    "openInTerminal": "Resume in terminal",
    "terminalTargetTerminal": "Terminal",
    "terminalTargetKitty": "kitty",
    "terminalTargetCopy": "Copy only",
    "terminalLaunched": "Terminal launched",
    "openFailed": "Failed to launch terminal",
    "resumeFallbackCopied": "Resume command copied for manual use",
    "copyProjectDir": "Copy directory",
    "projectDirCopied": "Directory copied",
    "copySourcePath": "Copy source file",
    "sourcePathCopied": "Source file copied",
    "delete": "Delete session",
    "deleting": "Deleting...",
    "deleteTooltip": "Permanently delete this local session record",
    "deleteConfirmTitle": "Delete session",
    "deleteConfirmMessage": "This will permanently delete the local session \"{{title}}\"\nSession ID: {{sessionId}}\n\nThis action cannot be undone.",
    "deleteConfirmAction": "Delete session",
    "sessionDeleted": "Session deleted",
    "deleteFailed": "Failed to delete session: {{error}}",
    "batchDeleteConfirmTitle": "Delete selected sessions",
    "batchDeleteConfirmMessage": "This will permanently delete {{count}} selected local sessions.\n\nThis action cannot be undone.",
    "batchDeleteConfirmAction": "Delete selected",
    "batchDeleteSuccess": "Deleted {{count}} sessions",
    "batchDeleteFailed": "{{failed}} sessions could not be deleted",
    "batchDeleteRequestFailed": "Batch delete failed. Please try again later.",
    "loadingMessages": "Loading transcript...",
    "emptySession": "No messages available",
    "clickToCopyPath": "Click to copy path",
    "tocTitle": "Contents",
    "justNow": "Just now",
    "minutesAgo": "{{count}} min ago",
    "hoursAgo": "{{count}} hr ago",
    "daysAgo": "{{count}} days ago",
    "roleUser": "User",
    "roleSystem": "System",
    "roleTool": "Tool",
    "resume": "Resume Session",
    "resumeTooltip": "Resume this session in terminal",
    "noResumeCommand": "This session cannot be resumed",
    "copyCommand": "Copy Command",
    "copyMessage": "Copy Message",
    "messageCopied": "Message copied",
    "conversationHistory": "Conversation History",
    "expandContent": "Expand full content",
    "collapseContent": "Collapse"
  },
  "console": {
    "providerSwitchReceived": "Received provider switch event:",
    "setupListenerFailed": "Failed to setup provider switch listener:",
    "updateProviderFailed": "Update provider failed:",
    "autoImportFailed": "Auto import default configuration failed:",
    "openLinkFailed": "Failed to open link:",
    "getVersionFailed": "Failed to get version info:",
    "loadSettingsFailed": "Failed to load settings:",
    "getConfigPathFailed": "Failed to get config path:",
    "getConfigDirFailed": "Failed to get config directory:",
    "detectPortableFailed": "Failed to detect portable mode:",
    "saveSettingsFailed": "Failed to save settings:",
    "updateFailed": "Update failed:",
    "checkUpdateFailed": "Check for updates failed:",
    "openConfigFolderFailed": "Failed to open config folder:",
    "selectConfigDirFailed": "Failed to select config directory:",
    "getDefaultConfigDirFailed": "Failed to get default config directory:",
    "openReleaseNotesFailed": "Failed to open release notes:"
  },
  "providerForm": {
    "supplierName": "Provider Name",
    "supplierNameRequired": "Provider Name *",
    "supplierNamePlaceholder": "e.g., Anthropic Official",
    "websiteUrl": "Website URL",
    "websiteUrlPlaceholder": "https://example.com (optional)",
    "apiEndpoint": "API Endpoint",
    "apiEndpointPlaceholder": "https://your-api-endpoint.com",
    "codexApiEndpointPlaceholder": "https://your-api-endpoint.com/v1",
    "manageAndTest": "Manage & Test",
    "configContent": "Config Content",
    "officialNoApiKey": "Official login does not require API Key, save directly",
    "codexOfficialNoApiKey": "Official does not require API Key, save directly",
    "codexApiKeyAutoFill": "Just fill in here, auth.json below will be auto-filled",
    "apiKeyAutoFill": "Just fill in here, config below will be auto-filled",
    "cnOfficialApiKeyHint": "💡 Only need to fill in API Key, endpoint is preset",
    "aggregatorApiKeyHint": "💡 Only need to fill in API Key, endpoint is preset",
    "thirdPartyApiKeyHint": "💡 Only need to fill in API Key, endpoint is preset",
    "customApiKeyHint": "💡 Custom configuration requires manually filling all necessary fields",
    "omoHint": "💡 OMO config manages Agent model assignments and supports both oh-my-openagent.jsonc and oh-my-opencode.jsonc",
    "officialHint": "💡 Official provider uses browser login, no API Key needed",
    "providerKeyStatusLoading": "Provider identifier status is still loading. Please try again shortly.",
    "getApiKey": "Get API Key",
    "partnerPromotion": {
      "kimi": "New Kimi users get 10% of their first successful top-up back as bonus API credit, up to CNY ¥1,000.",
      "a6api": "A6API is a token aggregation platform with a built-in real-time price leaderboard that automatically picks the lowest price on the market. Smooth and stable, simple to operate, and no more tedious price comparisons. Register now to claim free trial credits!",
      "sudocode": "With one SudoCode key, Claude Code and Claude Desktop use Claude Opus 5, while Codex uses GPT-5.6. Sign up, join QQ group 726213516, and contact the group owner to claim CNY ¥10 in trial credit.",
      "code0": "code0.ai is an AI coding service platform for developers, supporting Claude Code, Codex, and Gemini. Exclusive for CC Switch users: contact support via the official website to claim free trial credits!",
      "packycode": "PackyCode is an official partner of CC Switch. Register using this link and enter \"cc-switch\" promo code during recharge to get 10% off",
      "apikeyfun": "APIKEY.FUN offers a special deal for CC Switch users. Register through the exclusive link to enjoy up to permanent 5% off top-ups.",
      "apinebula": "APINEBULA offers CC Switch users a special discount: register using the link and enter the \"ccswitch\" promo code during your first top-up to get 10% off.",
      "patewayai": "PatewayAI offers special benefits for CC Switch users. Register via this link to receive $3 credit.",
      "claudeapi": "ClaudeAPI offers special benefits for CC Switch users. Register via this link to claim test credits.",
      "claudecn": "ClaudeCN is an enterprise-grade AI gateway operated by a registered company, supporting enterprise procurement processes with corporate payments, contracts, and compliance guarantees.",
      "runapi": "RunAPI offers special benefits for CC Switch users. Register via this link and enjoy 10% off your first top-up.",
      "opencode_go": "OpenCode Go offers subscription access to a range of coding models. View plan details and subscribe via this link.",
      "dmxapi": "Claude Code exclusive model 66% OFF now!",
      "cubence": "Cubence is an official partner of CC Switch. Register using this link and enter \"CCSWITCH\" promo code during recharge to get 10% off every top-up",
      "aigocode": "AIGoCode is an official partner of CC Switch. Register using this link and get 10% bonus credit on your first top-up!",
      "rightcode": "RightCode is an official partner of CC Switch. Register using this link and get 5% bonus credit on every top-up!",
      "aicodemirror": "AICodeMirror is an official partner of CC Switch. Register using this link to get 20% off!",
      "aicoding": "AI Coding offers an exclusive discount for CC Switch users — 10% off your first top-up!",
      "crazyrouter": "CrazyRouter offers an exclusive bonus for CC Switch users — 30% extra credit on your first top-up!",
      "sssaicode": "SSAI Code offers an exclusive bonus for CC Switch users — $10 extra credit on every top-up!",
      "siliconflow": "SiliconFlow is an official partner of CC Switch",
      "ucloud": "Compshare offers an exclusive bonus for CC Switch users — register via this link to get ¥5 platform trial credit!",
      "micu": "Micu is an official partner of CC Switch",
      "etok": "Join the ETok community on the official website and subscribe to a plan.",
      "shengsuanyun": "Shengsuanyun offers exclusive benefits for CC Switch users. New users who register via this link get ¥10 free credits and 10% bonus on first top-up!",
      "doubaoseed": "DouBao offers exclusive benefits for CC Switch users: register via this link to get 500K tokens of inference credits for all DouBao text models and 5M tokens of free Seedance 2.0 credits.",
      "volcengine_agentplan": "Volcengine Ark Agent Plan offers exclusive benefits for CC Switch users: subscribe via this link and new customers get 75% off for the first two months, plus an extra 5% off with the exclusive invite code 6J6FV5N2 — as low as ¥9.4/month!",
      "volcengine_codingplan": "Volcengine Ark Coding Plan offers exclusive benefits for CC Switch users: subscribe via this link and new customers get 75% off for the first two months, plus an extra 5% off with the exclusive invite code 6J6FV5N2 — as low as ¥9.4/month!",
      "byteplus": "Register via this link to get 500,000 tokens of free inference quota per model.",
      "ccsub": "CCSub is a stable, affordable AI API relay — a drop-in replacement for Claude.ai & OpenAI subscriptions, with one key for all models at ~30% of direct API cost.",
      "subrouter": "SubRouter is an AI relay aggregator that lets one key access multiple models and providers.",
      "qiniu": "Qiniu Cloud is a multi-protocol AI relay: one key for native Claude, GPT, and Gemini models, with the Anthropic, OpenAI, and Gemini APIs all supported.",
      "fenno": "Fenno.ai is a stable, efficient API relay giving you access to a wide range of mainstream models. Exclusive CC Switch offer: subscribe via this link to the $1.99 Trial Plan worth $50 in credits, valid for 7 days!",
      "zetaapi": "ZetaAPI delivers real, undegraded models at as low as 35% of official pricing. Exclusive CC Switch offer: register via this link and use promo code CC-SWITCH for 10% off your first top-up!",
      "teamorouter": "TeamoRouter is an enterprise-grade Agentic LLM gateway with pricing up to 90% off. It offers exclusive benefits for CC Switch users: register via this link as a new user for 10% off your first top-up!",
      "ppio": "PPIO is a leading independent Agentic Cloud provider in China, serving every flagship open-source model through a single API key. Register via this link and complete identity verification to receive a ¥10 credit voucher.",
      "xycai": "XycAi is an enterprise-grade token factory: one-click access to 200+ global models, automatic SLA compensation, and 100% refunds for abnormal cache charges!",
      "9527code": "9527 CODE is an enterprise-grade, full-capability AI relay platform delivering fast, stable relay for Claude Code, Codex and other mainstream models. One year of continuous operation, 99.9% service stability, and 7×24 human technical support. New users can contact support for trial credit, with unlimited referral cashback!",
      "soleapi": "SoleAPI is an AI model gateway for developers and enterprises: one API key reaches 30+ leading models including Claude, GPT and Gemini, natively compatible with the OpenAI and Anthropic protocols, with real-time smart routing, millisecond failover, 99.99% availability and 24/7 support. Sign up via the referral link for free trial credits and ongoing cashback for inviting friends who top up!",
      "fluxa": "FluxA and Baidu AI Cloud jointly launched AgenticPlan, letting AI agents buy, manage and use models, APIs and tools on their own. It includes Baidu Qianfan TokenPlan at up to 40% off with flagship models such as DeepSeek V4, GLM 5.2 and Kimi, plus bonus FluxA AgentMarket API credits that unlock 1,000+ paid APIs for search, data scraping, social media, finance, crypto, image generation and video."
    },
    "presets": {
      "ucloud": "Compshare",
      "ucloudCoding": "Compshare Coding Plan",
      "shengsuanyun": "Shengsuanyun",
      "qiniu": "Qiniu",
      "doubaoseed": "Volcengine Doubao",
      "openrouter": "OpenRouter",
      "deepseek": "DeepSeek",
      "together": "Together AI"
    },
    "parameterConfig": "Parameter Config - {{name}} *",
    "mainModel": "Main Model (optional)",
    "mainModelPlaceholder": "e.g., GLM-4.6",
    "fastModel": "Fast Model (optional)",
    "fastModelPlaceholder": "e.g., GLM-4.5-Air",
    "modelHint": "💡 Leave blank to use provider's default model",
    "apiHint": "💡 Fill in Claude API compatible service endpoint, avoid trailing slash",
    "apiHintOAI": "💡 Fill in OpenAI Chat Completions compatible service endpoint, avoid trailing slash",
    "apiHintGeminiNative": "💡 Prefer a Gemini Native base URL such as https://generativelanguage.googleapis.com or https://generativelanguage.googleapis.com/v1beta; the proxy will append models/*:generateContent automatically",
    "codexApiHint": "💡 Fill in service endpoint compatible with OpenAI Response format",
    "fillSupplierName": "Please fill in provider name",
    "fillConfigContent": "Please fill in configuration content",
    "fillParameter": "Please fill in {{label}}",
    "fillTemplateValue": "Please fill in {{label}}",
    "endpointRequired": "API endpoint is required for non-official providers",
    "apiKeyRequired": "API Key is required for non-official providers",
    "softValidation": {
      "title": "Configuration has the following issues",
      "hint": "Save anyway? Switching to this provider may fail; you can fill these in later.",
      "saveAnyway": "Save anyway"
    },
    "configJsonError": "Config JSON format error, please check syntax",
    "authJsonRequired": "auth.json must be a JSON object",
    "authJsonError": "auth.json format error, please check JSON syntax",
    "fillAuthJson": "Please fill in auth.json configuration",
    "fillApiKey": "Please fill in OPENAI_API_KEY",
    "visitWebsite": "Visit {{url}}",
    "anthropicModel": "Main Model",
    "anthropicSmallFastModel": "Fast Model",
    "apiFormat": "Upstream Format",
    "apiFormatHint": "Pick Anthropic Messages when your provider is natively an Anthropic Messages API (direct, no format conversion); pick Chat when it uses Chat Completions; pick Responses when it uses the Responses API; pick Gemini Native when it uses Gemini generateContent. Chat, Responses, and Gemini Native require routing takeover to convert to Anthropic Messages.",
    "customUserAgent": "Custom User-Agent",
    "customUserAgentHint": "Only takes effect when local routing/proxy takeover is enabled; replaces the User-Agent in requests forwarded to the provider API.",
    "customUserAgentInvalid": "User-Agent must not contain control characters (e.g. line breaks); otherwise it will be ignored.",
    "customUserAgentPresets": "Presets",
    "localProxyRequestOverrides": "Local proxy request overrides",
    "localProxyRequestOverridesHint": "Only takes effect after local routing/proxy takeover; applied to the transformed upstream request.",
    "localProxyRequestOverridesInvalid": "Local proxy request overrides format error: {{error}}",
    "localProxyHeaderOverrides": "Header overrides",
    "localProxyHeaderOverridesInvalidDetail": "Header overrides format error: {{error}}",
    "localProxyBodyOverrides": "Body overrides",
    "localProxyBodyOverridesInvalidDetail": "Body overrides format error: {{error}}",
    "fullUrlLabel": "Full URL",
    "fullUrlEnabled": "Full URL Mode",
    "fullUrlDisabled": "Mark as Full URL",
    "fullUrlHint": "💡 Enter the full request URL. This mode requires routing to be enabled, and routing will use the URL as-is without appending a path",
    "fullUrlHintGeminiNative": "💡 In Gemini Native full URL mode, two inputs are supported: 1. official/structured Gemini URLs, which will still be normalized to the requested model and streaming method; 2. opaque custom relay URLs, which will be used mostly as-is with only query parameters appended",
    "apiFormatAnthropic": "Anthropic Messages (Native)",
    "apiFormatOpenAIChat": "OpenAI Chat Completions (Requires routing)",
    "apiFormatOpenAIResponses": "OpenAI Responses API (Requires routing)",
    "apiFormatGeminiNative": "Gemini Native generateContent (Requires routing)",
    "codexApiFormatResponses": "OpenAI Responses API (Native)",
    "codexApiFormatOpenAIChat": "OpenAI Chat Completions (Requires routing)",
    "codexApiFormatHint": "Select the Codex API format actually supported by this provider; the config stays on Responses for newer Codex versions, while Chat Completions is converted through local routing.",
    "authField": "Auth Field",
    "authFieldAuthToken": "ANTHROPIC_AUTH_TOKEN (Default)",
    "authFieldApiKey": "ANTHROPIC_API_KEY",
    "authFieldHint": "Select the authentication env variable name for the config",
    "apiHintResponses": "💡 Fill in OpenAI Responses API compatible service endpoint, avoid trailing slash",
    "anthropicDefaultHaikuModel": "Default Haiku Model",
    "anthropicDefaultSonnetModel": "Default Sonnet Model",
    "anthropicDefaultOpusModel": "Default Opus Model",
    "modelPlaceholder": "",
    "smallModelPlaceholder": "",
    "haikuModelPlaceholder": "",
    "modelHelper": "Optional: Specify default Claude model to use, leave blank to use system default.",
    "modelMappingLabel": "Model Mapping",
    "modelMappingHint": "Display names only affect the /model menu; 1M is only a Claude Code context-capability declaration.",
    "modelRoleLabel": "Model role",
    "modelRoleSonnet": "Sonnet",
    "modelRoleOpus": "Opus",
    "modelRoleFable": "Fable",
    "modelRoleHaiku": "Haiku",
    "modelRoleSubagent": "Subagent",
    "modelDisplayNameLabel": "Display name",
    "modelDisplayNamePlaceholder": "e.g. DeepSeek V4 Pro",
    "modelNoDisplayName": "Not shown in /model",
    "requestModelLabel": "Requested model",
    "modelOneMHeader": "Declare 1M",
    "modelOneMLabel": "1M",
    "fallbackModelLabel": "Default fallback model",
    "fallbackModelHint": "A fallback for requests that don't clearly map to Sonnet, Opus, Fable, or Haiku. Recommended for third-party/relay endpoints—otherwise such requests (including Haiku background subtasks) are forwarded under their original Claude model name and may fail if the upstream doesn't host it. Safe to leave blank for official endpoints.",
    "quickSetModels": "Quick Set",
    "quickSetSuccess": "Model name applied to all roles",
    "advancedOptionsToggle": "Advanced Options",
    "advancedOptionsHint": "Includes API format, auth field, and model mapping. Defaults work for most use cases.",
    "categoryOfficial": "Official",
    "categoryCnOfficial": "Opensource Official",
    "categoryAggregation": "Aggregation",
    "categoryThirdParty": "Third Party",
    "fetchModels": "Fetch Models",
    "fetchingModels": "Fetching...",
    "searchModelPlaceholder": "Search models...",
    "searchModelEmpty": "No matching models.",
    "searchModelAriaLabel": "Select model",
    "fetchModelsSuccess": "Found {{count}} models",
    "fetchedModelsTitle": "Available models ({{count}})",
    "modelAlreadyAdded": "Already added",
    "addSelectedModels": "Add selected ({{count}})",
    "fetchModelsFailed": "Failed to fetch models",
    "fetchModelsEmpty": "No models found",
    "fetchModelsNeedApiKey": "Please fill in API Key first",
    "fetchModelsNeedEndpoint": "Please fill in API endpoint first",
    "fetchModelsNeedConfig": "Please fill in API endpoint and API Key first",
    "fetchModelsAuthFailed": "API Key is invalid or lacks permission",
    "fetchModelsNotSupported": "This provider does not support fetching model list",
    "fetchModelsEndpointNotFound": "No reachable models endpoint found. Please check the Base URL or confirm whether the provider exposes this API.",
    "fetchModelsTimeout": "Request timed out, please check network connection",
    "requiredFields": "Please fill in provider name, API endpoint, API Key and model"
  },
  "copilot": {
    "authSection": "GitHub Copilot Authentication",
    "authStatus": "Authentication Status",
    "authenticated": "Authenticated as {{username}}",
    "notAuthenticated": "Not authenticated",
    "loginWithGitHub": "Login with GitHub",
    "githubAccount": "GitHub account",
    "manageAccounts": "Manage accounts",
    "loginRequired": "Please login to GitHub Copilot first",
    "statusLoading": "Loading account status...",
    "statusUnavailable": "Status unavailable",
    "statusLoadFailed": "Failed to load GitHub Copilot account status. Please retry.",
    "waitingForAuth": "Waiting for authorization...",
    "enterCode": "Please enter the code in your browser:",
    "logout": "Logout",
    "authSuccess": "GitHub Copilot authentication successful",
    "authFailed": "Authentication failed: {{error}}",
    "authTimeout": "Authentication timed out, please try again",
    "tokenExpired": "Token expired, please re-authenticate",
    "accountCount": "{{count}} account(s)",
    "selectAccount": "Select Account",
    "selectAccountPlaceholder": "Select a GitHub account",
    "useDefaultAccount": "Use default account",
    "loggedInAccounts": "Logged in accounts",
    "defaultAccount": "Default",
    "selected": "Selected",
    "removeAccount": "Remove account",
    "setAsDefault": "Set as default",
    "addAnotherAccount": "Add another account",
    "logoutAll": "Logout all accounts",
    "retry": "Retry",
    "copyCode": "Copy code",
    "migrationFailed": "Legacy auth migration failed: {{error}}",
    "loadModelsFailed": "Failed to load Copilot models",
    "deploymentType": "GitHub Deployment Type",
    "deploymentGitHubCom": "GitHub.com",
    "deploymentEnterprise": "GitHub Enterprise Server",
    "enterpriseDomainPlaceholder": "e.g. company.ghe.com"
  },
  "codexOauth": {
    "authStatus": "Auth status",
    "notAuthenticated": "Not authenticated",
    "loginWithChatGPT": "Sign in with ChatGPT",
    "loginRequired": "Please sign in to ChatGPT first",
    "statusLoading": "Loading account status...",
    "statusUnavailable": "Status unavailable",
    "statusLoadFailed": "Failed to load ChatGPT account status. Please retry.",
    "waitingForAuth": "Waiting for authorization...",
    "enterCode": "Enter the code in your browser:",
    "accountCount": "{{count}} account(s)",
    "selectAccount": "Select account",
    "chatgptAccount": "ChatGPT account",
    "accountToUse": "Account to use",
    "signInMethod": "Sign-in method",
    "manageAccounts": "Manage accounts",
    "selectAccountPlaceholder": "Choose a ChatGPT account",
    "officialAccountPlaceholder": "Choose a sign-in method",
    "addOrManageAccounts": "Add or manage ChatGPT accounts…",
    "explicitSelectionRequired": "Choose a sign-in method",
    "useDefaultAccount": "Use default account",
    "noneOptionLabel": "Follow Codex login",
    "reauthTitle": "Some accounts need to sign in again",
    "reauthDescription": "To match the browser-login behavior, these accounts must sign in again to restore the required login credential (id_token). Once re-authenticated they can be used for managed binding.",
    "reauthBadge": "Re-login required",
    "reauthLogin": "Re-login",
    "reauthSelectHint": "This account needs to sign in again to enable managed binding.",
    "reauthNow": "Re-login now",
    "duplicateAccount": "This ChatGPT account has already been added. Use the existing account.",
    "loggedInAccounts": "Logged in accounts",
    "defaultAccount": "Default",
    "selected": "Selected",
    "removeAccount": "Remove account",
    "setAsDefault": "Set as default",
    "addAnotherAccount": "Add another account",
    "logoutAll": "Logout all accounts",
    "retry": "Retry",
    "copyCode": "Copy code",
    "fastMode": "FAST mode",
    "fastModeDescription": "Send service_tier=\"priority\" for lower latency. Off by default — enabling it consumes your ChatGPT quota at a higher rate."
  },
  "xaiOauth": {
    "authStatus": "xAI OAuth authentication",
    "accountCount": "Usable accounts: {{count}}",
    "reauthRequired": "Sign-in required",
    "notAuthenticated": "Not authenticated",
    "selectAccount": "Select account",
    "selectAccountPlaceholder": "Select an xAI account",
    "useDefaultAccount": "Use default account",
    "accounts": "xAI accounts",
    "defaultAccount": "Default",
    "expired": "Credentials expired",
    "setAsDefault": "Set as default",
    "removeAccount": "Remove account",
    "addOrReauth": "Add account or sign in again",
    "login": "Sign in with xAI",
    "waitingForAuth": "Waiting for xAI authorization…",
    "enterCode": "If the browser did not fill it in automatically, enter:",
    "retry": "Retry",
    "logoutAll": "Remove all xAI accounts",
    "loginRequired": "Sign in to an xAI account first"
  },
  "managedAuth": {
    "accountRemoved": "Account removed",
    "selectedAccountNeedsReauth": "The linked account is missing or needs you to sign in again",
    "selectedAccountUnavailable": "The linked account is missing or needs you to sign in again. Select another account."
  },
  "endpointTest": {
    "title": "API Endpoint Management",
    "endpoints": "endpoints",
    "autoSelect": "Auto Select",
    "testSpeed": "Test",
    "testing": "Testing",
    "addEndpointPlaceholder": "https://api.example.com",
    "done": "Done",
    "noEndpoints": "No endpoints",
    "failed": "Failed",
    "enterValidUrl": "Please enter a valid URL",
    "invalidUrlFormat": "Invalid URL format",
    "onlyHttps": "Only HTTP/HTTPS supported",
    "urlExists": "This URL already exists",
    "saveFailed": "Save failed, please try again",
    "loadEndpointsFailed": "Failed to load custom endpoints:",
    "addEndpointFailed": "Failed to add custom endpoint:",
    "removeEndpointFailed": "Failed to remove custom endpoint:",
    "removeFailed": "Remove failed: {{error}}",
    "updateLastUsedFailed": "Failed to update endpoint last used time",
    "pleaseAddEndpoint": "Please add an endpoint first",
    "testUnavailable": "Speed test unavailable",
    "noResult": "No result returned",
    "testFailed": "Speed test failed: {{error}}",
    "empty": "No endpoints"
  },
  "providerAdvanced": {
    "pricingConfig": "Pricing Config",
    "useCustomPricing": "Use separate config",
    "pricingConfigDesc": "Configure separate pricing parameters for this provider. Uses global defaults when disabled.",
    "costMultiplier": "Cost Multiplier",
    "costMultiplierPlaceholder": "Leave empty to use global default (1)",
    "costMultiplierHint": "Actual cost = Base cost × Multiplier, supports decimals like 1.5",
    "pricingModelSourceLabel": "Pricing Mode",
    "pricingModelSourceInherit": "Inherit global default",
    "pricingModelSourceRequest": "Request model",
    "pricingModelSourceResponse": "Response model",
    "pricingModelSourceHint": "Choose whether to match pricing by request model or response model"
  },
  "codexConfig": {
    "authJson": "auth.json (JSON) *",
    "authJsonPlaceholder": "{\n  \"OPENAI_API_KEY\": \"sk-your-api-key-here\"\n}",
    "authJsonHint": "Codex auth.json configuration content",
    "authJsonStorageHint": "Proxy takeover is showing the stored auth, not the live auth.json.",
    "configToml": "config.toml (TOML)",
    "configTomlHint": "Codex config.toml configuration content",
    "configTomlStorageHint": "Proxy takeover is showing the stored config, not the live config.toml.",
    "proxyTakeoverStorageNotice": "💡 This app is under proxy takeover. You are editing the stored provider config; the live config is already temporarily managed by the proxy.",
    "writeCommonConfig": "Apply Common Config",
    "editCommonConfig": "Edit Common Config",
    "editCommonConfigTitle": "Edit Codex Common Config Snippet",
    "commonConfigHint": "This snippet will be appended to the end of config.toml when 'Apply Common Config' is checked",
    "enableRemoteCompaction": "Enable remote compaction",
    "remoteCompactionHint": "When enabled, the active model_providers entry name is written as OpenAI so Codex can try remote compaction.",
    "apiUrlLabel": "API Request URL",
    "extractFromCurrent": "Extract from Editor",
    "extractNoCommonConfig": "No common config available to extract from editor",
    "extractFailed": "Extract failed: {{error}}",
    "saveFailed": "Save failed: {{error}}",
    "modelNameHint": "Specify the model to use, will be auto-updated in config.toml",
    "modelName": "Model Name",
    "upstreamFormatLabel": "Upstream Format",
    "upstreamFormatHint": "Pick Responses when your provider is natively a Responses API (direct, no format conversion); pick Chat when it uses the Chat Completions protocol; pick Anthropic Messages when it only offers the native Anthropic Messages protocol. Chat and Anthropic Messages both require routing takeover to convert to Responses.",
    "upstreamFormatChat": "Chat Completions (routing required)",
    "upstreamFormatResponses": "Responses (native)",
    "upstreamFormatAnthropic": "Anthropic Messages (routing required)",
    "anthropicAuthFieldLabel": "Auth field",
    "anthropicAuthFieldAuthToken": "ANTHROPIC_AUTH_TOKEN (Authorization)",
    "anthropicAuthFieldApiKey": "ANTHROPIC_API_KEY (x-api-key)",
    "anthropicAuthFieldHint": "Choose which header carries the API key to the gateway: ANTHROPIC_AUTH_TOKEN sends Authorization: Bearer; ANTHROPIC_API_KEY sends x-api-key. Only one is sent.",
    "impersonateClaudeCodeLabel": "Emulate Claude Code client",
    "impersonateClaudeCodeHint": "Enable when the gateway (or its upstream) restricts usage to Claude Code: spoofs the User-Agent, anthropic-beta and x-app headers, and injects the Claude Code identity as the first system prompt line.",
    "maxOutputTokensLabel": "Max output tokens",
    "maxOutputTokensPlaceholder": "Leave empty to use the default 8192",
    "maxOutputTokensHint": "Codex does not forward model_max_output_tokens in the request body, so the default 8192 ceiling can truncate long or thinking-heavy responses (stop_reason=max_tokens). This value overrides the request's max_tokens on the Anthropic path. Do not exceed the real output ceiling of the model/gateway or it may 400. Leave empty to use the default 8192.",
    "promptCacheRoutingLabel": "Prompt cache routing",
    "promptCacheRoutingAuto": "Auto (recommended)",
    "promptCacheRoutingEnabled": "Enabled",
    "promptCacheRoutingDisabled": "Disabled",
    "promptCacheRoutingHint": "Auto sends prompt_cache_key only to known-compatible upstreams. Enable it for other compatible gateways, or disable it if a strict gateway rejects unknown fields with HTTP 400. Only a stable client-provided session ID is used.",
    "upstreamModelName": "Upstream Model Name",
    "upstreamModelNameHint": "For Chat format, enter the real upstream model here; routing converts Codex Responses requests to Chat Completions while keeping this model.",
    "modelNamePlaceholder": "e.g., gpt-5-codex",
    "contextWindow1M": "1M Context Window",
    "contextWindow": "Context Window",
    "contextWindowPlaceholder": "e.g., 128000",
    "autoCompactLimit": "Auto Compact Limit",
    "autoCompactLimitPlaceholder": "e.g., 90000",
    "autoCompactLimitHint": "Auto-compacts history when context reaches this token limit",
    "modelMetadataAdvanced": "Model Metadata Advanced Options",
    "modelMetadataAdvancedHint": "Overrides Codex metadata for unknown models; clearing a field removes the matching config.toml entry.",
    "defaultModelLabel": "Default Model",
    "defaultModelPlaceholder": "e.g. gpt-5.6-sol",
    "defaultModelHint": "The model Codex requests by default; change it anytime without waiting for a preset update. If left empty while model mapping is configured, the first mapping row is used.",
    "defaultModelNotInCatalog": "This model is not in the model mapping, so the Codex /model menu won't list it (direct requests still work).",
    "addToModelMapping": "Add to mapping",
    "modelMappingTitle": "Model Mapping",
    "modelMappingHint": "Generates Codex model_catalog_json so /model can show these third-party model names; entries are saved exactly as listed. Codex must be restarted to refresh the model list after changes.",
    "addCatalogModel": "Add Model",
    "catalogDisplayName": "Display Name",
    "catalogDisplayNamePlaceholder": "e.g., DeepSeek V4 Flash",
    "catalogModelId": "Model ID",
    "catalogModelPlaceholder": "e.g., deepseek-v4-flash",
    "catalogColumnDisplay": "Menu Display Name",
    "catalogColumnModel": "Actual Request Model",
    "catalogColumnContext": "Context Window",
    "catalogColumnReasoning": "Reasoning Levels",
    "reasoningLevelsNotSet": "Not set",
    "reasoningLevelsSearch": "Search reasoning levels...",
    "reasoningLevelsEmpty": "No levels",
    "defaultReasoningLevelLabel": "Default level",
    "defaultReasoningLevelPlaceholder": "Auto",
    "reasoningModeToggle": "Supports Thinking Mode",
    "reasoningModeHint": "Enable when the upstream Chat Completions API supports toggling thinking on/off. Providers like Kimi, GLM and Qwen usually fall into this category.",
    "reasoningEffortToggle": "Supports Reasoning Effort",
    "reasoningEffortHint": "Enable when the upstream supports thinking-depth control such as low/high/max. Enabling this also turns on thinking mode and converts Codex's reasoning.effort into the upstream Chat parameter.",
    "reasoningGroupTitle": "Reasoning Capability",
    "reasoningSectionHint": "Preset providers are configured automatically; custom providers are inferred from name/URL. Override manually only when auto-detection is wrong.",
    "advancedSectionHint": "Includes upstream format, model mapping, reasoning overrides and custom User-Agent. Providers using the Chat Completions protocol require routing takeover to be enabled.",
    "noCommonConfigToApply": "The common config snippet is empty or contains nothing to write"
  },
  "geminiConfig": {
    "envFile": "Environment Variables (.env)",
    "envFileHint": "Configure Gemini environment variables in .env format",
    "configJson": "Configuration File (config.json)",
    "configJsonHint": "Configure Gemini extended parameters in JSON format (optional)",
    "writeCommonConfig": "Apply Common Config",
    "editCommonConfig": "Edit Common Config",
    "editCommonConfigTitle": "Edit Gemini Common Config Snippet",
    "commonConfigHint": "This snippet writes to Gemini .env when 'Apply Common Config' is checked (GOOGLE_GEMINI_BASE_URL and GEMINI_API_KEY are not allowed)",
    "extractFromCurrent": "Extract from Editor",
    "extractNoCommonConfig": "No common config available to extract from editor",
    "extractFailed": "Extract failed: {{error}}",
    "saveFailed": "Save failed: {{error}}",
    "extractedConfigInvalid": "Extracted config format is invalid",
    "invalidJsonFormat": "Common config snippet format error (must be valid JSON)",
    "commonConfigInvalidKeys": "Common config snippet must not include GOOGLE_GEMINI_BASE_URL or GEMINI_API_KEY (found: {{keys}})",
    "commonConfigInvalidValues": "Common config snippet values must be strings",
    "noCommonConfigToApply": "Common config snippet is empty or has no applicable entries",
    "configMergeFailed": "Config merge failed: {{error}}",
    "configReplaceFailed": "Config replace failed: {{error}}"
  },
  "opencode": {
    "npmPackage": "API Format",
    "selectPackage": "Select API format",
    "npmPackageHint": "Select the API format for the AI service",
    "baseUrl": "Base URL",
    "baseUrlHint": "Custom API endpoint URL",
    "models": "Models",
    "modelsHint": "Configure available models and their display names",
    "addModel": "Add Model",
    "modelId": "Model ID",
    "modelName": "Display Name",
    "noModels": "No models configured",
    "modelsRequired": "Please add at least one model",
    "toggleModelDetails": "Toggle model details",
    "providerKey": "Provider Key",
    "providerKeyPlaceholder": "my-provider",
    "providerKeyHint": "Unique identifier in config file. Use lowercase letters, numbers, and hyphens only.",
    "providerKeyLockedHint": "This provider has already been added to the app config, so its key can no longer be changed.",
    "providerKeyRequired": "Provider key is required",
    "providerKeyDuplicate": "This key is already in use",
    "providerKeyInvalid": "Invalid format. Use lowercase letters, numbers, and hyphens only.",
    "headers": "Headers",
    "headersHint": "Optional HTTP headers sent with provider requests, such as HTTP-Referer or X-Title.",
    "addHeader": "Add header",
    "headerName": "Header",
    "headerValue": "Value",
    "headerNamePlaceholder": "X-Title",
    "headerValuePlaceholder": "CC Switch",
    "removeHeader": "Remove header",
    "noHeaders": "No custom headers configured",
    "extraOptions": "Extra Options",
    "extraOptionsHint": "Configure extra SDK options like timeout, setCacheKey, etc. Values are auto-parsed to appropriate types (number, boolean, etc.).",
    "addExtraOption": "Add",
    "extraOptionKey": "Key",
    "extraOptionValue": "Value",
    "extraOptionKeyPlaceholder": "timeout",
    "extraOptionValuePlaceholder": "600000",
    "noExtraOptions": "No extra options configured",
    "noModelOptions": "Model options, click + to add",
    "modelLimits": "Token Limits",
    "limitContext": "Context",
    "limitOutput": "Output",
    "modelExtraFields": "Model Properties",
    "noModelExtraFields": "Model properties (variants, cost, etc.), click + to add",
    "modelExtraFieldKeyPlaceholder": "variants",
    "sdkOptions": "SDK Options",
    "modelOptionKeyPlaceholder": "provider",
    "modelOptionValuePlaceholder": "{\"order\": [\"baseten\"]}"
  },
  "providerPreset": {
    "label": "Provider Preset",
    "custom": "Custom Configuration",
    "other": "Other",
    "hint": "You can continue to adjust the fields below after selecting a preset.",
    "searchTooltip": "Search presets",
    "searchAriaLabel": "Search provider presets",
    "searchPlaceholder": "Search name, website, or category...",
    "sortAriaLabel": "Toggle preset sorting",
    "sortNameAscTooltip": "Sort by name A-Z",
    "sortOriginalTooltip": "Restore original order",
    "noSearchResults": "No provider presets match your search."
  },
  "usage": {
    "title": "Usage Statistics",
    "subtitle": "View AI model usage and cost statistics",
    "today": "24 Hours",
    "last7days": "7 Days",
    "last30days": "30 Days",
    "presetToday": "Today",
    "preset1d": "1d",
    "preset7d": "7d",
    "preset14d": "14d",
    "preset30d": "30d",
    "totalRequests": "Total Requests",
    "totalCost": "Total Cost",
    "cost": "Cost",
    "unpriced": "Unpriced",
    "perMillion": "(per million)",
    "trends": "Usage Trends",
    "rangeToday": "Last 24 hours (hourly)",
    "rangeLast7Days": "Last 7 days",
    "rangeLast30Days": "Last 30 days",
    "totalTokens": "New Tokens (Input+Output)",
    "cacheTokens": "Cache Tokens",
    "realTotal": "Tokens Processed",
    "realTotalHint": "Input + Output + Cache Write + Cache Read",
    "freshInput": "Fresh Input",
    "cacheHitRate": "Cache Hit Rate",
    "requestLogs": "Request Logs",
    "providerStats": "Provider Stats",
    "modelStats": "Model Stats",
    "time": "Time",
    "provider": "Provider",
    "billingModel": "Billing Model",
    "inputTokens": "Input",
    "outputTokens": "Output",
    "cacheReadTokens": "Cache Hit",
    "cacheCreationTokens": "Cache Creation",
    "timingInfo": "Duration/TTFT",
    "status": "Status",
    "multiplier": "Multiplier",
    "requestModel": "Request Model",
    "responseModel": "Response Model",
    "noData": "No data",
    "unknownProvider": "Unknown Provider",
    "stream": "Stream",
    "nonStream": "Non-stream",
    "source": "Source",
    "requestsLabel": "requests",
    "costLabel": "total cost",
    "appFilter": {
      "all": "All",
      "claude": "Claude Code",
      "codex": "Codex",
      "gemini": "Gemini",
      "opencode": "OpenCode",
      "grokbuild": "Grok Build",
      "pi": "Pi",
      "mcode": "MiniMax Code"
    },
    "rawInputLabel": "Raw",
    "sessionSync": {
      "title": "Auto-Scan Session Logs",
      "description": "Periodically scans each client's local session logs to track usage; when off, logs are only scanned on manual sync",
      "syncNow": "Sync Now",
      "syncCompleted": "Sync completed: {{imported}} imported, {{files}} files scanned, {{errors}} errors",
      "syncFailed": "Session usage sync failed: {{error}}"
    },
    "rebuildCodex": {
      "title": "Codex Usage Maintenance",
      "description": "Rebuild Codex session usage from local rollout logs",
      "warning": "The database is backed up first. History whose source JSONL has been deleted cannot be re-imported.",
      "action": "Rebuild Codex Usage",
      "confirmTitle": "Rebuild Codex usage?",
      "confirmMessage": "This clears existing Codex session details and rollups, then imports them again from local Codex logs.\n\nHistory with deleted logs will be lost. Forks whose parent rollout is missing will be deferred.",
      "confirmAction": "Back Up and Rebuild",
      "completed": "Rebuild complete: {{imported}} imported, {{errors}} errors, {{suspected}} suspected duplicates, {{deferred}} deferred files",
      "failed": "Codex usage rebuild failed: {{error}}"
    },
    "totalRecords": "{{total}} records total",
    "goToPage": "Go",
    "pageInputPlaceholder": "Page",
    "modelPricing": "Model Pricing",
    "loadPricingError": "Failed to load pricing data",
    "modelPricingDesc": "Configure token costs for each model",
    "noPricingData": "No pricing data. Click \"Add\" to add model pricing configuration.",
    "model": "Model",
    "pricingModel": "Pricing Model",
    "displayName": "Display Name",
    "inputCost": "Input Cost",
    "outputCost": "Output Cost",
    "cacheReadCost": "Cache Hit",
    "cacheWriteCost": "Cache Creation",
    "deleteConfirmTitle": "Confirm Delete",
    "deleteConfirmDesc": "Are you sure you want to delete this model pricing? This action cannot be undone.",
    "queryFailed": "Query failed",
    "refreshUsage": "Refresh usage",
    "planUsage": "Plan usage",
    "invalid": "Expired",
    "total": "Total:",
    "used": "Used:",
    "remaining": "Remaining:",
    "justNow": "Just now",
    "minutesAgo": "{{count}} min ago",
    "hoursAgo": "{{count}} hr ago",
    "daysAgo": "{{count}} day ago",
    "multiplePlans": "{{count}} plans",
    "expand": "Expand",
    "collapse": "Collapse",
    "modelIdPlaceholder": "e.g., claude-3-5-sonnet-20241022",
    "displayNamePlaceholder": "e.g., Claude 3.5 Sonnet",
    "appType": "App Type",
    "statusCode": "Status Code",
    "allSources": "All Sources",
    "allModels": "All Models",
    "filterBySource": "Filter by source",
    "filterByModel": "Filter by model",
    "refreshInterval": "Auto-refresh interval",
    "refreshOff": "Off",
    "timeRange": "Time Range",
    "customRange": "Calendar Filter",
    "customRangeHint": "Supports both date and time",
    "startTime": "Start Time",
    "endTime": "End Time",
    "liveEndTime": "End time follows current time",
    "liveEndTimeNow": "Now",
    "input": "Input",
    "output": "Output",
    "cacheWrite": "Creation",
    "cacheWriteNotReported": "OpenAI protocol doesn't distinguish cache creation; only cache hits are reported",
    "cacheWritePartial": "Some protocols (e.g. OpenAI) don't report cache creation; the value may be incomplete",
    "cacheRead": "Hit",
    "baseCost": "Base",
    "costMultiplier": "Cost Multiplier",
    "withMultiplier": "with multiplier",
    "requestDetail": "Request Detail",
    "requestNotFound": "Request not found",
    "basicInfo": "Basic Info",
    "tokenUsage": "Token Usage",
    "cacheCreationCost": "Cache Creation Cost",
    "costBreakdown": "Cost Breakdown",
    "performance": "Performance",
    "latency": "Latency",
    "errorMessage": "Error Message",
    "requests": "Requests",
    "tokens": "Tokens",
    "avgCost": "Average Cost",
    "avgLatency": "Average Latency",
    "successRate": "Success Rate",
    "requestId": "Request ID",
    "never": "Never",
    "modelId": "Model ID",
    "modelIdRequired": "Model ID is required",
    "inputCostPerMillion": "Input Cost (per million tokens, USD)",
    "outputCostPerMillion": "Output Cost (per million tokens, USD)",
    "invalidPrice": "Price must be non-negative",
    "invalidTimeRange": "Please select complete start/end time",
    "invalidTimeRangeOrder": "Start time cannot be later than end time",
    "timeRangeTooLarge": "Time range is too large, please narrow it down",
    "addPricing": "Add Pricing",
    "editPricing": "Edit Pricing",
    "pricingAdded": "Pricing added",
    "pricingUpdated": "Pricing updated",
    "importFromModelsDev": "Import from models.dev",
    "modelsDevHint": "Skip manual entry — pick model pricing from models.dev",
    "modelsDevPickerTitle": "Import Pricing from models.dev",
    "modelsDevPickerDesc": "Select a model to import (prices in USD per million tokens). One model per import.",
    "modelsDevSearchPlaceholder": "Search models or providers (full search)...",
    "modelsDevAllProviders": "All providers",
    "modelsDevLoadError": "Failed to load models.dev data",
    "modelsDevRetry": "Retry",
    "modelsDevImportButton": "Import",
    "modelsDevImporting": "Importing...",
    "modelsDevImported": "Imported pricing for {{name}}",
    "modelsDevNoResults": "No matching models",
    "modelsDevTruncated": "Showing first {{shown}} of {{total}} results — refine your search",
    "modelsDevDefaultHint": "Showing the {{shown}} most recently released models (of {{total}}) — type to search all",
    "modelsDevAutoSync": {
      "title": "Automatic models.dev pricing sync",
      "description": "When enabled, periodically fetch selected prices when CC Switch launches and keep them in your local pricing file.",
      "enabled": "Enabled",
      "disabled": "Disabled",
      "enableConfirmTitle": "Enable automatic pricing sync?",
      "enableConfirmMessage": "After enabling, CC Switch will periodically update prices for the selected models from models.dev when it launches (at most once every 6 hours). Built-in and manually configured prices with the same model ID will be overwritten.",
      "enableConfirmAction": "Enable automatic sync",
      "configure": "Choose models",
      "configureTitle": "Choose models for automatic pricing sync",
      "configureDescription": "Search and filter models to update automatically. Your choices are stored locally.",
      "commonModels": "Automatically include common models",
      "commonModelsDescription": "Selects {{count}} recent Claude, GPT, Gemini, Grok, DeepSeek, Qwen, MiMo, LongCat, Kimi, MiniMax, and GLM models.",
      "selectFiltered": "Select filtered ({{count}})",
      "clearFiltered": "Clear filtered",
      "selectedCount": "{{count}} models selected",
      "selectionHint": "Selections with the same normalized model ID are imported once.",
      "commonBadge": "Common",
      "selectionSaved": "Automatic pricing selection saved",
      "syncSuccess": "Pricing sync complete: {{imported}} models checked, {{changed}} updated",
      "syncFailed": "Pricing sync failed: {{error}}",
      "configLoadFailed": "Failed to load local pricing configuration: {{error}}",
      "neverSynced": "Never",
      "lastSync": "Last sync",
      "commonStatus": "Common models",
      "lastError": "Last automatic sync failed: {{error}}",
      "localFile": "Local pricing file",
      "openFolder": "Open folder",
      "openFolderFailed": "Failed to open the local pricing folder: {{error}}",
      "reloadLocalFile": "Reload file",
      "localFileReloaded": "Local pricing file reloaded",
      "localFileReloadFailed": "Failed to reload local pricing file: {{error}}",
      "syncNow": "Sync now"
    },
    "cacheReadCostPerMillion": "Cache Read Cost (per million tokens, USD)",
    "cacheCreationCostPerMillion": "Cache Write Cost (per million tokens, USD)"
  },
  "usageScript": {
    "title": "Configure Usage Query",
    "enableUsageQuery": "Enable usage query",
    "presetTemplate": "Preset template",
    "requestUrl": "Request URL",
    "requestUrlPlaceholder": "e.g. https://api.example.com",
    "method": "HTTP method",
    "templateCustom": "Custom",
    "templateGeneral": "General",
    "templateNewAPI": "NewAPI",
    "templateCopilot": "GitHub Copilot",
    "templateTokenPlan": "Token Plan",
    "templateBalance": "Official",
    "templateOfficialSubscription": "Official Subscription",
    "copilotAutoAuth": "Auto OAuth authentication, no manual credentials needed",
    "tokenPlanHint": "Automatically uses the provider's API Key and Base URL to query Token Plan quota",
    "balanceHint": "Automatically uses the provider's API Key to query account balance",
    "officialSubscriptionHint": "Reads the local CLI OAuth credentials and calls the official API to query subscription quota. Disabled by default and only requests after you enable it.",
    "resetDate": "Reset date",
    "premiumRequests": "Premium Requests",
    "credentialsConfig": "Credentials",
    "credentialsHint": "Leave empty to use provider config",
    "optional": "optional",
    "apiKeyPlaceholder": "Leave empty to use provider's API Key",
    "baseUrlPlaceholder": "Leave empty to use provider's base URL",
    "baseUrl": "Base URL",
    "accessToken": "Access Token",
    "accessTokenPlaceholder": "Generate in 'Security Settings'",
    "userId": "User ID",
    "userIdPlaceholder": "e.g., 114514",
    "accessKeyId": "AccessKey ID",
    "secretAccessKey": "SecretAccessKey",
    "volcengineAkSkHint": "Volcengine usage query needs an account-level AccessKey ID / Secret (different from the inference API key). Create them in the Volcengine console via the top-right account menu → 'API Access Keys'.",
    "volcengineKeyConsoleLink": "Create keys at:",
    "zhipuTeamHint": "Zhipu team plan usage query needs the team API key (reuses this provider's credentials) + organization ID + project ID (sent as bigmodel-organization / bigmodel-project request headers). Find the organization and project IDs in the team admin console's usage page URL.",
    "zhipuTeamConsoleLink": "Team usage page:",
    "organizationId": "Organization ID",
    "organizationIdPlaceholder": "e.g. org-xxxxxx",
    "projectId": "Project ID",
    "projectIdPlaceholder": "e.g. proj-xxxxxx",
    "defaultPlan": "Default Plan",
    "queryFailedMessage": "Query failed",
    "queryScript": "Query script (JavaScript)",
    "timeoutSeconds": "Timeout (seconds)",
    "headers": "Headers",
    "body": "Body",
    "timeoutHint": "Range: 2-30 seconds",
    "timeoutMustBeInteger": "Timeout must be an integer, decimal part ignored",
    "timeoutCannotBeNegative": "Timeout cannot be negative",
    "autoIntervalMinutes": "Auto query interval (minutes, 0 to disable)",
    "autoQueryInterval": "Auto Query Interval (minutes)",
    "autoQueryIntervalHint": "0 to disable; recommend 5-60 minutes",
    "intervalMustBeInteger": "Interval must be an integer, decimal part ignored",
    "intervalCannotBeNegative": "Interval cannot be negative",
    "intervalAdjusted": "Interval adjusted to {{value}} minutes",
    "scriptHelp": "Script writing instructions:",
    "configFormat": "Configuration format:",
    "commentOptional": "optional",
    "commentResponseIsJson": "response is the JSON data returned by the API",
    "extractorFormat": "Extractor return format (all fields optional):",
    "tips": "💡 Tips:",
    "testing": "Testing...",
    "testScript": "Test script",
    "format": "Format",
    "saveConfig": "Save config",
    "scriptEmpty": "Script configuration cannot be empty",
    "mustHaveReturn": "Script must contain return statement",
    "testSuccess": "Test successful!",
    "testFailed": "Test failed",
    "formatSuccess": "Format successful",
    "formatFailed": "Format failed",
    "supportedVariables": "Supported Variables",
    "variablesHint": "Supported variables: {{apiKey}}, {{baseUrl}} | extractor function receives API response JSON object",
    "scriptConfig": "Request configuration",
    "extractorCode": "Extractor code",
    "extractorHint": "Return object should include remaining quota fields",
    "fieldIsValid": "• isValid: Boolean, whether plan is valid",
    "fieldInvalidMessage": "• invalidMessage: String, reason for expiration (shown when isValid is false)",
    "fieldRemaining": "• remaining: Number, remaining quota",
    "fieldUnit": "• unit: String, unit (e.g., \"USD\")",
    "fieldPlanName": "• planName: String, plan name",
    "fieldTotal": "• total: Number, total quota",
    "fieldUsed": "• used: Number, used quota",
    "fieldExtra": "• extra: String, custom display text",
    "tip1": "• Variables {{apiKey}} and {{baseUrl}} are automatically replaced",
    "tip2": "• Extractor function runs in sandbox environment, supports ES2020+ syntax",
    "tip3": "• Entire config must be wrapped in () to form object literal expression"
  },
  "dbUpgrade": {
    "title": "Database version is too new",
    "description": "This database was created by a newer version of CC Switch. Upgrade the app to continue. Upgrading will not delete your data.",
    "versionInfo": "Database v{{db}} · App supports v{{supported}}",
    "dbPath": "Database file",
    "checking": "Checking for available updates…",
    "updateAvailable": "Version v{{version}} is available; upgrading will let you continue.",
    "incompatibleTitle": "Upgrading won't fix this",
    "incompatibleDescription": "You are already on the latest version, but the database (v{{db}}) is still newer than this app supports (v{{supported}}). It was likely created by a third-party client or a newer build, so upgrading the official app cannot make it compatible.",
    "preparing": "Preparing update…",
    "downloading": "Downloading update…",
    "upgradeNow": "Upgrade app",
    "retry": "Retry upgrade",
    "openReleases": "Open releases page",
    "openConfigDir": "Open config folder",
    "quit": "Quit"
  },
  "errors": {
    "usage_query_failed": "Usage query failed",
    "configLoadFailedTitle": "Configuration Load Failed",
    "configLoadFailedMessage": "Unable to read configuration file:\n{{path}}\n\nError details:\n{{detail}}\n\nPlease check if the JSON is valid, or restore from a backup file (e.g., config.json.bak) in the same directory.\n\nThe app will exit so you can fix this.",
    "frontendCrashTitle": "Something went wrong in the interface",
    "frontendCrashMessage": "An attempt was made to write the error to the application diagnostic log. Reload the interface, and attach the log when opening an issue if the problem continues.",
    "reloadInterface": "Reload interface"
  },
  "presetSelector": {
    "title": "Select Configuration Type",
    "custom": "Custom",
    "customDescription": "Manually configure provider, requires complete configuration",
    "officialDescription": "Official login, no API Key required",
    "presetDescription": "Use preset configuration, only API Key required"
  },
  "mcp": {
    "title": "MCP Management",
    "import": "Import",
    "importExisting": "Import Existing",
    "addMcp": "Add MCP",
    "claudeTitle": "Claude Code MCP Management",
    "codexTitle": "Codex MCP Management",
    "geminiTitle": "Gemini MCP Management",
    "unifiedPanel": {
      "title": "MCP Server Management",
      "addServer": "Add Server",
      "editServer": "Edit Server",
      "deleteServer": "Delete Server",
      "deleteConfirm": "Are you sure you want to delete server \"{{id}}\"? This action cannot be undone.",
      "noServers": "No servers yet",
      "enabledApps": "Enabled Apps",
      "noImportFound": "No MCP servers to import found. All servers are already managed by CC Switch.",
      "importSuccess": "Successfully imported {{count}} MCP servers",
      "searchPlaceholder": "Search MCP name, description, tag, or command...",
      "searchAriaLabel": "Search managed MCP servers",
      "noSearchResults": "No MCP servers match your search",
      "apps": {
        "claude": "Claude",
        "codex": "Codex",
        "gemini": "Gemini",
        "grokbuild": "Grok Build",
        "opencode": "OpenCode",
        "openclaw": "OpenClaw",
        "hermes": "Hermes",
        "mcode": "MiniMax Code"
      }
    },
    "userLevelPath": "User-level MCP path",
    "serverList": "Servers",
    "loading": "Loading...",
    "empty": "No MCP servers",
    "emptyDescription": "Click the button in the top right to add your first MCP server",
    "add": "Add MCP",
    "addServer": "Add MCP",
    "editServer": "Edit MCP",
    "addClaudeServer": "Add Claude Code MCP",
    "editClaudeServer": "Edit Claude Code MCP",
    "addCodexServer": "Add Codex MCP",
    "editCodexServer": "Edit Codex MCP",
    "configPath": "Config Path",
    "serverCount": "{{count}} MCP server(s) configured",
    "enabledCount": "{{count}} enabled",
    "template": {
      "fetch": "Quick Template: mcp-fetch"
    },
    "form": {
      "title": "MCP Title (Unique)",
      "titlePlaceholder": "my-mcp-server",
      "name": "Display Name",
      "namePlaceholder": "e.g. @modelcontextprotocol/server-time",
      "enabledApps": "Enable to Apps",
      "noAppsWarning": "At least one app must be selected",
      "description": "Description",
      "descriptionPlaceholder": "Optional description",
      "tags": "Tags (comma separated)",
      "tagsPlaceholder": "stdio, time, utility",
      "homepage": "Homepage",
      "homepagePlaceholder": "https://example.com",
      "docs": "Docs",
      "docsPlaceholder": "https://example.com/docs",
      "additionalInfo": "Additional Info",
      "jsonConfig": "Full JSON Configuration",
      "jsonConfigOrPrefix": "Full JSON configuration or use",
      "tomlConfigOrPrefix": "Full TOML configuration or use",
      "jsonPlaceholder": "{\n  \"type\": \"stdio\",\n  \"command\": \"uvx\",\n  \"args\": [\"mcp-server-fetch\"]\n}",
      "tomlConfig": "Full TOML Configuration",
      "tomlPlaceholder": "type = \"stdio\"\ncommand = \"uvx\"\nargs = [\"mcp-server-fetch\"]",
      "useWizard": "Config Wizard",
      "syncOtherSide": "Mirror to {{target}}",
      "syncOtherSideHint": "Apply the same settings to {{target}}; existing entries with the same id will be overwritten.",
      "willOverwriteWarning": "Will overwrite existing config in {{target}}"
    },
    "wizard": {
      "title": "MCP Configuration Wizard",
      "hint": "Quickly configure MCP server and auto-generate JSON configuration",
      "type": "Type",
      "typeStdio": "stdio",
      "typeHttp": "http",
      "typeSse": "sse",
      "command": "Command",
      "commandPlaceholder": "npx or uvx",
      "args": "Arguments",
      "argsPlaceholder": "arg1\narg2",
      "env": "Environment Variables",
      "envPlaceholder": "KEY1=value1\nKEY2=value2",
      "url": "URL",
      "urlPlaceholder": "https://api.example.com/mcp",
      "urlRequired": "Please enter URL",
      "headers": "Headers (optional)",
      "headersPlaceholder": "Authorization: Bearer your_token_here\nContent-Type: application/json",
      "preview": "Configuration Preview",
      "apply": "Apply Configuration"
    },
    "id": "Identifier (unique)",
    "type": "Type",
    "command": "Command",
    "validateCommand": "Validate Command",
    "args": "Args",
    "argsPlaceholder": "e.g., mcp-server-fetch --help",
    "env": "Environment (one per line, KEY=VALUE)",
    "envPlaceholder": "FOO=bar\nHELLO=world",
    "reset": "Reset",
    "msg": {
      "saved": "Saved",
      "deleted": "Deleted",
      "enabled": "Enabled",
      "disabled": "Disabled",
      "templateAdded": "Template added"
    },
    "error": {
      "idRequired": "Please enter identifier",
      "idExists": "Identifier already exists. Please choose another.",
      "jsonInvalid": "Invalid JSON format",
      "tomlInvalid": "Invalid TOML format",
      "commandRequired": "Please enter command",
      "singleServerObjectRequired": "Please paste a single MCP server object (do not include top-level mcpServers)",
      "saveFailed": "Save failed",
      "deleteFailed": "Delete failed"
    },
    "validation": {
      "ok": "Command available",
      "fail": "Command not found"
    },
    "confirm": {
      "deleteTitle": "Delete MCP Server",
      "deleteMessage": "Are you sure you want to delete MCP server \"{{id}}\"? This action cannot be undone."
    },
    "presets": {
      "title": "Select MCP Type",
      "enable": "Enable",
      "enabled": "Enabled",
      "installed": "Installed",
      "docs": "Docs",
      "requiresEnv": "Requires env",
      "fetch": {
        "name": "mcp-server-fetch",
        "description": "Universal HTTP request tool, supports GET/POST and other HTTP methods, suitable for quick API requests and web data scraping"
      },
      "time": {
        "name": "@modelcontextprotocol/server-time",
        "description": "Time query tool providing current time, timezone conversion, and date calculation features"
      },
      "memory": {
        "name": "@modelcontextprotocol/server-memory",
        "description": "Knowledge graph memory system supporting entities, relations, and observations to help AI remember important information from conversations"
      },
      "sequential-thinking": {
        "name": "@modelcontextprotocol/server-sequential-thinking",
        "description": "Sequential thinking tool helping AI break down complex problems into multiple steps for deeper thinking"
      },
      "context7": {
        "name": "@upstash/context7-mcp",
        "description": "Context7 documentation search tool providing latest library docs and code examples, with higher limits when configured with a key"
      }
    }
  },
  "prompts": {
    "manage": "Prompts",
    "title": "{{appName}} Prompt Management",
    "claudeTitle": "Claude Prompt Management",
    "codexTitle": "Codex Prompt Management",
    "add": "Add Prompt",
    "edit": "Edit Prompt",
    "addTitle": "Add {{appName}} Prompt",
    "editTitle": "Edit {{appName}} Prompt",
    "import": "Import Existing",
    "count": "{{count}} prompts",
    "enabled": "Enabled",
    "enable": "Enable",
    "enabledName": "Enabled: {{name}}",
    "noneEnabled": "No prompt enabled",
    "currentFile": "Current {{filename}} Content",
    "empty": "No prompts yet",
    "emptyDescription": "Click the button above to add or import prompts",
    "loading": "Loading...",
    "searchPlaceholder": "Search prompt name, description, or content...",
    "searchAriaLabel": "Search managed prompts",
    "noSearchResults": "No prompts match your search",
    "name": "Name",
    "namePlaceholder": "e.g., Default Project Prompt",
    "description": "Description",
    "descriptionPlaceholder": "Optional description",
    "content": "Content",
    "contentPlaceholder": "# {{filename}}\n\nEnter prompt content here...",
    "loadFailed": "Failed to load prompts",
    "saveSuccess": "Saved successfully",
    "saveFailed": "Failed to save",
    "deleteSuccess": "Deleted successfully",
    "deleteFailed": "Failed to delete",
    "enableSuccess": "Enabled successfully",
    "enableFailed": "Failed to enable",
    "disableSuccess": "Disabled successfully",
    "disableFailed": "Failed to disable",
    "importSuccess": "Imported successfully",
    "importFailed": "Failed to import",
    "confirm": {
      "deleteTitle": "Confirm Delete",
      "deleteMessage": "Are you sure you want to delete prompt \"{{name}}\"?"
    }
  },
  "profiles": {
    "switcherAriaLabel": "Project: {{name}}",
    "switcherTooltip": {
      "claude": "Projects: switch the Claude Code provider / MCP / Skills / memory files in one click",
      "claude-desktop": "Projects: switch the Claude Desktop provider in one click",
      "codex": "Projects: switch the Codex provider / MCP / Skills / memory files in one click"
    },
    "none": "No project",
    "searchPlaceholder": "Search projects",
    "empty": "No projects yet",
    "createFromCurrent": "New project",
    "createDescription": {
      "claude": "Save the current Claude Code provider, MCP, Skills and memory file as a project you can switch to later.",
      "claude-desktop": "Save the current Claude Desktop provider as a project you can switch to later.",
      "codex": "Save the current Codex provider, MCP, Skills and memory file configuration as a project you can switch to later."
    },
    "manage": "Manage projects…",
    "manageTitle": "Manage Projects",
    "manageDescription": "Projects are configuration snapshots. When you switch projects, the current configuration is automatically saved back to the project you are leaving.",
    "namePlaceholder": "e.g. Development, Drawing",
    "rename": "Rename",
    "noSnapshotForScope": "Not saved for this app yet",
    "delete": "Delete",
    "deleteConfirmTitle": "Confirm Delete",
    "deleteConfirmMessage": "Are you sure you want to delete project \"{{name}}\"? Your current configuration will not be changed.",
    "createSuccess": "Project created",
    "createFailed": "Failed to create project: {{detail}}",
    "updateSuccess": "Project updated",
    "updateFailed": "Failed to update project: {{detail}}",
    "deleteSuccess": "Project deleted",
    "deleteFailed": "Failed to delete project: {{detail}}",
    "applySuccess": "Project applied",
    "applyFailed": "Failed to apply project: {{detail}}",
    "applyWarnings": "Project applied with {{warningCount}} warning(s):\n{{details}}",
    "clearSuccess": "Switched to no project"
  },
  "workspace": {
    "title": "Workspace Files",
    "manage": "Workspace",
    "files": {
      "agents": "Agent instructions and rules",
      "soul": "Agent personality and communication style",
      "user": "User profile and preferences",
      "identity": "Agent name and avatar",
      "tools": "Local tool documentation",
      "memory": "Long-term memory and decisions",
      "heartbeat": "Heartbeat run checklist",
      "bootstrap": "First-run bootstrap ritual",
      "boot": "Gateway reboot checklist"
    },
    "editing": "Edit {{filename}}",
    "saveSuccess": "Saved successfully",
    "saveFailed": "Failed to save",
    "loadFailed": "Failed to load",
    "openDirectory": "Open in file manager",
    "dailyMemory": {
      "title": "Daily Memory",
      "sectionTitle": "Daily Memory",
      "cardTitle": "Daily Memory Files",
      "cardDescription": "Browse & manage daily memories",
      "createToday": "Add Memory",
      "empty": "No daily memory files yet",
      "loadFailed": "Failed to load daily memory files",
      "createFailed": "Failed to create daily memory file",
      "deleteSuccess": "Daily memory file deleted",
      "deleteFailed": "Failed to delete daily memory file",
      "confirmDeleteTitle": "Delete Daily Memory",
      "confirmDeleteMessage": "Delete the daily memory for {{date}}? This cannot be undone.",
      "searchPlaceholder": "Search full content...",
      "searchScopeHint": "Full-text search across all daily memories. ⌘F",
      "searchCloseHint": "Esc to close",
      "noSearchResults": "No daily memories match your search.",
      "searching": "Searching...",
      "searchFailed": "Search failed",
      "matchCount": "{{count}} match(es)"
    }
  },
  "openclaw": {
    "backupCreated": "Backup created: {{path}}",
    "providerKey": "Provider Key",
    "providerKeyPlaceholder": "my-provider",
    "providerKeyHint": "Unique identifier in config file. Use lowercase letters, numbers, and hyphens only.",
    "providerKeyLockedHint": "This provider has already been added to the app config, so its key can no longer be changed.",
    "providerKeyRequired": "Provider key is required",
    "providerKeyDuplicate": "This key is already in use",
    "providerKeyInvalid": "Invalid format. Use lowercase letters, numbers, and hyphens only.",
    "apiProtocol": "API Protocol",
    "selectProtocol": "Select API Protocol",
    "apiProtocolHint": "Select the protocol type compatible with the provider's API. Most providers use OpenAI Completions format.",
    "baseUrl": "API Endpoint",
    "baseUrlHint": "The provider's API endpoint address.",
    "models": "Model Configuration",
    "addModel": "Add Model",
    "selectDefaultModel": "Select Default Model",
    "noModels": "No models configured",
    "modelId": "Model ID",
    "modelIdPlaceholder": "claude-3-sonnet",
    "modelName": "Display Name",
    "modelNamePlaceholder": "Claude 3 Sonnet",
    "toggleModelDetails": "Expand or collapse model details",
    "removeModel": "Remove model",
    "contextWindow": "Context Length",
    "maxTokens": "Max Output Tokens",
    "reasoning": "Supports Extended Thinking",
    "inputTypes": "Input Types",
    "modelCost": "Cost ($/million tokens)",
    "inputCost": "Input",
    "outputCost": "Output",
    "cacheReadCost": "Cache Read",
    "cacheWriteCost": "Cache Write",
    "userAgent": "Send User-Agent",
    "userAgentHint": "Some providers require a browser User-Agent header to work properly.",
    "env": {
      "title": "Environment Variables",
      "description": "Manage environment variables in openclaw.json (API keys, custom variables, etc.)",
      "editorHint": "Edit the full env section as JSON. Nested objects such as env.vars and env.shellEnv are supported.",
      "objectRequired": "OpenClaw env must be a JSON object.",
      "invalidJson": "OpenClaw env must be valid JSON.",
      "empty": "OpenClaw env cannot be empty. Use {} for an empty object.",
      "keyPlaceholder": "Variable name",
      "valuePlaceholder": "Value",
      "add": "Add Variable",
      "saveSuccess": "Environment variables saved",
      "saveFailed": "Failed to save environment variables",
      "loadFailed": "Failed to load environment variables",
      "duplicateKey": "Duplicate variable name detected: {{key}}"
    },
    "tools": {
      "title": "Tool Permissions",
      "description": "Manage tool permissions in openclaw.json (allow/deny lists)",
      "profile": "Permission Profile",
      "profileMinimal": "Minimal",
      "profileCoding": "Coding",
      "profileMessaging": "Messaging",
      "profileFull": "Full",
      "profileUnset": "Not set",
      "unsupportedProfileTitle": "Unsupported tools profile detected",
      "unsupportedProfileDescription": "The current tools.profile value '{{value}}' is not in the supported OpenClaw list. It will be preserved until you choose a new value.",
      "unsupportedProfileLabel": "unsupported",
      "allowList": "Allow List",
      "denyList": "Deny List",
      "patternPlaceholder": "Tool name or pattern",
      "addAllow": "Add Allow",
      "addDeny": "Add Deny",
      "saveSuccess": "Tool permissions saved",
      "saveFailed": "Failed to save tool permissions",
      "loadFailed": "Failed to load tool permissions"
    },
    "agents": {
      "title": "Agents Config",
      "description": "Manage agents.defaults in openclaw.json (default model, runtime parameters, etc.)",
      "modelSection": "Model Configuration",
      "primaryModel": "Default Model",
      "primaryModelHint": "Select from models of configured providers",
      "notSet": "Not set",
      "fallbackModels": "Fallback Models",
      "fallbackModelsHint": "When the primary model is unavailable, fallbacks are tried in order",
      "addFallback": "Add fallback model",
      "noModels": "No configured provider models. Please add an OpenClaw provider first.",
      "notInList": "{{value}} (not configured)",
      "runtimeSection": "Runtime Parameters",
      "workspace": "Workspace Path",
      "timeout": "Timeout (seconds)",
      "contextTokens": "Context Tokens",
      "maxConcurrent": "Max Concurrent",
      "legacyTimeoutTitle": "Legacy timeout detected",
      "legacyTimeoutDescription": "This config still uses agents.defaults.timeout. Saving here will migrate it to timeoutSeconds.",
      "saveSuccess": "Agents config saved",
      "saveFailed": "Failed to save agents config",
      "loadFailed": "Failed to load agents config"
    },
    "health": {
      "title": "OpenClaw config warnings detected",
      "invalidToolsProfile": "tools.profile contains an unsupported value. OpenClaw currently expects minimal, coding, messaging, or full.",
      "legacyTimeout": "agents.defaults.timeout is deprecated. Save the Agents panel to migrate it to timeoutSeconds.",
      "stringifiedEnvVars": "env.vars should be an object, but the current value looks stringified or malformed.",
      "stringifiedShellEnv": "env.shellEnv should be an object, but the current value looks stringified or malformed.",
      "parseFailed": "openclaw.json could not be parsed as valid JSON5. Fix the file before editing it here."
    }
  },
  "hermes": {
    "form": {
      "baseUrl": "API Endpoint",
      "baseUrlHint": "The API endpoint URL for this provider.",
      "providerKey": "Provider Key",
      "providerKeyPlaceholder": "my-provider",
      "providerKeyHint": "Lowercase letters, numbers, and hyphens only. Used as the provider name in config.yaml.",
      "providerKeyLockedHint": "This provider is in Hermes config; key is locked.",
      "providerKeyRequired": "Provider key is required",
      "providerKeyInvalid": "Provider key can only contain lowercase letters, numbers, and hyphens",
      "providerKeyDuplicate": "This provider key already exists",
      "apiMode": "API Mode",
      "apiModeHint": "Provider API protocol. Choose the format that matches your endpoint.",
      "apiModeChatCompletions": "OpenAI Chat Completions",
      "apiModeAnthropicMessages": "Anthropic Messages",
      "apiModeCodexResponses": "OpenAI Responses",
      "apiModeBedrockConverse": "AWS Bedrock Converse",
      "baseUrlRequired": "API endpoint is required",
      "baseUrlScheme": "Use an http:// or https:// address",
      "baseUrlInvalid": "API endpoint is not a valid URL",
      "models": "Models",
      "addModel": "Add model",
      "noModels": "No models configured. Switching to this provider won't change the default model.",
      "modelId": "Model ID",
      "modelIdPlaceholder": "anthropic/claude-opus-5",
      "modelName": "Display name",
      "modelNamePlaceholder": "Claude Opus 5",
      "contextLength": "Context length",
      "toggleModelDetails": "Expand or collapse model details",
      "removeModel": "Remove model",
      "modelsHint": "When activated, the first model becomes the Hermes default.",
      "rateLimitDelay": "Rate limit delay (seconds)",
      "rateLimitDelayHint": "Minimum delay in seconds between consecutive requests (optional). Leave empty for no limit."
    },
    "webui": {
      "open": "Open Hermes Web UI",
      "offline": "Hermes Web UI is not running. Start it with `hermes dashboard` first.",
      "openFailed": "Failed to open Hermes Web UI",
      "launchConfirmTitle": "Hermes Dashboard is not running",
      "launchConfirmMessage": "Open a terminal and start it now with `hermes dashboard`?\n\nThe browser will open automatically once startup completes.\n\nIf the terminal reports that `hermes` cannot be found or the web extras are missing, run first:\npip install hermes-agent[web]",
      "launchConfirmAction": "Open terminal & launch",
      "launching": "Started `hermes dashboard` in a terminal.",
      "launchFailed": "Failed to open terminal"
    },
    "memory": {
      "title": "Memory",
      "agentTab": "Agent Memory (MEMORY.md)",
      "userTab": "User Profile (USER.md)",
      "usage": "{{current}} / {{limit}} characters",
      "overLimit": "Over budget — Hermes will truncate on next load",
      "enableOn": "Enabled",
      "enableOff": "Disabled",
      "disabledHint": "Hermes will skip this memory until re-enabled",
      "toggleFailed": "Failed to toggle memory",
      "saveSuccess": "Memory saved",
      "saveFailed": "Failed to save memory",
      "loadFailed": "Failed to read memory file",
      "openConfig": "Adjust limits in Hermes Web UI",
      "runtimeNote": "Changes apply on Hermes restart or new session."
    }
  },
  "env": {
    "warning": {
      "title": "Environment Variable Conflicts Detected",
      "description": "Found {{count}} environment variables that may override your configuration"
    },
    "actions": {
      "expand": "View Details",
      "collapse": "Collapse",
      "selectAll": "Select All",
      "clearSelection": "Clear Selection",
      "deleteSelected": "Delete Selected ({{count}})",
      "deleting": "Deleting..."
    },
    "field": {
      "value": "Value",
      "source": "Source"
    },
    "source": {
      "userRegistry": "User Environment Variable (Registry)",
      "systemRegistry": "System Environment Variable (Registry)",
      "systemEnv": "System Environment Variable"
    },
    "delete": {
      "success": "Environment variables deleted successfully",
      "error": "Failed to delete environment variables"
    },
    "backup": {
      "location": "Backup location: {{path}}"
    },
    "confirm": {
      "title": "Confirm Delete Environment Variables",
      "message": "Are you sure you want to delete {{count}} environment variable(s)?",
      "backupNotice": "A backup will be created automatically before deletion. You can restore it later. Changes take effect after restarting the application or terminal.",
      "confirm": "Confirm Delete"
    },
    "error": {
      "noSelection": "Please select environment variables to delete"
    }
  },
  "skills": {
    "manage": "Skills",
    "title": "Skills Management",
    "description": "Discover and install skills from popular repositories to extend Claude Code/Codex/Gemini capabilities",
    "refresh": "Refresh",
    "refreshing": "Refreshing...",
    "repoManager": "Repository Management",
    "count": "{{count}} skills",
    "empty": "No skills available",
    "emptyDescription": "Add skill repositories to discover available skills",
    "addRepo": "Add Skill Repository",
    "loading": "Loading...",
    "installed": "Installed",
    "install": "Install",
    "installing": "Installing...",
    "uninstall": "Uninstall",
    "uninstalling": "Uninstalling...",
    "view": "View",
    "noDescription": "No description",
    "loadFailed": "Failed to load",
    "installSuccess": "Skill {{name}} installed",
    "installFailed": "Failed to install",
    "uninstallSuccess": "Skill {{name}} uninstalled",
    "uninstallPiPreserved": "Pi's copy could not be verified as CC Switch-managed and was left in place: {{path}}",
    "uninstallPiCleanupIncomplete": "Pi cleanup could not be completed. Check the Pi Skills directory manually for a leftover copy.",
    "uninstallFailed": "Failed to uninstall",
    "update": "Update",
    "updating": "Updating...",
    "updateAvailable": "Update",
    "updateSuccess": "Skill {{name}} updated to latest version",
    "updateFailed": "Failed to update",
    "checkUpdates": "Check Updates",
    "checkingUpdates": "Checking...",
    "noUpdates": "All skills are up to date",
    "updatesFound": "{{count}} skill(s) have updates available",
    "updateAll": "Update All ({{count}})",
    "updatingAll": "Updating...",
    "updateAllSuccess": "Successfully updated {{count}} skill(s)",
    "error": {
      "skillNotFound": "Skill not found: {{directory}}",
      "missingRepoInfo": "Missing repository info (owner or name)",
      "downloadTimeout": "Download repository {{owner}}/{{name}} timeout ({{timeout}}s)",
      "downloadTimeoutHint": "Please check network connection or retry later",
      "skillPathNotFound": "Skill path '{{path}}' not found in repository {{owner}}/{{name}}",
      "skillDirNotFound": "Skill directory not found: {{path}}",
      "directoryConflict": "Skill directory '{{directory}}' is already occupied by {{existing_repo}}, cannot install from {{new_repo}}",
      "emptyArchive": "Downloaded archive is empty",
      "invalidRepoRef": "Invalid repository reference: {{owner}}/{{name}}",
      "archiveTooLarge": "Archive exceeds the {{limit_mb}} MB extraction limit; aborted",
      "archiveTooManyEntries": "Archive has too many entries ({{count}}); the limit is {{limit}}",
      "downloadFailed": "Download failed: HTTP {{status}}",
      "allBranchesFailed": "All branches failed, tried: {{branches}}",
      "httpError": "HTTP error {{status}}",
      "http403": "GitHub access restricted, possibly rate limited",
      "http404": "Repository or branch not found, please check URL",
      "http429": "Too many requests, please wait and retry",
      "parseMetadataFailed": "Failed to parse skill metadata",
      "getHomeDirFailed": "Unable to get user home directory",
      "noSkillsInZip": "No skills found in ZIP file (requires SKILL.md file)",
      "networkError": "Network error",
      "fsError": "File system error",
      "unknownError": "Unknown error",
      "suggestion": {
        "checkNetwork": "Please check network connection",
        "checkProxy": "Consider configuring HTTP proxy",
        "retryLater": "Please retry later",
        "checkRepoUrl": "Please check repository URL and branch name",
        "checkDiskSpace": "Please check disk space",
        "checkPermission": "Please check directory permissions",
        "uninstallFirst": "Please uninstall the existing skill with the same name first",
        "checkZipContent": "Please verify the ZIP file contains valid skill directories (with SKILL.md files)"
      }
    },
    "repo": {
      "title": "Manage Skill Repositories",
      "description": "Add or remove GitHub skill repository sources",
      "url": "Repository URL",
      "urlPlaceholder": "owner/name or https://github.com/owner/name",
      "branch": "Branch",
      "branchPlaceholder": "main",
      "path": "Skills Path",
      "pathPlaceholder": "skills (optional, leave empty for root)",
      "add": "Add Repository",
      "list": "Added Repositories",
      "empty": "No repositories",
      "invalidUrl": "Invalid repository URL format",
      "addSuccess": "Repository {{owner}}/{{name}} added, detected {{count}} skills",
      "addFailed": "Failed to add",
      "removeSuccess": "Repository {{owner}}/{{name}} removed",
      "removeFailed": "Failed to remove",
      "skillCount": "{{count}} skills detected"
    },
    "search": "Search Skills",
    "searchPlaceholder": "Search skill name or repo...",
    "installedSearchPlaceholder": "Search installed skill name, description, or repo...",
    "installedSearchAriaLabel": "Search installed skills",
    "noInstalledSearchResults": "No installed skills match your search",
    "searchSource": {
      "repos": "Repos",
      "skillssh": "skills.sh"
    },
    "skillssh": {
      "searchPlaceholder": "Search skills.sh (min 2 chars)...",
      "installs": "{{count}} installs",
      "loadMore": "Load More",
      "loading": "Searching skills.sh...",
      "noResults": "No skills found for \"{{query}}\"",
      "error": "Failed to search skills.sh",
      "poweredBy": "Powered by skills.sh"
    },
    "filter": {
      "placeholder": "Filter by status",
      "all": "All",
      "installed": "Installed",
      "uninstalled": "Not installed",
      "repo": "Filter by repo",
      "allRepos": "All repos"
    },
    "noResults": "No matching skills found",
    "noInstalled": "No skills installed",
    "noInstalledDescription": "Discover and install skills from repositories, or import existing skills",
    "discover": "Discover Skills",
    "import": "Import Existing",
    "importDescription": "Select skills to import into CC Switch unified management",
    "importSuccess": "Successfully imported {{count}} skills",
    "importSelected": "Import Selected ({{count}})",
    "noUnmanagedFound": "No skills to import found. All skills are already managed by CC Switch.",
    "unmanagedAvailable": "Skills available to import",
    "foundIn": "Found in",
    "local": "Local",
    "uninstallConfirm": "Are you sure you want to uninstall \"{{name}}\"? This will remove the skill from all apps and create a local backup first.",
    "uninstallInMainPanel": "Please uninstall skills from the main panel",
    "notFound": "Skill not found",
    "backup": {
      "location": "Backup location: {{path}}"
    },
    "restoreFromBackup": {
      "button": "Restore Backup",
      "title": "Restore From Backup",
      "description": "Choose a Skills backup to restore its files locally and add it back to the current list.",
      "empty": "No Skills backups available to restore",
      "createdAt": "Backed up at",
      "path": "Backup path",
      "restore": "Restore",
      "restoring": "Restoring...",
      "delete": "Delete",
      "deleting": "Deleting...",
      "deleteSuccess": "Deleted backup for {{name}}",
      "deleteFailed": "Failed to delete skill backup",
      "deleteConfirmTitle": "Delete Backup",
      "deleteConfirmMessage": "Are you sure you want to delete the backup for \"{{name}}\"? This action cannot be undone.",
      "success": "Skill {{name}} restored from backup",
      "failed": "Failed to restore from backup"
    },
    "apps": {
      "claude": "Claude",
      "codex": "Codex",
      "gemini": "Gemini",
      "opencode": "OpenCode",
      "openclaw": "OpenClaw"
    },
    "installFromZip": {
      "button": "Install from ZIP",
      "installing": "Installing...",
      "successSingle": "Skill {{name}} installed",
      "successMultiple": "Successfully installed {{count}} skills",
      "noSkillsFound": "No skills found in ZIP file (requires SKILL.md file)"
    }
  },
  "deeplink": {
    "confirmImport": "Confirm Import Provider",
    "confirmImportDescription": "The following configuration will be imported from deep link into CC Switch",
    "importPrompt": "Import Prompt",
    "importPromptDescription": "Please confirm whether to import this system prompt",
    "importMcp": "Import MCP Servers",
    "importMcpDescription": "Please confirm whether to import these MCP Servers",
    "importSkill": "Add Skill Repository",
    "importSkillDescription": "Please confirm whether to add this Skill repository",
    "promptImportSuccess": "Prompt imported successfully",
    "promptImportSuccessDescription": "Imported prompt: {{name}}",
    "mcpImportSuccess": "MCP Servers imported successfully",
    "mcpImportSuccessDescription": "Successfully imported {{count}} server(s)",
    "mcpPartialSuccess": "Partial import success",
    "mcpPartialSuccessDescription": "Success: {{success}}, Failed: {{failed}}",
    "skillImportSuccess": "Skill repository added successfully",
    "skillImportSuccessDescription": "Added repository: {{repo}}",
    "app": "App Type",
    "providerName": "Provider Name",
    "homepage": "Homepage",
    "endpoint": "API Endpoint",
    "apiKey": "API Key",
    "icon": "Icon",
    "model": "Model",
    "haikuModel": "Haiku Model",
    "sonnetModel": "Sonnet Model",
    "opusModel": "Opus Model",
    "multiModel": "Multi-Modal Model",
    "notes": "Notes",
    "import": "Import",
    "importing": "Importing...",
    "warning": "Please confirm the information above is correct before importing. You can edit or delete it later in the provider list.",
    "parseError": "Failed to parse deep link",
    "importSuccess": "Import successful",
    "importSuccessDescription": "Provider \"{{name}}\" has been successfully imported",
    "importError": "Failed to import",
    "configSource": "Config Source",
    "configEmbedded": "Embedded Config",
    "configRemote": "Remote Config",
    "configDetails": "Config Details",
    "configUrl": "Config File URL",
    "configMergeError": "Failed to merge configuration file",
    "primaryEndpoint": "Primary",
    "mcp": {
      "title": "Batch Import MCP Servers",
      "targetApps": "Target Apps",
      "serverCount": "MCP Servers ({{count}})",
      "enabledWarning": "After import, configurations will be written to all specified apps immediately",
      "command": "Command",
      "args": "Args",
      "env": "Env",
      "url": "URL"
    },
    "prompt": {
      "title": "Import System Prompt",
      "app": "App",
      "name": "Name",
      "description": "Description",
      "contentPreview": "Content Preview",
      "enabledWarning": "After import, this prompt will be enabled immediately and other prompts will be disabled"
    },
    "skill": {
      "title": "Add Claude Skill Repository",
      "repo": "GitHub Repository",
      "directory": "Target Directory",
      "branch": "Branch",
      "skillsPath": "Skills Path",
      "hint": "This will add the Skill repository to the list.",
      "hintDetail": "After adding, you can install specific Skills from the Skills management page."
    },
    "usageScript": "Usage Query",
    "usageScriptEnabled": "Enabled",
    "usageScriptDisabled": "Disabled",
    "usageScriptCode": "Script code",
    "usageScriptWarning": "This is JavaScript that runs when usage is queried, once enabled. Import it only if you trust the source.",
    "usageApiKey": "Usage API Key",
    "usageBaseUrl": "Usage Query URL",
    "usageAccessToken": "Usage Access Token",
    "usageUserId": "Usage User ID",
    "usageAutoInterval": "Auto Query",
    "usageAutoIntervalValue": "Every {{minutes}} minutes",
    "risk": {
      "envHijack": "This config sets environment variables that change how processes load code (e.g. injecting libraries or replacing CA certificates). Import only from a source you trust.",
      "privateEndpoint": "This address points at localhost or a private network. Do not import unless it is your own local service.",
      "shellCommand": "This config runs a full command line through a shell — what actually executes is in the arguments. Review each line."
    }
  },
  "iconPicker": {
    "search": "Search Icons",
    "searchPlaceholder": "Enter icon name...",
    "noResults": "No matching icons found",
    "category": {
      "aiProvider": "AI Providers",
      "cloud": "Cloud Platforms",
      "tool": "Dev Tools",
      "other": "Other"
    }
  },
  "providerIcon": {
    "label": "Icon",
    "colorLabel": "Icon Color",
    "selectIcon": "Select Icon",
    "preview": "Preview",
    "clickToChange": "Click to change icon",
    "clickToSelect": "Click to select icon"
  },
  "migration": {
    "success": "Configuration migrated successfully",
    "skillsSuccess": "Automatically imported {{count}} skill(s) into unified management",
    "skillsFailed": "Failed to auto import skills",
    "skillsFailedDescription": "Open the Skills page and click \"Import Existing\" to import manually (or restart and try again)."
  },
  "agents": {
    "title": "Agents"
  },
  "health": {
    "operational": "Operational",
    "degraded": "Degraded",
    "failed": "Failed",
    "circuitOpen": "Circuit Open",
    "consecutiveFailures": "{{count}} consecutive failures"
  },
  "failover": {
    "enabled": "{{app}} failover enabled",
    "disabled": "{{app}} failover disabled",
    "toggleFailed": "Operation failed: {{detail}}",
    "inQueue": "In queue",
    "addQueue": "Add",
    "priority": {
      "tooltip": "Failover priority {{priority}}"
    },
    "tooltip": {
      "enabled": "{{app}} failover enabled\nRequests follow queue priority (P1→P2→...)",
      "disabled": "Enable {{app}} failover\nSwitches to queue P1 immediately, then falls back on failures",
      "takeoverRequired": "Take over {{app}} first, then enable failover"
    }
  },
  "proxy": {
    "panel": {
      "serviceAddress": "Service Address",
      "addressCopied": "Address copied",
      "currentProvider": "Current Provider:",
      "waitingFirstRequest": "Current Provider: Waiting for first request...",
      "stoppedTitle": "Routing Service Stopped",
      "stoppedDescription": "Use the toggle above to start the service",
      "openSettings": "Configure Routing Service",
      "stats": {
        "activeConnections": "Active Connections",
        "totalRequests": "Total Requests",
        "successRate": "Success Rate",
        "uptime": "Uptime"
      }
    },
    "settings": {
      "title": "Routing Service Settings",
      "description": "Configure local routing server listening address, port and runtime parameters. Changes take effect immediately after saving.",
      "alert": {
        "autoApply": "Changes will be automatically synced to the running routing service without manual restart."
      },
      "basic": {
        "title": "Basic Settings",
        "description": "Configure routing service listening address and port."
      },
      "advanced": {
        "title": "Advanced Parameters",
        "description": "Control request stability and logging."
      },
      "timeout": {
        "title": "Timeout Settings",
        "description": "Configure timeout for streaming and non-streaming requests."
      },
      "fields": {
        "listenAddress": {
          "label": "Listen Address",
          "placeholder": "127.0.0.1",
          "description": "IP address the routing server listens on (recommended: 127.0.0.1)"
        },
        "listenPort": {
          "label": "Listen Port",
          "placeholder": "15721",
          "description": "Port number the routing server listens on (1024 ~ 65535)"
        },
        "maxRetries": {
          "label": "Max Retries",
          "placeholder": "3",
          "description": "Number of retries on request failure (0 ~ 10)"
        },
        "requestTimeout": {
          "label": "Request Timeout (sec)",
          "placeholder": "0 (unlimited) or 300",
          "description": "Maximum wait time for a single request (0 = unlimited, or 10 ~ 600 seconds)"
        },
        "enableLogging": {
          "label": "Record Request Usage",
          "description": "Write routing request usage and status to the local statistics database"
        },
        "streamingFirstByteTimeout": {
          "label": "Streaming First Byte Timeout (sec)",
          "description": "Maximum time to wait for the first data chunk"
        },
        "streamingIdleTimeout": {
          "label": "Streaming Idle Timeout (sec)",
          "description": "Maximum interval between data chunks"
        },
        "nonStreamingTimeout": {
          "label": "Non-Streaming Timeout (sec)",
          "description": "Total timeout for non-streaming requests"
        }
      },
      "validation": {
        "addressInvalid": "Please enter a valid IP address",
        "portMin": "Port must be greater than 1024",
        "portMax": "Port must be less than 65535",
        "retryMin": "Retry count cannot be negative",
        "retryMax": "Retry count cannot exceed 10",
        "timeoutNonNegative": "Timeout cannot be negative",
        "timeoutMax": "Timeout cannot exceed 600 seconds",
        "timeoutRange": "Please enter 0 or a value between 10-600",
        "streamingTimeoutMin": "Timeout must be at least 5 seconds",
        "streamingTimeoutMax": "Timeout cannot exceed 300 seconds"
      },
      "actions": {
        "save": "Save Configuration"
      },
      "toast": {
        "saved": "Routing configuration saved",
        "saveFailed": "Save failed: {{error}}"
      },
      "invalidPort": "Invalid port, please enter a number between 1024-65535",
      "invalidAddress": "Invalid address. Enter an IPv4 (e.g. 127.0.0.1), IPv6 (e.g. ::1), or localhost",
      "configSaved": "Routing configuration saved",
      "configSaveFailed": "Failed to save configuration",
      "restartRequired": "Restart routing service for address or port changes to take effect"
    },
    "switchFailed": "Switch failed: {{error}}",
    "takeover": {
      "ariaLabel": "{{appLabel}} local routing",
      "hint": "Select apps to route — once enabled, requests from that app will go through local routing",
      "enabled": "{{app}} routing enabled",
      "disabled": "{{app}} routing disabled",
      "failed": "Failed to toggle routing: {{detail}}",
      "tooltip": {
        "active": "{{appLabel}} is routing - {{address}}:{{port}}\nSwitch provider for hot switching",
        "broken": "{{appLabel}} is routing, but routing service is not running",
        "inactive": "Route {{appLabel}}'s requests through local routing"
      }
    },
    "failover": {
      "proxyRequired": "Routing service must be started to configure failover",
      "autoSwitch": "Auto Failover",
      "autoSwitchDescription": "When enabled, switches to queue P1 immediately and automatically tries the next provider in the queue on failures"
    },
    "failoverQueue": {
      "title": "Failover Queue",
      "description": "Manage failover order for each app's providers",
      "info": "When auto failover is enabled, requests follow the queue priority order (P1 first). On failures, the system will try the next provider in the queue.",
      "selectProvider": "Select a provider to add to queue",
      "noAvailableProviders": "No providers available to add",
      "empty": "Failover queue is empty. Add providers to enable automatic failover.",
      "orderHint": "Queue order matches the provider list order on the Home page. Reorder providers on the Home page to change priority.",
      "dragHint": "Drag providers to adjust failover order. Lower numbers have higher priority.",
      "toggleEnabled": "Enable/Disable",
      "addSuccess": "Added to failover queue",
      "addFailed": "Failed to add",
      "removeSuccess": "Removed from failover queue",
      "removeFailed": "Failed to remove",
      "reorderSuccess": "Queue order updated",
      "reorderFailed": "Failed to update order",
      "toggleFailed": "Failed to update status"
    },
    "autoFailover": {
      "info": "When the failover queue has multiple providers, the system will try them in priority order when requests fail. When a provider reaches the consecutive failure threshold, the circuit breaker will open and skip it temporarily.",
      "configSaved": "Auto failover config saved",
      "configSaveFailed": "Failed to save",
      "validationFailed": "The following fields are out of valid range: {{fields}}",
      "retrySettings": "Retry & Timeout Settings",
      "failureThreshold": "Failure Threshold",
      "failureThresholdHint": "Open circuit breaker after this many consecutive failures (recommended: 3-10)",
      "timeout": "Recovery Wait Time (seconds)",
      "timeoutHint": "Wait this long before trying to recover after circuit opens (recommended: 30-120)",
      "circuitBreakerSettings": "Circuit Breaker Settings",
      "successThreshold": "Recovery Success Threshold",
      "successThresholdHint": "Close circuit breaker after this many successes in half-open state",
      "errorRate": "Error Rate Threshold (%)",
      "errorRateHint": "Open circuit breaker when error rate exceeds this value",
      "minRequests": "Minimum Requests",
      "minRequestsHint": "Minimum requests before calculating error rate",
      "explanationTitle": "How It Works",
      "failureThresholdLabel": "Failure Threshold",
      "failureThresholdExplain": "Circuit breaker opens after this many consecutive failures, making the provider temporarily unavailable",
      "timeoutLabel": "Recovery Wait Time",
      "timeoutExplain": "After circuit opens, wait this long before trying half-open state",
      "successThresholdLabel": "Recovery Success Threshold",
      "successThresholdExplain": "In half-open state, close circuit breaker after this many successes, making provider available again",
      "errorRateLabel": "Error Rate Threshold",
      "errorRateExplain": "Open circuit breaker when error rate exceeds this value, even if failure threshold not reached",
      "maxRetries": "Max Retries",
      "timeoutSettings": "Timeout Settings",
      "streamingFirstByte": "Streaming First Byte Timeout",
      "streamingIdle": "Streaming Idle Timeout",
      "nonStreaming": "Non-Streaming Timeout",
      "maxRetriesHint": "Number of retries on request failure (0-10)",
      "streamingFirstByteHint": "Max time to wait for first data chunk, range 1-120s, default 60s",
      "streamingIdleHint": "Max interval between data chunks, range 60-600s, 0 to disable (prevents mid-stream stalls)",
      "nonStreamingHint": "Total timeout for non-streaming requests, range 60-1200s, default 600s (10 min)"
    },
    "logging": {
      "enabled": "Logging enabled",
      "disabled": "Logging disabled",
      "failed": "Failed to toggle logging"
    },
    "server": {
      "started": "Routing service started - {{address}}:{{port}}",
      "startFailed": "Failed to start routing service: {{detail}}",
      "stopped": "Routing service stopped",
      "stopFailed": "Failed to stop routing service: {{detail}}"
    },
    "stoppedWithRestore": "Routing service stopped, all routing configs restored",
    "stopWithRestoreFailed": "Stop failed: {{detail}}"
  },
  "streamCheck": {
    "reachable": "{{providerName}} is reachable ({{responseTimeMs}}ms)",
    "reachableSlow": "{{providerName}} reachable but slow ({{responseTimeMs}}ms)",
    "unreachable": "{{providerName}} unreachable: {{message}}",
    "unreachableHint": "Could not establish a connection (DNS / connect / TLS / timeout). Check the base_url and your network.",
    "connectivityNote": "Connectivity check only probes whether the provider address is reachable; it does not send a real model request. Any response counts as \"reachable\" — which does not guarantee that auth or model settings are correct.",
    "configSaved": "Connectivity check settings saved",
    "configSaveFailed": "Save failed",
    "checkParams": "Check Parameters",
    "timeout": "Timeout (seconds)",
    "maxRetries": "Max Retries",
    "degradedThreshold": "Slow-response threshold (ms)",
    "error": "{{providerName}} check error: {{error}}"
  },
  "proxyConfig": {
    "proxyEnabled": "Routing Master Switch",
    "appTakeover": "Routing Enabled",
    "perAppConfig": "Per-App Config",
    "circuitBreaker": "Circuit Breaker",
    "circuitBreakerSettings": "Circuit Breaker Settings",
    "failureThreshold": "Failure Threshold",
    "successThreshold": "Success Threshold",
    "recoveryTimeout": "Recovery Timeout",
    "errorRateThreshold": "Error Rate Threshold",
    "minRequests": "Min Requests",
    "timeoutConfig": "Timeout Config",
    "streamingFirstByte": "Streaming First Byte Timeout",
    "streamingIdle": "Streaming Idle Timeout",
    "nonStreaming": "Non-Streaming Timeout"
  },
  "universalProvider": {
    "duplicate": "Duplicate",
    "duplicatedAndSynced": "Universal provider duplicated and synced",
    "duplicateError": "Failed to duplicate universal provider",
    "title": "Universal Provider",
    "description": "Universal providers manage Claude, Codex, and Gemini configurations simultaneously. Changes are automatically synced to all enabled apps.",
    "add": "Add Universal Provider",
    "edit": "Edit Universal Provider",
    "empty": "No universal providers yet",
    "emptyHint": "Click the \"Add Universal Provider\" button below to create one",
    "selectPreset": "Select Preset Type",
    "name": "Name",
    "namePlaceholder": "e.g., My NewAPI",
    "baseUrl": "API URL",
    "apiKey": "API Key",
    "websiteUrl": "Website URL",
    "websiteUrlPlaceholder": "https://example.com (optional, displayed in the list)",
    "notes": "Notes",
    "notesPlaceholder": "Optional: Add notes",
    "enabledApps": "Enabled Apps",
    "modelConfig": "Model Configuration",
    "model": "Model",
    "sync": "Sync to Apps",
    "synced": "Synced to all apps",
    "syncError": "Sync failed",
    "noAppsEnabled": "No apps enabled",
    "added": "Universal provider added",
    "addedAndSynced": "Universal provider added and synced",
    "addedButSyncFailed": "Universal provider added, but sync failed",
    "updated": "Universal provider updated",
    "deleted": "Universal provider deleted",
    "addFailed": "Failed to add universal provider",
    "hint": "Cross-app unified config, auto-sync to Claude/Codex/Gemini",
    "manage": "Manage",
    "loadError": "Failed to load universal providers",
    "saveError": "Failed to save universal provider",
    "deleteError": "Failed to delete universal provider",
    "deleteConfirmTitle": "Delete Universal Provider",
    "deleteConfirmDescription": "Are you sure you want to delete \"{{name}}\"? This will also delete its generated provider configurations in each app.",
    "syncConfirmTitle": "Sync Universal Provider",
    "syncConfirmDescription": "Syncing \"{{name}}\" will overwrite the associated provider configurations in Claude, Codex, and Gemini. Do you want to continue?",
    "syncConfirm": "Sync",
    "saveAndSync": "Save & Sync",
    "savedAndSynced": "Saved and synced to all apps",
    "saveAndSyncError": "Failed to save and sync",
    "configJsonPreview": "Config JSON Preview",
    "configJsonPreviewHint": "The following configurations will be synced to each app (only the displayed fields will be overwritten, other custom settings will be preserved)"
  },
  "omo": {
    "editProfile": "Edit OMO Config",
    "newProfile": "New OMO Config",
    "profileName": "Name",
    "mainAgents": "Main Agents",
    "subAgents": "Sub Agents",
    "categories": "Categories",
    "customAgents": "Custom Agents",
    "noCustomAgents": "No custom agents",
    "otherFields": "Other Config",
    "globalConfig": "OMO Global Config",
    "globalConfigShort": "OMO Config",
    "globalConfigSaved": "Global config saved",
    "addProfile": "Add OMO Provider",
    "disabledItems": "Disabled Items",
    "advanced": "Advanced Settings",
    "profileCreated": "OMO config created",
    "profileUpdated": "OMO config updated",
    "invalidJson": "Other Fields contains invalid JSON",
    "confirmDelete": "Delete Config",
    "confirmDeleteMsg": "Delete \"{{name}}\"?",
    "profileDeleted": "Config deleted",
    "imported": "Imported as \"{{name}}\"",
    "import": "Import",
    "global": "Global",
    "empty": "No OMO configs yet. Click + Add or Import from local.",
    "applied": "Applied",
    "apply": "Apply",
    "enable": "Enable",
    "enabled": "Enabled",
    "disabled": "OMO disabled",
    "disableFailed": "Failed to disable OMO: {{error}}",
    "selectPlaceholder": "Select...",
    "clear": "Clear",
    "clearWrapped": "(Clear)",
    "defaultWrapped": "(Default)",
    "variantPlaceholder": "variant",
    "selectEnabledModel": "Select configured model",
    "selectModel": "Select configured model",
    "recommendedHint": "Recommended: {{model}}",
    "searchModel": "Search model...",
    "selectModelFirst": "Select model first",
    "noEnabledModels": "No configured models",
    "noVariantsForModel": "No variants for model",
    "currentValueNotEnabled": "{{value}} (current value, not configured)",
    "currentValueUnavailable": "{{value}} (current value, unavailable)",
    "advancedLabel": "Advanced",
    "advancedJsonInvalid": "Advanced JSON is invalid",
    "advancedJsonHint": "temperature, top_p, budgetTokens, prompt_append, permission, etc. Leave empty for defaults",
    "noEnabledModelsWarning": "No configured models available. Configure OpenCode models first.",
    "modelSourcePartialWarning": "Some provider model configs are invalid and were skipped.",
    "modelSourceFallbackWarning": "Failed to load live provider state. Falling back to configured providers.",
    "runtimeModelsFailedWarning": "Failed to load OpenCode runtime models. Showing configured providers only.",
    "importLocalReplaceSuccess": "Imported local file and replaced Agents/Categories/Other Fields",
    "importLocalFailed": "Failed to read local file: {{error}}",
    "agentKeyPlaceholder": "agent key",
    "categoryKeyPlaceholder": "category key",
    "modelNamePlaceholder": "model-name",
    "custom": "Custom",
    "customCategories": "Custom Categories",
    "modelConfiguration": "Model Configuration",
    "fillRecommended": "Fill Recommended",
    "fillRecommendedSuccess": "Filled {{count}} recommended models",
    "fillRecommendedPartial": "Filled {{filled}} recommended models, {{unmatched}} unmatched",
    "fillRecommendedMostlyUnmatched": "Filled only {{filled}}, {{unmatched}} unmatched (e.g. {{examples}}). Configure providers offering these models or pick a substitute.",
    "fillRecommendedAllSet": "All slots already have models configured",
    "fillRecommendedNoMatch": "Recommended models not found in configured providers (e.g. {{examples}})",
    "configSummary": "{{agents}} agents, {{categories}} categories configured · Click ⚙ for advanced params",
    "enabledModelsCount": "{{count}} configured models available",
    "source": "from:",
    "otherFieldsJson": "Other Fields (JSON)",
    "slimOtherFieldsHint": "Use this area for top-level OMO Slim config such as council, fallback, multiplexer, disabled_mcps, and todoContinuation.",
    "searchOrType": "Search or type custom value...",
    "noMatches": "No matches",
    "jsonMustBeObject": "{{field}} must be a JSON object",
    "jsonInvalid": "{{field}} contains invalid JSON",
    "importGlobalSuccess": "Imported global config from local file (unsaved)",
    "importGlobalFailed": "Failed to read local file: {{error}}",
    "importLocal": "Import Local",
    "saveGlobalConfig": "Save Global Config",
    "schemaUrl": "$schema",
    "resetDefault": "Reset",
    "sisyphusAgentConfig": "Sisyphus Agent Config",
    "disabledAgents": "Agents",
    "disabledAgentsPlaceholder": "Disabled Agents",
    "disabledMcps": "MCPs",
    "disabledMcpsPlaceholder": "Disabled MCPs",
    "disabledHooks": "Hooks",
    "disabledHooksPlaceholder": "Disabled Hooks",
    "disabledSkills": "Skills",
    "disabledSkillsPlaceholder": "Disabled Skills",
    "advancedLsp": "LSP Config",
    "advancedExperimental": "Experimental Features",
    "advancedBackgroundTask": "Background Tasks",
    "advancedBrowserAutomation": "Browser Automation",
    "advancedClaudeCode": "Claude Code",
    "agentDesc": {
      "sisyphus": "Main orchestrator",
      "hephaestus": "Autonomous deep worker",
      "prometheus": "Strategic planner",
      "atlas": "Task manager",
      "oracle": "Strategic advisor",
      "librarian": "Multi-repo researcher",
      "explore": "Fast code search",
      "multimodalLooker": "Media analyzer",
      "metis": "Pre-plan analysis advisor",
      "momus": "Plan reviewer",
      "sisyphusJunior": "Delegated task executor"
    },
    "agentTooltip": {
      "sisyphus": "Main orchestrator responsible for task planning, delegation and parallel execution. Uses extended thinking (32k budget) and drives workflows through TODO lists to ensure task completion.",
      "atlas": "Main orchestrator (holds TODO list) responsible for task distribution and coordination during execution phase. Delegates to specialized agents rather than completing all work directly.",
      "prometheus": "Strategic planner that collects requirements through interview mode and creates detailed work plans. Can only read/write Markdown files in .sisyphus/ directory, never writes code directly.",
      "hephaestus": "Autonomous deep worker (\"legitimate craftsman\") inspired by AmpCode deep mode. Goal-oriented execution that launches 2-5 explore/librarian agents in parallel for research before taking action.",
      "oracle": "Architecture decision and debugging advisor. Read-only consulting agent providing excellent logical reasoning and deep analysis. Cannot write files or delegate tasks.",
      "librarian": "Multi-repository analysis and documentation retrieval expert. Deeply understands codebases and provides evidence-based answers. Excels at finding official documentation and open-source implementation examples.",
      "explore": "Fast codebase exploration and context grep expert. Uses lightweight models for high-speed search. The scout for understanding code structure.",
      "multimodalLooker": "Visual content expert that analyzes PDFs, images, charts and other non-text media, extracting information and insights from them.",
      "metis": "Plan consultant that performs pre-analysis before planning. Identifies hidden intents, ambiguities and AI failure points to prevent over-engineering.",
      "momus": "Plan reviewer that validates plan clarity, verifiability and completeness with high precision. Rejects and requests revisions until plans are perfect.",
      "sisyphusJunior": "Category-generated executor, automatically created via category parameters. Focuses on executing assigned tasks and cannot re-delegate, preventing infinite delegation loops."
    },
    "categoryDesc": {
      "visualEngineering": "Visual/frontend engineering",
      "ultrabrain": "Ultra thinking",
      "deep": "Deep work",
      "artistry": "Creative/artistic",
      "quick": "Quick response",
      "unspecifiedLow": "General low tier",
      "unspecifiedHigh": "General high tier",
      "writing": "Writing"
    },
    "categoryTooltip": {
      "visualEngineering": "Frontend and visual engineering category for UI/UX design, styling, animation and interface implementation. Defaults to Gemini 3.6 Flash model.",
      "ultrabrain": "Deep logical reasoning category for complex architectural decisions requiring extensive analysis. Defaults to GPT-5.3 Codex ultra-high reasoning variant.",
      "deep": "Deep autonomous problem-solving category with goal-oriented execution. Conducts thorough research before action, suitable for difficult problems requiring deep understanding.",
      "artistry": "Highly creative and artistic task category that inspires novel ideas and creative solutions. Defaults to Gemini 3.6 Flash high variant.",
      "quick": "Lightweight task category for single-file modifications, typo fixes, and simple adjustments. Defaults to Claude Haiku 4.5 fast model.",
      "unspecifiedLow": "Uncategorized low-effort task category for tasks that don't fit other categories with small workload. Defaults to Claude Sonnet 4.5.",
      "unspecifiedHigh": "Uncategorized high-effort task category for tasks that don't fit other categories with large workload. Defaults to Claude Opus 5 max variant.",
      "writing": "Writing category for documentation, prose and technical writing. Defaults to Kimi K2.5 model."
    },
    "slimAgentDesc": {
      "orchestrator": "Orchestrator",
      "oracle": "Oracle",
      "librarian": "Librarian",
      "explorer": "Explorer",
      "designer": "Designer",
      "fixer": "Fixer",
      "council": "Council"
    },
    "slimAgentTooltip": {
      "orchestrator": "Writes executable code, orchestrates multi-agent workflow, summons experts",
      "oracle": "Root cause analysis, architecture review, debugging guidance (read-only)",
      "librarian": "Documentation lookup, GitHub code search (read-only)",
      "explorer": "Regex search, AST pattern matching, file discovery (read-only)",
      "designer": "Modern responsive design, CSS/Tailwind expertise",
      "fixer": "Code implementation, refactoring, testing, verification",
      "council": "Multi-model consensus agent. Runs multiple read-only councillors in parallel, then lets the master synthesize the final answer."
    }
  },
  "openclawConfig": {
    "defaultModel": {
      "title": "Default Model",
      "description": "Configure the default primary model and fallback models for OpenClaw",
      "primary": "Primary Model",
      "primaryPlaceholder": "e.g., deepseek/deepseek-chat",
      "fallbacks": "Fallback Models",
      "fallbacksPlaceholder": "e.g., openrouter/anthropic/claude-sonnet-4.5",
      "addFallback": "Add Fallback Model",
      "saved": "Default model configuration saved",
      "saveFailed": "Failed to save default model"
    },
    "modelCatalog": {
      "title": "Model Catalog",
      "description": "Configure model aliases and allowlist",
      "modelId": "Model ID",
      "modelIdPlaceholder": "e.g., deepseek/deepseek-chat",
      "alias": "Alias",
      "aliasPlaceholder": "e.g., DeepSeek",
      "addEntry": "Add Model",
      "removeEntry": "Remove",
      "saved": "Model catalog saved",
      "saveFailed": "Failed to save model catalog",
      "empty": "No model catalog entries",
      "emptyHint": "Add models to the catalog to configure aliases"
    },
    "suggestedDefaults": "Apply Suggested Defaults",
    "suggestedDefaultsHint": "Use this preset's recommended default model configuration"
  },
  "subscription": {
    "title": "Subscription Quota",
    "fiveHour": "5-Hour",
    "sevenDay": "7-Day",
    "sevenDayFable": "Fable",
    "sevenDayOpus": "7-Day (Opus)",
    "sevenDaySonnet": "7-Day (Sonnet)",
    "thirtyDay": "30-Day",
    "geminiPro": "Pro",
    "geminiFlash": "Flash",
    "geminiFlashLite": "Flash Lite",
    "weeklyLimit": "Weekly",
    "monthly": "Monthly",
    "credits": "Credits",
    "copilotPremium": "Premium",
    "utilization": "{{value}}%",
    "resetsIn": "Resets in {{time}}",
    "extraUsage": "Extra Usage",
    "expired": "Session expired",
    "expiredHint": "Run the {{tool}} command to refresh your login",
    "queryFailed": "Query failed",
    "refresh": "Refresh"
  },
  "aggregate": {
    "migrationHint": "Existing route IDs are incompatible or duplicated. Normal edits preserve IDs. Back up before converting; existing sessions may need to select a model again.",
    "migrationPreview": "Preview legacy route conversion",
    "migrationBackup": "Download route backup",
    "migrationConfirm": "Confirm route ID conversion",
    "migrationLimits": "Effort limit",
    "migrationUnlimited": "Unlimited",

    "enable": "Enable aggregate routing",
    "title": "Aggregate provider",
    "hint": "Holds no endpoint or key; routes requests to other providers by model. Restart Claude Desktop after enabling.",
    "tier": "Tier",
    "targetProvider": "Target provider",
    "upstreamModel": "Upstream model",
    "upstreamModelPlaceholder": "Upstream model name",
    "displayName": "Display name",
    "supports1m": "1M context",
    "slotIdPreview": "Slot ID",
    "addProvider": "Add provider",
    "defaultTarget": "Fallback target",
    "defaultTargetHint": "Requests matching no slot go here (Claude's internal calls use it)",
    "notSaveable": "Add at least one slot and choose a fallback target before saving",
    "modeLockedHint": "Aggregate routing takes over request forwarding, so the mode is locked to model mapping (proxy).",
    "defaultTargetPlaceholder": "Required: unmatched requests fall back here",
    "defaultModel": "Default model",
    "defaultModelPlaceholder": "Unset: follow the first in order",
    "defaultModelHint": "The model new sessions start with; defaults to the first in order",
    "defaultBadge": "Default",
    "expandAll": "Expand all",
    "collapseAll": "Collapse all",
    "addModel": "Add model",
    "modelsSummaryLadder": "{{count}} models · {{ladder}} effort",
    "effortBadgeHeader": "Think",
    "effortLadder": "Effort✓",
    "effortLadderTip": "Full thinking-effort ladder (low…max) from a real model ID",
    "effortToggle": "Toggle",
    "effortToggleTip": "Extended-thinking on/off only, no effort levels",
    "effortNone": "✗",
    "effortNoneTip": "Overflow ID unknown to Claude Desktop; no thinking controls",
    "maxEffort": "Cap",
    "maxEffortOff": "Unlimited",
    "removeModel": "Remove this model",
    "aliasRouting": "Alias routing (prefix-based redirect when no slot matches, first match wins)",
    "aliasPrefix": "Request prefix",
    "aliasPrefixPlaceholder": "e.g. claude-sonnet",
    "aliasTarget": "Target slot",
    "aliasTargetPlaceholder": "Pick a slot",
    "addAliasRule": "Add rule",
    "removeAliasRule": "Remove rule",
    "aliasTip": "An overly broad prefix (e.g. claude-) swallows every unmatched name; mind the scope"
  },
  "codexAggregate": {
    "enable": "Enable aggregate routing",
    "title": "Aggregate provider",
    "hint": "Holds no endpoint or key; routes requests to other providers by model.",
    "model": "Model",
    "modelPlaceholder": "Client model name",
    "targetProvider": "Target provider",
    "targetProviderPlaceholder": "Pick a provider",
    "upstreamModel": "Upstream model",
    "upstreamModelPlaceholder": "Upstream model name",
    "displayName": "Display name",
    "addSlot": "Add model",
    "removeSlot": "Remove this model",
    "fetchModels": "Fetch model list",
    "emptyState": "No slots yet — use “Add model” below to start.",
    "defaultTarget": "Fallback target",
    "defaultTargetHint": "Requests matching no slot go here",
    "defaultTargetPlaceholder": "Required: unmatched requests fall back here",
    "defaultModel": "Default model",
    "defaultModelHint": "The model Codex CLI starts on; defaults to the first slot",
    "defaultModelPlaceholder": "Unset: follow the first slot"
  }
}


## Full source: src/i18n/locales/ja.json
{
  "aggregate": {
    "migrationHint": "既存のルートIDに互換性の問題または重複があります。通常の編集ではIDを保持します。変換前にバックアップしてください。既存セッションでモデルの再選択が必要になる場合があります。",
    "migrationPreview": "旧ルート変換のプレビュー",
    "migrationBackup": "ルートのバックアップをダウンロード",
    "migrationConfirm": "ルートIDの変換を確認",
    "migrationLimits": "上限",
    "migrationUnlimited": "制限なし"
  },

  "app": {
    "title": "CC Switch",
    "description": "Claude Code・Codex・Gemini CLI のためのオールインワンアシスタント"
  },
  "common": {
    "add": "追加",
    "edit": "編集",
    "delete": "削除",
    "save": "保存",
    "saving": "保存中...",
    "cancel": "キャンセル",
    "confirm": "確認",
    "close": "閉じる",
    "done": "完了",
    "settings": "設定",
    "about": "バージョン情報",
    "version": "バージョン",
    "loading": "読み込み中...",
    "notInstalled": "未インストール",
    "success": "成功",
    "error": "エラー",
    "unknown": "不明",
    "enterValidValue": "有効な値を入力してください",
    "clear": "クリア",
    "format": "フォーマット",
    "formatSuccess": "整形しました",
    "formatError": "整形に失敗しました: {{error}}",
    "copy": "コピー",
    "view": "表示",
    "back": "戻る",
    "refresh": "更新",
    "refreshing": "更新中...",
    "import": "インポート",
    "all": "すべて",
    "search": "検索",
    "enableAllForApp": "{{app}} ですべて有効化",
    "disableAllForApp": "{{app}} ですべて無効化",
    "bulkToggleFailed": "{{count}} 件の更新に失敗しました",
    "reset": "リセット",
    "actions": "操作",
    "deleting": "削除中...",
    "auto": "自動",
    "enabled": "有効",
    "notSet": "未設定",
    "collapse": "折りたたむ"
  },
  "firstRunNotice": {
    "title": "CC Switch へようこそ",
    "bodyDefault": "CC Switch は Claude Code / Codex / Gemini CLI の複数プロバイダーをワンクリックで切り替えられるツールです。すでにこれらのツールを設定済みの場合、CC Switch は現在の設定を「default」という名前のプロバイダーとして自動的に保存するので、既存の設定が失われることはありません。",
    "bodyOfficial": "リストには「Official（公式）」プリセットも用意されており、公式バージョンに戻したくなったらクリックするだけで切り替えられます。切り替える前に現在の設定は自動で default にバックアップされるので、自由に行き来できます。これが CC Switch の仕組みです 😊",
    "confirm": "了解しました"
  },
  "apiKeyInput": {
    "placeholder": "API Key を入力",
    "show": "API Key を表示",
    "hide": "API Key を隠す"
  },
  "jsonEditor": {
    "mustBeObject": "設定はオブジェクト形式の JSON で入力してください（配列や他の型は不可）",
    "invalidJson": "JSON 形式が正しくありません"
  },
  "commonConfig": {
    "guideTitle": "共通設定スニペットとは？",
    "guidePurpose": "異なるプロバイダー間でプラグインや環境変数などの非機密設定を共有するための機能です。プロバイダーを切り替えてもこれらの設定は失われません。",
    "guideUsage": "使い方：① 「編集内容から抽出」をクリックして共通部分を保存  ② 新規プロバイダー作成時に「共通設定を適用」をチェック",
    "guideReExtract": "新しいプラグインや Hook をインストールした場合は、共通設定を再抽出して他のプロバイダーに同期してください。",
    "guideReassurance": "ご安心ください：元の設定はデフォルトプロバイダーに安全に保存されており、失われることはありません。",
    "emptyTitle": "共通設定スニペットがまだありません",
    "emptyHint": "下の「編集内容から抽出」ボタンをクリックして、現在の設定から再利用可能な部分を抽出してください"
  },
  "claudeConfig": {
    "configLabel": "Claude Code settings.json (JSON) *",
    "writeCommonConfig": "共通設定を適用",
    "editCommonConfig": "共通設定を編集",
    "editCommonConfigTitle": "共通設定スニペットを編集",
    "commonConfigHint": "「共通設定を適用」がオンのとき settings.json にマージされます",
    "fullSettingsHint": "Claude Code の settings.json 全文",
    "extractFromCurrent": "編集内容から抽出",
    "extractNoCommonConfig": "編集内容から抽出できる共通設定がありません",
    "extractFailed": "抽出に失敗しました: {{error}}",
    "saveFailed": "保存に失敗しました: {{error}}",
    "hideAttribution": "AI署名を非表示",
    "enableTeammates": "Teammates モード",
    "enableToolSearch": "Tool Search を有効化",
    "effortMax": "最大強度思考",
    "disableAutoUpgrade": "自動アップグレードを無効化",
    "disableArtifact": "Artifact ツールを無効化"
  },
  "header": {
    "viewOnGithub": "GitHub で見る",
    "toggleDarkMode": "ダークモードに切り替え",
    "toggleLightMode": "ライトモードに切り替え",
    "addProvider": "プロバイダーを追加",
    "switchToChinese": "中国語に切り替え",
    "switchToEnglish": "英語に切り替え",
    "enterEditMode": "編集モードに入る",
    "exitEditMode": "編集モードを終了",
    "windowMinimize": "ウィンドウを最小化",
    "windowMaximize": "ウィンドウを最大化",
    "windowRestore": "ウィンドウを元に戻す",
    "windowClose": "ウィンドウを閉じる"
  },
  "provider": {
    "connectivityCheck": "接続チェック",
    "tabProvider": "プロバイダー",
    "tabUniversal": "統一プロバイダー",
    "noProviders": "まだプロバイダーがありません",
    "noProvidersDescription": "既存の設定がある場合は「現在の設定をインポート」をクリックしてください。すべてのデータが default プロバイダーに安全に保存されます",
    "noProvidersDescriptionSnippet": "API キーとリクエスト URL 以外のデータ（プラグインなど）は共通設定スニペットに保存され、プロバイダー間で共有できます",
    "importCurrent": "現在の設定をインポート",
    "importFromClaude": "Claude Code の既存プロバイダーをインポート",
    "importCurrentDescription": "現在使用中の設定をデフォルトプロバイダーとしてインポート",
    "currentlyUsing": "現在使用中",
    "enable": "有効化",
    "inUse": "使用中",
    "needsRouting": "ルーティングが必要",
    "noRoutingSupport": "ルーティング非対応",
    "blockedByProxyHint": "プロキシ引き継ぎモードでは公式プロバイダーに切り替えできません",
    "editProvider": "プロバイダーを編集",
    "editProviderHint": "保存すると現在のプロバイダーにすぐ反映されます。",
    "deleteProvider": "プロバイダーを削除",
    "addNewProvider": "新しいプロバイダーを追加",
    "addFooterHint": "💡 プリセットを選んだら、下のフィールド（API Key など）を入力してください",
    "addClaudeProvider": "Claude Code プロバイダーを追加",
    "addCodexProvider": "Codex プロバイダーを追加",
    "addGeminiProvider": "Gemini プロバイダーを追加",
    "addOpenCodeProvider": "OpenCode プロバイダーを追加",
    "addToConfig": "追加",
    "removeFromConfig": "削除",
    "setAsDefault": "デフォルトに設定",
    "isDefault": "現在のデフォルト",
    "inConfig": "追加済み",
    "addProviderHint": "一覧にすばやく切り替えられるよう、ここに情報を入力してください。",
    "editClaudeProvider": "Claude Code プロバイダーを編集",
    "editCodexProvider": "Codex プロバイダーを編集",
    "configError": "設定エラー",
    "notConfigured": "公式サイト用に未設定",
    "applyToClaudePlugin": "Claude プラグインに適用",
    "removeFromClaudePlugin": "Claude プラグインから解除",
    "dragToReorder": "ドラッグで並べ替え",
    "dragHandle": "ドラッグで並べ替え",
    "searchPlaceholder": "名前・メモ・URLで検索...",
    "searchAriaLabel": "プロバイダーを検索",
    "searchScopeHint": "名前・メモ・URL を対象に検索します。",
    "searchCloseHint": "Esc で閉じる",
    "searchCloseAriaLabel": "検索を閉じる",
    "noSearchResults": "一致するプロバイダーがありません。",
    "duplicate": "複製",
    "sortUpdateFailed": "並び順の更新に失敗しました",
    "configureUsage": "利用状況を設定",
    "managedByHermes": "Hermes 管理",
    "managedByHermesHint": "Hermes の providers: dict で定義されています。Hermes Web UI で編集または削除してください。",
    "openTerminal": "ターミナルを開く",
    "terminalOpened": "ターミナルを開きました",
    "terminalOpenFailed": "ターミナルを開けませんでした",
    "name": "プロバイダー名",
    "namePlaceholder": "例: Claude Official",
    "websiteUrl": "Web サイト URL",
    "notes": "メモ",
    "notesPlaceholder": "例: 会社用アカウント",
    "configJson": "Config JSON",
    "writeCommonConfig": "共通設定を適用",
    "editCommonConfigButton": "共通設定を編集",
    "configJsonHint": "Claude Code の設定をすべて入力してください",
    "editCommonConfigTitle": "共通設定スニペットを編集",
    "editCommonConfigHint": "共通設定スニペットは、この機能をオンにしたすべてのプロバイダーへマージされます",
    "addProvider": "プロバイダーを追加",
    "sortUpdated": "並び順を更新しました",
    "usageSaved": "利用状況の設定を保存しました",
    "usageSaveFailed": "利用状況設定の保存に失敗しました",
    "geminiConfig": "Gemini 設定",
    "geminiConfigHint": ".env 形式で Gemini を設定してください",
    "form": {
      "gemini": {
        "model": "モデル",
        "oauthTitle": "OAuth 認証モード",
        "oauthHint": "Google 公式は OAuth 個人認証を使用するため API Key は不要です。初回利用時にブラウザが開きます。",
        "apiKeyPlaceholder": "Gemini API Key を入力"
      }
    },
    "duplicateLiveIdsLoadFailed": "設定内のプロバイダー識別子を読み込めませんでした。設定を修正してから再度お試しください"
  },
  "claudeCode": {
    "needsRouting": "ルーティングが必要",
    "noRoutingSupport": "ルーティング非対応"
  },
  "codex": {
    "needsRouting": "ルーティングが必要",
    "noRoutingSupport": "ルーティング非対応",
    "officialRouting": "公式アカウントルーティング",
    "nativeLogin": "Codex ログイン",
    "followCodexLogin": "Codex のログインに追従",
    "followCodexLoginDescription": "Codex CLI で現在ログイン中のアカウントに追従します",
    "openAiAccount": "OpenAI アカウント",
    "accountNotSelected": "アカウントが選択されていません",
    "chooseAccount": "アカウントを選択",
    "accountStatusUnavailable": "アカウント情報を読み込めません",
    "boundAccountUnavailable": "連携済みアカウントを利用できません",
    "accountLoading": "アカウントを読み込み中…"
  },
  "claudeDesktop": {
    "modelConfigTitle": "モデル設定",
    "modelModeLabel": "接続方式",
    "modelModeDirect": "直接接続",
    "modelModeProxy": "モデルマッピング",
    "officialNotice": "Claude Desktop の公式プロバイダーは内蔵の 1P サインインを使用します。API キーやエンドポイントの設定は不要です。",
    "mode": "モデル処理方式",
    "modeDirect": "直結",
    "modeProxy": "ルーティング必要",
    "modelMappingToggle": "モデルマッピングが必要",
    "modelMappingOffHint": "プロバイダーが Claude Desktop の三つの役割 ID（claude-sonnet-* / claude-opus-* / claude-haiku-*）を受け付ける場合のみ直結できます。それ以外のモデル名（claude-3-5-sonnet-… などの旧式 ID を含む）は「モデルマッピング」を選択してください。",
    "modelMappingOnHint": "Claude Desktop は claude-sonnet-* / claude-opus-* / claude-haiku-* の三つの役割 ID のみ受け付けます。「モデルマッピング」を選択すると、CC Switch がこの三役割をプロバイダーの実モデルにマッピングし、使用中はローカルルーティングを起動したままにします。",
    "routeMapTitle": "モデルマッピング",
    "routeMapHint": "Sonnet・Opus・Haiku の各区分に実際のリクエストモデルを入力してください。DeepSeek や Kimi などのブランド名はメニュー表示名に入れられます。空欄の区分は Sonnet（または最初に入力した区分）のモデルを引き継ぐため、サブ agent が呼び出す Haiku が常に利用可能になります。",
    "routeModelLabel": "モデル役割",
    "routeRoleSonnet": "Sonnet",
    "routeRoleOpus": "Opus",
    "routeRoleFable": "Fable",
    "routeRoleHaiku": "Haiku",
    "labelOverrideLabel": "メニュー表示名",
    "upstreamModelLabel": "リクエストモデル",
    "supports1mLabel": "1M 対応を宣言",
    "supports1mShort": "1M",
    "directModelListTitle": "モデル一覧",
    "directModelListCollapsedHint": "ネイティブ Claude モデルのプロバイダーでは通常不要です。Claude Desktop が /v1/models を自動取得します。",
    "directModelListHint": "Claude Desktop で使用できる Sonnet、Opus、Haiku モデルを設定します。空欄の場合、Claude Desktop が /v1/models を自動取得します。1M をオンにすると 1M コンテキスト対応を宣言します。",
    "directModelInvalid": "直結モデルは Claude Desktop が認識できる Sonnet / Opus / Haiku モデル ID を使う必要があります",
    "addModel": "モデルを追加",
    "addRoute": "モデルを追加",
    "routeInvalid": "モデル役割を選択し、リクエストモデルを入力してください",
    "routesRequired": "少なくとも 1 つのモデルマッピングが必要です",
    "statusTitle": "Claude Desktop 設定の確認が必要です",
    "statusUnsupported": "このプラットフォームでは Claude Desktop 3P 設定の書き込みはまだサポートされていません。",
    "statusStaleRawModels": "Claude Desktop profile に Sonnet / Opus / Haiku の役割ファミリー以外のモデル ID が含まれています。新しい Claude Desktop では拒否される可能性があります。現在のプロバイダーへ再度切り替えると修復できます。",
    "statusMissingRouteMappings": "現在のプロバイダーはモデルマッピングを有効にしていますが、有効なルートがありません。プロバイダーを編集し、少なくとも 1 つのマッピングを追加してください。",
    "statusGatewayTokenMissing": "ローカルルーティング token がまだ生成されていません。このプロバイダーへ再度切り替えると新しい token が書き込まれます。",
    "statusBaseUrlMismatch": "Claude Desktop profile の URL が現在のプロバイダーと一致しません。現在: {{actual}}、期待値: {{expected}}。現在のプロバイダーへ再度切り替えると修復できます。",
    "route": {
      "tooltip": {
        "active": "Claude Desktop ローカルルーティングは起動中です - {{address}}:{{port}}",
        "inactive": "モデルマッピングや形式変換が必要なプロバイダー向けに Claude Desktop ローカルルーティングを起動します。設定アドレス: {{address}}:{{port}}"
      },
      "stopBlockedByTakeover": "別のアプリがプロキシテイクオーバーを使用しています。設定で該当アプリのテイクオーバーを無効にしてから、ローカルルーティングを停止してください。"
    }
  },
  "notifications": {
    "providerAdded": "プロバイダーを追加しました",
    "providerSaved": "プロバイダー設定を保存しました",
    "providerDeleted": "プロバイダーを削除しました",
    "switchSuccess": "切り替え成功！",
    "codexRestartRequired": "切り替えました。反映するにはクライアントを再起動してください",
    "grokBuildRestartRequired": "切り替えました。反映するには Grok Build を再起動してください",
    "claudeDesktopRestartRequired": "切り替えました。反映するには Claude Desktop を再起動してください",
    "claudeDesktopProxyRestartRequired": "切り替えました。CC Switch を起動したまま Claude Desktop を再起動してください",
    "addToConfigSuccess": "設定に追加しました",
    "removeFromConfigSuccess": "設定から削除しました",
    "removeFromConfigFailed": "プロバイダーを削除できません",
    "switchFailedTitle": "切り替えに失敗しました",
    "switchFailed": "切り替えに失敗しました: {{error}}",
    "autoImported": "既存設定からデフォルトプロバイダーを自動作成しました",
    "addFailed": "プロバイダーの追加に失敗しました: {{error}}",
    "saveFailed": "保存に失敗しました: {{error}}",
    "saveFailedGeneric": "保存に失敗しました。もう一度お試しください",
    "appliedToClaudePlugin": "Claude プラグインに適用しました",
    "removedFromClaudePlugin": "Claude プラグインから削除しました",
    "syncClaudePluginFailed": "Claude プラグインとの同期に失敗しました",
    "skipClaudeOnboardingFailed": "Claude Code の初回確認スキップに失敗しました",
    "clearClaudeOnboardingSkipFailed": "Claude Code の初回確認の復元に失敗しました",
    "updateSuccess": "プロバイダーを更新しました",
    "updateFailed": "プロバイダーの更新に失敗しました: {{error}}",
    "deleteSuccess": "プロバイダーを削除しました",
    "deleteFailed": "プロバイダーの削除に失敗しました: {{error}}",
    "settingsSaved": "設定を保存しました",
    "settingsSaveFailed": "設定の保存に失敗しました: {{error}}",
    "proxyRequiredForSwitch": "このプロバイダーは{{reason}}、ルーティングサービスが必要です。先にルーティングを起動してください",
    "proxyReasonCopilot": "GitHub Copilot を Claude プロバイダーとして使用しており",
    "proxyReasonOpenAIChat": "OpenAI Chat API フォーマットを使用しており",
    "proxyReasonOpenAIResponses": "OpenAI Responses API フォーマットを使用しており",
    "proxyReasonAnthropicMessages": "Anthropic Messages API フォーマットを使用しており",
    "proxyReasonFullUrl": "完全 URL 接続モードが有効になっており",
    "proxyReasonManagedOAuth": "マネージド OAuth ログイン（トークンはローカルルーティングが注入）を使用しており",
    "proxyReasonRoutingRequired": "リクエスト処理にローカルルーティングが必要であり",
    "openAIFormatHint": "このプロバイダーは OpenAI 互換フォーマットを使用しており、ルーティングサービスの有効化が必要です",
    "copilotProxyHint": "GitHub Copilot を Claude プロバイダーとして使用する場合、ローカルルーティングが常に必要です。ルーティングは現在のモデルに応じて Chat Completions または Responses を自動的に選択します。",
    "openLinkFailed": "リンクを開けませんでした",
    "openclawModelsRegistered": "モデルが /model リストに登録されました",
    "openclawDefaultModelSet": "デフォルトモデルに設定しました",
    "openclawDefaultModelSetFailed": "デフォルトモデルの設定に失敗しました",
    "openclawNoModels": "モデルが設定されていません",
    "openclawModelNotFound": "選択したモデルは存在しません。更新してからもう一度お試しください。",
    "backfillWarning": "切り替え成功しましたが、前のプロバイダーへの設定保存に失敗しました",
    "codexAuthCleanupFailed": "切り替えは成功しましたが、auth.json を削除できませんでした。公式ログイン資格情報がディスクに残っています。完全に削除するには Codex 設定ディレクトリの auth.json を手動で削除してください",
    "windowControlFailed": "ウィンドウ操作に失敗しました: {{error}}",
    "officialBlockedByProxy": "ローカルルーティングモード中は公式プロバイダーに切り替えできません。ルーティング経由で公式 API にアクセスするとアカウントが停止される可能性があります。",
    "proxyOfficialWarning": "現在のプロバイダー {{name}} は公式です。ローカルルーティングを使用する前にサードパーティプロバイダーに切り替えてください。",
    "proxyReasonClaudeDesktop": "Claude Desktop ローカルルーティングモードを使用中"
  },
  "confirm": {
    "deleteProvider": "プロバイダーを削除",
    "deleteProviderMessage": "プロバイダー「{{name}}」を削除してもよろしいですか？この操作は元に戻せません。",
    "removeProvider": "プロバイダーを解除",
    "removeProviderMessage": "プロバイダー「{{name}}」を設定から解除してもよろしいですか？\n\n解除後、このプロバイダーは無効になりますが、設定データは CC Switch に保持されます。いつでも再追加できます。",
    "piDefaultProviderWarning": "Pi のグローバルデフォルトは現在このプロバイダーを参照しています。続行すると、Pi は別の利用可能なモデルを試します。/model で再選択するか、/login で別のプロバイダーにログインできます。",
    "proxy": {
      "title": "ローカルルーティングの有効化",
      "message": "ローカルルーティングは上級機能です。有効にする前に、その仕組みを理解していることをご確認ください。\n\n適切な設定方法については、関連ドキュメントまたはプロバイダーにご相談ください。",
      "confirm": "理解しました、有効にする"
    },
    "failover": {
      "title": "フェイルオーバーの有効化",
      "message": "フェイルオーバーは上級機能です。有効にする前に、その仕組みを理解していることをご確認ください。\n\nフェイルオーバーキューでプロバイダーの優先順位を先に設定することをお勧めします。",
      "confirm": "理解しました、有効にする"
    },
    "unifyCodexHistory": {
      "title": "Codex セッション履歴を統一",
      "message": "オンにすると、公式サブスクリプションとサードパーティが同じセッション履歴リストを共有します。注意：プロバイダーをまたいで古いセッションを再開すると、encrypted_content を相手のバックエンドが復号できず失敗する場合があります。\n\n既存の公式セッション履歴を共有リストへ移行することもできます（移行前に ~/.cc-switch/backups へ自動バックアップされ、オフにする際に復元を選択できます）。",
      "migrateExisting": "既存の公式セッション履歴も移行する",
      "confirm": "理解しました、オンにする"
    },
    "unifyCodexHistoryOff": {
      "title": "セッション履歴の統一をオフにする",
      "message": "オフにすると、公式サブスクリプションとサードパーティはそれぞれ独立した履歴リストに戻ります。オン期間中に作成されたセッションは提供元を判別できないため、サードパーティの履歴に残り、公式サブスクリプションからは見えなくなります。",
      "restoreBackup": "オンにした際に移行した公式セッションを公式履歴へ復元する（バックアップから正確に復元）",
      "confirm": "オフにする"
    },
    "usage": {
      "title": "使用量クエリの設定",
      "message": "使用量クエリにはカスタムスクリプトまたは API パラメータが必要です。プロバイダーから必要な情報を取得していることをご確認ください。\n\n設定方法が不明な場合は、プロバイダーのドキュメントを先にご確認ください。",
      "confirm": "理解しました、設定する"
    },
    "autoSync": {
      "title": "自動同期を有効にする",
      "message": "自動同期を有効にすると、データベースの変更ごとに WebDAV サーバーへ自動アップロードされます。\n\nネットワークトラフィックが大幅に増加する可能性があります。ネットワーク環境と WebDAV サービスが頻繁なデータ転送に対応できることをご確認ください。",
      "confirm": "理解しました、有効にする"
    },
    "commonConfig": {
      "title": "共通設定について",
      "message": "「共通設定スニペット」を使うと、プラグインや環境変数などの設定を異なるプロバイダー間で共有でき、切り替え時に失われることがありません。\n\n使い方：\n① プロバイダーを編集 →「共通設定を編集」→「編集内容から抽出」\n② 新規プロバイダー作成時に「共通設定を適用」をチェック（デフォルトでオン）\n\n新しいプラグインや Hook をインストールした場合は、共通設定を再抽出してください。",
      "confirm": "わかりました"
    }
  },
  "settings": {
    "title": "設定",
    "general": "一般",
    "tabGeneral": "一般",
    "tabAuth": "認証",
    "tabAdvanced": "詳細",
    "tabProxy": "ルーティング",
    "authCenter": {
      "title": "OAuth 認証センター",
      "description": "Claude Code で他のサブスクリプションをご利用いただけます。コンプライアンスリスクにご注意ください。",
      "beta": "Beta",
      "copilotDescription": "GitHub Copilot アカウントを管理します",
      "codexOauthDescription": "ChatGPT アカウントを管理します",
      "xaiOauthDescription": "xAI / Grok アカウントを管理します"
    },
    "advanced": {
      "configDir": {
        "title": "設定ディレクトリ",
        "description": "Claude、Codex、Gemini の設定保存パスを管理"
      },
      "proxy": {
        "title": "ローカルルーティング",
        "description": "ルーティングサービスの切り替え、ステータスとポート情報を表示",
        "enableFeature": "メインページにルーティング切り替えを表示",
        "enableFeatureDescription": "有効にすると、メインページ上部にルーティングとフェイルオーバーの切り替えが表示されます",
        "enableFailoverToggle": "メインページにフェイルオーバー切り替えを表示",
        "enableFailoverToggleDescription": "有効にすると、メインページ上部にフェイルオーバー切り替えが独立して表示されます",
        "running": "実行中",
        "stopped": "停止中"
      },
      "connectivityCheck": {
        "title": "接続チェック設定",
        "description": "プロバイダー接続チェックのタイムアウト、リトライ、低速判定しきい値を設定"
      },
      "failover": {
        "title": "自動フェイルオーバー",
        "description": "フェイルオーバーキューとサーキットブレーカー戦略を設定"
      },
      "pricing": {
        "title": "コスト計算",
        "description": "各モデルのトークン料金ルールを管理"
      },
      "globalProxy": {
        "title": "グローバル送信プロキシ",
        "description": "CC Switch が外部 API にアクセスする際のプロキシを設定"
      },
      "data": {
        "title": "データ管理",
        "description": "ローカル設定データのインポートとエクスポート"
      },
      "backup": {
        "title": "バックアップと復元",
        "description": "自動バックアップの管理、データベーススナップショットの表示と復元"
      },
      "cloudSync": {
        "title": "クラウド同期",
        "description": "WebDAV でデバイス間のデータを同期"
      },
      "rectifier": {
        "title": "整流器",
        "description": "API リクエストの互換性問題を自動修正",
        "enabled": "整流器を有効化",
        "enabledDescription": "マスタースイッチ、オフにするとすべての整流機能が無効になります",
        "requestGroup": "リクエスト整流",
        "responseGroup": "レスポンス整流",
        "thinkingSignature": "Thinking 署名整流",
        "thinkingSignatureDescription": "Anthropic タイプのプロバイダーが thinking 署名の非互換性や不正なリクエストエラーを返した場合、互換性のない thinking 関連ブロックを自動削除し、同じプロバイダーで 1 回リトライします",
        "thinkingBudget": "Thinking Budget 整流",
        "thinkingBudgetDescription": "Anthropic タイプのプロバイダーが budget_tokens 制約エラー（例: 1024 以上）を返した場合、thinking を enabled に正規化し、thinking 予算を 32000 に設定し、必要に応じて max_tokens を 64000 に引き上げて 1 回リトライします",
        "mediaFallback": "非対応画像フォールバック",
        "mediaFallbackDescription": "プロバイダーが画像入力に対応していない場合（テキストのみの能力が宣言されている、または上流が画像非対応エラーを返した場合）、画像ブロックを [Unsupported Image] マーカーに自動置換し、会話を中断させません",
        "mediaHeuristic": "テキスト専用モデルの事前判定",
        "mediaHeuristicDescription": "送信前に、内蔵の確認済みテキスト専用モデル登録に基づいて画像を除去します。オフにしても無効になるのはプロキシの登録ベース事前処理だけで、宣言済みテキスト専用モデルの処理と上流エラー時のフォールバックは残り、Codex モデルカタログの能力宣言は変わりません"
      },
      "optimizer": {
        "title": "Bedrock リクエストオプティマイザー",
        "description": "リクエスト送信前に Thinking と Cache の設定を自動最適化（Bedrock プロバイダーのみ有効）",
        "enabled": "オプティマイザーを有効化",
        "thinkingOptimizer": "Thinking 最適化",
        "thinkingOptimizerDescription": "Opus/Sonnet に Adaptive Thinking を自動的に有効化し、レガシーモデルに Extended Thinking を注入",
        "cacheInjection": "Cache 注入",
        "cacheInjectionDescription": "リクエストの重要な位置に標準の 5 分間 Cache ブレークポイントを自動注入し、重複トークンの課金を削減"
      },
      "logConfig": {
        "title": "アプリ診断ログ",
        "description": "アプリ診断ログの出力レベルを制御",
        "enabled": "診断ログを有効化",
        "enabledDescription": "cc-switch.log を制御します。リクエスト使用量記録と crash.log には影響しません",
        "level": "ログレベル",
        "levelDescription": "出力する最小ログレベルを設定",
        "levels": {
          "error": "エラー",
          "warn": "警告",
          "info": "情報",
          "debug": "デバッグ",
          "trace": "トレース"
        },
        "levelHint": "ログレベルの説明：",
        "levelDesc": {
          "error": "重大なエラーのみ",
          "warn": "エラー + 警告",
          "info": "一般的な操作情報（デフォルト）",
          "debug": "SSE ストリームとリクエスト/レスポンスを含む詳細情報",
          "trace": "すべてのログ、最も詳細"
        }
      }
    },
    "language": "言語",
    "languageHint": "切り替えるとすぐにプレビューされ、保存後に永続化されます。",
    "theme": "テーマ",
    "themeHint": "アプリのテーマを選択します。すぐに反映されます。",
    "themeLight": "ライト",
    "themeDark": "ダーク",
    "themeSystem": "システム",
    "importExport": "SQL インポート/エクスポート",
    "importExportHint": "移行や復元用にデータベースの SQL バックアップをインポート/エクスポートします（インポートは CC Switch がエクスポートしたバックアップのみ対応）。",
    "exportConfig": "SQL バックアップをエクスポート",
    "selectConfigFile": "SQL ファイルを選択",
    "noFileSelected": "ファイルが選択されていません。",
    "import": "インポート",
    "importing": "インポート中...",
    "importSuccess": "インポート成功！",
    "importFailed": "インポート失敗",
    "syncLiveFailed": "インポートしましたが、現在のプロバイダーへの同期に失敗しました。手動で再選択してください。",
    "importPartialSuccess": "設定はインポートされましたが、現在のプロバイダーへの同期に失敗しました。",
    "importPartialHint": "ライブ設定を更新するため、もう一度プロバイダーを選択してください。",
    "configExported": "設定をエクスポートしました:",
    "exportFailed": "エクスポートに失敗しました",
    "selectFileFailed": "有効な SQL バックアップファイルを選択してください",
    "configCorrupted": "SQL ファイルが壊れているか形式が無効な可能性があります",
    "backupId": "バックアップ ID",
    "backupManager": {
      "title": "データベースバックアップ",
      "description": "以前の状態に復元するための自動データベーススナップショット",
      "empty": "バックアップはまだありません",
      "restore": "復元",
      "restoring": "復元中...",
      "confirmTitle": "バックアップの復元を確認",
      "confirmMessage": "このバックアップを復元すると現在のデータベースが上書きされます。安全バックアップが先に作成されます。",
      "restoreSuccess": "復元成功！安全バックアップが作成されました",
      "restoreFailed": "復元に失敗しました",
      "safetyBackupId": "安全バックアップID",
      "intervalLabel": "自動バックアップ間隔",
      "retainLabel": "バックアップ保持数",
      "intervalDisabled": "無効",
      "intervalHours": "{{hours}} 時間",
      "intervalDays": "{{days}} 日",
      "rename": "名前変更",
      "renameSuccess": "バックアップの名前を変更しました",
      "renameFailed": "名前変更に失敗しました",
      "namePlaceholder": "新しい名前を入力",
      "createBackup": "今すぐバックアップ",
      "creating": "バックアップ中...",
      "createSuccess": "バックアップが作成されました",
      "createFailed": "バックアップに失敗しました",
      "delete": "削除",
      "deleting": "削除中...",
      "deleteSuccess": "バックアップを削除しました",
      "deleteFailed": "削除に失敗しました",
      "deleteConfirmTitle": "バックアップの削除を確認",
      "deleteConfirmMessage": "このバックアップは完全に削除されます。この操作は取り消せません。"
    },
    "webdavSync": {
      "title": "WebDAV クラウド同期",
      "description": "WebDAV を使ってデバイス間でデータベースとスキル設定を同期します。",
      "baseUrl": "WebDAV サーバー URL",
      "baseUrlPlaceholder": "https://example.com/remote.php/dav/files/user",
      "username": "ユーザー名",
      "usernamePlaceholder": "メールアドレスまたはユーザー名",
      "password": "パスワード",
      "passwordPlaceholder": "アプリパスワード",
      "remoteRoot": "リモートルートディレクトリ",
      "profile": "同期プロファイル名",
      "autoSync": "自動同期",
      "autoSyncHint": "有効にすると、データベース変更のたびに WebDAV へ自動アップロードします。",
      "test": "接続テスト",
      "testing": "テスト中...",
      "testSuccess": "接続成功",
      "testFailed": "接続失敗：{{error}}",
      "save": "設定を保存",
      "saving": "保存中...",
      "saveFailed": "設定の保存に失敗しました：{{error}}",
      "upload": "クラウドにアップロード",
      "uploading": "アップロード中...",
      "uploadSuccess": "WebDAV にアップロードしました",
      "uploadFailed": "アップロードに失敗しました：{{error}}",
      "autoSyncFailedToast": "自動同期に失敗しました：{{error}}",
      "download": "クラウドからダウンロード",
      "downloading": "ダウンロード中...",
      "downloadSuccess": "WebDAV からダウンロード・復元しました",
      "downloadFailed": "ダウンロードに失敗しました：{{error}}",
      "lastSync": "前回の同期：{{time}}",
      "autoSyncLastErrorTitle": "前回の自動同期に失敗しました",
      "autoSyncLastErrorHint": "ネットワークまたは WebDAV 設定を確認してください。次回の変更時に自動再試行されます。",
      "missingUrl": "WebDAV サーバー URL を入力してください",
      "presets": {
        "label": "サービス",
        "jianguoyun": "坚果云",
        "jianguoyunHint": "坚果云の「セキュリティ設定」で「サードパーティアプリパスワード」を生成してください。ログインパスワードは使用しないでください。",
        "nextcloud": "Nextcloud",
        "nextcloudHint": "your-server を Nextcloud サーバーのアドレスに、USERNAME をユーザー名に置き換えてください。",
        "synology": "Synology NAS",
        "synologyHint": "Synology の「パッケージセンター」で WebDAV Server パッケージをインストール・有効化してください。",
        "custom": "カスタム"
      },
      "remoteRootDefault": "デフォルト: cc-switch-sync",
      "profileDefault": "デフォルト: default",
      "saveAndTestSuccess": "設定を保存しました。接続正常です",
      "saveAndTestFailed": "設定を保存しましたが、接続テストに失敗しました：{{error}}",
      "noRemoteData": "クラウドに同期データが見つかりません",
      "incompatibleVersion": "リモートデータに互換性がありません（プロトコル v{{protocolVersion}}、データベース {{dbCompatVersion}}）。このクライアントは protocol v2 / db-v6 をサポートしています。",
      "unsaved": "未保存",
      "saved": "保存済み",
      "unsavedChanges": "先に設定を保存してください",
      "saveBeforeSync": "アップロード/ダウンロードを有効にするには、先に設定を保存してください。",
      "fetchingRemote": "リモート情報を取得中...",
      "fetchRemoteFailed": "リモート情報の取得に失敗しました。設定とネットワークを確認してください。",
      "confirmDownload": {
        "title": "クラウドから復元",
        "deviceName": "アップロード元",
        "createdAt": "アップロード日時",
        "path": "リモートパス",
        "dbCompat": "DB 互換レイヤー",
        "artifacts": "内容",
        "legacyNotice": "旧レイアウトのリモートパスを検出しました。復元後、次回のアップロードは新しい v2/db-v6 パスに書き込まれます。",
        "warning": "ローカルのすべてのデータとスキル設定が上書きされます",
        "confirm": "復元を実行"
      },
      "confirmUpload": {
        "title": "クラウドにアップロード",
        "content": "以下の内容を WebDAV サーバーに同期します：",
        "dbItem": "データベース（すべてのプロバイダー設定とデータ）",
        "skillsItem": "スキル（すべてのカスタムスキル）",
        "targetPath": "保存先パス",
        "existingData": "クラウドの既存データ",
        "deviceName": "アップロード元",
        "createdAt": "アップロード日時",
        "path": "リモートパス",
        "dbCompat": "DB 互換レイヤー",
        "warning": "リモートの既存同期データが上書きされます",
        "legacyNotice": "旧レイアウトのリモートデータを検出しました。今回のアップロードは新しい v2/db-v6 パスに書き込み、旧パスは上書きしません。",
        "confirm": "アップロードを実行"
      }
    },
    "syncType": {
      "label": "同期方式",
      "webdav": "WebDAV",
      "s3": "S3互換ストレージ"
    },
    "s3Sync": {
      "presets": {
        "label": "サービス",
        "awsS3": "AWS S3",
        "awsS3Hint": "IAM Access Keyを使用。s3:PutObject/GetObject/HeadObject権限が必要です。Region例: us-east-1, ap-northeast-1",
        "minio": "MinIO",
        "minioHint": "カスタムEndpointが必要です（例: http://minio.local:9000）。Regionは us-east-1 に設定可能",
        "r2": "Cloudflare R2",
        "r2Hint": "Endpoint: https://<account_id>.r2.cloudflarestorage.com、Regionは auto に設定",
        "oss": "Alibaba Cloud OSS",
        "ossHint": "Endpoint: https://oss-<region>.aliyuncs.com、Region例: cn-hangzhou, cn-shanghai",
        "cos": "Tencent Cloud COS",
        "cosHint": "Endpoint: https://cos.<region>.myqcloud.com、Region例: ap-guangzhou, ap-beijing",
        "obs": "Huawei OBS",
        "obsHint": "Endpoint: https://obs.<region>.myhuaweicloud.com、Region例: cn-north-4, cn-east-3",
        "custom": "S3互換サービス（カスタム）",
        "customHint": "任意のS3互換サービス。カスタムEndpointが必要です"
      },
      "region": "リージョン",
      "regionPlaceholder": "例: us-east-1",
      "bucket": "バケット",
      "bucketPlaceholder": "例: my-cc-switch-bucket",
      "accessKeyId": "Access Key ID",
      "accessKeyIdPlaceholder": "例: AKIA...",
      "secretAccessKey": "Secret Access Key",
      "secretAccessKeyPlaceholder": "既存のシークレットを保持する場合は変更しないでください",
      "endpoint": "エンドポイント（AWSは空欄可）",
      "endpointHint": "多くの S3 互換サービスでは必須です",
      "endpointPlaceholder": "例: https://s3-compatible.example.com",
      "remoteRoot": "リモートルートディレクトリ",
      "remoteRootDefault": "デフォルト: cc-switch-sync",
      "profile": "同期プロファイル名",
      "profileDefault": "デフォルト: default",
      "autoSync": "自動同期",
      "autoSyncHint": "有効にすると、データベース変更のたびに S3 へ自動アップロードします。",
      "enabled": "S3 同期を有効化",
      "enabledHint": "S3 のアップロード/ダウンロードと自動同期を有効にします。",
      "mutualExclusionTitle": "同期方式の切り替え",
      "mutualExclusionMessage": "S3同期を有効にすると、現在のWebDAV同期が無効になります。続行しますか？",
      "mutualExclusionMessageReverse": "WebDAV同期を有効にすると、現在のS3同期が無効になります。続行しますか？",
      "mutualExclusionFailed": "同期方式の切り替えに失敗しました：{{error}}",
      "testConnection": "接続テスト",
      "connectionOk": "S3接続成功",
      "test": "接続テスト",
      "testing": "テスト中...",
      "testSuccess": "S3 接続成功",
      "testFailed": "S3 接続失敗：{{error}}",
      "save": "設定を保存",
      "saving": "保存中...",
      "saveFailed": "設定の保存に失敗しました：{{error}}",
      "saveAndTestSuccess": "設定を保存しました。S3 接続正常です",
      "saveAndTestFailed": "設定を保存しましたが、S3 接続テストに失敗しました：{{error}}",
      "upload": "クラウドにアップロード",
      "uploading": "アップロード中...",
      "uploadSuccess": "S3 にアップロードしました",
      "uploadFailed": "S3 アップロードに失敗しました：{{error}}",
      "autoSyncFailedToast": "S3 自動同期に失敗しました：{{error}}",
      "download": "クラウドからダウンロード",
      "downloading": "ダウンロード中...",
      "downloadSuccess": "S3 からダウンロード・復元しました",
      "downloadFailed": "S3 ダウンロードに失敗しました：{{error}}",
      "lastSync": "前回の同期：{{time}}",
      "autoSyncLastErrorTitle": "前回の S3 自動同期に失敗しました",
      "autoSyncLastErrorHint": "ネットワークまたは S3 設定を確認してください。次回の変更時に自動再試行されます。",
      "missingBucket": "S3 バケットを入力してください",
      "noRemoteData": "S3 バケットに同期データが見つかりません",
      "incompatibleVersion": "リモートデータに互換性がありません（バージョン {{version}}）。このクライアントは protocol v2 / db-v6 をサポートしています。",
      "unsaved": "未保存",
      "saved": "保存済み",
      "unsavedChanges": "先に設定を保存してください",
      "saveBeforeSync": "アップロード/ダウンロードを有効にするには、先に設定を保存してください。",
      "fetchingRemote": "リモート情報を取得中...",
      "fetchRemoteFailed": "リモート情報の取得に失敗しました。設定とネットワークを確認してください。",
      "notConfigured": "S3同期が設定されていません",
      "disabled": "S3同期が無効です",
      "confirmDownload": {
        "title": "S3 から復元",
        "deviceName": "アップロード元",
        "createdAt": "アップロード日時",
        "artifacts": "内容",
        "warning": "ローカルのすべてのデータとスキル設定が上書きされます",
        "confirm": "復元を実行"
      },
      "confirmUpload": {
        "title": "S3 にアップロード",
        "content": "以下の内容を S3 バケットに同期します：",
        "dbItem": "データベース（すべてのプロバイダー設定とデータ）",
        "skillsItem": "スキル（すべてのカスタムスキル）",
        "targetPath": "保存先オブジェクトパス",
        "existingData": "クラウドの既存データ",
        "deviceName": "アップロード元",
        "createdAt": "アップロード日時",
        "warning": "この S3 パスにある既存の同期データが上書きされます",
        "confirm": "アップロードを実行"
      }
    },
    "autoReload": "データを更新しました",
    "languageOptionChinese": "简体中文",
    "languageOptionTraditionalChinese": "繁體中文",
    "languageOptionEnglish": "English",
    "languageOptionJapanese": "日本語",
    "windowBehavior": "ウィンドウ動作",
    "windowBehaviorHint": "最小化動作や Claude プラグイン連携を設定します。",
    "launchOnStartup": "起動時に自動実行",
    "launchOnStartupDescription": "システム起動時に CC Switch を自動起動します",
    "silentStartup": "サイレント起動",
    "silentStartupDescription": "起動時にメインウィンドウを表示せず、トレイのみで起動",
    "autoLaunchFailed": "自動起動の設定に失敗しました",
    "minimizeToTray": "閉じるときトレイへ最小化",
    "minimizeToTrayDescription": "チェックすると閉じるボタンでトレイに隠し、オフならアプリを終了します。",
    "useAppWindowControls": "アプリ内ウィンドウボタンを有効化",
    "useAppWindowControlsDescription": "有効にすると、アプリヘッダーに最小化・最大化/復元・閉じるボタンを表示します。",
    "enableClaudePluginIntegration": "Claude Code 拡張に適用",
    "enableClaudePluginIntegrationDescription": "オンにすると VS Code の Claude Code 拡張のプロバイダーも同期します",
    "skipClaudeOnboarding": "Claude Code の初回確認をスキップ",
    "skipClaudeOnboardingDescription": "オンにすると Claude Code の初回インストール確認をスキップします",
    "codexAuth": "Codex アプリ拡張",
    "preserveCodexOfficialAuthOnSwitch": "直接切替時に公式ログインを保持",
    "preserveCodexOfficialAuthOnSwitchDescription": "ローカルルーティングが無効な場合のサードパーティ切替を制御します。ルーティング接管中は常に Codex の公式ログインを保持します。",
    "unifyCodexSessionHistory": "Codex セッション履歴を統一",
    "unifyCodexSessionHistoryDescription": "オンにすると、公式サブスクリプションも共有の custom プロバイダー ID で動作し、公式とサードパーティのセッションが同じ履歴リストに表示されます。既存の公式セッションの移行も選択できます（移行前に自動バックアップ）。オフにする際はバックアップから復元できます。注意：プロバイダーをまたいで古いセッションを再開すると、encrypted_content の推論内容を相手のバックエンドが復号できず、再開に失敗する場合があります。",
    "unifyCodexHistoryRestoreCompleted": "バックアップから公式セッション履歴を復元しました（セッションファイル {{files}} 件、インデックス {{rows}} 行）",
    "unifyCodexHistoryRestoreFailed": "公式セッション履歴の復元に失敗しました。もう一度お試しください",
    "unifyCodexHistoryRestoreNothing": "現在の Codex ディレクトリに復元可能な移行バックアップはありません",
    "unifyCodexHistoryRestoreSkippedToggleOn": "統一セッション履歴が再度有効化されたため、復元をスキップしました",
    "appVisibility": {
      "title": "ホームページ表示",
      "description": "ホームページに表示するアプリを選択",
      "claudeDesc": "Anthropic Claude Code CLI",
      "codexDesc": "OpenAI Codex CLI",
      "geminiDesc": "Google Gemini CLI",
      "opencodeDesc": "OpenCode CLI",
      "showProfileSwitcher": "プロジェクト切り替えを表示",
      "showProfileSwitcherDescription": "メイン画面上部にプロジェクト切り替えを表示します"
    },
    "skillStorage": {
      "title": "スキル保存場所",
      "description": "CC Switch がスキルのマスターコピーを保存するディレクトリを選択します",
      "ccSwitch": "CC Switch",
      "unified": "~/.agents/skills",
      "ccSwitchHint": "スキルは ~/.cc-switch/skills/ に保存され、シンボリックリンクまたはコピーで各アプリに同期されます。",
      "unifiedHint": "スキルは ~/.agents/skills/ に保存されます（Agent Skills オープン標準）。対応ツール（Claude Code、Codex、Gemini CLI など）はこのディレクトリのスキルを直接検出します。",
      "confirmTitle": "スキル保存場所の移行",
      "confirmMessage": "{{count}} 個のスキルを新しい場所に移動します。続行しますか？",
      "migrationSuccess": "{{count}} 個のスキルを移行しました",
      "migrationPartial": "{{migrated}} 個のスキルを移行、{{errors}} 個のエラー。詳細はログを確認してください。"
    },
    "skillSync": {
      "title": "スキル同期方式",
      "description": "スキルファイルの同期方法を選択",
      "symlink": "シンボリックリンク",
      "copy": "ファイルコピー",
      "symlinkHint": "シンボリックリンクはディスク容量を節約し、リアルタイム同期を有効にします。注意：Windowsでは管理者権限または開発者モードが必要な場合があります"
    },
    "terminal": {
      "title": "優先ターミナル",
      "description": "ターミナルボタンをクリックした時に使用するターミナルアプリを選択",
      "fallbackHint": "選択したターミナルが利用できない場合、システムのデフォルトが使用されます",
      "options": {
        "macos": {
          "terminal": "Terminal.app",
          "iterm2": "iTerm2",
          "alacritty": "Alacritty",
          "kitty": "Kitty",
          "ghostty": "Ghostty",
          "otty": "Otty",
          "wezterm": "WezTerm",
          "kaku": "Kaku",
          "warp": "Warp"
        },
        "windows": {
          "cmd": "コマンドプロンプト",
          "powershell": "PowerShell",
          "wt": "Windows Terminal"
        },
        "linux": {
          "gnomeTerminal": "GNOME Terminal",
          "konsole": "Konsole",
          "xfce4Terminal": "Xfce4 Terminal",
          "alacritty": "Alacritty",
          "kitty": "Kitty",
          "ghostty": "Ghostty"
        }
      }
    },
    "configDirectoryOverride": "設定ディレクトリの上書き（詳細）",
    "configDirectoryDescription": "WSL などで Claude Code や Codex を使う場合、ここで設定ディレクトリを WSL 側に合わせるとデータを揃えられます。",
    "appConfigDir": "CC Switch 設定ディレクトリ",
    "appConfigDirDescription": "CC Switch の保存場所をカスタマイズします（クラウド同期フォルダを指定すると設定を同期できます）",
    "browsePlaceholderApp": "例: C:\\\\Users\\\\Administrator\\\\.cc-switch",
    "claudeConfigDir": "Claude Code 設定ディレクトリ",
    "claudeConfigDirDescription": "Claude の設定ディレクトリ（settings.json）を上書きします。カスタムディレクトリでは .claude.json（MCP）をその中に保存し、既定の ~/.claude では Claude Code の既定どおり ~/.claude.json を使います。",
    "codexConfigDir": "Codex 設定ディレクトリ",
    "codexConfigDirDescription": "Codex の設定ディレクトリを上書きします。",
    "geminiConfigDir": "Gemini 設定ディレクトリ",
    "geminiConfigDirDescription": "Gemini の設定ディレクトリ（.env）を上書きします。",
    "grokConfigDir": "Grok Build 設定ディレクトリ",
    "grokConfigDirDescription": "Grok Build の設定ディレクトリ（config.toml）を上書きします。",
    "opencodeConfigDir": "OpenCode 設定ディレクトリ",
    "opencodeConfigDirDescription": "OpenCode の設定ディレクトリ（opencode.json）を上書きします。",
    "openclawConfigDir": "OpenClaw 設定ディレクトリ",
    "openclawConfigDirDescription": "OpenClaw の設定ディレクトリ（openclaw.json）を上書きします。",
    "hermesConfigDir": "Hermes 設定ディレクトリ",
    "hermesConfigDirDescription": "Hermes の設定ディレクトリ（config.yaml）を上書きします。",
    "piConfigDir": "Pi 設定ディレクトリ",
    "piConfigDirDescription": "Pi の設定ディレクトリ（models.json、指示ファイル、プロンプト、Skills、セッション）を上書きします。",
    "browsePlaceholderClaude": "例: /home/<your-username>/.claude",
    "browsePlaceholderCodex": "例: /home/<your-username>/.codex",
    "browsePlaceholderGemini": "例: /home/<your-username>/.gemini",
    "browsePlaceholderGrok": "例: /home/<your-username>/.grok",
    "browsePlaceholderOpencode": "例: /home/<your-username>/.config/opencode",
    "browsePlaceholderOpenclaw": "例: /home/<your-username>/.openclaw",
    "browsePlaceholderHermes": "例: /home/<your-username>/.hermes",
    "browsePlaceholderPi": "例: /home/<your-username>/.pi/agent",
    "browseDirectory": "ディレクトリを選択",
    "resetDefault": "デフォルトに戻す（保存後に反映）",
    "checkForUpdates": "アップデートを確認",
    "updateTo": "v{{version}} に更新",
    "updating": "更新中...",
    "checking": "確認中...",
    "upToDate": "最新バージョンです",
    "aboutHint": "バージョン情報と更新状況を表示します。",
    "portableMode": "ポータブルモード: 更新は手動ダウンロードが必要です。",
    "updateAvailable": "新しいバージョンがあります: {{version}}",
    "updateBadge": "更新あり",
    "updateFailed": "更新のインストールに失敗しました。ダウンロードページを開こうとしました。",
    "checkUpdateFailed": "更新の確認に失敗しました。時間をおいて再試行してください。",
    "openReleaseNotesFailed": "リリースノートの表示に失敗しました",
    "releaseNotes": "リリースノート",
    "viewReleaseNotes": "このバージョンのリリースノートを見る",
    "viewCurrentReleaseNotes": "現在のバージョンのリリースノートを見る",
    "officialWebsite": "公式サイト",
    "github": "GitHub",
    "starPrompt": "CC Switch がお役に立てたなら、GitHub でスターをお願いします。私たちにとって大きな励みになります",
    "manualInstallCommands": "手動インストールコマンド",
    "oneClickInstallHint": "Claude Code / Codex / Gemini CLI / OpenCode / OpenClaw / Hermes / Pi をインストールまたは更新",
    "localEnvCheck": "ローカル環境チェック",
    "updateAllTools": "すべて更新（{{count}}）",
    "currentVersion": "現在のバージョン",
    "latestVersion": "最新バージョン",
    "updateAvailableShort": "更新あり",
    "toolInstall": "インストール",
    "toolUpdate": "更新",
    "toolReady": "準備完了",
    "toolActionDone": "{{count}} 個のツールの{{action}}が完了しました",
    "toolActionPartial": "{{succeeded}} 個成功、{{failed}} 個失敗（{{action}}）",
    "toolActionFailed": "インストール/更新コマンドの実行に失敗しました",
    "toolNotRunnable": "インストール済みですが実行できません（バージョン未検出）",
    "toolActionVersionUnchangedTitle": "バージョンは変わりませんでした",
    "toolActionVersionUnchanged": "現在も {{version}}（最新: {{latest}}）です。アップデーターが成功を報告しても実際には更新されていない可能性があります。",
    "toolActionInstalledNotRunnable": "インストールされましたが、現在の環境では実行できません。確認してください",
    "installedNotRunnable": "インストール済み・実行不可",
    "toolCheckEnv": "実行環境を確認",
    "toolDiagnose": "インストールを診断",
    "toolDiagnosing": "診断中…",
    "toolConflictTitle": "複数のインストールを検出",
    "toolConflictHint": "コマンドラインは「既定」のものを使用します。更新が別の場所に適用された可能性があります。",
    "toolConflictDefault": "既定",
    "toolConflictNotRunnable": "実行不可",
    "toolDiagnoseNoConflict": "競合するインストールは見つかりませんでした",
    "toolDiagnoseFailed": "診断に失敗しました",
    "toolUpgradeConfirmTitle": "アップグレード先の確認",
    "toolUpgradeConfirmHint": "複数のインストールを検出しました。今回のアップグレードはすべてを更新するわけではありません。実際に作用する箇所は下記の各項目をご確認ください。",
    "toolUpgradeWillRun": "実行内容：",
    "toolUpgradeConfirmBtn": "アップグレードを実行",
    "toolUpgradeUnanchoredHint": "コマンドラインが実際に使用する箇所を特定できません。既定のアップグレードコマンドを実行します（PATH 上の最初の npm にインストールされる場合があります）。",
    "envBadge": {
      "wsl": "WSL",
      "windows": "Win",
      "macos": "macOS",
      "linux": "Linux"
    },
    "wslShell": "Shell",
    "wslShellFlag": "フラグ",
    "installCommandsCopied": "インストールコマンドをコピーしました",
    "installCommandsCopyFailed": "コピーに失敗しました。手動でコピーしてください。",
    "importFailedError": "設定のインポートに失敗しました: {{message}}",
    "exportFailedError": "設定のエクスポートに失敗しました:",
    "restartRequired": "再起動が必要です",
    "restartRequiredMessage": "CC Switch の設定ディレクトリを変更すると再起動が必要です。今すぐ再起動しますか？",
    "restartNow": "今すぐ再起動",
    "restartLater": "後で再起動",
    "restartFailed": "アプリの再起動に失敗しました。手動で閉じて再度開いてください。",
    "devModeRestartHint": "開発モードでは自動再起動をサポートしていません。手動で再起動してください。",
    "saving": "保存中...",
    "globalProxy": {
      "label": "グローバルプロキシ",
      "hint": "すべてのリクエスト（API、Skills ダウンロードなど）をプロキシ経由で送信します。ローカルルーティング有効時、アプリのリクエストもこのプロキシを経由します。空欄で直接接続。",
      "username": "ユーザー名（任意）",
      "password": "パスワード（任意）",
      "test": "接続テスト",
      "scan": "ローカルプロキシをスキャン",
      "clear": "クリア",
      "scanFailed": "スキャンに失敗しました: {{error}}",
      "saved": "ルーティング設定を保存しました",
      "saveFailed": "保存に失敗しました: {{error}}",
      "testSuccess": "接続成功！遅延 {{latency}}ms",
      "testFailed": "接続に失敗しました: {{error}}",
      "pricingDefaultsTitle": "課金のデフォルト設定",
      "pricingDefaultsDescription": "アプリごとのデフォルト倍率と課金モードを設定します。",
      "pricingAppLabel": "アプリ",
      "defaultCostMultiplierLabel": "デフォルト倍率",
      "defaultCostMultiplierHint": "コスト計算用の倍率（小数対応）。",
      "pricingModelSourceLabel": "課金モード",
      "pricingModelSourceRequest": "リクエストモデル",
      "pricingModelSourceResponse": "レスポンスモデル",
      "pricingSave": "課金設定を保存",
      "pricingSaved": "課金設定を保存しました",
      "pricingSaveFailed": "課金設定の保存に失敗しました: {{error}}",
      "pricingLoadFailed": "課金設定の読み込みに失敗しました: {{error}}",
      "defaultCostMultiplierRequired": "デフォルト倍率は必須です",
      "defaultCostMultiplierInvalid": "デフォルト倍率の形式が正しくありません"
    },
    "saveFailedGeneric": "保存に失敗しました。もう一度お試しください"
  },
  "apps": {
    "claude": "Claude",
    "claudeCode": "Claude Code",
    "claudeDesktop": "Claude Desktop",
    "claude-desktop": "Claude Desktop",
    "codex": "Codex",
    "gemini": "Gemini",
    "grokbuild": "Grok Build",
    "opencode": "OpenCode",
    "openclaw": "OpenClaw",
    "hermes": "Hermes",
    "pi": "Pi",
    "mcode": "MiniMax Code"
  },
  "pi": {
    "empty": {
      "title": "API キープロバイダーはまだありません",
      "description": "右上の + から、プリセットまたはカスタムプロバイダーを追加できます。"
    },
    "provider": {
      "enabled": "Pi で有効にしました",
      "enableFailed": "Pi でこのプロバイダーを有効にできませんでした",
      "removed": "Pi から削除しました",
      "writeConflict": "別のプロセスが Pi の設定を更新しています。しばらくしてから再試行してください。"
    },
    "form": {
      "providerKey": "プロバイダーキー",
      "providerKeyRequired": "プロバイダーキーを入力してください",
      "selectPresetRequired": "先にプリセットまたはカスタム設定を選択してください",
      "fixJsonFirst": "下の設定 JSON を修正してから、構造化フィールドを編集してください。",
      "nameRequired": "表示名を入力してください",
      "credential": "API キー",
      "credentialRequired": "このプリセットの API キーを入力してください",
      "absoluteHttpUrlRequired": "{{label}} は絶対 HTTP または HTTPS URL で指定してください",
      "positiveNumberRequired": "{{label}} は 0 より大きい数値で指定してください",
      "models": "モデル設定",
      "noModels": "モデルはまだ設定されていません",
      "addModel": "モデルを追加",
      "removeModel": "モデルを削除",
      "modelId": "モデル ID",
      "modelIdRequired": "モデル {{index}} に ID が必要です",
      "modelName": "表示名",
      "modelNameRequired": "モデル {{index}} に表示名が必要です",
      "modelNamePlaceholder": "表示名",
      "toggleModelDetails": "モデル詳細を開閉",
      "reasoning": "拡張思考に対応",
      "imageInput": "画像入力に対応",
      "thinkingLevelsLabel": "思考レベル",
      "customizeThinkingLevels": "カスタマイズ",
      "thinkingLevelDefault": "Pi デフォルト",
      "thinkingLevelUnsupported": "利用不可",
      "thinkingLevelValue": "{{level}} の上流値",
      "editThinkingLevel": "{{level}}レベルを編集",
      "thinkingLevelFollowDefault": "Pi のデフォルトに従う",
      "thinkingLevelMapTo": "マッピング先",
      "thinkingLevelMarkUnavailable": "このレベルは利用不可",
      "thinkingLevelMapInvalid": "思考レベルは Pi のネイティブキーのみ使用でき、値は文字列または null である必要があります。",
      "thinkingLevels": {
        "off": "オフ",
        "minimal": "最小",
        "low": "低",
        "medium": "中",
        "high": "高",
        "xhigh": "超高",
        "max": "最大"
      },
      "contextWindow": "コンテキストウィンドウ",
      "maxTokens": "最大出力トークン数",
      "compatibility": "互換性",
      "compatibilityHint": "互換エンドポイントやローカル環境向けにリクエスト動作を調整します。",
      "addCompatibilityOption": "追加",
      "noCompatibilityOptions": "互換性オプションはありません",
      "optionKey": "オプション",
      "optionValue": "値",
      "removeCompatibilityOption": "互換性オプションを削除",
      "effectiveApiRequired": "モデル {{id}} には、直接またはプロバイダーから継承した API が必要です",
      "effectiveBaseUrlRequired": "モデル {{id}} には、直接またはプロバイダーから継承したベース URL が必要です",
      "duplicateModel": "モデル ID {{id}} が重複しています",
      "modelRequired": "モデルを 1 つ以上追加してください",
      "providerKeyDuplicate": "このプロバイダーキーは既に存在します"
    },
    "current": {
      "readFailed": "Pi のプロバイダー設定を読み込めません",
      "stateUnavailableHint": "CC Switch が Pi のプロバイダー設定を読み込むまで、プロバイダーの変更は無効です。"
    },
    "prompts": {
      "globalTab": "グローバルプロンプト",
      "systemTab": "グローバルシステムプロンプト",
      "templatesTab": "プロンプトテンプレート",
      "agentsLibrary": "AGENTS.md ライブラリ",
      "agentsLibraryDescription": "1 つのプロンプトを選び、Pi のグローバル AGENTS.md に書き込みます。",
      "writtenToAgents": "AGENTS.md に書き込み済み",
      "externalAgents": "外部 AGENTS.md",
      "noGlobalPrompt": "グローバル AGENTS.md は未設定",
      "noGlobalPrompts": "グローバルプロンプトがありません",
      "noGlobalPromptsDescription": "右上からプロンプトを追加し、必要なものをグローバル AGENTS.md に書き込めます。",
      "noPromptDescription": "説明なし",
      "usePrompt": "使用",
      "stopUsing": "停止",
      "usePromptSuccess": "グローバル AGENTS.md を更新しました",
      "stopUsingSuccess": "グローバル AGENTS.md を削除しました",
      "stopBeforeDelete": "先に使用を停止してください",
      "systemFilesDescription": "通常は追記を使用し、基本指示を完全に制御する場合のみ置換を使用してください。",
      "systemAppend": "システムプロンプトの追記",
      "systemAppendDescription": "Pi の組み込み基本プロンプトの後に指示を追加します。",
      "systemOverride": "システムプロンプトの置換",
      "systemOverrideDescription": "Pi の組み込み基本プロンプトを置換します。コンテキストや AGENTS.md などは Pi が引き続き追加します。",
      "systemOverrideWarning": "SYSTEM.md は Pi の組み込み基本プロンプトを置換します。基本指示を完全に制御する必要がない限り、APPEND_SYSTEM.md を使用してください。",
      "recommended": "推奨",
      "configured": "設定済み",
      "configuredEmpty": "設定済み（空）",
      "notConfigured": "未設定",
      "unavailable": "読み込み失敗",
      "markdownContent": "Markdown 内容",
      "instructionPlaceholder": "Pi が使用する Markdown 内容",
      "blankInstruction": "空白以外の内容を入力するか、グローバルファイルを削除してください。",
      "saveAndConfigure": "保存して設定",
      "removeGlobalFile": "グローバルファイルを削除",
      "activateOverrideTitle": "{{filename}} を設定しますか？",
      "activateOverrideMessage": "{{filename}} を作成すると Pi の組み込み基本プロンプトが置換されます。コンテキスト、AGENTS.md、Skills などは Pi の規則に従って引き続き追加されます。",
      "removeFileTitle": "{{filename}} を削除しますか？",
      "removeFileMessage": "Pi のグローバル設定ディレクトリから {{filename}} を削除します。",
      "fileSaved": "{{filename}} を保存しました",
      "fileRemoved": "{{filename}} を削除しました",
      "saveFailed": "Pi 指示ファイルを保存できませんでした",
      "deleteFailed": "Pi 指示ファイルを削除できませんでした",
      "reloadNotice": "開いている Pi セッションには自動反映されません。変更後、Pi がアイドル状態のときに /reload を実行してください。新しいセッションは自動的に読み込みます。",
      "templatesDescription": "保存したテンプレートは Pi で /コマンド名 として呼び出せます。有効化は不要です。",
      "newTemplate": "新しいプロンプトテンプレート",
      "editTemplate": "/{{slug}} を編集",
      "templateCommand": "スラッシュコマンド",
      "templateSlug": "例: review",
      "templateSlugInvalid": "空白やファイル名の予約文字を含まない、1 つのコマンド名を入力してください。",
      "templateSlugExists": "そのスラッシュコマンドは既に存在します。",
      "templateDescription": "メモ",
      "templateDescriptionPlaceholder": "任意の説明",
      "templateContent": "テンプレート Markdown",
      "templateContentPlaceholder": "Pi が展開する Markdown を入力します。YAML frontmatter は保持されます。",
      "templateSyntax": "Pi テンプレート構文",
      "templateSyntaxDescription": "任意の frontmatter では description と argument-hint を使用できます。本文では $1、$2、$@ または $ARGUMENTS、${@:N}、${@:N:L} の引数置換を使用できます。",
      "createTemplate": "テンプレートを作成",
      "templateCreated": "Pi プロンプトテンプレートを作成しました",
      "templateSaved": "/{{slug}} を保存しました",
      "templateDeleted": "/{{slug}} を削除しました",
      "templateLoadFailed": "Pi プロンプトテンプレートを読み込めませんでした",
      "templateSaveFailed": "Pi プロンプトテンプレートを保存できませんでした",
      "templateDeleteFailed": "Pi プロンプトテンプレートを削除できませんでした",
      "searchTemplates": "プロンプトテンプレートの名前、説明、内容を検索…",
      "noTemplates": "プロンプトテンプレートがありません",
      "noTemplatesDescription": "右上からテンプレートを作成すると、Pi でスラッシュコマンドとして呼び出せます。",
      "noTemplateResults": "一致するテンプレートがありません",
      "deleteTemplateTitle": "/{{slug}} を削除しますか？",
      "deleteTemplateMessage": "prompts/{{slug}}.md を完全に削除します。"
    }
  },
  "appSwitcher": {
    "more": "その他のアプリ"
  },
  "grokBuild": {
    "apiBackend": "API Backend",
    "contextWindow": "コンテキストウィンドウ",
    "contextWindowInvalid": "コンテキストウィンドウは正の整数で指定してください",
    "profile": "クライアントモデルプロファイル",
    "rawConfig": "config.toml",
    "invalidToml": "config.toml の形式が不正です: {{error}}",
    "defaultModelPlaceholder": "例: grok-4.5",
    "defaultModelHint": "Grok Build がデフォルトでリクエストするモデルです。プリセットの更新を待たずにいつでも変更できます。",
    "advancedSectionHint": "上流フォーマット、思考機能、カスタム User-Agent の設定を含みます。Chat Completions / Anthropic Messages プロトコルを使用するプロバイダーはルーティング引き継ぎの有効化が必要です。",
    "reasoningEffortHint": "上流が low/high/max などの思考の深さの制御に対応している場合に有効化します。有効にすると思考モードも自動的にオンになり、リクエストの reasoning effort を上流の Chat パラメータに変換します。",
    "maxOutputTokensHint": "デフォルト上限 8192 では長い回答や深い思考時に切り詰められることがあります（stop_reason=max_tokens）。この値は Anthropic 経路で max_tokens を上書きします。モデル／ゲートウェイの実際の出力上限を超えると 400 になる場合があります。空欄でデフォルトの 8192 を使用します。"
  },
  "sessionManager": {
    "title": "セッション管理",
    "subtitle": "Claude Code / Codex / Gemini CLI / Grok Build / OpenCode / OpenClaw / Hermes / Pi のセッションを管理",
    "searchPlaceholder": "内容・ディレクトリ・ID で検索",
    "searchSessions": "セッションを検索",
    "providerFilterAll": "すべて",
    "providerFilterTooltip": "プロバイダーフィルター",
    "sessionList": "セッション一覧",
    "viewModeTooltip": "表示方式",
    "viewModeFlat": "一覧",
    "viewModeGrouped": "分類",
    "unknownDirectory": "不明なディレクトリ",
    "toggleProviderGroup": "{{provider}} プロバイダーグループを開閉",
    "toggleDirectoryGroup": "{{directory}} ディレクトリグループを開閉",
    "collapseAllGroups": "すべて折りたたむ",
    "selectProviderGroupForBatch": "{{provider}} プロバイダーグループ内のセッションを選択",
    "selectDirectoryGroupForBatch": "{{directory}} ディレクトリグループ内のセッションを選択",
    "manageBatchTooltip": "一括管理に入る",
    "exitBatchModeTooltip": "一括管理を終了",
    "batchModeHint": "削除するセッションを選択",
    "selectForBatch": "セッションを選択",
    "selectedCount": "{{count}} 件を選択中",
    "selectAllFiltered": "一覧を全選択",
    "clearFilteredSelection": "全選択を解除",
    "clearSelection": "クリア",
    "deleteSelected": "削除",
    "batchDeleting": "削除中...",
    "loadingSessions": "セッションを読み込み中...",
    "noSessions": "セッションが見つかりません",
    "piRelativeSessionDir": "Pi の sessionDir は Pi を起動したディレクトリからの相対パスであるため、グローバルブラウザーから安全に列挙できません。すべての Pi セッションをここで表示するには、sessionDir に絶対パスを設定してください:",
    "piDiscoveryUnavailable": "Pi セッションを検査できませんでした: {{error}}",
    "selectSession": "セッションを選択してください",
    "noSummary": "概要なし",
    "lastActive": "最終アクティブ",
    "projectDir": "プロジェクトディレクトリ",
    "sourcePath": "元ファイル",
    "copyResumeCommand": "再開コマンドをコピー",
    "resumeCommandCopied": "再開コマンドをコピーしました",
    "openInTerminal": "ターミナルで再開",
    "terminalTargetTerminal": "Terminal",
    "terminalTargetKitty": "kitty",
    "terminalTargetCopy": "コピーのみ",
    "terminalLaunched": "ターミナルを起動しました",
    "openFailed": "ターミナルの起動に失敗しました",
    "resumeFallbackCopied": "再開コマンドをコピーしました（手動で実行してください）",
    "copyProjectDir": "ディレクトリをコピー",
    "projectDirCopied": "ディレクトリをコピーしました",
    "copySourcePath": "元ファイルをコピー",
    "sourcePathCopied": "元ファイルをコピーしました",
    "delete": "セッションを削除",
    "deleting": "削除中...",
    "deleteTooltip": "このローカルセッション記録を完全に削除します",
    "deleteConfirmTitle": "セッションを削除",
    "deleteConfirmMessage": "ローカルセッション「{{title}}」を完全に削除します\nSession ID: {{sessionId}}\n\nこの操作は元に戻せません。",
    "deleteConfirmAction": "セッションを削除",
    "sessionDeleted": "セッションを削除しました",
    "deleteFailed": "セッションの削除に失敗しました: {{error}}",
    "batchDeleteConfirmTitle": "選択したセッションを削除",
    "batchDeleteConfirmMessage": "選択した {{count}} 件のローカルセッションを完全に削除します。\n\nこの操作は元に戻せません。",
    "batchDeleteConfirmAction": "選択した項目を削除",
    "batchDeleteSuccess": "{{count}} 件のセッションを削除しました",
    "batchDeleteFailed": "{{failed}} 件のセッションを削除できませんでした",
    "batchDeleteRequestFailed": "一括削除に失敗しました。しばらくしてから再試行してください。",
    "loadingMessages": "内容を読み込み中...",
    "emptySession": "表示できる内容がありません",
    "clickToCopyPath": "クリックしてパスをコピー",
    "tocTitle": "目次",
    "justNow": "たった今",
    "minutesAgo": "{{count}}分前",
    "hoursAgo": "{{count}}時間前",
    "daysAgo": "{{count}}日前",
    "roleUser": "ユーザー",
    "roleSystem": "システム",
    "roleTool": "ツール",
    "resume": "セッションを再開",
    "resumeTooltip": "ターミナルでこのセッションを再開",
    "noResumeCommand": "このセッションは再開できません",
    "copyCommand": "コマンドをコピー",
    "copyMessage": "メッセージをコピー",
    "messageCopied": "メッセージがコピーされました",
    "conversationHistory": "会話履歴",
    "expandContent": "全文を表示",
    "collapseContent": "折りたたむ"
  },
  "console": {
    "providerSwitchReceived": "プロバイダー切り替えイベントを受信:",
    "setupListenerFailed": "プロバイダー切り替えリスナーの設定に失敗:",
    "updateProviderFailed": "プロバイダー更新に失敗:",
    "autoImportFailed": "デフォルト設定の自動インポートに失敗:",
    "openLinkFailed": "リンクを開けませんでした:",
    "getVersionFailed": "バージョン情報の取得に失敗:",
    "loadSettingsFailed": "設定の読み込みに失敗:",
    "getConfigPathFailed": "設定パスの取得に失敗:",
    "getConfigDirFailed": "設定ディレクトリの取得に失敗:",
    "detectPortableFailed": "ポータブルモードの検出に失敗:",
    "saveSettingsFailed": "設定の保存に失敗:",
    "updateFailed": "更新に失敗:",
    "checkUpdateFailed": "更新確認に失敗:",
    "openConfigFolderFailed": "設定フォルダを開けませんでした:",
    "selectConfigDirFailed": "設定ディレクトリの選択に失敗:",
    "getDefaultConfigDirFailed": "デフォルト設定ディレクトリの取得に失敗:",
    "openReleaseNotesFailed": "リリースノートを開けませんでした:"
  },
  "providerForm": {
    "supplierName": "プロバイダー名",
    "supplierNameRequired": "プロバイダー名 *",
    "supplierNamePlaceholder": "例: Anthropic Official",
    "websiteUrl": "Web サイト URL",
    "websiteUrlPlaceholder": "https://example.com（任意）",
    "apiEndpoint": "API エンドポイント",
    "apiEndpointPlaceholder": "https://your-api-endpoint.com",
    "codexApiEndpointPlaceholder": "https://your-api-endpoint.com/v1",
    "manageAndTest": "管理・テスト",
    "configContent": "設定内容",
    "officialNoApiKey": "公式ログインは API Key 不要です。そのまま保存できます",
    "codexOfficialNoApiKey": "公式は API Key 不要です。そのまま保存してください",
    "codexApiKeyAutoFill": "ここに入力すれば auth.json も自動で埋まります",
    "apiKeyAutoFill": "ここに入力すれば下の設定も自動で埋まります",
    "cnOfficialApiKeyHint": "💡 API Key のみ入力すれば OK。エンドポイントはプリセット済みです",
    "aggregatorApiKeyHint": "💡 API Key のみ入力すれば OK。エンドポイントはプリセット済みです",
    "thirdPartyApiKeyHint": "💡 API Key のみ入力すれば OK。エンドポイントはプリセット済みです",
    "customApiKeyHint": "💡 カスタム設定では必要な項目をすべて手動で入力してください",
    "omoHint": "💡 OMO 設定は Agent のモデル割り当てを管理し、oh-my-openagent.jsonc / oh-my-opencode.jsonc の両方に対応します",
    "officialHint": "💡 公式プロバイダーはブラウザログインで、API Key は不要です",
    "providerKeyStatusLoading": "プロバイダー識別子の状態を読み込んでいます。しばらくしてからもう一度お試しください",
    "getApiKey": "API Key を取得",
    "partnerPromotion": {
      "kimi": "Kimi の新規ユーザーは、初回チャージに成功するとチャージ金額の 10%（最大 CNY ¥1,000）が API クレジットとして進呈されます。",
      "a6api": "A6API はトークンアグリゲーションサイトです。リアルタイム価格ランキングを内蔵し、全ネット最安値を自動で選択。動作は滑らかで安定し、面倒な価格比較も不要。登録するだけで体験クレジットがもらえます！",
      "sudocode": "SudoCode の1つのキーで、Claude Code と Claude Desktop では Claude Opus 5、Codex では GPT-5.6 を利用できます。登録後 QQ グループ 726213516 に参加し、管理者へ連絡すると CNY ¥10 のトライアルクレジットを受け取れます。",
      "code0": "code0.ai は開発者向けの AI コーディングサービスプラットフォームで、Claude Code、Codex、Gemini に対応。CC Switch ユーザー限定特典：公式サイトからサポートに連絡してテストクレジットを受け取れます！",
      "packycode": "PackyCode は CC Switch の公式パートナーです。登録後チャージ時に \"cc-switch\" を入力すると 10% オフ",
      "apikeyfun": "APIKEY.FUN は CC Switch ユーザー向けに特別優待を提供しています。専用リンクから登録すると、最大でチャージ永久 5% オフを受けられます。",
      "apinebula": "APINEBULA は CC Switch ユーザー向けに特別割引を提供しています。専用リンクから登録し、チャージ時にプロモコード「ccswitch」を入力すると、さらに 10% OFF の割引が適用されます。",
      "patewayai": "PatewayAI は CC Switch ユーザーに特別な特典を提供しています。このリンクから登録すると $3 のクレジットがもらえます。",
      "claudeapi": "ClaudeAPI は CC Switch ユーザーに特別な特典を提供しています。このリンクから登録するとテストクレジットを受け取ることができます。",
      "claudecn": "ClaudeCN は登録企業が運営するエンタープライズグレードの AI ゲートウェイプラットフォームで、企業調達プロセスをサポートし、法人支払い、契約、コンプライアンス保証を提供します。",
      "runapi": "RunAPI は CC Switch ユーザーに特別な特典を提供しています。このリンクから登録すると、初回チャージが 10% オフになります。",
      "opencode_go": "OpenCode Go は、複数のコーディングモデルを利用できるサブスクリプションサービスです。このリンクからプランの詳細確認と申し込みができます。",
      "dmxapi": "Claude Code 専用モデル 66% OFF 実施中！",
      "cubence": "Cubence は CC Switch の公式パートナーです。登録後チャージ時に \"CCSWITCH\" を入力すると、毎回 10% オフ",
      "aigocode": "AIGoCode は CC Switch の公式パートナーです。このリンクから登録すると、初回チャージ時に 10% のボーナスクレジットがもらえます！",
      "rightcode": "RightCode は CC Switch の公式パートナーです。このリンクから登録すると、毎回のチャージに 5% のボーナスクレジットがもらえます！",
      "aicodemirror": "AICodeMirror は CC Switch の公式パートナーです。このリンクから登録すると20%オフ！",
      "aicoding": "AI Coding は CC Switch ユーザー向けに特別割引を提供しています。初回チャージが 10% オフ！",
      "crazyrouter": "CrazyRouter は CC Switch ユーザー向けに特別ボーナスを提供しています。初回チャージで 30% の追加クレジットがもらえます！",
      "sssaicode": "SSAI Code は CC Switch ユーザー向けに特別ボーナスを提供しています。チャージごとに $10 の追加クレジットがもらえます！",
      "siliconflow": "SiliconFlow は CC Switch の公式パートナーです",
      "ucloud": "Compshare は CC Switch ユーザー向けに特別ボーナスを提供しています。このリンクから登録すると、5元のプラットフォーム体験クレジットがもらえます！",
      "micu": "Micu は CC Switch の公式パートナーです",
      "etok": "公式サイトで ETok コミュニティに参加し、プランを購読してください。",
      "shengsuanyun": "胜算云はCC Switchユーザーに特別特典を提供しています。このリンクから登録すると、10元分の無料クレジットと初回チャージ10%ボーナスがもらえます！",
      "doubaoseed": "豆包大モデルは CC Switch ユーザーに専属特典を提供しています：このリンクから登録すると、豆包全テキストモデル50万トークンの推論クレジットおよびSeedance2.0の500万トークン無料クレジットがもらえます。",
      "volcengine_agentplan": "火山方舟 Agent Plan は CC Switch ユーザーに専属特典を提供しています：このリンクから方舟 Agent Plan を購読すると、新規のお客様は最初の 2 か月が 75% オフ、さらに専用招待コード 6J6FV5N2 で 5% オフが加算され、月額 9.4 元から！",
      "volcengine_codingplan": "火山方舟 Coding Plan は CC Switch ユーザーに専属特典を提供しています：このリンクから方舟 Coding Plan を購読すると、新規のお客様は最初の 2 か月が 75% オフ、さらに専用招待コード 6J6FV5N2 で 5% オフが加算され、月額 9.4 元から！",
      "byteplus": "このリンクから登録すると、各モデルごとに50万トークンの無料推論クォータがもらえます。",
      "ccsub": "CCSub は安定・低価格の AI API リレーサービスです。Claude Code の公式サブスクリプションの代替として、1つのキーで全モデルを公式比約1/3のコストで利用できます。",
      "subrouter": "SubRouter は、1つのキーで複数のモデルとプロバイダーにアクセスできる AI 中継アグリゲーターです。",
      "qiniu": "Qiniu Cloud（七牛云）はマルチプロトコル対応の AI 中継プラットフォームです。1つのキーでネイティブの Claude・GPT・Gemini モデルを利用でき、Anthropic／OpenAI／Gemini の各 API に対応します。",
      "fenno": "Fenno.ai は安定・高効率な API 中継サービスで、幅広い主要モデルを利用できます。CC Switch 利用者限定特典：このリンクから 1.99 ドルで 50 ドル相当の Trial プランを購入できます（有効期間 7 日間）！",
      "zetaapi": "ZetaAPI はモデルを水増し・劣化させず、公式価格の 35% から利用できます。CC Switch 利用者限定特典：このリンクから登録し、初回チャージ時にプロモコード CC-SWITCH を使うと初回チャージ 10% オフ！",
      "teamorouter": "TeamoRouter はエンタープライズグレードの Agentic LLM ゲートウェイで、料金は最大 90% オフ。CC Switch ユーザーに特別特典を提供しています：このリンクから新規登録すると初回チャージが 10% オフ！",
      "ppio": "PPIO は中国有数の独立系 Agentic Cloud プロバイダーで、API キー 1 つで主要なオープンソースモデルをすべて利用できます。このリンクから登録し実名認証を完了すると、¥10 のクーポンがもらえます。",
      "xycai": "XycAi はエンタープライズグレードのトークンファクトリー：200+ のグローバルモデルにワンクリック接続、SLA 自動補償、異常キャッシュは 100% 返金！",
      "9527code": "9527 CODE はエンタープライズ級のフルスペック AI 中継プラットフォームで、Claude Code や Codex などの主要モデルに高速・安定した中継サービスを提供します。1 年間の継続運営、サービス安定性 99.9%、7×24 時間の有人技術サポート。新規ユーザーはサポートへのご連絡で体験クレジットを進呈、紹介キャッシュバックは上限なし！",
      "soleapi": "SoleAPI は開発者と企業向けの AI モデルゲートウェイ。API キー 1 つで Claude・GPT・Gemini など 30 以上の主要モデルを利用でき、OpenAI / Anthropic プロトコルにネイティブ対応。リアルタイムのスマートルーティングとミリ秒単位の自動切替で可用性 99.99%、24 時間 365 日サポート。専用リンクから登録すると無料のお試しクレジット、友人招待で継続的なキャッシュバック！",
      "fluxa": "FluxA と Baidu AI Cloud が共同で提供する AgenticPlan は、AI エージェントがモデル・API・ツールを自ら購入し、管理し、利用できるようにします。百度千帆 TokenPlan を最大 40% オフで含み、DeepSeek V4・GLM 5.2・Kimi などの主力モデルを利用可能。さらに FluxA AgentMarket の API クレジットが付き、検索・データ取得・ソーシャルメディア・金融・暗号資産・画像生成・動画など 1,000 以上の有料 API を利用できます。"
    },
    "presets": {
      "ucloud": "Compshare",
      "ucloudCoding": "Compshare Coding Plan",
      "shengsuanyun": "Shengsuanyun",
      "qiniu": "Qiniu",
      "doubaoseed": "Volcengine Doubao",
      "openrouter": "OpenRouter",
      "deepseek": "DeepSeek",
      "together": "Together AI"
    },
    "parameterConfig": "パラメーター設定 - {{name}} *",
    "mainModel": "メインモデル（任意）",
    "mainModelPlaceholder": "例: GLM-4.6",
    "fastModel": "高速モデル（任意）",
    "fastModelPlaceholder": "例: GLM-4.5-Air",
    "modelHint": "💡 空欄ならプロバイダーのデフォルトモデルを使用します",
    "apiHint": "💡 Claude API 互換サービスのエンドポイントを入力してください。末尾にスラッシュを付けないでください",
    "apiHintOAI": "💡 OpenAI Chat Completions 互換サービスのエンドポイントを入力してください。末尾にスラッシュを付けないでください",
    "apiHintGeminiNative": "💡 Gemini Native では https://generativelanguage.googleapis.com または https://generativelanguage.googleapis.com/v1beta のような base URL を推奨します。プロキシが models/*:generateContent を自動補完します",
    "codexApiHint": "💡 OpenAI Response 互換のサービスエンドポイントを入力してください",
    "fillSupplierName": "プロバイダー名を入力してください",
    "fillConfigContent": "設定内容を入力してください",
    "fillParameter": "{{label}} を入力してください",
    "fillTemplateValue": "{{label}} を入力してください",
    "endpointRequired": "公式以外は API エンドポイントが必須です",
    "apiKeyRequired": "公式以外は API Key が必須です",
    "softValidation": {
      "title": "設定に以下の問題があります",
      "hint": "それでも保存しますか？保存後、このプロバイダーへの切り替えが失敗する可能性がありますが、後から補完できます。",
      "saveAnyway": "それでも保存"
    },
    "configJsonError": "Config JSON の形式が正しくありません。構文を確認してください",
    "authJsonRequired": "auth.json は JSON オブジェクトで入力してください",
    "authJsonError": "auth.json の形式が正しくありません。JSON を確認してください",
    "fillAuthJson": "auth.json の設定を入力してください",
    "fillApiKey": "OPENAI_API_KEY を入力してください",
    "visitWebsite": "{{url}} を開く",
    "anthropicModel": "メインモデル",
    "anthropicSmallFastModel": "高速モデル",
    "apiFormat": "上流フォーマット",
    "apiFormatHint": "プロバイダーがネイティブ Anthropic Messages API なら Anthropic Messages を選択（直結、フォーマット変換なし）。Chat Completions プロトコルなら Chat、Responses API なら Responses、Gemini generateContent プロトコルなら Gemini Native を選択。Chat、Responses、Gemini Native は Anthropic Messages への変換にルーティング引き継ぎの有効化が必要です。",
    "customUserAgent": "カスタム User-Agent",
    "customUserAgentHint": "ローカルルーティング/プロキシ引き継ぎが有効な場合にのみ適用され、プロバイダー API へ転送するリクエストの User-Agent を置き換えます。",
    "customUserAgentInvalid": "User-Agent に制御文字（改行など）を含めることはできません。含まれている場合は無視されます。",
    "customUserAgentPresets": "プリセット",
    "localProxyRequestOverrides": "ローカルプロキシのリクエスト上書き",
    "localProxyRequestOverridesHint": "ローカルルーティング/プロキシ引き継ぎ後にのみ有効で、変換後の上流リクエストへ適用されます。",
    "localProxyRequestOverridesInvalid": "ローカルプロキシのリクエスト上書き形式エラー: {{error}}",
    "localProxyHeaderOverrides": "Header 上書き",
    "localProxyHeaderOverridesInvalidDetail": "Header 上書きの形式エラー: {{error}}",
    "localProxyBodyOverrides": "Body 上書き",
    "localProxyBodyOverridesInvalidDetail": "Body 上書きの形式エラー: {{error}}",
    "fullUrlLabel": "フル URL",
    "fullUrlEnabled": "フル URL モード",
    "fullUrlDisabled": "フル URL として設定",
    "fullUrlHint": "💡 完全なリクエスト URL を入力してください。このモードはルーティングを有効にして使用する必要があり、ルーティングはこの URL をそのまま使用し、パスを追加しません",
    "fullUrlHintGeminiNative": "💡 Gemini Native のフル URL モードでは 2 種類の入力を扱えます。1. 公式/構造化された Gemini URL は、要求されたモデルやストリーミング方式に合わせて正規化されます。2. カスタム relay の opaque な完全 URL は、主にそのまま使用され、必要なクエリだけ追加されます",
    "apiFormatAnthropic": "Anthropic Messages（ネイティブ）",
    "apiFormatOpenAIChat": "OpenAI Chat Completions（ルーティングが必要）",
    "apiFormatOpenAIResponses": "OpenAI Responses API（ルーティングが必要）",
    "apiFormatGeminiNative": "Gemini Native generateContent（ルーティングが必要）",
    "codexApiFormatResponses": "OpenAI Responses API（ネイティブ）",
    "codexApiFormatOpenAIChat": "OpenAI Chat Completions（ルーティングが必要）",
    "codexApiFormatHint": "このプロバイダーが実際に対応している Codex API フォーマットを選択します。新しい Codex との互換性のため設定は Responses のままにし、Chat Completions はローカルルーティングで変換します。",
    "authField": "認証フィールド",
    "authFieldAuthToken": "ANTHROPIC_AUTH_TOKEN（デフォルト）",
    "authFieldApiKey": "ANTHROPIC_API_KEY",
    "authFieldHint": "設定に書き込む認証環境変数名を選択",
    "apiHintResponses": "💡 OpenAI Responses API 互換サービスのエンドポイントを入力してください。末尾にスラッシュを付けないでください",
    "anthropicDefaultHaikuModel": "既定 Haiku モデル",
    "anthropicDefaultSonnetModel": "既定 Sonnet モデル",
    "anthropicDefaultOpusModel": "既定 Opus モデル",
    "modelPlaceholder": "",
    "smallModelPlaceholder": "",
    "haikuModelPlaceholder": "",
    "modelHelper": "任意: 既定で使いたい Claude モデルを指定。空欄ならシステム既定を使用します。",
    "modelMappingLabel": "モデルマッピング",
    "modelMappingHint": "表示名は /model メニューだけに影響します。1M は Claude Code へのコンテキスト能力宣言です。",
    "modelRoleLabel": "モデル役割",
    "modelRoleSonnet": "Sonnet",
    "modelRoleOpus": "Opus",
    "modelRoleFable": "Fable",
    "modelRoleHaiku": "Haiku",
    "modelRoleSubagent": "Subagent",
    "modelDisplayNameLabel": "表示名",
    "modelDisplayNamePlaceholder": "例: DeepSeek V4 Pro",
    "modelNoDisplayName": "/model には表示されません",
    "requestModelLabel": "リクエストモデル",
    "modelOneMHeader": "1M 対応を宣言",
    "modelOneMLabel": "1M",
    "fallbackModelLabel": "既定フォールバックモデル",
    "fallbackModelHint": "Sonnet・Opus・Fable・Haiku のいずれにも明確に対応しないリクエストのフォールバックです。サードパーティ/中継エンドポイントでは設定を推奨します。設定しないと、これらのリクエスト（Haiku のバックグラウンドサブタスクを含む）が元の Claude モデル名のまま上流へ転送され、上流に該当モデルが無い場合は失敗することがあります。公式エンドポイントでは空欄で構いません。",
    "quickSetModels": "一括設定",
    "quickSetSuccess": "モデル名をすべての役割に適用しました",
    "advancedOptionsToggle": "高級オプション",
    "advancedOptionsHint": "API フォーマット、認証フィールド、モデルマッピングの設定を含みます。通常はデフォルトのままで問題ありません。",
    "categoryOfficial": "公式",
    "categoryCnOfficial": "オープンソース公式",
    "categoryAggregation": "アグリゲーター",
    "categoryThirdParty": "サードパーティ",
    "fetchModels": "モデル一覧を取得",
    "fetchingModels": "取得中...",
    "searchModelPlaceholder": "モデルを検索...",
    "searchModelEmpty": "一致するモデルがありません",
    "searchModelAriaLabel": "モデルを選択",
    "fetchModelsSuccess": "{{count}}件のモデルを取得",
    "fetchedModelsTitle": "利用可能なモデル（{{count}}件）",
    "modelAlreadyAdded": "追加済み",
    "addSelectedModels": "選択したモデルを追加（{{count}}件）",
    "fetchModelsFailed": "モデル一覧の取得に失敗しました",
    "fetchModelsEmpty": "モデルが見つかりません",
    "fetchModelsNeedApiKey": "先に API Key を入力してください",
    "fetchModelsNeedEndpoint": "先に API エンドポイントを入力してください",
    "fetchModelsNeedConfig": "先に API エンドポイントと API Key を入力してください",
    "fetchModelsAuthFailed": "API Key が無効か、権限がありません",
    "fetchModelsNotSupported": "このプロバイダーはモデル一覧の取得に対応していません",
    "fetchModelsEndpointNotFound": "利用可能なモデル一覧エンドポイントが見つかりません。Base URL を確認するか、プロバイダーが該当 API を公開しているかご確認ください",
    "fetchModelsTimeout": "リクエストがタイムアウトしました。ネットワーク接続を確認してください",
    "requiredFields": "プロバイダー名、API エンドポイント、API Key、モデルを入力してください"
  },
  "copilot": {
    "authSection": "GitHub Copilot 認証",
    "authStatus": "認証状態",
    "authenticated": "認証済み: {{username}}",
    "notAuthenticated": "未認証",
    "loginWithGitHub": "GitHub でログイン",
    "githubAccount": "GitHub アカウント",
    "manageAccounts": "アカウント管理",
    "loginRequired": "先に GitHub Copilot にログインしてください",
    "statusLoading": "アカウント状態を読み込み中...",
    "statusUnavailable": "状態を取得できません",
    "statusLoadFailed": "GitHub Copilot のアカウント状態を読み込めませんでした。再試行してください。",
    "waitingForAuth": "認証を待っています...",
    "enterCode": "ブラウザで以下のコードを入力してください：",
    "logout": "ログアウト",
    "authSuccess": "GitHub Copilot 認証に成功しました",
    "authFailed": "認証に失敗しました: {{error}}",
    "authTimeout": "認証がタイムアウトしました。もう一度お試しください",
    "tokenExpired": "トークンの有効期限が切れました。再認証してください",
    "accountCount": "{{count}} アカウント",
    "selectAccount": "アカウントを選択",
    "selectAccountPlaceholder": "GitHub アカウントを選択",
    "useDefaultAccount": "デフォルトアカウントを使用",
    "loggedInAccounts": "ログイン済みアカウント",
    "defaultAccount": "デフォルト",
    "selected": "選択中",
    "removeAccount": "アカウントを削除",
    "setAsDefault": "デフォルトに設定",
    "addAnotherAccount": "別のアカウントを追加",
    "logoutAll": "すべてのアカウントをログアウト",
    "retry": "再試行",
    "copyCode": "コードをコピー",
    "migrationFailed": "旧認証データの移行に失敗しました: {{error}}",
    "loadModelsFailed": "Copilot モデル一覧の読み込みに失敗しました",
    "deploymentType": "GitHub デプロイメントタイプ",
    "deploymentGitHubCom": "GitHub.com",
    "deploymentEnterprise": "GitHub Enterprise Server",
    "enterpriseDomainPlaceholder": "例: company.ghe.com"
  },
  "codexOauth": {
    "authStatus": "認証状態",
    "notAuthenticated": "未認証",
    "loginWithChatGPT": "ChatGPT でログイン",
    "loginRequired": "先に ChatGPT にログインしてください",
    "statusLoading": "アカウント状態を読み込み中...",
    "statusUnavailable": "状態を取得できません",
    "statusLoadFailed": "ChatGPT のアカウント状態を読み込めませんでした。再試行してください。",
    "waitingForAuth": "認証を待機中...",
    "enterCode": "ブラウザで以下のコードを入力してください：",
    "accountCount": "{{count}} アカウント",
    "selectAccount": "アカウントを選択",
    "chatgptAccount": "ChatGPT アカウント",
    "accountToUse": "使用するアカウント",
    "signInMethod": "ログイン方法",
    "manageAccounts": "アカウント管理",
    "selectAccountPlaceholder": "ChatGPT アカウントを選択",
    "officialAccountPlaceholder": "ログイン方法を選択",
    "addOrManageAccounts": "ChatGPT アカウントを追加または管理…",
    "explicitSelectionRequired": "ログイン方法を選択してください",
    "useDefaultAccount": "デフォルトアカウントを使用",
    "noneOptionLabel": "Codex のログインに追従",
    "reauthTitle": "再ログインが必要なアカウントがあります",
    "reauthDescription": "ブラウザログインと同じ挙動にするため、これらのアカウントは再ログインして必要な認証情報（id_token）を補完する必要があります。再ログイン後は管理アカウントのバインドに利用できます。",
    "reauthBadge": "再ログインが必要",
    "reauthLogin": "再ログイン",
    "reauthSelectHint": "このアカウントは管理バインドを有効にするため再ログインが必要です。",
    "reauthNow": "今すぐ再ログイン",
    "duplicateAccount": "この ChatGPT アカウントは追加済みです。既存のアカウントを使用してください。",
    "loggedInAccounts": "ログイン済みアカウント",
    "defaultAccount": "デフォルト",
    "selected": "選択中",
    "removeAccount": "アカウントを削除",
    "setAsDefault": "デフォルトに設定",
    "addAnotherAccount": "別のアカウントを追加",
    "logoutAll": "すべてのアカウントをログアウト",
    "retry": "再試行",
    "copyCode": "コードをコピー",
    "fastMode": "FAST モード",
    "fastModeDescription": "低遅延のため service_tier=\"priority\" を送信します。既定ではオフ——オンにすると ChatGPT のクォータがより速く消費されます。"
  },
  "xaiOauth": {
    "authStatus": "xAI OAuth 認証",
    "accountCount": "利用可能なアカウント: {{count}} 件",
    "reauthRequired": "再ログインが必要です",
    "notAuthenticated": "未認証",
    "selectAccount": "アカウントを選択",
    "selectAccountPlaceholder": "xAI アカウントを選択",
    "useDefaultAccount": "デフォルトアカウントを使用",
    "accounts": "xAI アカウント",
    "defaultAccount": "デフォルト",
    "expired": "認証情報が失効しました",
    "setAsDefault": "デフォルトに設定",
    "removeAccount": "アカウントを削除",
    "addOrReauth": "アカウントを追加または再ログイン",
    "login": "xAI でログイン",
    "waitingForAuth": "xAI の認証を待っています…",
    "enterCode": "ブラウザに自動入力されていない場合は、次を入力してください：",
    "retry": "再試行",
    "logoutAll": "すべての xAI アカウントを削除",
    "loginRequired": "先に xAI アカウントへログインしてください"
  },
  "managedAuth": {
    "accountRemoved": "アカウントを削除しました",
    "selectedAccountNeedsReauth": "リンクされたアカウントが存在しないか、再ログインが必要です",
    "selectedAccountUnavailable": "リンクされたアカウントが存在しないか、再ログインが必要です。別のアカウントを選択してください"
  },
  "endpointTest": {
    "title": "API エンドポイント管理",
    "endpoints": "エンドポイント",
    "autoSelect": "自動選択",
    "testSpeed": "テスト",
    "testing": "テスト中",
    "addEndpointPlaceholder": "https://api.example.com",
    "done": "完了",
    "noEndpoints": "エンドポイントがありません",
    "failed": "失敗",
    "enterValidUrl": "有効な URL を入力してください",
    "invalidUrlFormat": "URL 形式が正しくありません",
    "onlyHttps": "HTTP/HTTPS のみサポートします",
    "urlExists": "この URL はすでに存在します",
    "saveFailed": "保存に失敗しました。もう一度お試しください",
    "loadEndpointsFailed": "カスタムエンドポイントの読み込みに失敗:",
    "addEndpointFailed": "カスタムエンドポイントの追加に失敗:",
    "removeEndpointFailed": "カスタムエンドポイントの削除に失敗:",
    "removeFailed": "削除に失敗しました: {{error}}",
    "updateLastUsedFailed": "エンドポイントの最終使用時間の更新に失敗しました",
    "pleaseAddEndpoint": "まずエンドポイントを追加してください",
    "testUnavailable": "速度テストを実行できません",
    "noResult": "結果がありません",
    "testFailed": "速度テストに失敗しました: {{error}}",
    "empty": "エンドポイントがありません"
  },
  "providerAdvanced": {
    "pricingConfig": "課金設定",
    "useCustomPricing": "個別設定を使用",
    "pricingConfigDesc": "このプロバイダーに個別の課金パラメータを設定します。無効の場合はグローバル設定を使用します。",
    "costMultiplier": "コスト倍率",
    "costMultiplierPlaceholder": "空白の場合はグローバル設定を使用（1）",
    "costMultiplierHint": "実際のコスト = 基本コスト × 倍率、1.5 などの小数をサポート",
    "pricingModelSourceLabel": "課金モード",
    "pricingModelSourceInherit": "グローバル設定を継承",
    "pricingModelSourceRequest": "リクエストモデル",
    "pricingModelSourceResponse": "レスポンスモデル",
    "pricingModelSourceHint": "リクエストモデルまたはレスポンスモデルで価格を照合するかを選択"
  },
  "codexConfig": {
    "authJson": "auth.json (JSON) *",
    "authJsonPlaceholder": "{\n  \"OPENAI_API_KEY\": \"sk-your-api-key-here\"\n}",
    "authJsonHint": "Codex の auth.json 設定内容",
    "authJsonStorageHint": "プロキシ引き継ぎ中は保存済みの auth を表示しており、実際の auth.json ではありません。",
    "configToml": "config.toml (TOML)",
    "configTomlHint": "Codex の config.toml 設定内容",
    "configTomlStorageHint": "プロキシ引き継ぎ中は保存済みの config を表示しており、実際の config.toml ではありません。",
    "proxyTakeoverStorageNotice": "💡 このアプリはプロキシ引き継ぎ中です。ここで編集しているのは保存済みのプロバイダー設定で、実際の live 設定はすでにプロキシが一時的に引き継いでいます。",
    "writeCommonConfig": "共通設定を適用",
    "editCommonConfig": "共通設定を編集",
    "editCommonConfigTitle": "Codex 共通設定スニペットを編集",
    "commonConfigHint": "「共通設定を適用」がオンの場合、config.toml の末尾に追記されます",
    "enableRemoteCompaction": "リモート圧縮を有効化",
    "remoteCompactionHint": "有効にすると、現在の model_providers エントリの name を OpenAI に設定し、Codex がリモート圧縮を試行できるようにします。",
    "apiUrlLabel": "API リクエスト URL",
    "extractFromCurrent": "編集内容から抽出",
    "extractNoCommonConfig": "編集内容から抽出できる共通設定がありません",
    "extractFailed": "抽出に失敗しました: {{error}}",
    "saveFailed": "保存に失敗しました: {{error}}",
    "modelNameHint": "使用するモデルを指定します。config.toml に自動更新されます",
    "modelName": "モデル名",
    "upstreamFormatLabel": "上流フォーマット",
    "upstreamFormatHint": "プロバイダーがネイティブ Responses API なら Responses を選択（直結、フォーマット変換なし）。Chat Completions プロトコルなら Chat を選択。ネイティブ Anthropic Messages プロトコルのみ提供する場合は Anthropic Messages を選択。Chat と Anthropic Messages はどちらも Responses への変換にルーティング引き継ぎの有効化が必要です。",
    "upstreamFormatChat": "Chat Completions（ルーティング必須）",
    "upstreamFormatResponses": "Responses（ネイティブ）",
    "upstreamFormatAnthropic": "Anthropic Messages（ルーティング必須）",
    "anthropicAuthFieldLabel": "認証フィールド",
    "anthropicAuthFieldAuthToken": "ANTHROPIC_AUTH_TOKEN（Authorization）",
    "anthropicAuthFieldApiKey": "ANTHROPIC_API_KEY（x-api-key）",
    "anthropicAuthFieldHint": "ゲートウェイに API キーを渡すヘッダーを選択します。ANTHROPIC_AUTH_TOKEN は Authorization: Bearer、ANTHROPIC_API_KEY は x-api-key を送信します。送信されるのはどちらか一方のみです。",
    "impersonateClaudeCodeLabel": "Claude Code クライアントを模倣",
    "impersonateClaudeCodeHint": "ゲートウェイ（またはその上流）が Claude Code のみに制限している場合に有効化します。User-Agent・anthropic-beta・x-app ヘッダーを偽装し、システムプロンプトの先頭行に Claude Code のアイデンティティを注入します。",
    "maxOutputTokensLabel": "最大出力トークン",
    "maxOutputTokensPlaceholder": "空欄の場合はデフォルトの 8192 を使用",
    "maxOutputTokensHint": "Codex は model_max_output_tokens をリクエストボディに含めないため、デフォルト上限 8192 では長い回答や深い思考時に切り詰められることがあります（stop_reason=max_tokens）。この値は Anthropic 経路で max_tokens を上書きします。モデル／ゲートウェイの実際の出力上限を超えると 400 になる場合があります。空欄でデフォルトの 8192 を使用します。",
    "promptCacheRoutingLabel": "プロンプトキャッシュルーティング",
    "promptCacheRoutingAuto": "自動（推奨）",
    "promptCacheRoutingEnabled": "有効",
    "promptCacheRoutingDisabled": "無効",
    "promptCacheRoutingHint": "自動モードでは、互換性を確認済みの上流にのみ prompt_cache_key を送信します。他の互換ゲートウェイでは有効にし、未知のフィールドを 400 で拒否する厳格なゲートウェイでは無効にしてください。クライアントが提供した安定したセッション ID のみを使用します。",
    "upstreamModelName": "上流モデル名",
    "upstreamModelNameHint": "Chat 形式ではここに実際の上流モデルを入力します。ルーティングで Codex の Responses リクエストを Chat Completions に変換し、このモデルを維持します。",
    "modelNamePlaceholder": "例: gpt-5-codex",
    "contextWindow1M": "1M コンテキストウィンドウ",
    "contextWindow": "コンテキストウィンドウ",
    "contextWindowPlaceholder": "例: 128000",
    "autoCompactLimit": "自動圧縮しきい値",
    "autoCompactLimitPlaceholder": "例: 90000",
    "autoCompactLimitHint": "コンテキストトークン数がこのしきい値に達すると履歴を自動圧縮",
    "modelMetadataAdvanced": "モデルメタデータ詳細オプション",
    "modelMetadataAdvancedHint": "未知のモデル向けに Codex メタデータを上書きします。空にすると対応する config.toml 設定を削除します。",
    "defaultModelLabel": "デフォルトモデル",
    "defaultModelPlaceholder": "例: gpt-5.6-sol",
    "defaultModelHint": "Codex がデフォルトでリクエストするモデルです。プリセットの更新を待たずにいつでも変更できます。空欄のままモデルマッピングを設定している場合は、マッピングの先頭行が使われます。",
    "defaultModelNotInCatalog": "このモデルはモデルマッピングにないため、Codex の /model メニューには表示されません（直接リクエストは有効です）。",
    "addToModelMapping": "マッピングに追加",
    "modelMappingTitle": "モデルマッピング",
    "modelMappingHint": "Codex model_catalog_json を生成し、/model コマンドでこれらの第三者モデル名を表示できるようにします。リストの内容はそのまま保存されます。変更後、モデルリストを更新するには Codex の再起動が必要です。",
    "addCatalogModel": "モデルを追加",
    "catalogDisplayName": "表示名",
    "catalogDisplayNamePlaceholder": "例: DeepSeek V4 Flash",
    "catalogModelId": "モデル ID",
    "catalogModelPlaceholder": "例: deepseek-v4-flash",
    "catalogColumnDisplay": "メニュー表示名",
    "catalogColumnModel": "実際のリクエストモデル",
    "catalogColumnContext": "コンテキストウィンドウ",
    "catalogColumnReasoning": "思考レベル",
    "reasoningLevelsNotSet": "未設定",
    "reasoningLevelsSearch": "思考レベルを検索...",
    "reasoningLevelsEmpty": "レベルなし",
    "defaultReasoningLevelLabel": "デフォルトレベル",
    "defaultReasoningLevelPlaceholder": "自動",
    "reasoningModeToggle": "思考モードに対応",
    "reasoningModeHint": "上流の Chat Completions API が思考（thinking）のオン/オフ切り替えに対応している場合に有効化します。Kimi、GLM、Qwen などが通常このタイプに該当します。",
    "reasoningEffortToggle": "思考レベルに対応",
    "reasoningEffortHint": "上流が low/high/max などの思考の深さの制御に対応している場合に有効化します。有効にすると思考モードも自動的にオンになり、Codex の reasoning.effort を上流の Chat パラメータに変換します。",
    "reasoningGroupTitle": "思考能力",
    "reasoningSectionHint": "プリセットの供給元は自動的に設定され、カスタム供給元は名前/URL から自動推論されます。自動識別が正しくない場合のみ手動で上書きしてください。",
    "advancedSectionHint": "上流フォーマット、モデルマッピング、思考能力、カスタム User-Agent の設定を含みます。Chat Completions プロトコルを使用するプロバイダーはルーティング引き継ぎの有効化が必要です。",
    "noCommonConfigToApply": "共通設定スニペットが空か、書き込む内容がありません"
  },
  "geminiConfig": {
    "envFile": "環境変数 (.env)",
    "envFileHint": ".env 形式で Gemini の環境変数を設定",
    "configJson": "設定ファイル (config.json)",
    "configJsonHint": "Gemini 拡張パラメーターを JSON 形式で設定（任意）",
    "writeCommonConfig": "共通設定を適用",
    "editCommonConfig": "共通設定を編集",
    "editCommonConfigTitle": "Gemini 共通設定スニペットを編集",
    "commonConfigHint": "「共通設定を適用」がオンのとき Gemini の .env に書き込みます（GOOGLE_GEMINI_BASE_URL、GEMINI_API_KEY は使用できません）",
    "extractFromCurrent": "編集内容から抽出",
    "extractNoCommonConfig": "編集内容から抽出できる共通設定がありません",
    "extractFailed": "抽出に失敗しました: {{error}}",
    "saveFailed": "保存に失敗しました: {{error}}",
    "extractedConfigInvalid": "抽出した設定のフォーマットが不正です",
    "invalidJsonFormat": "共通設定スニペットの形式が不正です（有効な JSON でなければなりません）",
    "commonConfigInvalidKeys": "共通設定スニペットに GOOGLE_GEMINI_BASE_URL または GEMINI_API_KEY を含めることはできません（検出: {{keys}}）",
    "commonConfigInvalidValues": "共通設定スニペットの値は文字列である必要があります",
    "noCommonConfigToApply": "共通設定スニペットが空、または適用できる項目がありません",
    "configMergeFailed": "設定のマージに失敗しました: {{error}}",
    "configReplaceFailed": "設定の置換に失敗しました: {{error}}"
  },
  "opencode": {
    "npmPackage": "API フォーマット",
    "selectPackage": "API フォーマットを選択",
    "npmPackageHint": "AI サービスの API フォーマットを選択",
    "baseUrl": "Base URL",
    "baseUrlHint": "カスタム API エンドポイント URL",
    "models": "モデル設定",
    "modelsHint": "利用可能なモデルとその表示名を設定",
    "addModel": "モデルを追加",
    "modelId": "モデル ID",
    "modelName": "表示名",
    "noModels": "モデルが設定されていません",
    "modelsRequired": "モデルを少なくとも1つ追加してください",
    "toggleModelDetails": "モデル詳細を開閉",
    "providerKey": "プロバイダーキー",
    "providerKeyPlaceholder": "my-provider",
    "providerKeyHint": "設定ファイルの一意の識別子です。小文字、数字、ハイフンのみ使用できます。",
    "providerKeyLockedHint": "このプロバイダーは既にアプリ設定へ追加されているため、キーは変更できません。",
    "providerKeyRequired": "プロバイダーキーを入力してください",
    "providerKeyDuplicate": "このキーは既に使用されています",
    "providerKeyInvalid": "無効な形式です。小文字、数字、ハイフンのみ使用できます。",
    "headers": "ヘッダー",
    "headersHint": "HTTP-Referer や X-Title など、プロバイダーリクエストに付与する任意の HTTP ヘッダーです。",
    "addHeader": "ヘッダーを追加",
    "headerName": "ヘッダー",
    "headerValue": "値",
    "headerNamePlaceholder": "X-Title",
    "headerValuePlaceholder": "CC Switch",
    "removeHeader": "ヘッダーを削除",
    "noHeaders": "カスタムヘッダーはありません",
    "extraOptions": "追加オプション",
    "extraOptionsHint": "timeout、setCacheKey などの SDK オプションを設定。値は自動的に適切な型（数値、真偽値など）に変換されます。",
    "addExtraOption": "追加",
    "extraOptionKey": "キー名",
    "extraOptionValue": "値",
    "extraOptionKeyPlaceholder": "timeout",
    "extraOptionValuePlaceholder": "600000",
    "noExtraOptions": "追加オプションはありません",
    "noModelOptions": "モデルオプション、+ をクリックして追加",
    "modelLimits": "トークン制限",
    "limitContext": "コンテキスト",
    "limitOutput": "出力",
    "modelExtraFields": "モデルプロパティ",
    "noModelExtraFields": "モデルプロパティ（variants、cost など）、+ をクリックして追加",
    "modelExtraFieldKeyPlaceholder": "variants",
    "sdkOptions": "SDK オプション",
    "modelOptionKeyPlaceholder": "provider",
    "modelOptionValuePlaceholder": "{\"order\": [\"baseten\"]}"
  },
  "providerPreset": {
    "label": "プロバイダータイプ",
    "custom": "カスタム設定",
    "other": "その他",
    "hint": "プリセットを選んだ後でも、下のフィールドで調整できます。",
    "searchTooltip": "プリセットを検索",
    "searchAriaLabel": "プロバイダープリセットを検索",
    "searchPlaceholder": "名前、サイト、カテゴリで検索...",
    "sortAriaLabel": "プリセットの並び順を切り替え",
    "sortNameAscTooltip": "名前順 A-Z で並び替え",
    "sortOriginalTooltip": "元の順序に戻す",
    "noSearchResults": "一致するプロバイダープリセットがありません。"
  },
  "usage": {
    "title": "利用統計",
    "subtitle": "AI モデルの利用状況とコスト統計を表示",
    "today": "24時間",
    "last7days": "7日間",
    "last30days": "30日間",
    "presetToday": "当日",
    "preset1d": "1d",
    "preset7d": "7d",
    "preset14d": "14d",
    "preset30d": "30d",
    "totalRequests": "総リクエスト数",
    "totalCost": "総コスト",
    "cost": "コスト",
    "unpriced": "価格未設定",
    "perMillion": "(100万あたり)",
    "trends": "利用トレンド",
    "rangeToday": "直近24時間 (時間別)",
    "rangeLast7Days": "過去7日間",
    "rangeLast30Days": "過去30日間",
    "totalTokens": "新規トークン (Input+Output)",
    "cacheTokens": "キャッシュトークン",
    "realTotal": "実消費トークン",
    "realTotalHint": "Input + Output + キャッシュ書込 + キャッシュ命中",
    "freshInput": "新規入力",
    "cacheHitRate": "キャッシュヒット率",
    "requestLogs": "リクエストログ",
    "providerStats": "プロバイダー統計",
    "modelStats": "モデル統計",
    "time": "時間",
    "provider": "プロバイダー",
    "billingModel": "課金モデル",
    "inputTokens": "入力",
    "outputTokens": "出力",
    "cacheReadTokens": "キャッシュヒット",
    "cacheCreationTokens": "キャッシュ作成",
    "timingInfo": "応答時間/TTFT",
    "status": "ステータス",
    "multiplier": "倍率",
    "requestModel": "リクエストモデル",
    "responseModel": "レスポンスモデル",
    "noData": "データなし",
    "unknownProvider": "不明なプロバイダー",
    "stream": "ストリーム",
    "nonStream": "非ストリーム",
    "source": "ソース",
    "requestsLabel": "リクエスト",
    "costLabel": "合計コスト",
    "appFilter": {
      "all": "すべて",
      "claude": "Claude Code",
      "codex": "Codex",
      "gemini": "Gemini",
      "opencode": "OpenCode",
      "grokbuild": "Grok Build",
      "pi": "Pi",
      "mcode": "MiniMax Code"
    },
    "rawInputLabel": "原始",
    "sessionSync": {
      "title": "セッションログの自動スキャン",
      "description": "各クライアントのローカルセッションログを定期的にスキャンして使用量を集計します。オフにすると手動同期時のみスキャンします",
      "syncNow": "今すぐ同期",
      "syncCompleted": "同期完了：{{imported}} 件追加、{{files}} ファイルをスキャン、エラー {{errors}} 件",
      "syncFailed": "セッション使用量の同期に失敗しました：{{error}}"
    },
    "rebuildCodex": {
      "title": "Codex 使用量メンテナンス",
      "description": "ローカルの rollout ログから Codex セッション使用量を再構築します",
      "warning": "最初にデータベースを自動バックアップします。元の JSONL が削除済みの履歴は再インポートできません。",
      "action": "Codex 使用量を再構築",
      "confirmTitle": "Codex 使用量を再構築しますか？",
      "confirmMessage": "既存の Codex セッション明細と集計を削除し、ローカルの Codex ログから再インポートします。\n\n削除済みログの履歴は失われます。親 rollout がない fork は保留されます。",
      "confirmAction": "バックアップして再構築",
      "completed": "再構築完了：{{imported}} 件インポート、{{errors}} 件エラー、重複候補 {{suspected}} 件、保留ファイル {{deferred}} 件",
      "failed": "Codex 使用量の再構築に失敗しました：{{error}}"
    },
    "totalRecords": "全 {{total}} 件",
    "goToPage": "移動",
    "pageInputPlaceholder": "ページ",
    "modelPricing": "モデル料金",
    "loadPricingError": "料金データの読み込みに失敗しました",
    "modelPricingDesc": "各モデルのトークンコストを設定",
    "noPricingData": "料金データがありません。「追加」をクリックしてモデル料金を設定してください。",
    "model": "モデル",
    "pricingModel": "課金モデル",
    "displayName": "表示名",
    "inputCost": "入力コスト",
    "outputCost": "出力コスト",
    "cacheReadCost": "キャッシュヒット",
    "cacheWriteCost": "キャッシュ作成",
    "deleteConfirmTitle": "削除の確認",
    "deleteConfirmDesc": "このモデル料金を削除しますか？この操作は元に戻せません。",
    "queryFailed": "照会に失敗しました",
    "refreshUsage": "利用状況を更新",
    "planUsage": "プラン利用状況",
    "invalid": "期限切れ",
    "total": "合計:",
    "used": "使用:",
    "remaining": "残り:",
    "justNow": "たった今",
    "minutesAgo": "{{count}} 分前",
    "hoursAgo": "{{count}} 時間前",
    "daysAgo": "{{count}} 日前",
    "multiplePlans": "{{count}} プラン",
    "expand": "展開",
    "collapse": "折りたたむ",
    "modelIdPlaceholder": "例: claude-3-5-sonnet-20241022",
    "displayNamePlaceholder": "例: Claude 3.5 Sonnet",
    "appType": "アプリ種別",
    "statusCode": "ステータスコード",
    "allSources": "すべてのソース",
    "allModels": "すべてのモデル",
    "filterBySource": "ソースで絞り込む",
    "filterByModel": "モデルで絞り込む",
    "refreshInterval": "自動更新間隔",
    "refreshOff": "オフ",
    "timeRange": "期間",
    "customRange": "カレンダーフィルター",
    "customRangeHint": "日付と時刻の両方に対応",
    "startTime": "開始時刻",
    "endTime": "終了時刻",
    "liveEndTime": "終了時刻を現在時刻に追従",
    "liveEndTimeNow": "現在",
    "input": "Input",
    "output": "Output",
    "cacheWrite": "作成",
    "cacheWriteNotReported": "OpenAI プロトコルはキャッシュ作成を区別せず、キャッシュヒットのみ報告します",
    "cacheWritePartial": "一部のプロトコル（OpenAIなど）はキャッシュ作成を報告しないため、値は不完全な可能性があります",
    "cacheRead": "ヒット",
    "baseCost": "基本",
    "costMultiplier": "コスト倍率",
    "withMultiplier": "倍率込み",
    "requestDetail": "リクエスト詳細",
    "requestNotFound": "リクエストが見つかりません",
    "basicInfo": "基本情報",
    "tokenUsage": "Token 使用量",
    "cacheCreationCost": "キャッシュ作成コスト",
    "costBreakdown": "コスト明細",
    "performance": "パフォーマンス",
    "latency": "レイテンシー",
    "errorMessage": "エラーメッセージ",
    "requests": "リクエスト数",
    "tokens": "トークン",
    "avgCost": "平均コスト",
    "avgLatency": "平均レイテンシ",
    "successRate": "成功率",
    "requestId": "リクエスト ID",
    "never": "なし",
    "modelId": "モデル ID",
    "modelIdRequired": "モデル ID は必須です",
    "inputCostPerMillion": "入力コスト（100万トークンあたり、USD）",
    "outputCostPerMillion": "出力コスト（100万トークンあたり、USD）",
    "invalidPrice": "価格は負でない数値である必要があります",
    "invalidTimeRange": "開始/終了時刻を完全に選択してください",
    "invalidTimeRangeOrder": "開始時刻は終了時刻より前である必要があります",
    "timeRangeTooLarge": "時間範囲が大きすぎます。範囲を縮小してください",
    "addPricing": "価格設定を追加",
    "editPricing": "価格設定を編集",
    "pricingAdded": "価格設定が追加されました",
    "pricingUpdated": "価格設定が更新されました",
    "importFromModelsDev": "models.dev からインポート",
    "modelsDevHint": "手動入力の代わりに、models.dev からモデル価格を選択できます",
    "modelsDevPickerTitle": "models.dev から価格をインポート",
    "modelsDevPickerDesc": "インポートするモデルを選択してください（価格単位：USD / 100万トークン）。1回につき1モデルです。",
    "modelsDevSearchPlaceholder": "モデルまたはプロバイダーを検索（全件検索）...",
    "modelsDevAllProviders": "すべてのプロバイダー",
    "modelsDevLoadError": "models.dev データの読み込みに失敗しました",
    "modelsDevRetry": "再試行",
    "modelsDevImportButton": "インポート",
    "modelsDevImporting": "インポート中...",
    "modelsDevImported": "{{name}} の価格をインポートしました",
    "modelsDevNoResults": "一致するモデルがありません",
    "modelsDevTruncated": "{{total}} 件中、先頭 {{shown}} 件のみ表示しています。検索条件を絞り込んでください",
    "modelsDevDefaultHint": "最新リリース順に {{shown}} 件を表示しています（全 {{total}} 件）。キーワード入力で全件検索できます",
    "modelsDevAutoSync": {
      "title": "models.dev 料金の自動同期",
      "description": "有効にすると、CC Switch の起動時に選択したモデルの最新料金を定期的に取得し、ローカル料金ファイルに保存します。",
      "enabled": "有効",
      "disabled": "無効",
      "enableConfirmTitle": "料金の自動同期を有効にしますか？",
      "enableConfirmMessage": "有効にすると、CC Switch の起動時に models.dev から選択したモデルの料金を定期的に更新します（最大 6 時間に 1 回）。同じモデル ID の内蔵料金と手動設定した料金は上書きされます。",
      "enableConfirmAction": "自動同期を有効にする",
      "configure": "モデルを選択",
      "configureTitle": "料金を自動同期するモデルを選択",
      "configureDescription": "検索とプロバイダーの絞り込みで自動更新するモデルを選択します。選択内容はローカルに保存されます。",
      "commonModels": "よく使うモデルを自動的に含める",
      "commonModelsDescription": "最近の Claude、GPT、Gemini、Grok、DeepSeek、Qwen、MiMo、LongCat、Kimi、MiniMax、GLM から {{count}} モデルを選択します。",
      "selectFiltered": "絞り込み結果を選択（{{count}}）",
      "clearFiltered": "絞り込み結果を解除",
      "selectedCount": "{{count}} モデルを選択中",
      "selectionHint": "正規化後のモデル ID が同じ項目は一度だけインポートされます。",
      "commonBadge": "よく使う",
      "selectionSaved": "自動料金同期の選択を保存しました",
      "syncSuccess": "料金同期が完了しました：{{imported}} モデルを確認、{{changed}} モデルを更新",
      "syncFailed": "料金同期に失敗しました：{{error}}",
      "configLoadFailed": "ローカル料金設定の読み込みに失敗しました：{{error}}",
      "neverSynced": "未同期",
      "lastSync": "最終同期",
      "commonStatus": "よく使うモデル",
      "lastError": "前回の自動同期に失敗しました：{{error}}",
      "localFile": "ローカル料金ファイル",
      "openFolder": "フォルダーを開く",
      "openFolderFailed": "ローカル料金フォルダーを開けませんでした: {{error}}",
      "reloadLocalFile": "ファイルを再読み込み",
      "localFileReloaded": "ローカル料金ファイルを再読み込みしました",
      "localFileReloadFailed": "ローカル料金ファイルの再読み込みに失敗しました：{{error}}",
      "syncNow": "今すぐ同期"
    },
    "cacheReadCostPerMillion": "キャッシュ読み取りコスト（100万トークンあたり、USD）",
    "cacheCreationCostPerMillion": "キャッシュ書き込みコスト（100万トークンあたり、USD）"
  },
  "usageScript": {
    "title": "利用状況を設定",
    "enableUsageQuery": "利用状況照会を有効にする",
    "presetTemplate": "プリセットテンプレート",
    "requestUrl": "リクエスト URL",
    "requestUrlPlaceholder": "例: https://api.example.com",
    "method": "HTTP メソッド",
    "templateCustom": "カスタム",
    "templateGeneral": "General",
    "templateNewAPI": "NewAPI",
    "templateCopilot": "GitHub Copilot",
    "templateTokenPlan": "Token Plan",
    "templateBalance": "公式",
    "templateOfficialSubscription": "公式サブスクリプション",
    "copilotAutoAuth": "OAuth 認証を自動使用、手動設定不要",
    "tokenPlanHint": "プロバイダーのAPI KeyとBase URLを使用してToken Planクォータを自動クエリ",
    "balanceHint": "プロバイダーのAPI Keyを使用してアカウント残高を自動クエリ",
    "officialSubscriptionHint": "ローカル CLI の OAuth 認証情報を読み取り、公式 API でサブスクリプション枠を照会します。既定では無効で、有効化した後のみリクエストします。",
    "resetDate": "リセット日",
    "premiumRequests": "Premium リクエスト",
    "credentialsConfig": "認証情報",
    "credentialsHint": "空欄の場合はプロバイダー設定を使用",
    "optional": "オプション",
    "apiKeyPlaceholder": "空欄の場合はプロバイダーの API Key を使用",
    "baseUrlPlaceholder": "空欄の場合はプロバイダーの Base URL を使用",
    "baseUrl": "Base URL",
    "accessToken": "Access Token",
    "accessTokenPlaceholder": "「Security Settings」で生成",
    "userId": "ユーザー ID",
    "userIdPlaceholder": "例: 114514",
    "accessKeyId": "AccessKey ID",
    "secretAccessKey": "SecretAccessKey",
    "volcengineAkSkHint": "Volcengine の使用量照会にはアカウントレベルの AccessKey ID / Secret が必要です（推論 API キーとは別物）。Volcengine コンソール右上のアカウントメニュー →「API アクセスキー」で作成してください。",
    "volcengineKeyConsoleLink": "キー作成ページ：",
    "zhipuTeamHint": "智譜チームプランの使用量照会には、チーム API キー（このプロバイダーの認証情報を流用）+ 組織 ID + プロジェクト ID が必要です（リクエストヘッダー bigmodel-organization / bigmodel-project として送信）。組織 ID とプロジェクト ID はチーム管理コンソールの使用量ページの URL で確認できます。",
    "zhipuTeamConsoleLink": "チーム使用量ページ：",
    "organizationId": "組織 ID",
    "organizationIdPlaceholder": "例: org-xxxxxx",
    "projectId": "プロジェクト ID",
    "projectIdPlaceholder": "例: proj-xxxxxx",
    "defaultPlan": "デフォルトプラン",
    "queryFailedMessage": "照会に失敗しました",
    "queryScript": "照会スクリプト (JavaScript)",
    "timeoutSeconds": "タイムアウト（秒）",
    "headers": "ヘッダー",
    "body": "ボディ",
    "timeoutHint": "範囲: 2〜30 秒",
    "timeoutMustBeInteger": "タイムアウトは整数で入力してください（小数は切り捨て）",
    "timeoutCannotBeNegative": "タイムアウトは負の値にできません",
    "autoIntervalMinutes": "自動照会間隔（分、0 で無効）",
    "autoQueryInterval": "自動照会間隔（分）",
    "autoQueryIntervalHint": "0 で無効。推奨 5〜60 分",
    "intervalMustBeInteger": "間隔は整数で入力してください（小数は切り捨て）",
    "intervalCannotBeNegative": "間隔は負の値にできません",
    "intervalAdjusted": "間隔を {{value}} 分に調整しました",
    "scriptHelp": "スクリプトの書き方:",
    "configFormat": "設定の形式:",
    "commentOptional": "任意",
    "commentResponseIsJson": "response は API から返る JSON データです",
    "extractorFormat": "抽出関数の返却形式（すべて任意）:",
    "tips": "💡 ヒント:",
    "testing": "テスト中...",
    "testScript": "スクリプトをテスト",
    "format": "整形",
    "saveConfig": "設定を保存",
    "scriptEmpty": "スクリプト設定は空にできません",
    "mustHaveReturn": "スクリプトには return 文が必要です",
    "testSuccess": "テスト成功！",
    "testFailed": "テストに失敗しました",
    "formatSuccess": "整形に成功しました",
    "formatFailed": "整形に失敗しました",
    "supportedVariables": "使用可能な変数",
    "variablesHint": "使用可能な変数: {{apiKey}}, {{baseUrl}} | extractor 関数には API 応答の JSON オブジェクトが渡されます",
    "scriptConfig": "リクエスト設定",
    "extractorCode": "抽出コード",
    "extractorHint": "戻り値のオブジェクトに残り枠の項目を含めてください",
    "fieldIsValid": "• isValid: Boolean。プランが有効かどうか",
    "fieldInvalidMessage": "• invalidMessage: String。無効時の理由（isValid が false のとき表示）",
    "fieldRemaining": "• remaining: Number。残り枠",
    "fieldUnit": "• unit: String。単位（例: \"USD\"）",
    "fieldPlanName": "• planName: String。プラン名",
    "fieldTotal": "• total: Number。総枠",
    "fieldUsed": "• used: Number。使用量",
    "fieldExtra": "• extra: String。自由記述の追加テキスト",
    "tip1": "• 変数 {{apiKey}} と {{baseUrl}} は自動で置換されます",
    "tip2": "• 抽出関数はサンドボックスで実行され、ES2020+ の構文を使えます",
    "tip3": "• 全体を () で囲み、オブジェクトリテラル式にしてください"
  },
  "dbUpgrade": {
    "title": "データベースのバージョンが新しすぎます",
    "description": "このデータベースは新しいバージョンの CC Switch で作成されています。続行するにはアプリを更新してください。更新してもデータは削除されません。",
    "versionInfo": "データベース v{{db}} · アプリ対応 v{{supported}}",
    "dbPath": "データベースファイル",
    "checking": "利用可能な更新を確認中…",
    "updateAvailable": "新しいバージョン v{{version}} が利用可能です。更新すると続行できます。",
    "incompatibleTitle": "更新しても解決できません",
    "incompatibleDescription": "すでに最新バージョンですが、データベース（v{{db}}）はこのアプリの対応バージョン（v{{supported}}）より新しいままです。サードパーティ製クライアントまたはより新しいビルドで作成された可能性があり、公式アプリを更新しても互換性は得られません。",
    "preparing": "更新を準備中…",
    "downloading": "更新をダウンロード中…",
    "upgradeNow": "アプリを更新",
    "retry": "更新を再試行",
    "openReleases": "リリースページを開く",
    "openConfigDir": "設定フォルダを開く",
    "quit": "終了"
  },
  "errors": {
    "usage_query_failed": "利用状況の取得に失敗しました",
    "configLoadFailedTitle": "設定の読み込みに失敗しました",
    "configLoadFailedMessage": "設定ファイルを読み込めません:\n{{path}}\n\nエラー詳細:\n{{detail}}\n\nJSON が正しいか確認するか、同じディレクトリのバックアップファイル（config.json.bak など）から復元してください。\n\nアプリを終了して修正してください。",
    "frontendCrashTitle": "画面で問題が発生しました",
    "frontendCrashMessage": "エラー情報をアプリ診断ログに保存しようとしました。画面を再読み込みし、問題が続く場合は Issue にログを添付してください。",
    "reloadInterface": "画面を再読み込み"
  },
  "presetSelector": {
    "title": "設定タイプを選択",
    "custom": "カスタム",
    "customDescription": "手動で設定。完全な構成が必要",
    "officialDescription": "公式ログイン。API Key 不要",
    "presetDescription": "プリセットを使用。API Key だけ入力すれば OK"
  },
  "mcp": {
    "title": "MCP 管理",
    "import": "インポート",
    "importExisting": "既存をインポート",
    "addMcp": "MCPを追加",
    "claudeTitle": "Claude Code MCP 管理",
    "codexTitle": "Codex MCP 管理",
    "geminiTitle": "Gemini MCP 管理",
    "unifiedPanel": {
      "title": "MCP サーバー管理",
      "addServer": "サーバーを追加",
      "editServer": "サーバーを編集",
      "deleteServer": "サーバーを削除",
      "deleteConfirm": "サーバー「{{id}}」を削除しますか？この操作は元に戻せません。",
      "noServers": "まだサーバーがありません",
      "enabledApps": "有効なアプリ",
      "noImportFound": "インポートする MCP サーバーが見つかりませんでした。すべてのサーバーは CC Switch で管理されています。",
      "importSuccess": "{{count}} 個の MCP サーバーをインポートしました",
      "searchPlaceholder": "MCP の名前、説明、タグ、コマンドを検索...",
      "searchAriaLabel": "管理中の MCP サーバーを検索",
      "noSearchResults": "検索に一致する MCP サーバーがありません",
      "apps": {
        "claude": "Claude",
        "codex": "Codex",
        "gemini": "Gemini",
        "grokbuild": "Grok Build",
        "opencode": "OpenCode",
        "openclaw": "OpenClaw",
        "hermes": "Hermes",
        "mcode": "MiniMax Code"
      }
    },
    "userLevelPath": "ユーザーレベルの MCP パス",
    "serverList": "サーバー一覧",
    "loading": "読み込み中...",
    "empty": "MCP サーバーがありません",
    "emptyDescription": "右上のボタンから最初の MCP サーバーを追加してください",
    "add": "MCP を追加",
    "addServer": "MCP を追加",
    "editServer": "MCP を編集",
    "addClaudeServer": "Claude Code MCP を追加",
    "editClaudeServer": "Claude Code MCP を編集",
    "addCodexServer": "Codex MCP を追加",
    "editCodexServer": "Codex MCP を編集",
    "configPath": "設定パス",
    "serverCount": "MCP サーバー: {{count}} 件",
    "enabledCount": "{{count}} 件が有効",
    "template": {
      "fetch": "クイックテンプレート: mcp-fetch"
    },
    "form": {
      "title": "MCP ID（ユニーク）",
      "titlePlaceholder": "my-mcp-server",
      "name": "表示名",
      "namePlaceholder": "例: @modelcontextprotocol/server-time",
      "enabledApps": "適用するアプリ",
      "noAppsWarning": "少なくとも 1 つ選択してください",
      "description": "説明",
      "descriptionPlaceholder": "任意の説明",
      "tags": "タグ（カンマ区切り）",
      "tagsPlaceholder": "stdio, time, utility",
      "homepage": "ホームページ",
      "homepagePlaceholder": "https://example.com",
      "docs": "ドキュメント",
      "docsPlaceholder": "https://example.com/docs",
      "additionalInfo": "追加情報",
      "jsonConfig": "JSON 全設定",
      "jsonConfigOrPrefix": "JSON 全設定、または",
      "tomlConfigOrPrefix": "TOML 全設定、または",
      "jsonPlaceholder": "{\n  \"type\": \"stdio\",\n  \"command\": \"uvx\",\n  \"args\": [\"mcp-server-fetch\"]\n}",
      "tomlConfig": "TOML 全設定",
      "tomlPlaceholder": "type = \"stdio\"\ncommand = \"uvx\"\nargs = [\"mcp-server-fetch\"]",
      "useWizard": "設定ウィザード",
      "syncOtherSide": "{{target}} にも反映",
      "syncOtherSideHint": "{{target}} に同じ設定を書き込みます。既存の同一 ID は上書きされます。",
      "willOverwriteWarning": "{{target}} の既存設定を上書きします"
    },
    "wizard": {
      "title": "MCP 設定ウィザード",
      "hint": "MCP サーバーを素早く設定し JSON を自動生成します",
      "type": "タイプ",
      "typeStdio": "stdio",
      "typeHttp": "http",
      "typeSse": "sse",
      "command": "コマンド",
      "commandPlaceholder": "npx または uvx",
      "args": "引数",
      "argsPlaceholder": "arg1\narg2",
      "env": "環境変数",
      "envPlaceholder": "KEY1=value1\nKEY2=value2",
      "url": "URL",
      "urlPlaceholder": "https://api.example.com/mcp",
      "urlRequired": "URL を入力してください",
      "headers": "ヘッダー（任意）",
      "headersPlaceholder": "Authorization: Bearer your_token_here\nContent-Type: application/json",
      "preview": "設定プレビュー",
      "apply": "設定を反映"
    },
    "id": "識別子（ユニーク）",
    "type": "タイプ",
    "command": "コマンド",
    "validateCommand": "コマンドを検証",
    "args": "引数",
    "argsPlaceholder": "例: mcp-server-fetch --help",
    "env": "環境変数（1 行に 1 件、KEY=VALUE）",
    "envPlaceholder": "FOO=bar\nHELLO=world",
    "reset": "リセット",
    "msg": {
      "saved": "保存しました",
      "deleted": "削除しました",
      "enabled": "有効化しました",
      "disabled": "無効化しました",
      "templateAdded": "テンプレートを追加しました"
    },
    "error": {
      "idRequired": "識別子を入力してください",
      "idExists": "この識別子は既に存在します。別のものを選んでください。",
      "jsonInvalid": "JSON 形式が無効です",
      "tomlInvalid": "TOML 形式が無効です",
      "commandRequired": "コマンドを入力してください",
      "singleServerObjectRequired": "単一の MCP サーバーオブジェクトを貼り付けてください（トップレベルの mcpServers は不要）",
      "saveFailed": "保存に失敗しました",
      "deleteFailed": "削除に失敗しました"
    },
    "validation": {
      "ok": "コマンドが見つかりました",
      "fail": "コマンドが見つかりません"
    },
    "confirm": {
      "deleteTitle": "MCP サーバーを削除",
      "deleteMessage": "MCP サーバー「{{id}}」を削除してもよろしいですか？この操作は元に戻せません。"
    },
    "presets": {
      "title": "MCP タイプを選択",
      "enable": "有効化",
      "enabled": "有効",
      "installed": "インストール済み",
      "docs": "ドキュメント",
      "requiresEnv": "環境変数が必要",
      "fetch": {
        "name": "mcp-server-fetch",
        "description": "汎用 HTTP リクエストツール。GET/POST などに対応し、API テストや Web データ取得に最適です"
      },
      "time": {
        "name": "@modelcontextprotocol/server-time",
        "description": "現在時刻、タイムゾーン変換、日付計算を提供する時間クエリツール"
      },
      "memory": {
        "name": "@modelcontextprotocol/server-memory",
        "description": "エンティティ・関係・観測を扱うナレッジグラフ型メモリ。会話の重要情報を AI に記憶させます"
      },
      "sequential-thinking": {
        "name": "@modelcontextprotocol/server-sequential-thinking",
        "description": "複雑な問題をステップに分解して深く考えるためのシーケンシャル思考ツール"
      },
      "context7": {
        "name": "@upstash/context7-mcp",
        "description": "最新のライブラリドキュメントとコード例を提供する Context7 ドキュメント検索ツール。キー設定で上限が拡張されます"
      }
    }
  },
  "prompts": {
    "manage": "プロンプト",
    "title": "{{appName}} プロンプト管理",
    "claudeTitle": "Claude プロンプト管理",
    "codexTitle": "Codex プロンプト管理",
    "add": "プロンプトを追加",
    "edit": "プロンプトを編集",
    "addTitle": "{{appName}} プロンプトを追加",
    "editTitle": "{{appName}} プロンプトを編集",
    "import": "既存をインポート",
    "count": "{{count}} 件のプロンプト",
    "enabled": "有効",
    "enable": "有効化",
    "enabledName": "有効: {{name}}",
    "noneEnabled": "有効なプロンプトがありません",
    "currentFile": "現在の {{filename}} の内容",
    "empty": "まだプロンプトがありません",
    "emptyDescription": "上のボタンからプロンプトを追加またはインポートしてください",
    "loading": "読み込み中...",
    "searchPlaceholder": "プロンプトの名前、説明、内容を検索...",
    "searchAriaLabel": "管理中のプロンプトを検索",
    "noSearchResults": "検索に一致するプロンプトがありません",
    "name": "名前",
    "namePlaceholder": "例: デフォルトプロジェクトプロンプト",
    "description": "説明",
    "descriptionPlaceholder": "任意の説明",
    "content": "内容",
    "contentPlaceholder": "# {{filename}}\n\nここにプロンプト内容を入力...",
    "loadFailed": "プロンプトの読み込みに失敗しました",
    "saveSuccess": "保存しました",
    "saveFailed": "保存に失敗しました",
    "deleteSuccess": "削除しました",
    "deleteFailed": "削除に失敗しました",
    "enableSuccess": "有効化しました",
    "enableFailed": "有効化に失敗しました",
    "disableSuccess": "無効化しました",
    "disableFailed": "無効化に失敗しました",
    "importSuccess": "インポートしました",
    "importFailed": "インポートに失敗しました",
    "confirm": {
      "deleteTitle": "削除の確認",
      "deleteMessage": "プロンプト「{{name}}」を削除してもよろしいですか？"
    }
  },
  "profiles": {
    "switcherAriaLabel": "プロジェクト：{{name}}",
    "switcherTooltip": {
      "claude": "プロジェクト：Claude Code のプロバイダー / MCP / Skills / メモリファイルをワンクリックで切り替え",
      "claude-desktop": "プロジェクト：Claude Desktop のプロバイダーをワンクリックで切り替え",
      "codex": "プロジェクト：Codex のプロバイダー / MCP / Skills / メモリファイルをワンクリックで切り替え"
    },
    "none": "プロジェクトを使用しない",
    "searchPlaceholder": "プロジェクトを検索",
    "empty": "プロジェクトはまだありません",
    "createFromCurrent": "新規プロジェクト",
    "createDescription": {
      "claude": "Claude Code の現在のプロバイダー、MCP、Skills、メモリファイルをプロジェクトとして保存し、後からワンクリックで切り替えられます。",
      "claude-desktop": "Claude Desktop の現在のプロバイダーをプロジェクトとして保存し、後からワンクリックで切り替えられます。",
      "codex": "Codex の現在のプロバイダー、MCP、Skills、メモリファイルの設定をプロジェクトとして保存し、後からワンクリックで切り替えられます。"
    },
    "manage": "プロジェクトを管理…",
    "manageTitle": "プロジェクト管理",
    "manageDescription": "プロジェクトは設定のスナップショットです。プロジェクトを切り替えると、現在の設定は元のプロジェクトに自動的に保存されます。",
    "namePlaceholder": "例：開発、イラスト",
    "rename": "名前を変更",
    "noSnapshotForScope": "このアプリ側は未保存",
    "delete": "削除",
    "deleteConfirmTitle": "削除の確認",
    "deleteConfirmMessage": "プロジェクト「{{name}}」を削除してもよろしいですか？現在の設定は変更されません。",
    "createSuccess": "プロジェクトを作成しました",
    "createFailed": "プロジェクトの作成に失敗しました: {{detail}}",
    "updateSuccess": "プロジェクトを更新しました",
    "updateFailed": "プロジェクトの更新に失敗しました: {{detail}}",
    "deleteSuccess": "プロジェクトを削除しました",
    "deleteFailed": "プロジェクトの削除に失敗しました: {{detail}}",
    "applySuccess": "プロジェクトを適用しました",
    "applyFailed": "プロジェクトの適用に失敗しました: {{detail}}",
    "applyWarnings": "プロジェクトを適用しました（警告 {{warningCount}} 件）：\n{{details}}",
    "clearSuccess": "プロジェクトを使用しない状態に切り替えました"
  },
  "workspace": {
    "title": "ワークスペースファイル",
    "manage": "ワークスペース",
    "files": {
      "agents": "エージェントの操作指示とルール",
      "soul": "エージェントの人格とコミュニケーションスタイル",
      "user": "ユーザープロファイルと設定",
      "identity": "エージェントの名前とアバター",
      "tools": "ローカルツールドキュメント",
      "memory": "長期記憶と意思決定記録",
      "heartbeat": "ハートビート実行チェックリスト",
      "bootstrap": "初回実行ブートストラップ",
      "boot": "ゲートウェイ再起動チェックリスト"
    },
    "editing": "{{filename}} を編集",
    "saveSuccess": "保存しました",
    "saveFailed": "保存に失敗しました",
    "loadFailed": "読み込みに失敗しました",
    "openDirectory": "ファイルマネージャーで開く",
    "dailyMemory": {
      "title": "デイリーメモリー",
      "sectionTitle": "デイリーメモリー",
      "cardTitle": "デイリーメモリーファイル",
      "cardDescription": "デイリーメモリーの閲覧・管理",
      "createToday": "メモリーを追加",
      "empty": "デイリーメモリーファイルはまだありません",
      "loadFailed": "デイリーメモリーファイルの読み込みに失敗しました",
      "createFailed": "デイリーメモリーファイルの作成に失敗しました",
      "deleteSuccess": "デイリーメモリーファイルを削除しました",
      "deleteFailed": "デイリーメモリーファイルの削除に失敗しました",
      "confirmDeleteTitle": "デイリーメモリーを削除",
      "confirmDeleteMessage": "{{date}} のデイリーメモリーを削除しますか？この操作は取り消せません。",
      "searchPlaceholder": "全文検索...",
      "searchScopeHint": "すべてのデイリーメモリーを全文検索 ⌘F",
      "searchCloseHint": "Escで閉じる",
      "noSearchResults": "検索に一致するデイリーメモリーはありません。",
      "searching": "検索中...",
      "searchFailed": "検索に失敗しました",
      "matchCount": "{{count}}件一致"
    }
  },
  "openclaw": {
    "backupCreated": "バックアップを作成しました: {{path}}",
    "providerKey": "プロバイダーキー",
    "providerKeyPlaceholder": "my-provider",
    "providerKeyHint": "設定ファイル内のユニーク識別子。小文字、数字、ハイフンのみ使用可能。",
    "providerKeyLockedHint": "このプロバイダーは既にアプリ設定へ追加されているため、キーは変更できません。",
    "providerKeyRequired": "プロバイダーキーを入力してください",
    "providerKeyDuplicate": "このキーは既に使用されています",
    "providerKeyInvalid": "無効な形式です。小文字、数字、ハイフンのみ使用可能。",
    "apiProtocol": "API プロトコル",
    "selectProtocol": "API プロトコルを選択",
    "apiProtocolHint": "プロバイダーの API と互換性のあるプロトコルタイプを選択してください。ほとんどのプロバイダーは OpenAI Completions 形式を使用します。",
    "baseUrl": "API エンドポイント",
    "baseUrlHint": "プロバイダーの API エンドポイントアドレス。",
    "models": "モデル設定",
    "addModel": "モデルを追加",
    "selectDefaultModel": "デフォルトモデルを選択",
    "noModels": "モデルが設定されていません",
    "modelId": "モデル ID",
    "modelIdPlaceholder": "claude-3-sonnet",
    "modelName": "表示名",
    "modelNamePlaceholder": "Claude 3 Sonnet",
    "toggleModelDetails": "モデル詳細を展開または折りたたむ",
    "removeModel": "モデルを削除",
    "contextWindow": "コンテキスト長",
    "maxTokens": "最大出力トークン数",
    "reasoning": "拡張思考に対応",
    "inputTypes": "入力タイプ",
    "modelCost": "コスト（$/100万トークン）",
    "inputCost": "入力",
    "outputCost": "出力",
    "cacheReadCost": "キャッシュ読み取り",
    "cacheWriteCost": "キャッシュ書き込み",
    "userAgent": "User-Agent を送信",
    "userAgentHint": "一部のプロバイダーはブラウザの User-Agent ヘッダーが必要です。",
    "env": {
      "title": "環境変数",
      "description": "openclaw.json の環境変数設定を管理（APIキー、カスタム変数など）",
      "editorHint": "env セクション全体を JSON として編集します。env.vars や env.shellEnv などのネストしたオブジェクトにも対応しています。",
      "objectRequired": "OpenClaw の env は JSON オブジェクトである必要があります。",
      "invalidJson": "OpenClaw の env は有効な JSON である必要があります。",
      "empty": "OpenClaw の env は空にできません。空オブジェクトの場合は {} を使用してください。",
      "keyPlaceholder": "変数名",
      "valuePlaceholder": "値",
      "add": "変数を追加",
      "saveSuccess": "環境変数を保存しました",
      "saveFailed": "環境変数の保存に失敗しました",
      "loadFailed": "環境変数の読み込みに失敗しました",
      "duplicateKey": "重複する変数名が検出されました: {{key}}"
    },
    "tools": {
      "title": "ツール権限",
      "description": "openclaw.json のツール権限設定を管理（許可/拒否リスト）",
      "profile": "権限プロファイル",
      "profileMinimal": "最小",
      "profileCoding": "コーディング",
      "profileMessaging": "メッセージ",
      "profileFull": "フルアクセス",
      "profileUnset": "未設定",
      "unsupportedProfileTitle": "未対応のツールプロファイルを検出しました",
      "unsupportedProfileDescription": "現在の tools.profile の値 '{{value}}' は OpenClaw の対応リストにありません。新しい値を選択するまでこの値を保持します。",
      "unsupportedProfileLabel": "未対応",
      "allowList": "許可リスト",
      "denyList": "拒否リスト",
      "patternPlaceholder": "ツール名またはパターン",
      "addAllow": "許可を追加",
      "addDeny": "拒否を追加",
      "saveSuccess": "ツール権限を保存しました",
      "saveFailed": "ツール権限の保存に失敗しました",
      "loadFailed": "ツール権限の読み込みに失敗しました"
    },
    "agents": {
      "title": "Agents 設定",
      "description": "openclaw.json の agents.defaults 設定を管理（デフォルトモデル、ランタイムパラメータなど）",
      "modelSection": "モデル設定",
      "primaryModel": "デフォルトモデル",
      "primaryModelHint": "設定済みプロバイダのモデルから選択してください",
      "notSet": "未設定",
      "fallbackModels": "フォールバックモデル",
      "fallbackModelsHint": "プライマリモデルが利用不可の場合、優先度順にフォールバックが試行されます",
      "addFallback": "フォールバックモデルを追加",
      "noModels": "設定済みのプロバイダモデルがありません。先に OpenClaw プロバイダを追加してください。",
      "notInList": "{{value}} (未設定)",
      "runtimeSection": "ランタイムパラメータ",
      "workspace": "ワークスペースパス",
      "timeout": "タイムアウト（秒）",
      "contextTokens": "コンテキストトークン数",
      "maxConcurrent": "最大同時実行数",
      "legacyTimeoutTitle": "旧タイムアウト設定を検出しました",
      "legacyTimeoutDescription": "この設定ではまだ agents.defaults.timeout を使用しています。ここで保存すると timeoutSeconds に移行されます。",
      "saveSuccess": "Agents 設定を保存しました",
      "saveFailed": "Agents 設定の保存に失敗しました",
      "loadFailed": "Agents 設定の読み込みに失敗しました"
    },
    "health": {
      "title": "OpenClaw 設定の警告を検出しました",
      "invalidToolsProfile": "tools.profile に未対応の値が設定されています。OpenClaw が現在サポートしているのは minimal、coding、messaging、full です。",
      "legacyTimeout": "agents.defaults.timeout は非推奨です。Agents パネルを保存すると timeoutSeconds に移行されます。",
      "stringifiedEnvVars": "env.vars はオブジェクトである必要がありますが、現在の値は文字列化または破損しているようです。",
      "stringifiedShellEnv": "env.shellEnv はオブジェクトである必要がありますが、現在の値は文字列化または破損しているようです。",
      "parseFailed": "openclaw.json を有効な JSON5 として解析できませんでした。ここで編集する前にファイルを修正してください。"
    }
  },
  "hermes": {
    "form": {
      "baseUrl": "API エンドポイント",
      "baseUrlHint": "プロバイダーの API エンドポイント URL。",
      "providerKey": "プロバイダーキー",
      "providerKeyPlaceholder": "my-provider",
      "providerKeyHint": "小文字、数字、ハイフンのみ。config.yaml のプロバイダー名として使用されます。",
      "providerKeyLockedHint": "このプロバイダーは Hermes 設定に追加済みのため、キーは変更できません。",
      "providerKeyRequired": "プロバイダーキーは必須です",
      "providerKeyInvalid": "プロバイダーキーは小文字、数字、ハイフンのみ使用できます",
      "providerKeyDuplicate": "このプロバイダーキーは既に存在します",
      "apiMode": "API モード",
      "apiModeHint": "プロバイダーの API プロトコル。エンドポイントに合わせて正しい形式を選択してください。",
      "apiModeChatCompletions": "OpenAI Chat Completions",
      "apiModeAnthropicMessages": "Anthropic Messages",
      "apiModeCodexResponses": "OpenAI Responses",
      "apiModeBedrockConverse": "AWS Bedrock Converse",
      "baseUrlRequired": "API エンドポイントは必須です",
      "baseUrlScheme": "http:// または https:// で始まるアドレスを指定してください",
      "baseUrlInvalid": "API エンドポイントは有効な URL ではありません",
      "models": "モデル一覧",
      "addModel": "モデルを追加",
      "noModels": "モデル未設定。このプロバイダーに切り替えてもデフォルトモデルは更新されません。",
      "modelId": "モデル ID",
      "modelIdPlaceholder": "anthropic/claude-opus-5",
      "modelName": "表示名",
      "modelNamePlaceholder": "Claude Opus 5",
      "contextLength": "コンテキスト長",
      "toggleModelDetails": "モデル詳細を展開または折りたたむ",
      "removeModel": "モデルを削除",
      "modelsHint": "現在のプロバイダーとして有効にすると、最初のモデルが Hermes のデフォルトモデルになります。",
      "rateLimitDelay": "リクエスト間隔（秒）",
      "rateLimitDelayHint": "連続したリクエスト間の最小待機秒数（任意）。空欄の場合は制限なし。"
    },
    "webui": {
      "open": "Hermes Web UI を開く",
      "offline": "Hermes Web UI が起動していません。まず `hermes dashboard` を実行してください。",
      "openFailed": "Hermes Web UI を開けませんでした",
      "launchConfirmTitle": "Hermes Dashboard が起動していません",
      "launchConfirmMessage": "ターミナルを開いて `hermes dashboard` を実行しますか？\n\n起動完了後、ブラウザが自動的に開きます。\n\nターミナルに `hermes` が見つからない、または web 依存が不足するというエラーが表示される場合は、まず次を実行してください：\npip install hermes-agent[web]",
      "launchConfirmAction": "ターミナルを開いて起動",
      "launching": "ターミナルで hermes dashboard を起動しました。",
      "launchFailed": "ターミナルを開けませんでした"
    },
    "memory": {
      "title": "メモリ",
      "agentTab": "エージェント記憶 (MEMORY.md)",
      "userTab": "ユーザープロファイル (USER.md)",
      "usage": "{{current}} / {{limit}} 文字",
      "overLimit": "上限を超えました。Hermes は次回読み込み時に切り詰めます",
      "enableOn": "有効",
      "enableOff": "無効",
      "disabledHint": "再度有効化するまで Hermes はこの記憶をスキップします",
      "toggleFailed": "メモリの切り替えに失敗しました",
      "saveSuccess": "記憶を保存しました",
      "saveFailed": "記憶の保存に失敗しました",
      "loadFailed": "記憶ファイルの読み込みに失敗しました",
      "openConfig": "Hermes Web UI で上限を調整",
      "runtimeNote": "変更は Hermes の再起動または新規セッション時に反映されます。"
    }
  },
  "env": {
    "warning": {
      "title": "競合する環境変数を検出しました",
      "description": "設定を上書きする可能性のある環境変数を {{count}} 件見つけました"
    },
    "actions": {
      "expand": "詳細を表示",
      "collapse": "折りたたむ",
      "selectAll": "すべて選択",
      "clearSelection": "選択を解除",
      "deleteSelected": "選択 {{count}} 件を削除",
      "deleting": "削除中..."
    },
    "field": {
      "value": "値",
      "source": "ソース"
    },
    "source": {
      "userRegistry": "ユーザー環境変数（レジストリ）",
      "systemRegistry": "システム環境変数（レジストリ）",
      "systemEnv": "システム環境変数"
    },
    "delete": {
      "success": "環境変数を削除しました",
      "error": "環境変数の削除に失敗しました"
    },
    "backup": {
      "location": "バックアップ場所: {{path}}"
    },
    "confirm": {
      "title": "環境変数を削除しますか？",
      "message": "{{count}} 件の環境変数を削除してもよろしいですか？",
      "backupNotice": "削除前に自動バックアップを作成します。後で復元できます。再起動またはターミナル再起動後に反映されます。",
      "confirm": "削除を確認"
    },
    "error": {
      "noSelection": "削除する環境変数を選択してください"
    }
  },
  "skills": {
    "manage": "Skills",
    "title": "Skills 管理",
    "description": "人気リポジトリからスキルを探してインストールし、Claude Code/Codex/Gemini を拡張",
    "refresh": "更新",
    "refreshing": "更新中...",
    "repoManager": "リポジトリ管理",
    "count": "{{count}} 個のスキル",
    "empty": "スキルがありません",
    "emptyDescription": "スキルリポジトリを追加して探索してください",
    "addRepo": "スキルリポジトリを追加",
    "loading": "読み込み中...",
    "installed": "インストール済み",
    "install": "インストール",
    "installing": "インストール中...",
    "uninstall": "アンインストール",
    "uninstalling": "アンインストール中...",
    "view": "表示",
    "noDescription": "説明なし",
    "loadFailed": "読み込みに失敗しました",
    "installSuccess": "スキル {{name}} をインストールしました",
    "installFailed": "インストールに失敗しました",
    "uninstallSuccess": "スキル {{name}} をアンインストールしました",
    "uninstallPiPreserved": "Pi のコピーが CC Switch 管理下であることを確認できなかったため、そのまま残しました: {{path}}",
    "uninstallPiCleanupIncomplete": "Pi のクリーンアップを完了できませんでした。Pi Skills ディレクトリにコピーが残っていないか手動で確認してください。",
    "uninstallFailed": "アンインストールに失敗しました",
    "update": "更新",
    "updating": "更新中...",
    "updateAvailable": "更新あり",
    "updateSuccess": "スキル {{name}} を最新バージョンに更新しました",
    "updateFailed": "更新に失敗しました",
    "checkUpdates": "更新を確認",
    "checkingUpdates": "確認中...",
    "noUpdates": "すべてのスキルは最新です",
    "updatesFound": "{{count}} 個のスキルに更新があります",
    "updateAll": "すべて更新 ({{count}})",
    "updatingAll": "更新中...",
    "updateAllSuccess": "{{count}} 個のスキルを更新しました",
    "error": {
      "skillNotFound": "スキルが見つかりません: {{directory}}",
      "missingRepoInfo": "リポジトリ情報（owner または name）が不足しています",
      "downloadTimeout": "リポジトリ {{owner}}/{{name}} のダウンロードがタイムアウトしました（{{timeout}} 秒）",
      "downloadTimeoutHint": "ネットワークを確認するか、時間をおいて再試行してください",
      "skillPathNotFound": "リポジトリ {{owner}}/{{name}} にスキルパス '{{path}}' がありません",
      "skillDirNotFound": "スキルディレクトリが見つかりません: {{path}}",
      "directoryConflict": "スキルディレクトリ '{{directory}}' は既に {{existing_repo}} で使用されています。{{new_repo}} からインストールできません",
      "emptyArchive": "ダウンロードしたアーカイブが空です",
      "invalidRepoRef": "リポジトリの指定が不正です：{{owner}}/{{name}}",
      "archiveTooLarge": "アーカイブが展開上限 {{limit_mb}} MB を超えたため中止しました",
      "archiveTooManyEntries": "アーカイブのエントリ数が多すぎます（{{count}}）。上限は {{limit}} です",
      "downloadFailed": "ダウンロードに失敗しました: HTTP {{status}}",
      "allBranchesFailed": "すべてのブランチで失敗しました。試行: {{branches}}",
      "httpError": "HTTP エラー {{status}}",
      "http403": "GitHub へのアクセスが制限されています（レート制限の可能性）",
      "http404": "リポジトリまたはブランチが見つかりません。URL を確認してください",
      "http429": "リクエストが多すぎます。時間をおいて再試行してください",
      "parseMetadataFailed": "スキルメタデータの解析に失敗しました",
      "getHomeDirFailed": "ユーザーのホームディレクトリを取得できません",
      "noSkillsInZip": "ZIP ファイルにスキルが見つかりません（SKILL.md ファイルが必要です）",
      "networkError": "ネットワークエラー",
      "fsError": "ファイルシステムエラー",
      "unknownError": "不明なエラー",
      "suggestion": {
        "checkNetwork": "ネットワーク接続を確認してください",
        "checkProxy": "HTTP プロキシの設定を検討してください",
        "retryLater": "時間をおいて再試行してください",
        "checkRepoUrl": "リポジトリ URL とブランチ名を確認してください",
        "checkDiskSpace": "ディスク容量を確認してください",
        "checkPermission": "ディレクトリの権限を確認してください",
        "uninstallFirst": "同名のスキルを先にアンインストールしてください",
        "checkZipContent": "ZIP ファイルに有効なスキルディレクトリ（SKILL.md を含む）が含まれていることを確認してください"
      }
    },
    "repo": {
      "title": "スキルリポジトリを管理",
      "description": "GitHub のスキルリポジトリソースを追加または削除します",
      "url": "リポジトリ URL",
      "urlPlaceholder": "owner/name または https://github.com/owner/name",
      "branch": "ブランチ",
      "branchPlaceholder": "main",
      "path": "スキルパス",
      "pathPlaceholder": "skills（任意。空欄はルート）",
      "add": "リポジトリを追加",
      "list": "追加済みリポジトリ",
      "empty": "リポジトリがありません",
      "invalidUrl": "リポジトリ URL の形式が無効です",
      "addSuccess": "リポジトリ {{owner}}/{{name}} を追加しました。検出スキル: {{count}} 件",
      "addFailed": "追加に失敗しました",
      "removeSuccess": "リポジトリ {{owner}}/{{name}} を削除しました",
      "removeFailed": "削除に失敗しました",
      "skillCount": "{{count}} 件のスキルを検出"
    },
    "search": "スキルを検索",
    "searchPlaceholder": "スキル名またはリポジトリで検索...",
    "installedSearchPlaceholder": "インストール済みスキルの名前、説明、リポジトリを検索...",
    "installedSearchAriaLabel": "インストール済みスキルを検索",
    "noInstalledSearchResults": "検索に一致するインストール済みスキルがありません",
    "searchSource": {
      "repos": "リポジトリ",
      "skillssh": "skills.sh"
    },
    "skillssh": {
      "searchPlaceholder": "skills.sh を検索（2文字以上）...",
      "installs": "{{count}} インストール",
      "loadMore": "さらに読み込む",
      "loading": "skills.sh を検索中...",
      "noResults": "\"{{query}}\" に該当するスキルがありません",
      "error": "skills.sh の検索に失敗しました",
      "poweredBy": "Powered by skills.sh"
    },
    "filter": {
      "placeholder": "状態で絞り込み",
      "all": "すべて",
      "installed": "インストール済み",
      "uninstalled": "未インストール",
      "repo": "リポジトリで絞り込み",
      "allRepos": "すべてのリポジトリ"
    },
    "noResults": "一致するスキルが見つかりませんでした",
    "noInstalled": "インストールされたスキルがありません",
    "noInstalledDescription": "リポジトリからスキルを発見してインストールするか、既存のスキルをインポートしてください",
    "discover": "スキルを発見",
    "import": "既存をインポート",
    "importDescription": "CC Switch 統合管理にインポートするスキルを選択してください",
    "importSuccess": "{{count}} 件のスキルをインポートしました",
    "importSelected": "選択をインポート ({{count}})",
    "noUnmanagedFound": "インポートするスキルが見つかりませんでした。すべてのスキルは CC Switch で管理されています。",
    "unmanagedAvailable": "インポート可能なスキルがあります",
    "foundIn": "発見場所",
    "local": "ローカル",
    "uninstallConfirm": "「{{name}}」をアンインストールしますか？すべてのアプリからこのスキルが削除され、削除前にローカルバックアップが自動作成されます。",
    "uninstallInMainPanel": "メインパネルからスキルをアンインストールしてください",
    "notFound": "スキルが見つかりません",
    "backup": {
      "location": "バックアップ場所: {{path}}"
    },
    "restoreFromBackup": {
      "button": "バックアップから復元",
      "title": "バックアップから復元",
      "description": "Skills バックアップを選択して、ローカルにファイルを復元し、現在の一覧へ戻します。",
      "empty": "復元できる Skills バックアップはありません",
      "createdAt": "バックアップ日時",
      "path": "バックアップパス",
      "restore": "復元",
      "restoring": "復元中...",
      "delete": "削除",
      "deleting": "削除中...",
      "deleteSuccess": "スキルバックアップ {{name}} を削除しました",
      "deleteFailed": "スキルバックアップの削除に失敗しました",
      "deleteConfirmTitle": "バックアップを削除",
      "deleteConfirmMessage": "スキルバックアップ「{{name}}」を削除しますか？この操作は元に戻せません。",
      "success": "スキル {{name}} をバックアップから復元しました",
      "failed": "バックアップからの復元に失敗しました"
    },
    "apps": {
      "claude": "Claude",
      "codex": "Codex",
      "gemini": "Gemini",
      "opencode": "OpenCode",
      "openclaw": "OpenClaw"
    },
    "installFromZip": {
      "button": "ZIP からインストール",
      "installing": "インストール中...",
      "successSingle": "スキル {{name}} をインストールしました",
      "successMultiple": "{{count}} 件のスキルをインストールしました",
      "noSkillsFound": "ZIP ファイルにスキルが見つかりません（SKILL.md が必要です）"
    }
  },
  "deeplink": {
    "confirmImport": "プロバイダーのインポートを確認",
    "confirmImportDescription": "次の設定をディープリンクから CC Switch へインポートします",
    "importPrompt": "プロンプトをインポート",
    "importPromptDescription": "このシステムプロンプトをインポートするか確認してください",
    "importMcp": "MCP サーバーをインポート",
    "importMcpDescription": "これらの MCP サーバーをインポートするか確認してください",
    "importSkill": "スキルリポジトリを追加",
    "importSkillDescription": "このスキルリポジトリを追加するか確認してください",
    "promptImportSuccess": "プロンプトをインポートしました",
    "promptImportSuccessDescription": "インポートされたプロンプト: {{name}}",
    "mcpImportSuccess": "MCP サーバーをインポートしました",
    "mcpImportSuccessDescription": "{{count}} 件のサーバーをインポートしました",
    "mcpPartialSuccess": "一部のみインポート成功",
    "mcpPartialSuccessDescription": "成功: {{success}}、失敗: {{failed}}",
    "skillImportSuccess": "スキルリポジトリを追加しました",
    "skillImportSuccessDescription": "追加したリポジトリ: {{repo}}",
    "app": "アプリ種別",
    "providerName": "プロバイダー名",
    "homepage": "ホームページ",
    "endpoint": "API エンドポイント",
    "apiKey": "API Key",
    "icon": "アイコン",
    "model": "モデル",
    "haikuModel": "Haiku モデル",
    "sonnetModel": "Sonnet モデル",
    "opusModel": "Opus モデル",
    "multiModel": "マルチモーダルモデル",
    "notes": "メモ",
    "import": "インポート",
    "importing": "インポート中...",
    "warning": "インポート前に内容を確認してください。後から一覧で編集・削除できます。",
    "parseError": "ディープリンクの解析に失敗しました",
    "importSuccess": "インポート成功",
    "importSuccessDescription": "プロバイダー「{{name}}」をインポートしました",
    "importError": "インポートに失敗しました",
    "configSource": "設定ソース",
    "configEmbedded": "埋め込み設定",
    "configRemote": "リモート設定",
    "configDetails": "設定の詳細",
    "configUrl": "設定ファイル URL",
    "configMergeError": "設定ファイルのマージに失敗しました",
    "primaryEndpoint": "メイン",
    "mcp": {
      "title": "MCP サーバーを一括インポート",
      "targetApps": "ターゲットアプリ",
      "serverCount": "MCP サーバー（{{count}} 件）",
      "enabledWarning": "インポート後、指定したすべてのアプリに即座に書き込まれます",
      "command": "コマンド",
      "args": "引数",
      "env": "環境変数",
      "url": "URL"
    },
    "prompt": {
      "title": "システムプロンプトをインポート",
      "app": "アプリ",
      "name": "名前",
      "description": "説明",
      "contentPreview": "内容プレビュー",
      "enabledWarning": "インポート後すぐにこのプロンプトが有効になり、他は無効になります"
    },
    "skill": {
      "title": "Claude スキルリポジトリを追加",
      "repo": "GitHub リポジトリ",
      "directory": "対象ディレクトリ",
      "branch": "ブランチ",
      "skillsPath": "スキルパス",
      "hint": "この操作でスキルリポジトリが一覧に追加されます。",
      "hintDetail": "追加後、スキル管理ページから個別のスキルをインストールできます。"
    },
    "usageScript": "使用量クエリ",
    "usageScriptEnabled": "有効",
    "usageScriptDisabled": "無効",
    "usageScriptCode": "スクリプトコード",
    "usageScriptWarning": "これは有効化すると使用量クエリ時に実行される JavaScript です。提供元が信頼できる場合のみインポートしてください。",
    "usageApiKey": "使用量 API キー",
    "usageBaseUrl": "使用量クエリ URL",
    "usageAccessToken": "使用量アクセストークン",
    "usageUserId": "使用量ユーザー ID",
    "usageAutoInterval": "自動クエリ",
    "usageAutoIntervalValue": "{{minutes}} 分ごと",
    "risk": {
      "envHijack": "この設定には、プロセスの読み込み動作を変える環境変数（ライブラリの注入、CA 証明書の差し替えなど）が含まれています。信頼できる提供元か確認してください。",
      "privateEndpoint": "このアドレスはローカルホストまたは内部ネットワークを指しています。自分で立てたローカルサービス以外はインポートしないでください。",
      "shellCommand": "この設定はシェル経由でコマンド全体を実行します。実際に動作する内容は引数にあります。1 行ずつ確認してください。"
    }
  },
  "iconPicker": {
    "search": "アイコンを検索",
    "searchPlaceholder": "アイコン名を入力...",
    "noResults": "一致するアイコンが見つかりません",
    "category": {
      "aiProvider": "AI プロバイダー",
      "cloud": "クラウドプラットフォーム",
      "tool": "開発ツール",
      "other": "その他"
    }
  },
  "providerIcon": {
    "label": "アイコン",
    "colorLabel": "アイコンカラー",
    "selectIcon": "アイコンを選択",
    "preview": "プレビュー",
    "clickToChange": "クリックでアイコンを変更",
    "clickToSelect": "クリックでアイコンを選択"
  },
  "migration": {
    "success": "設定の移行が完了しました",
    "skillsSuccess": "スキルを {{count}} 件、自動的に統合管理へインポートしました",
    "skillsFailed": "スキルの自動インポートに失敗しました",
    "skillsFailedDescription": "Skills 画面で「既存をインポート」をクリックして手動でインポートしてください（または再起動して再試行）。"
  },
  "agents": {
    "title": "エージェント"
  },
  "health": {
    "operational": "正常",
    "degraded": "低下",
    "failed": "失敗",
    "circuitOpen": "サーキットオープン",
    "consecutiveFailures": "{{count}} 回連続失敗"
  },
  "failover": {
    "enabled": "{{app}} フェイルオーバーが有効になりました",
    "disabled": "{{app}} フェイルオーバーが無効になりました",
    "toggleFailed": "操作に失敗しました: {{detail}}",
    "inQueue": "キュー内",
    "addQueue": "追加",
    "priority": {
      "tooltip": "フェイルオーバー優先度 {{priority}}"
    },
    "tooltip": {
      "enabled": "{{app}} フェイルオーバーが有効\nキューの優先度（P1→P2→...）で使用します",
      "disabled": "{{app}} フェイルオーバーを有効にする\nキューの P1 に即時切替し、失敗時は次を順に試行します",
      "takeoverRequired": "先に {{app}} を引き継いでから、フェイルオーバーを有効にしてください"
    }
  },
  "proxy": {
    "panel": {
      "serviceAddress": "サービスアドレス",
      "addressCopied": "アドレスをコピーしました",
      "currentProvider": "現在のプロバイダー:",
      "waitingFirstRequest": "現在のプロバイダー: 最初のリクエスト待ち...",
      "stoppedTitle": "ルーティングサービス停止中",
      "stoppedDescription": "上のトグルでサービスを開始できます",
      "openSettings": "ルーティングサービスを設定",
      "stats": {
        "activeConnections": "アクティブ接続",
        "totalRequests": "総リクエスト数",
        "successRate": "成功率",
        "uptime": "稼働時間"
      }
    },
    "settings": {
      "title": "ルーティングサービス設定",
      "description": "ローカルルーティングサーバーのリッスンアドレス、ポート、実行パラメータを設定します。保存後すぐに反映されます。",
      "alert": {
        "autoApply": "変更は実行中のルーティングサービスに自動的に同期され、手動での再起動は不要です。"
      },
      "basic": {
        "title": "基本設定",
        "description": "ルーティングサービスのリッスンアドレスとポートを設定します。"
      },
      "advanced": {
        "title": "詳細パラメータ",
        "description": "リクエストの安定性とログ記録を制御します。"
      },
      "timeout": {
        "title": "タイムアウト設定",
        "description": "ストリーミングと非ストリーミングリクエストのタイムアウトを設定します。"
      },
      "fields": {
        "listenAddress": {
          "label": "リッスンアドレス",
          "placeholder": "127.0.0.1",
          "description": "ルーティングサーバーがリッスンするIPアドレス（推奨: 127.0.0.1）"
        },
        "listenPort": {
          "label": "リッスンポート",
          "placeholder": "15721",
          "description": "ルーティングサーバーがリッスンするポート番号（1024 ~ 65535）"
        },
        "maxRetries": {
          "label": "最大リトライ回数",
          "placeholder": "3",
          "description": "リクエスト失敗時のリトライ回数（0 ~ 10）"
        },
        "requestTimeout": {
          "label": "リクエストタイムアウト（秒）",
          "placeholder": "0（無制限）または 300",
          "description": "単一リクエストの最大待機時間（0 = 無制限、または 10 ~ 600 秒）"
        },
        "enableLogging": {
          "label": "リクエスト使用量を記録",
          "description": "ルーティングリクエストの使用量と状態をローカル統計データベースに保存"
        },
        "streamingFirstByteTimeout": {
          "label": "ストリーミング初回バイトタイムアウト（秒）",
          "description": "最初のデータチャンクを待つ最大時間"
        },
        "streamingIdleTimeout": {
          "label": "ストリーミングアイドルタイムアウト（秒）",
          "description": "データチャンク間の最大間隔"
        },
        "nonStreamingTimeout": {
          "label": "非ストリーミングタイムアウト（秒）",
          "description": "非ストリーミングリクエストの総タイムアウト"
        }
      },
      "validation": {
        "addressInvalid": "有効なIPアドレスを入力してください",
        "portMin": "ポートは1024より大きい必要があります",
        "portMax": "ポートは65535より小さい必要があります",
        "retryMin": "リトライ回数は負の値にできません",
        "retryMax": "リトライ回数は10を超えることはできません",
        "timeoutNonNegative": "タイムアウトは負の値にできません",
        "timeoutMax": "タイムアウトは600秒を超えることはできません",
        "timeoutRange": "0または10-600の間の値を入力してください",
        "streamingTimeoutMin": "タイムアウトは少なくとも5秒必要です",
        "streamingTimeoutMax": "タイムアウトは300秒を超えることはできません"
      },
      "actions": {
        "save": "設定を保存"
      },
      "toast": {
        "saved": "ルーティング設定を保存しました",
        "saveFailed": "保存に失敗しました: {{error}}"
      },
      "invalidPort": "無効なポートです。1024〜65535 の数値を入力してください",
      "invalidAddress": "無効なアドレスです。IPv4（例: 127.0.0.1）、IPv6（例: ::1）、または localhost を入力してください",
      "configSaved": "ルーティング設定を保存しました",
      "configSaveFailed": "設定の保存に失敗しました",
      "restartRequired": "アドレスまたはポートの変更を反映するにはルーティングサービスの再起動が必要です"
    },
    "switchFailed": "切り替えに失敗しました: {{error}}",
    "takeover": {
      "ariaLabel": "{{appLabel}} ローカルルーティング",
      "hint": "ルーティングするアプリを選択します。有効にすると、そのアプリのリクエストはローカルルーティング経由で転送されます",
      "enabled": "{{app}} ルーティング有効",
      "disabled": "{{app}} ルーティング無効",
      "failed": "ルーティングの切り替えに失敗しました: {{detail}}",
      "tooltip": {
        "active": "{{appLabel}} がルーティング中 - {{address}}:{{port}}\nホットスイッチングのためプロバイダを切り替え",
        "broken": "{{appLabel}} がルーティング中ですが、ルーティングサービスが実行されていません",
        "inactive": "{{appLabel}} のリクエストをローカルルーティング経由でルーティング"
      }
    },
    "failover": {
      "proxyRequired": "フェイルオーバーを設定するには、ルーティングサービスを先に起動する必要があります",
      "autoSwitch": "自動フェイルオーバー",
      "autoSwitchDescription": "有効にするとキューの P1 に即時切り替え、リクエスト失敗時はキュー内の次のプロバイダーを自動で試行します"
    },
    "failoverQueue": {
      "title": "フェイルオーバーキュー",
      "description": "各アプリのプロバイダーのフェイルオーバー順序を管理します",
      "info": "自動フェイルオーバーを有効にすると、キューの優先度順（P1 優先）でプロバイダーを使用します。失敗時はキュー内の次のプロバイダーを順に試行します。",
      "selectProvider": "キューに追加するプロバイダーを選択",
      "noAvailableProviders": "追加できるプロバイダーがありません",
      "empty": "フェイルオーバーキューが空です。自動フェイルオーバーを有効にするにはプロバイダーを追加してください。",
      "orderHint": "キューの順序はホームのプロバイダー一覧の順序と一致します。ホームでドラッグして順序を変更できます。",
      "dragHint": "ドラッグでフェイルオーバー順序を調整します。番号が小さいほど優先度が高くなります。",
      "toggleEnabled": "有効/無効",
      "addSuccess": "フェイルオーバーキューに追加しました",
      "addFailed": "追加に失敗しました",
      "removeSuccess": "フェイルオーバーキューから削除しました",
      "removeFailed": "削除に失敗しました",
      "reorderSuccess": "キュー順序を更新しました",
      "reorderFailed": "順序の更新に失敗しました",
      "toggleFailed": "状態の更新に失敗しました"
    },
    "autoFailover": {
      "info": "フェイルオーバーキューに複数のプロバイダーが設定されている場合、リクエストが失敗すると優先度順に試行します。プロバイダーが連続失敗のしきい値に達すると、サーキットブレーカーが開き、一時的にスキップされます。",
      "configSaved": "自動フェイルオーバー設定を保存しました",
      "configSaveFailed": "保存に失敗しました",
      "validationFailed": "以下のフィールドが有効範囲外です: {{fields}}",
      "retrySettings": "リトライとタイムアウト設定",
      "failureThreshold": "失敗しきい値",
      "failureThresholdHint": "この回数連続で失敗するとサーキットブレーカーが開きます（推奨: 3-10）",
      "timeout": "回復待ち時間（秒）",
      "timeoutHint": "サーキットが開いた後、回復を試みるまでの待ち時間（推奨: 30-120）",
      "circuitBreakerSettings": "サーキットブレーカー設定",
      "successThreshold": "回復成功しきい値",
      "successThresholdHint": "半開状態でこの回数成功するとサーキットブレーカーが閉じます",
      "errorRate": "エラー率しきい値 (%)",
      "errorRateHint": "この値を超えるとサーキットブレーカーが開きます",
      "minRequests": "最小リクエスト数",
      "minRequestsHint": "エラー率を計算する前の最小リクエスト数",
      "explanationTitle": "仕組み",
      "failureThresholdLabel": "失敗しきい値",
      "failureThresholdExplain": "この回数連続で失敗すると、サーキットブレーカーが開き、プロバイダーは一時的に利用不可になります",
      "timeoutLabel": "回復待ち時間",
      "timeoutExplain": "サーキットが開いた後、半開状態を試みるまでの待ち時間",
      "successThresholdLabel": "回復成功しきい値",
      "successThresholdExplain": "半開状態でこの回数成功するとサーキットブレーカーが閉じ、プロバイダーが再び利用可能になります",
      "errorRateLabel": "エラー率しきい値",
      "errorRateExplain": "失敗しきい値に達していなくても、エラー率がこの値を超えるとサーキットブレーカーが開きます",
      "maxRetries": "最大リトライ回数",
      "timeoutSettings": "タイムアウト設定",
      "streamingFirstByte": "ストリーミング最初のバイトタイムアウト",
      "streamingIdle": "ストリーミングアイドルタイムアウト",
      "nonStreaming": "非ストリーミングタイムアウト",
      "maxRetriesHint": "リクエスト失敗時のリトライ回数（0-10）",
      "streamingFirstByteHint": "最初のデータチャンクを待つ最大時間、範囲 1-120 秒、デフォルト 60 秒",
      "streamingIdleHint": "データチャンク間の最大間隔、範囲 60-600 秒、0 で無効化（途中停止を防止）",
      "nonStreamingHint": "非ストリーミングリクエストの合計タイムアウト、範囲 60-1200 秒、デフォルト 600 秒（10 分）"
    },
    "logging": {
      "enabled": "ログ記録が有効になりました",
      "disabled": "ログ記録が無効になりました",
      "failed": "ログ状態の切り替えに失敗しました"
    },
    "server": {
      "started": "ルーティングサービスが開始されました - {{address}}:{{port}}",
      "startFailed": "ルーティングサービスの開始に失敗しました: {{detail}}",
      "stopped": "ルーティングサービスが停止しました",
      "stopFailed": "ルーティングサービスの停止に失敗しました: {{detail}}"
    },
    "stoppedWithRestore": "ルーティングサービスが停止し、すべてのルーティング設定が復元されました",
    "stopWithRestoreFailed": "停止に失敗しました: {{detail}}"
  },
  "streamCheck": {
    "reachable": "{{providerName}} は接続可能 ({{responseTimeMs}}ms)",
    "reachableSlow": "{{providerName}} は接続可能だが低速 ({{responseTimeMs}}ms)",
    "unreachable": "{{providerName}} に接続できません: {{message}}",
    "unreachableHint": "接続を確立できませんでした（DNS / 接続 / TLS / タイムアウト）。base_url とネットワークを確認してください。",
    "connectivityNote": "接続チェックはプロバイダーのアドレスに到達できるかを確認するだけで、実際のモデルリクエストは送信しません。何らかの応答があれば「到達可能」とみなされますが、認証やモデル設定が正しいことを保証するものではありません。",
    "configSaved": "接続チェック設定を保存しました",
    "configSaveFailed": "保存に失敗しました",
    "checkParams": "チェックパラメーター",
    "timeout": "タイムアウト（秒）",
    "maxRetries": "最大リトライ回数",
    "degradedThreshold": "低速判定しきい値（ミリ秒）",
    "error": "{{providerName}} のチェックでエラーが発生しました: {{error}}"
  },
  "proxyConfig": {
    "proxyEnabled": "ルーティング総スイッチ",
    "appTakeover": "ルーティング有効",
    "perAppConfig": "アプリ別設定",
    "circuitBreaker": "サーキットブレーカー",
    "circuitBreakerSettings": "サーキットブレーカー設定",
    "failureThreshold": "失敗閾値",
    "successThreshold": "回復閾値",
    "recoveryTimeout": "回復待機時間",
    "errorRateThreshold": "エラー率閾値",
    "minRequests": "最小リクエスト数",
    "timeoutConfig": "タイムアウト設定",
    "streamingFirstByte": "ストリーミング初回バイトタイムアウト",
    "streamingIdle": "ストリーミングアイドルタイムアウト",
    "nonStreaming": "非ストリーミングタイムアウト"
  },
  "universalProvider": {
    "duplicate": "複製",
    "duplicatedAndSynced": "統合プロバイダーを複製して同期しました",
    "duplicateError": "統合プロバイダーの複製に失敗しました",
    "title": "統合プロバイダー",
    "description": "統合プロバイダーは Claude、Codex、Gemini の設定を同時に管理します。変更は有効なすべてのアプリに自動的に同期されます。",
    "add": "統合プロバイダーを追加",
    "edit": "統合プロバイダーを編集",
    "empty": "統合プロバイダーがありません",
    "emptyHint": "下の「統合プロバイダーを追加」ボタンをクリックして作成してください",
    "selectPreset": "プリセットタイプを選択",
    "name": "名前",
    "namePlaceholder": "例：私の NewAPI",
    "baseUrl": "API URL",
    "apiKey": "API キー",
    "websiteUrl": "ウェブサイト URL",
    "websiteUrlPlaceholder": "https://example.com（オプション、リストに表示されます）",
    "notes": "メモ",
    "notesPlaceholder": "オプション：メモを追加",
    "enabledApps": "有効なアプリ",
    "modelConfig": "モデル設定",
    "model": "モデル",
    "sync": "アプリに同期",
    "synced": "すべてのアプリに同期しました",
    "syncError": "同期に失敗しました",
    "noAppsEnabled": "有効なアプリがありません",
    "added": "統合プロバイダーを追加しました",
    "addedAndSynced": "統合プロバイダーを追加して同期しました",
    "addedButSyncFailed": "統合プロバイダーを追加しましたが、同期に失敗しました",
    "updated": "統合プロバイダーを更新しました",
    "deleted": "統合プロバイダーを削除しました",
    "addFailed": "統合プロバイダーの追加に失敗しました",
    "hint": "クロスアプリ統合設定。Claude/Codex/Gemini に自動同期します",
    "manage": "管理",
    "loadError": "統合プロバイダーの読み込みに失敗しました",
    "saveError": "統合プロバイダーの保存に失敗しました",
    "deleteError": "統合プロバイダーの削除に失敗しました",
    "deleteConfirmTitle": "統合プロバイダーを削除",
    "deleteConfirmDescription": "「{{name}}」を削除してもよろしいですか？各アプリで生成されたプロバイダー設定も削除されます。",
    "syncConfirmTitle": "統合プロバイダーを同期",
    "syncConfirmDescription": "「{{name}}」を同期すると、Claude、Codex、Gemini の関連プロバイダー設定が上書きされます。続行しますか？",
    "syncConfirm": "同期",
    "saveAndSync": "保存して同期",
    "savedAndSynced": "すべてのアプリに保存・同期されました",
    "saveAndSyncError": "保存と同期に失敗しました",
    "configJsonPreview": "設定 JSON プレビュー",
    "configJsonPreviewHint": "以下は各アプリに同期される設定内容です（表示されているフィールドのみ上書きされ、他のカスタム設定は保持されます）"
  },
  "omo": {
    "editProfile": "OMO 設定を編集",
    "newProfile": "新規 OMO 設定",
    "profileName": "名前",
    "mainAgents": "メインエージェント",
    "subAgents": "サブエージェント",
    "categories": "カテゴリ",
    "customAgents": "カスタムエージェント",
    "noCustomAgents": "カスタムエージェントなし",
    "otherFields": "その他の設定",
    "globalConfig": "OMO グローバル設定",
    "globalConfigShort": "OMO 設定",
    "globalConfigSaved": "グローバル設定を保存しました",
    "addProfile": "OMO プロバイダーを追加",
    "disabledItems": "無効項目設定",
    "advanced": "詳細設定",
    "profileCreated": "OMO 設定を作成しました",
    "profileUpdated": "OMO 設定を更新しました",
    "invalidJson": "その他のフィールドに無効なJSONが含まれています",
    "confirmDelete": "設定を削除",
    "confirmDeleteMsg": "「{{name}}」を削除しますか？",
    "profileDeleted": "設定を削除しました",
    "imported": "「{{name}}」としてインポートしました",
    "import": "インポート",
    "global": "グローバル",
    "empty": "OMO 設定がありません。+ 追加またはローカルからインポートしてください。",
    "applied": "適用済み",
    "apply": "適用",
    "enable": "有効化",
    "enabled": "有効中",
    "disabled": "OMO を無効化しました",
    "disableFailed": "OMO の無効化に失敗しました: {{error}}",
    "selectPlaceholder": "選択してください...",
    "clear": "クリア",
    "clearWrapped": "(クリア)",
    "defaultWrapped": "(デフォルト)",
    "variantPlaceholder": "variant",
    "selectEnabledModel": "設定済みモデルを選択",
    "selectModel": "設定済みモデルを選択",
    "recommendedHint": "推奨: {{model}}",
    "searchModel": "モデルを検索...",
    "selectModelFirst": "先にモデルを選択",
    "noEnabledModels": "設定済みモデルがありません",
    "noVariantsForModel": "このモデルには思考レベルがありません",
    "currentValueNotEnabled": "{{value}} (現在値・未設定)",
    "currentValueUnavailable": "{{value}} (現在値・利用不可)",
    "advancedLabel": "詳細",
    "advancedJsonInvalid": "詳細 JSON が不正です",
    "advancedJsonHint": "temperature, top_p, budgetTokens, prompt_append, permission など。空欄でデフォルトを使用します",
    "noEnabledModelsWarning": "利用可能な設定済みモデルがありません。先に OpenCode モデルを設定してください。",
    "modelSourcePartialWarning": "一部プロバイダーのモデル設定が不正なため、候補から除外しました。",
    "modelSourceFallbackWarning": "live プロバイダー状態の取得に失敗したため、設定済みプロバイダーへフォールバックしました。",
    "runtimeModelsFailedWarning": "OpenCode ランタイムモデルの取得に失敗しました。設定済みプロバイダーのモデルのみ表示します。",
    "importLocalReplaceSuccess": "ローカルファイルから読み込み、Agents/Categories/Other Fields を置き換えました",
    "importLocalFailed": "ローカルファイルの読み込みに失敗しました: {{error}}",
    "agentKeyPlaceholder": "agent キー",
    "categoryKeyPlaceholder": "カテゴリキー",
    "modelNamePlaceholder": "model-name",
    "custom": "カスタム",
    "customCategories": "カスタムカテゴリ",
    "modelConfiguration": "モデル設定",
    "fillRecommended": "推奨を入力",
    "fillRecommendedSuccess": "推奨モデル {{count}} 件を設定しました",
    "fillRecommendedPartial": "推奨モデル {{filled}} 件を設定、{{unmatched}} 件は未一致",
    "fillRecommendedMostlyUnmatched": "{{filled}} 件のみ設定、{{unmatched}} 件は未一致（例: {{examples}}）。これらのモデルを提供するプロバイダーを設定するか、代替を選択してください。",
    "fillRecommendedAllSet": "すべてのスロットにモデルが設定済みです",
    "fillRecommendedNoMatch": "推奨モデルが設定済みプロバイダーに見つかりませんでした（例: {{examples}}）",
    "configSummary": "{{agents}} 個の Agent、{{categories}} 個の Category を設定済み · ⚙ で詳細を展開",
    "enabledModelsCount": "設定済みモデル {{count}} 件",
    "source": "出典:",
    "otherFieldsJson": "その他のフィールド (JSON)",
    "slimOtherFieldsHint": "council、fallback、multiplexer、disabled_mcps、todoContinuation など、OMO Slim のトップレベル設定はここに記述します。",
    "searchOrType": "検索またはカスタム値を入力...",
    "noMatches": "一致する項目がありません",
    "jsonMustBeObject": "{{field}} は JSON オブジェクトである必要があります",
    "jsonInvalid": "{{field}} に無効な JSON が含まれています",
    "importGlobalSuccess": "ローカルファイルからグローバル設定を読み込みました（未保存）",
    "importGlobalFailed": "ローカルファイルの読み込みに失敗しました: {{error}}",
    "importLocal": "ローカルからインポート",
    "saveGlobalConfig": "グローバル設定を保存",
    "schemaUrl": "$schema",
    "resetDefault": "デフォルトに戻す",
    "sisyphusAgentConfig": "Sisyphus Agent 設定",
    "disabledAgents": "Agents",
    "disabledAgentsPlaceholder": "無効化する Agents",
    "disabledMcps": "MCPs",
    "disabledMcpsPlaceholder": "無効化する MCPs",
    "disabledHooks": "Hooks",
    "disabledHooksPlaceholder": "無効化する Hooks",
    "disabledSkills": "Skills",
    "disabledSkillsPlaceholder": "無効化する Skills",
    "advancedLsp": "LSP 設定",
    "advancedExperimental": "実験的機能",
    "advancedBackgroundTask": "バックグラウンドタスク",
    "advancedBrowserAutomation": "ブラウザ自動化",
    "advancedClaudeCode": "Claude Code",
    "agentDesc": {
      "sisyphus": "メインオーケストレーター",
      "hephaestus": "自律型ディープワーカー",
      "prometheus": "戦略プランナー",
      "atlas": "タスクマネージャー",
      "oracle": "戦略アドバイザー",
      "librarian": "マルチリポジトリ研究員",
      "explore": "高速コード検索",
      "multimodalLooker": "メディアアナライザー",
      "metis": "計画前分析アドバイザー",
      "momus": "プランレビュアー",
      "sisyphusJunior": "委任タスクエグゼキューター"
    },
    "agentTooltip": {
      "sisyphus": "メインオーケストレーター。タスクの計画、委任、並列実行を担当。拡張思考（32k バジェット）を使用し、TODO リストでワークフローを駆動してタスク完了を確保します。",
      "atlas": "メインオーケストレーター（TODO リスト保持）。実行フェーズでのタスク配分と調整を担当。すべての作業を直接行うのではなく、専門エージェントに委任します。",
      "prometheus": "戦略プランナー。インタビューモードで要件を収集し、詳細な作業計画を策定。.sisyphus/ ディレクトリ内の Markdown ファイルの読み書きのみ可能で、直接コードを書くことはありません。",
      "hephaestus": "自律型ディープワーカー（「正当な職人」）。AmpCode ディープモードに着想を得た目標指向の実行を行い、行動前に 2-5 個の探索/ライブラリアンエージェントを並列起動して調査します。",
      "oracle": "アーキテクチャ決定とデバッグのアドバイザー。読み取り専用のコンサルティングエージェントで、優れた論理的推論と深い分析を提供。ファイルの書き込みやタスクの委任はできません。",
      "librarian": "マルチリポジトリ分析とドキュメント検索の専門家。コードベースを深く理解し、エビデンスに基づく回答を提供。公式ドキュメントやオープンソース実装例の検索に長けています。",
      "explore": "高速コードベース探索とコンテキスト grep の専門家。軽量モデルを使用した高速検索で、コード構造を理解するための先鋒です。",
      "multimodalLooker": "ビジュアルコンテンツの専門家。PDF、画像、グラフなどの非テキストメディアを分析し、情報とインサイトを抽出します。",
      "metis": "プランコンサルタント。計画前に事前分析を行い、隠れた意図、曖昧な点、AI の失敗ポイントを特定して、過剰エンジニアリングを防止します。",
      "momus": "プランレビュアー。計画の明確さ、検証可能性、完全性を高精度で検証。計画が完璧になるまで却下と修正を要求します。",
      "sisyphusJunior": "カテゴリ生成のエグゼキューター。category パラメータにより自動生成され、割り当てられたタスクの実行に専念し、再委任はできません。無限委任ループを防止します。"
    },
    "categoryDesc": {
      "visualEngineering": "ビジュアル/フロントエンド工学",
      "ultrabrain": "超深度思考",
      "deep": "ディープワーク",
      "artistry": "クリエイティブ/芸術",
      "quick": "クイックレスポンス",
      "unspecifiedLow": "汎用ロースペック",
      "unspecifiedHigh": "汎用ハイスペック",
      "writing": "ライティング"
    },
    "categoryTooltip": {
      "visualEngineering": "フロントエンドとビジュアルエンジニアリングカテゴリ。UI/UX デザイン、スタイリング、アニメーション、インターフェース実装に特化。デフォルトで Gemini 3.6 Flash モデルを使用。",
      "ultrabrain": "ディープロジック推論カテゴリ。広範な分析が必要な複雑なアーキテクチャ決定に使用。デフォルトで GPT-5.3 Codex の超高推論バリアントを使用。",
      "deep": "ディープ自律問題解決カテゴリ。目標指向の実行で、行動前に徹底的な調査を実施。深い理解が必要な難問に適しています。",
      "artistry": "高度にクリエイティブで芸術的なタスクカテゴリ。斬新なアイデアとクリエイティブなソリューションを促進。デフォルトで Gemini 3.6 Flash の高推論バリアントを使用。",
      "quick": "軽量タスクカテゴリ。単一ファイルの修正、タイポ修正、簡単な調整などの些細な作業に使用。デフォルトで Claude Haiku 4.5 高速モデルを使用。",
      "unspecifiedLow": "未分類の低作業量タスクカテゴリ。他のカテゴリに該当せず作業量が小さいタスクに適用。デフォルトで Claude Sonnet 4.5 を使用。",
      "unspecifiedHigh": "未分類の高作業量タスクカテゴリ。他のカテゴリに該当せず作業量が大きいタスクに適用。デフォルトで Claude Opus 5 の max バリアントを使用。",
      "writing": "ライティングカテゴリ。ドキュメント、散文、技術文書に特化。デフォルトで Kimi K2.5 モデルを使用。"
    },
    "slimAgentDesc": {
      "orchestrator": "オーケストレーター",
      "oracle": "オラクル",
      "librarian": "ライブラリアン",
      "explorer": "エクスプローラー",
      "designer": "デザイナー",
      "fixer": "フィクサー",
      "council": "カウンシル"
    },
    "slimAgentTooltip": {
      "orchestrator": "実行コードの作成、マルチエージェントワークフローの調整、エキスパートの召喚",
      "oracle": "根本原因分析、アーキテクチャレビュー、デバッグガイダンス（読み取り専用）",
      "librarian": "ドキュメント検索、GitHubコード検索（読み取り専用）",
      "explorer": "正規表現検索、ASTパターンマッチング、ファイル検出（読み取り専用）",
      "designer": "モダンなレスポンシブデザイン、CSS/Tailwindの専門知識",
      "fixer": "コード実装、リファクタリング、テスト、検証",
      "council": "複数モデルの合議エージェント。複数の読み取り専用 councillor を並列実行し、master が最終回答を統合します。"
    }
  },
  "openclawConfig": {
    "defaultModel": {
      "title": "デフォルトモデル",
      "description": "OpenClaw のデフォルトのプライマリモデルとフォールバックモデルを設定します",
      "primary": "プライマリモデル",
      "primaryPlaceholder": "例: deepseek/deepseek-chat",
      "fallbacks": "フォールバックモデル",
      "fallbacksPlaceholder": "例: openrouter/anthropic/claude-sonnet-4.5",
      "addFallback": "フォールバックモデルを追加",
      "saved": "デフォルトモデル設定を保存しました",
      "saveFailed": "デフォルトモデルの保存に失敗しました"
    },
    "modelCatalog": {
      "title": "モデルカタログ",
      "description": "モデルのエイリアスと許可リストを設定します",
      "modelId": "モデル ID",
      "modelIdPlaceholder": "例: deepseek/deepseek-chat",
      "alias": "エイリアス",
      "aliasPlaceholder": "例: DeepSeek",
      "addEntry": "モデルを追加",
      "removeEntry": "削除",
      "saved": "モデルカタログを保存しました",
      "saveFailed": "モデルカタログの保存に失敗しました",
      "empty": "モデルカタログエントリがありません",
      "emptyHint": "エイリアスを設定するにはカタログにモデルを追加してください"
    },
    "suggestedDefaults": "推奨デフォルト設定を適用",
    "suggestedDefaultsHint": "このプリセットの推奨デフォルトモデル設定を使用します"
  },
  "subscription": {
    "title": "サブスクリプションクォータ",
    "fiveHour": "5時間",
    "sevenDay": "7日間",
    "sevenDayOpus": "7日間(Opus)",
    "sevenDayFable": "Fable",
    "sevenDaySonnet": "7日間(Sonnet)",
    "thirtyDay": "30日間",
    "geminiPro": "Pro",
    "geminiFlash": "Flash",
    "geminiFlashLite": "Flash Lite",
    "weeklyLimit": "週間",
    "monthly": "月間",
    "credits": "クレジット",
    "copilotPremium": "プレミアム",
    "utilization": "{{value}}%",
    "resetsIn": "{{time}}後にリセット",
    "extraUsage": "超過使用量",
    "expired": "セッション期限切れ",
    "expiredHint": "{{tool}}コマンドを実行してログインを更新してください",
    "queryFailed": "クエリに失敗しました",
    "refresh": "更新"
  }
}


## Full source: src/types.ts
export type ProviderCategory =
  | "official" // 官方
  | "cn_official" // 开源官方（原"国产官方"）
  | "cloud_provider" // 云服务商（AWS Bedrock 等）
  | "aggregator" // 聚合网站
  | "third_party" // 第三方供应商
  | "custom" // 自定义
  | "omo" // Oh My OpenCode
  | "omo-slim"; // Oh My OpenCode Slim

export interface Provider {
  id: string;
  name: string;
  settingsConfig: Record<string, any>; // 应用配置对象：Claude 为 settings.json；Codex 为 { auth, config }
  websiteUrl?: string;
  // 新增：供应商分类（用于差异化提示/能力开关）
  category?: ProviderCategory;
  createdAt?: number; // 添加时间戳（毫秒）
  sortIndex?: number; // 排序索引（用于自定义拖拽排序）
  // 备注信息
  notes?: string;
  // 新增：是否为商业合作伙伴
  isPartner?: boolean;
  // 可选：供应商元数据（仅存于 ~/.cc-switch/config.json，不写入 live 配置）
  meta?: ProviderMeta;
  // 图标配置
  icon?: string; // 图标名称（如 "openai", "anthropic"）
  iconColor?: string; // 图标颜色（Hex 格式，如 "#00A67E"）
  // 是否加入故障转移队列
  inFailoverQueue?: boolean;
}

export interface AppConfig {
  providers: Record<string, Provider>;
  current: string;
}

// 自定义端点配置
export interface CustomEndpoint {
  url: string;
  addedAt: number;
  lastUsed?: number;
}

// 端点候选项（用于端点测速弹窗）
export interface EndpointCandidate {
  id?: string;
  url: string;
  isCustom?: boolean;
}

import type { TemplateType } from "./config/constants";

// 用量查询脚本配置
export interface UsageScript {
  enabled: boolean; // 是否启用用量查询
  language: "javascript"; // 脚本语言
  code: string; // 脚本代码（JSON 格式配置）
  timeout?: number; // 超时时间（秒，默认 10）
  templateType?: TemplateType; // 模板类型（用于后端判断验证规则）
  apiKey?: string; // 用量查询专用的 API Key（通用模板使用）
  baseUrl?: string; // 用量查询专用的 Base URL（通用和 NewAPI 模板使用）
  accessToken?: string; // 访问令牌（NewAPI 模板使用）
  userId?: string; // 用户ID（NewAPI 模板使用）
  accessKeyId?: string; // 火山方舟 AccessKey ID（用量查询签名用，与推理 Key 分离）
  secretAccessKey?: string; // 火山方舟 SecretAccessKey
  teamOrganizationId?: string; // 智谱团队套餐组织 ID（请求头 bigmodel-organization）
  teamProjectId?: string; // 智谱团队套餐项目 ID（请求头 bigmodel-project）
  codingPlanProvider?: string; // Coding Plan 供应商标识（如 "kimi", "zhipu", "minimax"）
  autoQueryInterval?: number; // 自动查询间隔（单位：分钟，0 表示禁用）
  autoIntervalMinutes?: number; // 自动查询间隔（分钟）- 别名字段
  request?: {
    // 请求配置
    url?: string; // 请求 URL
    method?: string; // HTTP 方法
    headers?: Record<string, string>; // 请求头
    body?: any; // 请求体
  };
}

const DEFAULT_USAGE_SCRIPT: UsageScript = {
  enabled: false,
  language: "javascript",
  code: "",
  timeout: 10,
  autoQueryInterval: 5,
};

export function createUsageScript(
  overrides?: Partial<UsageScript>,
): UsageScript {
  return { ...DEFAULT_USAGE_SCRIPT, ...overrides };
}

// 单个套餐用量数据
export interface UsageData {
  planName?: string; // 套餐名称（可选）
  extra?: string; // 扩展字段，可自由补充需要展示的文本（可选）
  isValid?: boolean; // 套餐是否有效（可选）
  invalidMessage?: string; // 失效原因说明（可选，当 isValid 为 false 时显示）
  total?: number; // 总额度（可选）
  used?: number; // 已用额度（可选）
  remaining?: number; // 剩余额度（可选）
  unit?: string; // 单位（可选）
}

// 用量查询结果（支持多套餐）
export interface UsageResult {
  success: boolean;
  data?: UsageData[]; // 改为数组，支持返回多个套餐
  error?: string;
}

export type AuthBindingSource = "provider_config" | "managed_account";

export interface AuthBinding {
  source: AuthBindingSource;
  authProvider?: string;
  accountId?: string;
}

export interface ClaudeDesktopModelRoute {
  model: string;
  labelOverride?: string;
  supports1m?: boolean;
}

// 聚合供应商路由：按档位把请求分流到其他供应商的具体模型
export type AggregateTier = "sonnet" | "opus" | "haiku" | "fable";

/** 思考强度阶梯（与 Claude Desktop 的 low…max 五档一致）。 */
export type AggregateMaxEffort = "low" | "medium" | "high" | "xhigh" | "max";

export interface AggregateRouteSlot {
  /** 生成的槽位 ID（持久化，稳定的路由键）。由 assignSlotIds 写入，后端只校验。 */
  routeId: string;
  tier: AggregateTier;
  providerId: string;
  upstreamModel: string;
  label?: string;
  supports1m?: boolean;
  /** 思考强度上限（仅完整阶梯 ID 有意义；写入 profile 时透出为 maxEffort） */
  maxEffort?: AggregateMaxEffort;
}

export interface AggregateAliasRule {
  /** 请求名小写化后的前缀（运行时 trim + 小写化后按序匹配，先赢）。空前缀静默跳过。 */
  prefix: string;
  /** 目标槽位 routeId；assignSlotIds 重编号时跟随，悬空置空串（运行时跳过） */
  slotId: string;
}

export type DefaultTarget =
  | { kind: "slotId"; value: string }
  | { kind: "providerId"; value: string };

export interface AggregateRoutes {
  slots: AggregateRouteSlot[];
  defaultTarget: DefaultTarget;
  /** 默认模型（槽位 routeId）：写 profile 时置顶（第一条 = Claude Desktop 的启动默认）。
   *  未设置 = 跟随排序首位。旧数据无此字段。 */
  defaultModel?: string;
  /** 别名路由规则：槽位未命中时按前缀（小写化、按序先赢）转投。缺省 = 无规则。 */
  aliasRules?: AggregateAliasRule[];
  /** 已删除的路由 ID：跨保存保留，避免旧会话的名称被新模型复用。 */
  retiredRouteIds?: string[];
}

// Codex 聚合路由（与上面的 Claude 侧表平行、形状互不兼容：独立 meta 键
// `codexAggregateRoutes`）。没有档位 / 思考强度 / 别名层——那些是 Claude Desktop
// 的协议概念；Codex 侧只有「客户端模型名 → 目标供应商 + 上游模型」。
export interface CodexAggregateSlot {
  /** 客户端模型名（Codex CLI 从模型目录里选的 slug，路由键）。
   *  非空 + 全表唯一由后端保存校验兜底。 */
  model: string;
  /** 目标 Codex 供应商 id（被引用者受删除保护） */
  providerId: string;
  /** 发往该供应商的模型名 */
  upstreamModel: string;
  /** 模型目录显示名；留空则回落 slug（后端以 skip_serializing_if 省略空值） */
  label?: string;
}

export interface CodexAggregateRoutes {
  /** 有序（= 客户端模型目录的顺序） */
  slots: CodexAggregateSlot[];
  defaultTarget: DefaultTarget;
  /** 默认模型（槽位 model）：写 modelCatalog 时置顶、seed TOML 顶层 model 取它。
   *  未设置 = 跟随槽位首位。 */
  defaultModel?: string;
}

export type CodexChatThinkingParam =
  | "none"
  | "thinking"
  | "enable_thinking"
  | "reasoning_split";

export type CodexChatEffortParam =
  | "none"
  | "reasoning_effort"
  // OpenRouter 原生归一化对象 reasoning:{effort}（区别于顶层 OpenAI 别名 reasoning_effort）
  | "reasoning.effort";

export type CodexChatEffortValueMode =
  | "passthrough"
  | "low_high"
  | "deepseek"
  // OpenRouter effort 枚举 xhigh|high|medium|low|minimal（无 max，max 钳到 xhigh）
  | "openrouter"
  // OpenCode Zen 网关：合法档位逐模型，见 modelCatalog 各条目 reasoningLevels
  // （镜像 models.dev）；代理转换层按请求模型查表钳制，无表不发 effort 字段
  | "zen";

export type CodexChatReasoningOutputFormat =
  | "auto"
  | "reasoning_content"
  | "reasoning"
  | "reasoning_details"
  | "think_tags";

export interface CodexChatReasoning {
  supportsThinking?: boolean;
  supportsEffort?: boolean;
  thinkingParam?: CodexChatThinkingParam;
  effortParam?: CodexChatEffortParam;
  effortValueMode?: CodexChatEffortValueMode;
  // 声明性字段：标注上游 reasoning 回传位置。当前提取靠穷举字段，未读取此值（think_tags 尚未接线）。
  outputFormat?: CodexChatReasoningOutputFormat;
}

export type PromptCacheRoutingMode = "auto" | "enabled" | "disabled";

export interface LocalProxyRequestOverrides {
  headers?: Record<string, string>;
  body?: Record<string, unknown>;
}

// 供应商元数据（字段名与后端一致，保持 snake_case）
export interface ProviderMeta {
  // 自定义端点：以 URL 为键，值为端点信息
  custom_endpoints?: Record<string, CustomEndpoint>;
  // 是否在切换/同步到 live 时应用通用配置片段
  commonConfigEnabled?: boolean;
  // Claude Desktop 3P 配置写入模式
  claudeDesktopMode?: "direct" | "proxy";
  // Claude Desktop 本地路由模式：Claude-safe route -> upstream model
  claudeDesktopModelRoutes?: Record<string, ClaudeDesktopModelRoute>;
  // 聚合供应商：无端点无凭据，按模型把请求分流到其他供应商
  aggregateRoutes?: AggregateRoutes;
  // Codex 聚合供应商：同上，按客户端模型名分流（形状与 aggregateRoutes 平行但不通用）
  codexAggregateRoutes?: CodexAggregateRoutes;
  // 用量查询脚本配置
  usage_script?: UsageScript;
  // 请求地址管理：测速后自动选择最佳端点
  endpointAutoSelect?: boolean;
  // 是否为官方合作伙伴
  isPartner?: boolean;
  // 合作伙伴促销 key（用于后端识别 PackyCode 等）
  partnerPromotionKey?: string;
  // 供应商成本倍率
  costMultiplier?: string;
  // 供应商计费模式来源
  pricingModelSource?: string;
  // API 格式（Claude / Codex 供应商使用）
  // - "anthropic": 原生 Anthropic Messages API 格式，直接透传
  // - "openai_chat": OpenAI Chat Completions 格式，需要格式转换
  // - "openai_responses": OpenAI Responses API 格式，需要格式转换
  // - "gemini_native": Gemini Native generateContent API 格式，需要格式转换
  apiFormat?:
    | "anthropic"
    | "openai_chat"
    | "openai_responses"
    | "gemini_native";
  // 通用认证绑定
  authBinding?: AuthBinding;
  // Claude 认证字段名
  apiKeyField?: ClaudeApiKeyField;
  // 是否将 base_url 视为完整 API 端点（代理直接使用此 URL，不拼接路径）
  isFullUrl?: boolean;
  // Prompt cache key for OpenAI Responses-compatible endpoints (improves cache hit rate)
  promptCacheKey?: string;
  // Session-based prompt-cache routing for Codex Responses -> Chat conversions.
  // auto enables only for known-compatible upstreams; enabled/disabled are user overrides.
  promptCacheRouting?: PromptCacheRoutingMode;
  // Codex OAuth FAST mode: injects service_tier="priority" on ChatGPT Codex requests
  codexFastMode?: boolean;
  // Codex Responses -> Chat Completions reasoning capability metadata
  codexChatReasoning?: CodexChatReasoning;
  // Codex → Anthropic path: emulate the Claude Code client (disabled by default; only an explicit true enables it)
  impersonateClaudeCode?: boolean;
  // Codex → Anthropic path: override the Anthropic max_tokens (output ceiling).
  // Codex does not forward model_max_output_tokens in the request body; without
  // this the path falls back to a conservative 8192 default, which can truncate
  // long/thinking-heavy responses. When set (>0) it takes precedence over the
  // request value and the default.
  maxOutputTokens?: number;
  // Custom User-Agent for local proxy routing. Only applied by the local proxy.
  customUserAgent?: string;
  // Local proxy request overrides. Only applied by the local proxy after route transforms.
  localProxyRequestOverrides?: LocalProxyRequestOverrides;
  // Whether this provider is currently projected into an additive app's live config.
  liveConfigManaged?: boolean;
  // 供应商类型（用于识别 Copilot 等特殊供应商）
  providerType?: string;
  // GitHub Copilot 关联账号 ID（旧字段，保留兼容读取）
  githubAccountId?: string;
}

// Skill 同步方式
export type SkillSyncMethod = "auto" | "symlink" | "copy";

// Skill 存储位置
export type SkillStorageLocation = "cc_switch" | "unified";

// Claude API 格式类型
// - "anthropic": 原生 Anthropic Messages API 格式，直接透传
// - "openai_chat": OpenAI Chat Completions 格式，需要格式转换
// - "openai_responses": OpenAI Responses API 格式，需要格式转换
// - "gemini_native": Gemini Native generateContent API 格式，需要格式转换
export type ClaudeApiFormat =
  | "anthropic"
  | "openai_chat"
  | "openai_responses"
  | "gemini_native";

// Codex API 格式类型
// - "openai_responses": OpenAI Responses API 格式，直接透传
// - "openai_chat": OpenAI Chat Completions 格式，需要本地路由转换
// - "anthropic": native Anthropic Messages format, needs local routing to convert to Responses
export type CodexApiFormat = "openai_responses" | "openai_chat" | "anthropic";

export interface CodexCatalogModel {
  model: string;
  displayName?: string;
  contextWindow?: string | number;
  // Hidden provider capability metadata for the generated model catalog.
  // supportsParallelToolCalls is native-profile-only; inputModalities wins over
  // automatic text-only model detection for every profile.
  supportsParallelToolCalls?: boolean;
  inputModalities?: string[];
  // Vendor's OFFICIAL base_instructions (model identity / system preamble).
  // Codex requires this field in every catalog entry; when omitted the backend
  // falls back to a neutral default. e.g. MiMo "developed by Xiaomi".
  baseInstructions?: string;
  // Per-model reasoning effort levels exposed in the generated Codex catalog
  // (e.g. ["none", "low", "medium", "high", "xhigh", "max"]). When omitted the
  // backend keeps the template's conservative none/high default.
  reasoningLevels?: string[];
  // Per-model default reasoning effort. Only meaningful together with
  // reasoningLevels; when omitted the backend keeps the template default if it
  // is still in the list, otherwise the highest declared level.
  defaultReasoningLevel?: string;
}

// Claude 认证字段类型
export type ClaudeApiKeyField = "ANTHROPIC_AUTH_TOKEN" | "ANTHROPIC_API_KEY";

// 主页面显示的应用配置
export interface VisibleApps {
  claude: boolean;
  "claude-desktop": boolean;
  codex: boolean;
  gemini: boolean;
  grokbuild: boolean;
  opencode: boolean;
  openclaw: boolean;
  hermes: boolean;
  pi: boolean;
  mcode: boolean;
}

// WebDAV 同步状态
export interface WebDavSyncStatus {
  lastSyncAt?: number | null;
  lastError?: string | null;
  lastErrorSource?: string | null;
  lastRemoteEtag?: string | null;
  lastLocalManifestHash?: string | null;
  lastRemoteManifestHash?: string | null;
}

// WebDAV 同步配置
export interface WebDavSyncSettings {
  enabled?: boolean;
  autoSync?: boolean;
  baseUrl?: string;
  username?: string;
  password?: string;
  remoteRoot?: string;
  profile?: string;
  status?: WebDavSyncStatus;
}

// S3 同步配置
export interface S3SyncSettings {
  enabled?: boolean;
  autoSync?: boolean;
  region?: string;
  bucket?: string;
  accessKeyId?: string;
  secretAccessKey?: string;
  endpoint?: string;
  remoteRoot?: string;
  profile?: string;
  status?: WebDavSyncStatus;
}

export type RemoteSnapshotLayout = "current" | "legacy";

// 远端快照信息（下载前预览）
export interface RemoteSnapshotInfo {
  deviceName: string;
  createdAt: string;
  snapshotId: string;
  version: number;
  protocolVersion: number;
  dbCompatVersion?: number | null;
  compatible: boolean;
  artifacts: string[];
  layout: RemoteSnapshotLayout;
  remotePath: string;
}

// 应用设置类型（用于设置对话框与 Tauri API）
// 存储在本地 ~/.cc-switch/settings.json，不随数据库同步
export interface ClaudeDesktopDisplay {
  name: string;
  subtitle: string;
  attribution: boolean;
}

export interface Settings {
  // ===== 设备级 UI 设置 =====
  // 是否在系统托盘（macOS 菜单栏）显示图标
  showInTray: boolean;
  // 点击关闭按钮时是否最小化到托盘而不是关闭应用
  minimizeToTrayOnClose: boolean;
  // 是否启用应用级窗口控制按钮（最小化/最大化/关闭）
  useAppWindowControls?: boolean;
  // 启用 Claude 插件联动（写入 ~/.claude/config.json 的 primaryApiKey）
  enableClaudePluginIntegration?: boolean;
  // 跳过 Claude Code 初次安装确认（写入 ~/.claude.json 的 hasCompletedOnboarding）
  skipClaudeOnboarding?: boolean;
  // 是否开机自启
  launchOnStartup?: boolean;
  // 静默启动（程序启动时不显示主窗口）
  silentStartup?: boolean;
  // 是否启用主页面本地代理功能（默认关闭）
  enableLocalProxy?: boolean;
  // User has confirmed the local proxy first-run notice
  proxyConfirmed?: boolean;
  // User has confirmed the usage query first-run notice
  usageConfirmed?: boolean;
  usageDashboardRefreshIntervalMs?: number;
  // 会话用量自动扫描开关（默认开启=自动模式；关闭后仅手动同步时扫描会话日志，代理记账不受影响）
  sessionAutoSyncEnabled?: boolean;
  // Whether to show the failover toggle independently on the main page
  enableFailoverToggle?: boolean;
  // Whether to show the project profile switcher on the main page header
  showProfileSwitcher?: boolean;
  // Preserve Codex ChatGPT login in auth.json when switching third-party providers
  preserveCodexOfficialAuthOnSwitch?: boolean;
  // Run official Codex under the shared "custom" provider id so future
  // sessions share one resume-history bucket with third-party providers
  unifyCodexSessionHistory?: boolean;
  // User opted in (enable dialog checkbox) to migrate existing official sessions
  unifyCodexMigrateExisting?: boolean;
  // User has confirmed the failover toggle first-run notice
  failoverConfirmed?: boolean;
  // User has confirmed the first-run welcome notice
  firstRunNoticeConfirmed?: boolean;
  // User has confirmed the auto-sync traffic warning
  autoSyncConfirmed?: boolean;
  // User has confirmed the common config first-run notice
  commonConfigConfirmed?: boolean;
  // 首选语言（可选，默认中文）
  language?: "en" | "zh" | "zh-TW" | "ja";

  // Claude Desktop 3P 左下角显示设置（deploymentDisplayName / 副标题 / 归属开关）；null=关闭
  claudeDesktopDisplay?: ClaudeDesktopDisplay | null;

  // 主页面显示的应用（默认全部显示）
  visibleApps?: VisibleApps;

  // ===== 设备级目录覆盖 =====
  // 覆盖 Claude Code 配置目录（可选）
  claudeConfigDir?: string;
  // 覆盖 Codex 配置目录（可选）
  codexConfigDir?: string;
  // 覆盖 Gemini 配置目录（可选）
  geminiConfigDir?: string;
  // 覆盖 Grok Build 配置目录（可选）
  grokConfigDir?: string;
  // 覆盖 OpenCode 配置目录（可选）
  opencodeConfigDir?: string;
  // 覆盖 OpenClaw 配置目录（可选）
  openclawConfigDir?: string;
  // 覆盖 Hermes 配置目录（可选）
  hermesConfigDir?: string;
  // 覆盖 Pi agent 配置目录（可选）
  piConfigDir?: string;

  // ===== 当前供应商 ID（设备级）=====
  // 当前 Claude 供应商 ID（优先于数据库 is_current）
  currentProviderClaude?: string;
  // 当前 Claude Desktop 供应商 ID（优先于数据库 is_current）
  currentProviderClaudeDesktop?: string;
  // 当前 Codex 供应商 ID（优先于数据库 is_current）
  currentProviderCodex?: string;
  // 当前 Gemini 供应商 ID（优先于数据库 is_current）
  currentProviderGemini?: string;

  // ===== Skill 同步设置 =====
  // Skill 同步方式：auto（默认，优先 symlink）、symlink、copy
  skillSyncMethod?: SkillSyncMethod;
  // Skill 存储位置：cc_switch（默认）或 unified（~/.agents/skills/）
  skillStorageLocation?: SkillStorageLocation;

  // ===== WebDAV v2 同步设置 =====
  webdavSync?: WebDavSyncSettings;

  // ===== S3 同步设置 =====
  s3Sync?: S3SyncSettings;

  // ===== 备份策略设置 =====
  // Auto-backup interval in hours (0=disabled, default 24)
  backupIntervalHours?: number;
  // Maximum backup files to retain (default 10)
  backupRetainCount?: number;

  // ===== 终端设置 =====
  // 首选终端应用（可选，默认使用系统默认终端）
  // macOS: "terminal" | "iterm2" | "warp" | "alacritty" | "kitty" | "ghostty" | "otty" | "wezterm" | "kaku"
  // Windows: "cmd" | "powershell" | "wt"
  // Linux: "gnome-terminal" | "konsole" | "xfce4-terminal" | "alacritty" | "kitty" | "ghostty"
  preferredTerminal?: string;

  // ===== 本机自动迁移状态 =====
  localMigrations?: {
    codexThirdPartyHistoryProviderBucketV1?: {
      completedAt: string;
      targetProviderId: string;
      sourceProviderIds?: string[];
      migratedJsonlFiles?: number;
      migratedStateRows?: number;
    };
  };
}

export interface SessionMeta {
  providerId: string;
  sessionId: string;
  title?: string;
  summary?: string;
  projectDir?: string | null;
  createdAt?: number;
  lastActiveAt?: number;
  sourcePath?: string;
  resumeCommand?: string;
}

export interface SessionMessage {
  role: string;
  content: string;
  ts?: number;
}

// MCP 服务器连接参数（宽松：允许扩展字段）
export interface McpServerSpec {
  // 可选：社区常见 .mcp.json 中 stdio 配置可不写 type
  type?: "stdio" | "http" | "sse";
  // stdio 字段
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  cwd?: string;
  // http 和 sse 字段
  url?: string;
  headers?: Record<string, string>;
  // 通用字段
  [key: string]: any;
}

// v3.7.0: MCP 服务器应用启用状态
export interface McpApps {
  mcode?: boolean;
  claude: boolean;
  "claude-desktop"?: boolean;
  codex: boolean;
  gemini: boolean;
  grokbuild?: boolean;
  opencode: boolean;
  openclaw: boolean;
  hermes: boolean;
}

// MCP 服务器条目（v3.7.0 统一结构）
export interface McpServer {
  id: string;
  name: string;
  server: McpServerSpec;
  apps: McpApps; // v3.7.0: 标记应用到哪些客户端
  description?: string;
  tags?: string[];
  homepage?: string;
  docs?: string;
  // 兼容旧字段（v3.6.x 及以前）
  enabled?: boolean; // 已废弃，v3.7.0 使用 apps 字段
  source?: string;
  [key: string]: any;
}

// MCP 服务器映射（id -> McpServer）
export type McpServersMap = Record<string, McpServer>;

// MCP 配置状态
export interface McpStatus {
  userConfigPath: string;
  userConfigExists: boolean;
  serverCount: number;
}

// 新：来自 config.json 的 MCP 列表响应
export interface McpConfigResponse {
  configPath: string;
  servers: Record<string, McpServer>;
}

// ============================================================================
// 统一供应商（Universal Provider）- 跨应用共享配置
// ============================================================================

// 统一供应商的应用启用状态
export interface UniversalProviderApps {
  claude: boolean;
  codex: boolean;
  gemini: boolean;
}

// Claude 模型配置
export interface ClaudeModelConfig {
  model?: string;
  haikuModel?: string;
  sonnetModel?: string;
  opusModel?: string;
}

// Codex 模型配置
export interface CodexModelConfig {
  model?: string;
  reasoningEffort?: string;
}

// Gemini 模型配置
export interface GeminiModelConfig {
  model?: string;
}

// 各应用的模型配置
export interface UniversalProviderModels {
  claude?: ClaudeModelConfig;
  codex?: CodexModelConfig;
  gemini?: GeminiModelConfig;
}

// 统一供应商（跨应用共享配置）
export interface UniversalProvider {
  id: string;
  name: string;
  providerType: string; // "newapi" | "custom" 等
  apps: UniversalProviderApps;
  baseUrl: string;
  apiKey: string;
  models: UniversalProviderModels;
  websiteUrl?: string;
  notes?: string;
  icon?: string;
  iconColor?: string;
  meta?: ProviderMeta;
  createdAt?: number;
  sortIndex?: number;
}

// 统一供应商映射（id -> UniversalProvider）
export type UniversalProvidersMap = Record<string, UniversalProvider>;

// ============================================================================
// OpenCode 专属配置（v3.9.2+）
// ============================================================================

// OpenCode 模型配置
export interface OpenCodeModel {
  name: string;
  limit?: {
    context?: number;
    output?: number;
  };
  options?: Record<string, unknown>; // 模型级别额外选项（provider 路由等）
  // 支持任意额外字段（cost、modalities、thinking、variants 等）
  [key: string]: unknown;
}

// OpenCode 供应商选项
export interface OpenCodeProviderOptions {
  baseURL?: string;
  apiKey?: string;
  headers?: Record<string, string>;
  // 支持额外选项（timeout, setCacheKey 等）
  [key: string]: unknown;
}

// OpenCode 供应商配置（settings_config 结构）
export interface OpenCodeProviderConfig {
  npm: string; // AI SDK 包名，如 "@ai-sdk/openai-compatible"
  name?: string; // 供应商显示名称
  options: OpenCodeProviderOptions;
  models: Record<string, OpenCodeModel>;
}

// OpenCode MCP 服务器配置（与统一格式不同）
export interface OpenCodeMcpServerSpec {
  type: "local" | "remote";
  // local 类型字段
  command?: string[]; // 与统一格式不同：命令和参数合并为数组
  environment?: Record<string, string>; // 与统一格式不同：使用 environment 而非 env
  // remote 类型字段
  url?: string;
  headers?: Record<string, string>;
  // 通用字段
  enabled?: boolean;
}

// ============================================================================
// OpenClaw 专属配置（v3.11.0+）
// ============================================================================

// OpenClaw 模型配置
export interface OpenClawModel {
  id: string;
  name: string;
  alias?: string;
  reasoning?: boolean; // 是否支持推理模式（如 o1、DeepSeek R1）
  input?: string[]; // 支持的输入类型（如 ["text"]、["text", "image"]）
  cost?: {
    input: number;
    output: number;
    cacheRead?: number; // 缓存读取价格
    cacheWrite?: number; // 缓存写入价格
  };
  contextWindow?: number;
  maxTokens?: number; // 最大输出 token 数
  compat?: {
    maxTokensField?: string; // 最大输出 token 请求字段名（如 "max_tokens"）
  };
}

// OpenClaw 默认模型配置（agents.defaults.model）
export interface OpenClawDefaultModel {
  primary: string;
  fallbacks?: string[];
}

// OpenClaw 模型目录条目（agents.defaults.models 中的值）
export interface OpenClawModelCatalogEntry {
  alias?: string;
}

export interface OpenClawHealthWarning {
  code: string;
  message: string;
  path?: string;
}

export interface OpenClawWriteOutcome {
  backupPath?: string;
  warnings: OpenClawHealthWarning[];
}

export type OpenClawToolsProfile = "minimal" | "coding" | "messaging" | "full";

// OpenClaw 供应商配置（settings_config 结构）
// 对应 OpenClaw 的 models.providers.<provider-id> 配置
export interface OpenClawProviderConfig {
  baseUrl?: string; // API 端点
  apiKey?: string; // API 密钥
  api?: string; // API 协议类型（如 "openai-completions"、"anthropic"）
  models?: OpenClawModel[]; // 可用模型列表
  headers?: Record<string, string>; // 自定义请求头（如 User-Agent）
  authHeader?: boolean; // 供应商自定义认证开关（如 Longcat）
}

// OpenClaw agents.defaults 完整配置
export interface OpenClawAgentsDefaults {
  model?: OpenClawDefaultModel;
  models?: Record<string, OpenClawModelCatalogEntry>;
  timeoutSeconds?: number;
  timeout?: number;
  [key: string]: unknown; // preserve unknown fields
}

// OpenClaw env 配置（openclaw.json 的 env 节点）
export interface OpenClawEnvConfig {
  [key: string]: unknown;
}

// OpenClaw tools 配置（openclaw.json 的 tools 节点）
export interface OpenClawToolsConfig {
  profile?: OpenClawToolsProfile | string;
  allow?: string[];
  deny?: string[];
  [key: string]: unknown; // preserve unknown fields
}

// ============================================================================
// Hermes Agent 专属配置
// ============================================================================

export interface HermesModelConfig {
  default?: string;
  provider?: string;
  base_url?: string;
  context_length?: number;
  max_tokens?: number;
  [key: string]: unknown;
}

export type HermesMemoryKind = "memory" | "user";

export interface HermesMemoryLimits {
  memory: number;
  user: number;
  memoryEnabled: boolean;
  userEnabled: boolean;
}


## Full source: src/utils/aggregateRoutes.ts
import type {
  AggregateRouteSlot,
  AggregateRoutes,
  AggregateTier,
  Provider,
} from "@/types";
import { effortLevelsFor } from "./claudeDesktopCapability";

/**
 * 每个档位的 **Claude Desktop 认得**的真模型 ID 池，按优先级排列。
 *
 * ID 决定了模型在 Claude Desktop 里的**能力画像**，其中一项是「有没有推理强度选择」。
 * 实测（2.2553.1.0，`app.asar` 内 `lPt(id)`）：
 *
 * ```js
 * lPt = (id) => XNt[qAt(id)] ?? (ZNt.test(id) ? YNt : undefined)   // 都不中 → 没有强度控件
 * XNt = { "claude-opus-4-8": {effortLevels:[low…max]}, … }          // 精确表：真 Anthropic ID
 * ZNt = /^(?:claude-)?(?:fable|mythos)(?:-|$)/                      // fable/mythos 族走正则
 * ```
 *
 * 也就是说 `claude-opus-1` 这种自造 ID 既不在表里、也不匹配该正则，**整条模型就没有
 * 推理强度控件**（而 `claude-fable-*` 反而有——它命中了族正则）。用户此前手写的
 * profile 也是这个套路：`name` 用真 ID（`claude-opus-4-8`）承载能力画像，`labelOverride`
 * 才是给人看的「实际调用的模型」。故这里按档位给出 ID 池，序号逐个取用。
 *
 * 阶梯明细见 claudeDesktopCapability.ts（EXACT_LADDERS）：`4-8`/`4-7` 含 xhigh，
 * `4-6` 无 xhigh 但有阶梯（低版本 asar 曾只有 extended 开关，已过时）；不取
 * `claude-opus-5`（它 `disallowThinkingDisabled`，会强制开启思考）。池子用尽后退回 `claude-{档位}-{序号}`：形状合法、可路由，
 * 只是那条不再有强度控件。
 *
 * 池 keyed by 槽位序号（该档位第几个槽），可以留空位——空位序号走溢出，
 * 用于「存量槽已占溢出 ID、新槽拿真 ID」的场景（如需为存量槽保 ID 可留空位）。
 *
 * 池内 ID 形如 `claude-{档位}-{数字}` 时会与溢出生成值撞名（`claude-sonnet-5` 踩过：
 * 同档第 5 个槽位也生成 `claude-sonnet-5`，两条槽位同 ID，后端去重吃掉一条），
 * 故 slotId 的溢出路径会跳过池内已占用的名字；assignSlotIds 批量分配时再传一个
 * 本次已分配的集合，溢出同时让开同伴（序号 5 让出 sonnet-5 取 6 后，序号 6 取 7）。
 */
const RECOGNIZED_IDS: Record<
  AggregateTier,
  Readonly<Partial<Record<number, string>>>
> = {
  opus: { 1: "claude-opus-4-8", 2: "claude-opus-4-7", 3: "claude-opus-4-6" },
  // claude-sonnet-5 在 Desktop 精确表内且阶梯最全（low…xhigh…max）。
  // 序号 4 固化 claude-sonnet-3：claude-sonnet-4 已被 CLI 目录退役（2026-06-15），
  // 与目录条目撞名的 ID 会被 /model 选择器过滤；合成名经 behavesAs 永远可显示。
  sonnet: {
    1: "claude-sonnet-4-6",
    2: "claude-sonnet-4-5",
    3: "claude-sonnet-5",
    4: "claude-sonnet-3",
  },
  haiku: { 1: "claude-haiku-4-5" },
  // fable 族的强度阶梯由族正则兜底，序号可无限生成，通常无需 ID 池。
  // 序号 5 固化 claude-fable-6：claude-fable-5 被 CLI 目录降级进 overflow 区
  // （继任 Fable 5.1 占 main），同名行在 /model 选择器被压走；合成名无此问题。
  fable: { 5: "claude-fable-6" },
};

/**
 * 生成槽位 ID：优先取该档位的真模型 ID，用尽后退回 `claude-{档位}-{序号}`。
 *
 * 这个字符串就是 Claude Desktop 模型列表里的 `inferenceModels[].name`，也是请求按
 * 模型分流的键，因此**必须过 Claude Desktop 的校验**。实测（2.2553.1.0）它的校验是
 * 「厂商词黑名单 + Anthropic 形状」：
 *
 * ```js
 * Vxe = /ark-code|…|deepseek|glm|gpt|gemini|grok|kimi|qwen|…/   // 厂商词
 * Go  = (name) => Vxe.test(name) ? false : Wo.test(name) || name.includes("claude")
 * ```
 *
 * 名字里只要出现 deepseek/glm 这类厂商词就会被判为 "is not an Anthropic model" 并从
 * 列表移除，**且是整组生效**——旧方案把供应商名 slug 进 ID（`claude-fable-deepseek`、
 * `claude-fable-zhipu-glm`），四个槽位被删光、选择器变空。故 ID 与供应商名无关，
 * 可读性交给「显示名」（`labelOverride`，不受该校验约束）。
 */
export function slotId(
  tier: AggregateTier,
  ordinal: number,
  taken: ReadonlySet<string> = new Set(),
): string {
  const pooled = RECOGNIZED_IDS[tier][ordinal];
  if (pooled) return pooled;
  const poolValues = new Set(Object.values(RECOGNIZED_IDS[tier]));
  let n = ordinal;
  let candidate = `claude-${tier}-${n}`;
  // 溢出：跳过池内已占用的名字（如 sonnet-5 入池后序号 5 顺移）以及与同批
  // 已分配同伴的撞名（assignSlotIds 传入 taken）。
  while (poolValues.has(candidate) || taken.has(candidate)) {
    n += 1;
    candidate = `claude-${tier}-${n}`;
  }
  return candidate;
}

/** 供应商是否为聚合供应商。 */
export function isAggregateProvider(provider: Pick<Provider, "meta">): boolean {
  return Boolean(provider.meta?.aggregateRoutes);
}

/** 对齐同版本后端的 Claude-safe ID 判定；保存校验仍以后端为权威。 */
function isCompatibleRouteId(id: string): boolean {
  const value = id.trim().toLowerCase();
  const vendor =
    /ark-code|astron|command-r|deepseek|doubao|gemini|gemma|glm|gpt|grok|hermes|hy3|kimi|lfm|\bling\b|llama|longcat|mimo|minimax|mistral|mixtral|moonshot|nemotron|openai|phi-|qianfan|qwen|tc-code|\bunic\b|yi-|stepfun|step-3|seed-|bytedance|hunyuan|granite|amazon\.nova|nova-|devstral|ministral|ernie|codex|arcee|trinity|abab|phi\d|\bk2\.|\bm2\.|jamba|arctic|solar|mercury|zamba|kat-coder|\bds-|dpsk/;
  return (
    !value.includes("[1m]") &&
    !vendor.test(value) &&
    /^(?:anthropic\/)?claude-(?:sonnet|opus|haiku|fable)-.+$/.test(value)
  );
}

export function needsRouteIdMigration(routes: AggregateRoutes): boolean {
  const seen = new Set<string>();
  return routes.slots.some((slot) => {
    const id = slot.routeId.trim().toLowerCase();
    const invalid = !isCompatibleRouteId(id) || seen.has(id);
    seen.add(id);
    return invalid;
  });
}

/** 仅供用户明确预览/确认迁移调用；普通编辑绝不自动转换旧 ID。 */
export function migrateIncompatibleRouteIds(
  routes: AggregateRoutes,
): AggregateRoutes {
  const counts = new Map<string, number>();
  for (const slot of routes.slots) {
    const id = slot.routeId.trim().toLowerCase();
    counts.set(id, (counts.get(id) ?? 0) + 1);
  }
  const slots = routes.slots.map((slot) => {
    const id = slot.routeId.trim().toLowerCase();
    const replace = !isCompatibleRouteId(id) || (counts.get(id) ?? 0) > 1;
    return replace ? { ...slot, routeId: "" } : slot;
  });
  const assigned = assignSlotIds({ ...routes, slots }, routes);
  const remap = new Map<string, string>();
  routes.slots.forEach((slot, i) => {
    if (slot.routeId && !remap.has(slot.routeId))
      remap.set(slot.routeId, assigned.slots[i].routeId);
  });
  return {
    ...assigned,
    slots: assigned.slots.map((slot) =>
      slot.maxEffort && !effortLevelsFor(slot.routeId).includes(slot.maxEffort)
        ? { ...slot, maxEffort: undefined }
        : slot,
    ),
    defaultTarget:
      routes.defaultTarget.kind === "slotId"
        ? {
            kind: "slotId",
            value:
              remap.get(routes.defaultTarget.value) ??
              routes.defaultTarget.value,
          }
        : routes.defaultTarget,
    defaultModel: routes.defaultModel
      ? remap.get(routes.defaultModel)
      : undefined,
    ...(routes.aliasRules
      ? {
          aliasRules: routes.aliasRules.map((rule) => ({
            ...rule,
            slotId: remap.get(rule.slotId) ?? "",
          })),
        }
      : {}),
  };
}

/** 由槽位派生标签（选择器显示名）：显式填写优先，否则「供应商 · 上游模型」。
 *
 *  未填写时**必须**给出非空默认值——空值会让 profile 省略 `labelOverride`，
 *  Claude Desktop 便退回「按 ID 自动格式化」，选择器里只剩 `claude-opus-2[1m]`
 *  这类看不出实际调用哪家模型的名字。 */
export function slotLabel(
  slot: {
    upstreamModel: string;
    label?: string;
  },
  providerName?: string,
): string {
  const explicit = slot.label?.trim();
  if (explicit && explicit.length > 0) return explicit;
  const model = slot.upstreamModel.trim();
  const name = providerName?.trim();
  if (!name) return model;
  return model ? `${name} · ${model}` : name;
}

/** 路由表是否可保存（至少一个槽位，且默认目标已选定非空值）。 */
export function canSaveAggregateRoutes(
  routes: AggregateRoutes | undefined | null,
): boolean {
  return Boolean(
    routes &&
      routes.slots.length > 0 &&
      routes.defaultTarget?.value.trim() &&
      (routes.defaultTarget.kind !== "slotId" ||
        routes.slots.some(
          (s) => s.routeId.trim() === routes.defaultTarget.value.trim(),
        )),
  );
}

/**
 * 供应商卡内档位行的固定顺序（从强到弱）。槽位在 `slots[]` 里的持久化顺序
 * 就是按这个序展平的（见 `flattenProviderGroups`），保证 ID 分配确定。
 */
export const TIER_ROW_ORDER: readonly AggregateTier[] = [
  "fable",
  "opus",
  "sonnet",
  "haiku",
];

/** 供应商卡的视图形状：一家供应商 + 各档位已映射的槽位（未映射的档位无键）。 */
export interface ProviderTierRows {
  providerId: string;
  rows: Partial<Record<AggregateTier, AggregateRouteSlot[]>>;
}

/**
 * 扁平槽位按供应商分组（编辑器渲染用）。卡序 = 供应商在列表里的首次出现顺序。
 * 同供应商同档位可以有多个模型，按原出现顺序完整保留。
 */
export function groupSlotsByProvider(
  slots: AggregateRouteSlot[],
): ProviderTierRows[] {
  const cards: ProviderTierRows[] = [];
  const byProvider = new Map<string, ProviderTierRows>();
  for (const slot of slots) {
    let card = byProvider.get(slot.providerId);
    if (!card) {
      card = { providerId: slot.providerId, rows: {} };
      byProvider.set(slot.providerId, card);
      cards.push(card);
    }
    (card.rows[slot.tier] ??= []).push(slot);
  }
  return cards;
}

/** 卡序 × 档位序（`TIER_ROW_ORDER`）重建扁平槽位数组，未映射档位不产出。 */
export function flattenProviderGroups(
  cards: ProviderTierRows[],
): AggregateRouteSlot[] {
  return cards.flatMap((card) => {
    const rows: AggregateRouteSlot[] = [];
    for (const tier of TIER_ROW_ORDER) {
      rows.push(...(card.rows[tier] ?? []));
    }
    return rows;
  });
}

/** 只给新槽位分配 ID；既有身份不随编辑或排序改变。删除记录跨保存保留。 */
export function assignSlotIds(
  routes: AggregateRoutes,
  previous?: AggregateRoutes,
): AggregateRoutes {
  const activeIds = new Set(routes.slots.map((s) => s.routeId).filter(Boolean));
  const retired = new Set([
    ...(previous?.retiredRouteIds ?? []),
    ...(routes.retiredRouteIds ?? []),
  ]);
  for (const slot of previous?.slots ?? []) {
    if (slot.routeId && !activeIds.has(slot.routeId)) retired.add(slot.routeId);
  }
  const canonical = (id: string) => id.trim().toLowerCase();
  const taken = new Set([...activeIds, ...retired].map(canonical));
  // 悬空引用也不得被一条新行悄悄认领；默认目标留给保存校验要求重新选择。
  if (routes.defaultTarget.kind === "slotId" && routes.defaultTarget.value)
    taken.add(canonical(routes.defaultTarget.value));
  if (routes.defaultModel) taken.add(canonical(routes.defaultModel));
  for (const rule of routes.aliasRules ?? [])
    if (rule.slotId) taken.add(canonical(rule.slotId));
  const slots = routes.slots.map((slot) => {
    if (slot.routeId) return { ...slot };
    let ordinal = 1;
    let id = slotId(slot.tier, ordinal, taken);
    while (taken.has(canonical(id))) id = slotId(slot.tier, ++ordinal, taken);
    taken.add(canonical(id));
    return { ...slot, routeId: id };
  });
  const live = new Set(slots.map((s) => s.routeId.trim()));
  const defaultModel =
    routes.defaultModel && live.has(routes.defaultModel.trim())
      ? routes.defaultModel
      : undefined;
  const aliasRules = routes.aliasRules?.map((rule) => ({
    ...rule,
    slotId: rule.slotId && live.has(rule.slotId.trim()) ? rule.slotId : "",
  }));
  return {
    ...routes,
    slots,
    defaultModel,
    ...(aliasRules ? { aliasRules } : {}),
    ...(retired.size ? { retiredRouteIds: [...retired] } : {}),
  };
}


## Full source: src/utils/aggregateRoutes.test.ts
import { describe, expect, it } from "vitest";
import type { AggregateAliasRule } from "@/types";
import {
  assignSlotIds,
  canSaveAggregateRoutes,
  flattenProviderGroups,
  groupSlotsByProvider,
  slotId,
  slotLabel,
  TIER_ROW_ORDER,
} from "./aggregateRoutes";

const TIERS = ["sonnet", "opus", "haiku", "fable"] as const;

describe("slotId", () => {
  it("优先取 Claude Desktop 认得的真实 ID（推理强度控件只认这些）", () => {
    expect(slotId("opus", 1)).toBe("claude-opus-4-8");
    expect(slotId("opus", 2)).toBe("claude-opus-4-7");
    expect(slotId("sonnet", 1)).toBe("claude-sonnet-4-6");
    expect(slotId("sonnet", 3)).toBe("claude-sonnet-5");
    expect(slotId("haiku", 1)).toBe("claude-haiku-4-5");
  });

  it("fable 族按序号生成（该族走正则，任意序号都有强度阶梯）", () => {
    expect(slotId("fable", 1)).toBe("claude-fable-1");
    expect(slotId("fable", 7)).toBe("claude-fable-7");
  });

  it("溢出让开池内已占用的名字（claude-sonnet-5 在池内，序号 5 顺移）", () => {
    expect(slotId("sonnet", 5)).toBe("claude-sonnet-6");
    expect(slotId("sonnet", 6)).toBe("claude-sonnet-6"); // 单次调用无状态，见下条批量保证
  });

  it("池子用尽后退回 claude-{档位}-{序号}", () => {
    expect(slotId("sonnet", 2)).toBe("claude-sonnet-4-5");
    expect(slotId("sonnet", 7)).toBe("claude-sonnet-7");
    expect(slotId("haiku", 2)).toBe("claude-haiku-2");
    expect(slotId("opus", 4)).toBe("claude-opus-4");
  });

  it("池固化避开 CLI 目录生命周期撞名（sonnet-4 退役 / fable-5 降级 overflow）", () => {
    // 与 CLI 目录条目撞名的真 ID 会被 /model 选择器过滤（退役硬拒 / 溢出排尾），
    // 合成名经 behavesAs 永远可显示——这两个池值把存量槽的新名固化成不动点。
    expect(slotId("sonnet", 4)).toBe("claude-sonnet-3");
    expect(slotId("fable", 5)).toBe("claude-fable-6");
  });

  it("同档位的 ID 互不相同（assignSlotIds 批量路径，池内 + 溢出混合）", () => {
    // 池里若混进 claude-{档位}-{数字} 形状的 ID，就会和溢出生成值撞名，
    // 两条槽位同 ID 会被后端去重吃掉一条（claude-sonnet-5 踩过）。
    // 批量分配时溢出还会让开本次已分配的 ID（如序号 5 让出 sonnet-5 后取 6，
    // 序号 6 不能再取 6）。唯一性由 assignSlotIds 的有状态分配保证。
    for (const tier of TIERS) {
      const routes = {
        slots: Array.from({ length: 20 }, () => ({
          routeId: "",
          tier,
          providerId: "p",
          upstreamModel: "m",
          supports1m: false,
        })),
        defaultTarget: { kind: "providerId" as const, value: "p" },
      };
      const ids = assignSlotIds(routes).slots.map((s) => s.routeId);
      expect(new Set(ids).size).toBe(ids.length);
    }
  });

  it("ID 里绝不出现供应商名（厂商词会让 Claude Desktop 整组丢弃模型列表）", () => {
    // 实测（Claude Desktop 2.2553.1.0，main.log 已确证）：模型列表里凡是名字含
    // deepseek/glm/kimi/gpt/qwen/gemini… 这类**厂商词**的条目，都会被判为
    // "is not an Anthropic model" 从列表移除。旧方案 claude-{tier}-{供应商名 slug}
    // 恰好撞上这条黑名单（claude-fable-deepseek、claude-fable-zhipu-glm），
    // 四个槽位被删光、选择器变空。ID 必须与供应商名无关，可读性交给「显示名」。
    for (const tier of TIERS) {
      for (let ordinal = 1; ordinal <= 20; ordinal += 1) {
        expect(slotId(tier, ordinal)).not.toMatch(
          /deepseek|glm|kimi|gpt|gemini|qwen/i,
        );
      }
    }
  });

  it("产物满足后端 is_claude_safe_model_id 形状", () => {
    // claude-{sonnet|opus|haiku|fable}-{非空}
    for (const tier of TIERS) {
      for (let ordinal = 1; ordinal <= 20; ordinal += 1) {
        expect(slotId(tier, ordinal)).toMatch(
          /^claude-(sonnet|opus|haiku|fable)-.+$/,
        );
      }
    }
  });
});

describe("slotLabel", () => {
  it("显式显示名优先（去掉首尾空白）", () => {
    expect(
      slotLabel(
        { upstreamModel: "glm-5.3", label: "  智谱 GLM  " },
        "智谱 GLM",
      ),
    ).toBe("智谱 GLM");
  });

  it("未填写时回落为「供应商 · 上游模型」", () => {
    expect(slotLabel({ upstreamModel: "glm-5.3" }, "智谱 GLM")).toBe(
      "智谱 GLM · glm-5.3",
    );
    expect(
      slotLabel({ upstreamModel: "glm-5.3", label: "   " }, "智谱 GLM"),
    ).toBe("智谱 GLM · glm-5.3");
  });

  it("缺任一侧时只显示存在的一侧", () => {
    expect(slotLabel({ upstreamModel: "glm-5.3" })).toBe("glm-5.3");
    expect(slotLabel({ upstreamModel: "  " }, "智谱 GLM")).toBe("智谱 GLM");
  });
});

describe("canSaveAggregateRoutes", () => {
  const slot = {
    routeId: "claude-sonnet-glm",
    tier: "sonnet" as const,
    providerId: "p-glm",
    upstreamModel: "glm-5.3",
  };

  it("需要至少一个槽位与一个非空默认目标值", () => {
    expect(
      canSaveAggregateRoutes({
        slots: [slot],
        defaultTarget: { kind: "providerId", value: "p-glm" },
      }),
    ).toBe(true);
  });

  it("默认目标值为空白（未选择）时不可保存", () => {
    expect(
      canSaveAggregateRoutes({
        slots: [slot],
        defaultTarget: { kind: "providerId", value: "" },
      }),
    ).toBe(false);
    expect(
      canSaveAggregateRoutes({
        slots: [slot],
        defaultTarget: { kind: "slotId", value: "   " },
      }),
    ).toBe(false);
  });

  it("无槽位或路由表为空时不可保存", () => {
    expect(
      canSaveAggregateRoutes({
        slots: [],
        defaultTarget: { kind: "providerId", value: "p-glm" },
      }),
    ).toBe(false);
    expect(canSaveAggregateRoutes(undefined)).toBe(false);
    expect(canSaveAggregateRoutes(null)).toBe(false);
  });
});

describe("assignSlotIds", () => {
  const base = {
    defaultTarget: { kind: "providerId" as const, value: "p-glm" },
  };

  it("按档位分别编号：同档第 1、2 个依次取该档 ID 池", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "flash",
        },
        {
          routeId: "",
          tier: "sonnet",
          providerId: "p-glm",
          upstreamModel: "pro",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-sonnet-4-6",
      "claude-sonnet-4-5",
    ]);
  });

  it("不同档位各自从池首开始", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        { routeId: "", tier: "sonnet", providerId: "p-ds", upstreamModel: "a" },
        { routeId: "", tier: "opus", providerId: "p-ds", upstreamModel: "b" },
        {
          routeId: "",
          tier: "sonnet",
          providerId: "p-glm",
          upstreamModel: "c",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-sonnet-4-6",
      "claude-opus-4-8",
      "claude-sonnet-4-5",
    ]);
  });

  it("编辑档位元数据不隐式改变已有 ID", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-sonnet-4-6",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "flash",
        },
      ],
    });
    expect(next.slots[0].routeId).toBe("claude-sonnet-4-6");
  });

  it("重复存量 ID 不被隐式迁移，仍由后端保存校验拒绝", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-sonnet-stale",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "flash",
        },
        {
          routeId: "claude-sonnet-stale",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "pro",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-sonnet-stale",
      "claude-sonnet-stale",
    ]);
  });

  it("上一版合法序号 ID 保留而不改变旧会话身份", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-opus-1",
          tier: "opus",
          providerId: "p-glm",
          upstreamModel: "glm-5.3-flash",
        },
        {
          routeId: "claude-opus-2",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "deepseek-flash",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-opus-1",
      "claude-opus-2",
    ]);
  });

  it("不兼容存量 ID 不在普通编辑中静默迁移", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-fable-zhipu-glm",
          tier: "fable",
          providerId: "p-glm",
          upstreamModel: "glm-5.3",
        },
      ],
    });
    expect(next.slots[0].routeId).toBe("claude-fable-zhipu-glm");
  });

  it("默认目标继续引用原槽位身份", () => {
    const next = assignSlotIds({
      defaultTarget: { kind: "slotId", value: "claude-fable-zhipu-glm" },
      slots: [
        {
          routeId: "claude-opus-deepseek",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "a",
        },
        {
          routeId: "claude-fable-zhipu-glm",
          tier: "fable",
          providerId: "p-glm",
          upstreamModel: "b",
        },
      ],
    });
    expect(next.defaultTarget).toEqual({
      kind: "slotId",
      value: "claude-fable-zhipu-glm",
    });
  });

  it("目标槽位已被删除时保持原值，绝不静默改指", () => {
    const next = assignSlotIds({
      defaultTarget: { kind: "slotId", value: "claude-fable-gone" },
      slots: [
        {
          routeId: "claude-sonnet-1",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "a",
        },
      ],
    });
    expect(next.defaultTarget).toEqual({
      kind: "slotId",
      value: "claude-fable-gone",
    });
  });

  it("assignSlotIds 保留 maxEffort 字段", () => {
    const routes = {
      slots: [
        {
          routeId: "claude-sonnet-5",
          tier: "sonnet" as const,
          providerId: "p",
          upstreamModel: "m",
          supports1m: false,
          maxEffort: "xhigh" as const,
        },
      ],
      defaultTarget: { kind: "providerId" as const, value: "p" },
    };
    expect(assignSlotIds(routes).slots[0].maxEffort).toBe("xhigh");
  });
});

describe("groupSlotsByProvider / flattenProviderGroups", () => {
  const slot = (
    routeId: string,
    tier: "fable" | "opus" | "sonnet" | "haiku",
    providerId: string,
    upstreamModel: string,
  ) => ({ routeId, tier, providerId, upstreamModel });

  it("卡序 = 供应商在扁平列表里的首次出现顺序（槽位交错也不乱）", () => {
    const cards = groupSlotsByProvider([
      slot("a", "fable", "p-glm", "glm-5.3"),
      slot("b", "opus", "p-ds", "deepseek-flash"),
      slot("c", "opus", "p-glm", "glm-5.3-flash"),
    ]);
    expect(cards.map((card) => card.providerId)).toEqual(["p-glm", "p-ds"]);
    expect(Object.keys(cards[0].rows)).toEqual(["fable", "opus"]);
    expect(cards[1].rows.opus?.[0].upstreamModel).toBe("deepseek-flash");
  });

  it("同供应商同档位所有存量模型都保留", () => {
    const cards = groupSlotsByProvider([
      slot("keep", "opus", "p-glm", "glm-5.3"),
      slot("drop", "opus", "p-glm", "glm-5.3-flash"),
    ]);
    expect(cards).toHaveLength(1);
    expect(cards[0].rows.opus?.map(s => s.routeId)).toEqual(["keep", "drop"]);
  });

  it("空列表得空卡片数组", () => {
    expect(groupSlotsByProvider([])).toEqual([]);
  });

  it("展平按卡序 × 档位固定顺序重建（fable→opus→sonnet→haiku）", () => {
    const flat = flattenProviderGroups([
      { providerId: "p-ds", rows: { opus: [slot("x", "opus", "p-ds", "d1")] } },
      {
        providerId: "p-glm",
        rows: {
          haiku: [slot("h", "haiku", "p-glm", "g3")],
          fable: [slot("f", "fable", "p-glm", "g1")],
        },
      },
    ]);
    expect(flat.map((s) => [s.providerId, s.tier])).toEqual([
      ["p-ds", "opus"],
      ["p-glm", "fable"],
      ["p-glm", "haiku"],
    ]);
  });

  it("未映射的档位不产生槽位（映射几个就有几个）", () => {
    const flat = flattenProviderGroups([
      {
        providerId: "p-glm",
        rows: { fable: [slot("f", "fable", "p-glm", "g1")] },
      },
    ]);
    expect(flat).toHaveLength(1);
  });

  it("档位行序常量与卡片渲染一致", () => {
    expect(TIER_ROW_ORDER).toEqual(["fable", "opus", "sonnet", "haiku"]);
  });
});

describe("assignSlotIds · defaultModel 跟随", () => {
  const base = {
    defaultTarget: { kind: "providerId" as const, value: "p-glm" },
  };

  it("默认模型继续引用原槽位 ID", () => {
    const next = assignSlotIds({
      ...base,
      defaultModel: "claude-opus-deepseek",
      slots: [
        {
          routeId: "claude-fable-zhipu-glm",
          tier: "fable",
          providerId: "p-glm",
          upstreamModel: "glm-5.3",
        },
        {
          routeId: "claude-opus-deepseek",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "deepseek-flash",
        },
      ],
    });
    expect(next.defaultModel).toBe("claude-opus-deepseek");
  });

  it("引用的槽位被删时置空（回落到排序首位）", () => {
    const next = assignSlotIds({
      ...base,
      defaultModel: "claude-fable-gone",
      slots: [
        {
          routeId: "claude-sonnet-1",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "a",
        },
      ],
    });
    expect(next.defaultModel).toBeUndefined();
  });

  it("未设置时保持未设置", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-sonnet-1",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "a",
        },
      ],
    });
    expect(next.defaultModel).toBeUndefined();
  });
});

describe("assignSlotIds aliasRules 跟随", () => {
  const base = {
    slots: [
      {
        routeId: "claude-sonnet-5",
        tier: "sonnet" as const,
        providerId: "p1",
        upstreamModel: "m1",
        supports1m: false,
      },
      {
        routeId: "claude-haiku-3",
        tier: "haiku" as const,
        providerId: "p1",
        upstreamModel: "m2",
        supports1m: false,
      },
    ],
    defaultTarget: { kind: "providerId" as const, value: "p1" },
  };

  it("插入新槽时别名仍引用原槽位身份", () => {
    const aliasRules: AggregateAliasRule[] = [
      { prefix: "claude-haiku", slotId: "claude-haiku-3" },
    ];
    const routes = { ...base, aliasRules };
    // 在最前插入一个 haiku 槽：新槽拿池首 claude-haiku-4-5，原 haiku-3 槽序号 2 溢出为 claude-haiku-2
    const inserted = {
      ...routes,
      slots: [
        {
          routeId: "",
          tier: "haiku" as const,
          providerId: "p1",
          upstreamModel: "m0",
          supports1m: false,
        },
        ...routes.slots,
      ],
    };
    const out = assignSlotIds(inserted);
    expect(out.slots[2].routeId).toBe("claude-haiku-3");
    expect(out.aliasRules?.[0]).toEqual({
      prefix: "claude-haiku",
      slotId: "claude-haiku-3",
    });
  });

  it("引用的槽已删时 slotId 清空、行保留", () => {
    const routes = {
      ...base,
      slots: base.slots.slice(0, 1), // 删掉 haiku 槽
      aliasRules: [{ prefix: "claude-haiku", slotId: "claude-haiku-3" }],
    };
    const out = assignSlotIds(routes);
    expect(out.aliasRules).toEqual([{ prefix: "claude-haiku", slotId: "" }]);
  });

  it("空 slotId 的规则不被 routeId 为空的新行认领", () => {
    const routes = {
      slots: [
        {
          routeId: "claude-sonnet-4",
          tier: "sonnet" as const,
          providerId: "p1",
          upstreamModel: "m1",
          supports1m: false,
        },
        {
          routeId: "",
          tier: "sonnet" as const,
          providerId: "p1",
          upstreamModel: "",
          supports1m: false,
        },
      ],
      defaultTarget: { kind: "providerId" as const, value: "p1" },
      aliasRules: [{ prefix: "claude-sonnet", slotId: "" }],
    };
    expect(assignSlotIds(routes).aliasRules).toEqual([
      { prefix: "claude-sonnet", slotId: "" },
    ]);
  });

  it("无 aliasRules 的旧数据往返后仍为 undefined", () => {
    expect(assignSlotIds(base).aliasRules).toBeUndefined();
  });
});


## Full source: src/utils/aggregateRoutes.compatibility.test.ts
import { describe, expect, it } from "vitest";
import {
  assignSlotIds,
  flattenProviderGroups,
  groupSlotsByProvider,
  migrateIncompatibleRouteIds,
  needsRouteIdMigration,
} from "./aggregateRoutes";
import type { AggregateRoutes } from "@/types";

const initial: AggregateRoutes = {
  slots: [
    {
      routeId: "claude-sonnet-4-6",
      tier: "sonnet",
      providerId: "a",
      upstreamModel: "upstream-a",
      label: "A",
      maxEffort: "high",
      supports1m: true,
    },
    {
      routeId: "claude-sonnet-4-5",
      tier: "sonnet",
      providerId: "b",
      upstreamModel: "upstream-b",
      label: "B",
    },
  ],
  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
  defaultModel: "claude-sonnet-4-6",
  aliasRules: [{ prefix: "team", slotId: "claude-sonnet-4-6" }],
};

describe("aggregate compatibility contract", () => {
  it("case-variant legacy duplicates require explicit migration and retire the entire ambiguous namespace", () => {
    const routes: AggregateRoutes = {
      ...initial,
      slots: [
        initial.slots[0],
        { ...initial.slots[1], routeId: "CLAUDE-SONNET-4-6" },
      ],
    };
    expect(needsRouteIdMigration(routes)).toBe(true);
    const next = migrateIncompatibleRouteIds(routes);
    expect(
      next.slots.every((s) => s.routeId.toLowerCase() !== "claude-sonnet-4-6"),
    ).toBe(true);
    expect(
      next.retiredRouteIds?.some(
        (id) => id.toLowerCase() === "claude-sonnet-4-6",
      ),
    ).toBe(true);
  });
  it("confirmed migration also normalizes an unsupported cap on an unchanged valid ID", () => {
    const routes: AggregateRoutes = {
      ...initial,
      slots: [
        { ...initial.slots[0], maxEffort: "xhigh" },
        { ...initial.slots[1], routeId: "claude-fable-glm", tier: "fable" },
      ],
    };
    const next = migrateIncompatibleRouteIds(routes);
    expect(next.slots[0].routeId).toBe(initial.slots[0].routeId);
    expect(next.slots[0].maxEffort).toBeUndefined();
  });
  it("explicit duplicate-ID migration removes a strength cap unsupported by the new ID", () => {
    const routes: AggregateRoutes = {
      slots: [
        { ...initial.slots[0], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
        { ...initial.slots[1], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
      ],
      defaultTarget: { kind: "providerId", value: "a" },
    };
    const migrated = migrateIncompatibleRouteIds(routes);
    expect(migrated.slots[0].routeId).toBe("claude-sonnet-4-6");
    expect(migrated.slots[0].maxEffort).toBeUndefined();
    expect(migrated.slots[1].routeId).toBe("claude-sonnet-4-5");
    expect(migrated.slots[1].maxEffort).toBeUndefined();
  });
  it("allocation does not reuse a retired ID with different letter case", () => {
    const routes: AggregateRoutes = {
      slots: [{ ...initial.slots[0], routeId: "" }],
      defaultTarget: { kind: "providerId", value: "a" },
      retiredRouteIds: ["CLAUDE-SONNET-4-6"],
    };
    expect(assignSlotIds(routes).slots[0].routeId).not.toBe(
      "claude-sonnet-4-6",
    );
  });
  it("reordering preserves the old model ID, mapping, default and alias", () => {
    const next = assignSlotIds({
      ...initial,
      slots: [...initial.slots].reverse(),
    });
    expect(
      next.slots.find((s) => s.routeId === initial.slots[0].routeId),
    ).toEqual(initial.slots[0]);
    expect(next.defaultTarget).toEqual(initial.defaultTarget);
    expect(next.defaultModel).toBe(initial.defaultModel);
    expect(next.aliasRules).toEqual(initial.aliasRules);
  });

  it("inserting a new model does not steal an existing ID", () => {
    const next = assignSlotIds({
      ...initial,
      slots: [
        {
          ...initial.slots[0],
          routeId: "",
          providerId: "new",
          upstreamModel: "new-model",
        },
        ...initial.slots,
      ],
    });
    expect(next.slots.slice(1)).toEqual(initial.slots);
    expect(next.slots[0].routeId).not.toBe(initial.slots[0].routeId);
    expect(next.defaultModel).toBe(initial.defaultModel);
  });

  it("deleting then adding and reloading cannot recycle a retired model ID", () => {
    const deleted = assignSlotIds(
      {
        ...initial,
        slots: [initial.slots[1]],
        defaultTarget: { kind: "providerId", value: "b" },
      },
      initial,
    );
    const persisted = JSON.parse(JSON.stringify(deleted)) as AggregateRoutes;
    const added = assignSlotIds(
      {
        ...persisted,
        slots: [
          ...persisted.slots,
          { ...initial.slots[0], routeId: "", upstreamModel: "new-model" },
        ],
      },
      persisted,
    );
    expect(added.slots[0].routeId).toBe(initial.slots[1].routeId);
    expect(added.slots[1].routeId).not.toBe(initial.slots[0].routeId);
    expect(
      (added as AggregateRoutes & { retiredRouteIds?: string[] })
        .retiredRouteIds,
    ).toContain(initial.slots[0].routeId);
    expect(added.aliasRules?.[0].slotId).toBe("");
  });

  it("grouping and flattening retains every model in the same provider/tier", () => {
    const slots = initial.slots.map((s) => ({ ...s, providerId: "a" }));
    expect(flattenProviderGroups(groupSlotsByProvider(slots))).toEqual(slots);
  });
});


## Full source: src/components/providers/forms/AggregateProviderFields.tsx
import { useEffect, useMemo, useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  Download,
  GripVertical,
  Loader2,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import type { CSSProperties, ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ImeSafeInput } from "@/components/ui/ime-safe-input";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ModelDropdown } from "./shared/ModelDropdown";
import type { FetchedModel } from "@/lib/api/model-fetch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useTranslation } from "react-i18next";
import type {
  AggregateAliasRule,
  AggregateMaxEffort,
  AggregateRouteSlot,
  AggregateRoutes,
  AggregateTier,
  DefaultTarget,
  Provider,
} from "@/types";
import {
  assignSlotIds,
  canSaveAggregateRoutes,
  flattenProviderGroups,
  groupSlotsByProvider,
  slotLabel,
  TIER_ROW_ORDER,
  type ProviderTierRows,
  needsRouteIdMigration,
  migrateIncompatibleRouteIds,
} from "@/utils/aggregateRoutes";
import {
  effortCapability,
  effortLevelsFor,
} from "@/utils/claudeDesktopCapability";

interface Props {
  value: AggregateRoutes;
  onChange: (next: AggregateRoutes) => void;
  /** 可作目标的常规供应商（不含聚合供应商自身与官方供应商，防止嵌套/无凭据目标） */
  candidates: Provider[];
  /** 该目标供应商已拉取到的模型列表；按供应商 id 缓存，同卡各档位共用 */
  modelsForProvider: (providerId: string) => FetchedModel[];
  /** 正在拉取的供应商 id；非 null 时所有拉取按钮进入 loading */
  fetchingProviderId: string | null;
  onFetchModels: (provider: Provider) => void;
}

/** 深拷贝卡片数组（行对象只读不改、整体替换，浅拷贝两层即可）。 */
const cloneCards = (cards: ProviderTierRows[]): ProviderTierRows[] =>
  cards.map((card) => ({
    providerId: card.providerId,
    rows: { ...card.rows },
  }));

const UNSET = "__unset__";

/** 卡片可拖拽包装：把手 props 通过 render-prop 交给卡头。 */
function SortableCard({
  id,
  children,
}: {
  id: string;
  children: (handle: ReactNode) => ReactNode;
}) {
  const { setNodeRef, attributes, listeners, transform, transition } =
    useSortable({ id });
  const style: CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };
  return (
    <div ref={setNodeRef} style={style}>
      {children(
        <button
          type="button"
          className="shrink-0 cursor-grab touch-none text-muted-foreground/60 hover:text-foreground"
          aria-label="drag"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </button>,
      )}
    </div>
  );
}

export function AggregateProviderFields({
  value,
  onChange,
  candidates,
  modelsForProvider,
  fetchingProviderId,
  onFetchModels,
}: Props) {
  const { t } = useTranslation();

  const [migrationPreview, setMigrationPreview] = useState<AggregateRoutes>();
  const [migrationBackup, setMigrationBackup] = useState(false);
  useEffect(() => {
    setMigrationPreview(undefined);
    setMigrationBackup(false);
  }, [value]);
  const downloadMigrationBackup = () => {
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "aggregate-routes-before-migration.json";
    link.click();
    URL.revokeObjectURL(url);
    setMigrationBackup(true);
  };

  // 显示名默认值要带上供应商名：同一个上游模型可能挂在两家供应商上，
  // 只写模型名仍分不清实际调用的是哪一家。
  const providerNameById = new Map(candidates.map((p) => [p.id, p.name]));
  const labelOf = (slot: AggregateRouteSlot) =>
    slotLabel(slot, providerNameById.get(slot.providerId));
  const nameOf = (id: string) => providerNameById.get(id) ?? id;

  // 编辑器按「供应商卡」渲染，存储仍是扁平 slots[]（分组是纯视图概念，
  // 后端与持久化零改动）。供应商被选了但还没映射任何档位时，slots 里没有
  // 它的痕迹，用 pendingProviders 记住这张空卡，否则它会在重渲染时消失。
  const [pendingProviders, setPendingProviders] = useState<string[]>([]);

  // 折叠状态：expandedIds 里的卡展开，其余（含新卡）默认折叠。
  // 用「展开集合」而非「折叠集合」：新增卡无需手动登记即默认折叠。
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  const grouped = useMemo(
    () => groupSlotsByProvider(value.slots),
    [value.slots],
  );
  const cards = useMemo(() => {
    const groupedIds = new Set(grouped.map((card) => card.providerId));
    const extras = pendingProviders
      .filter((id) => !groupedIds.has(id))
      .map((id): ProviderTierRows => ({ providerId: id, rows: {} }));
    return [...grouped, ...extras];
  }, [grouped, pendingProviders]);

  // 新行分配 ID；既有 ID 不因排序或编辑变化。
  // assignSlotIds 保留既有身份，并记录删除的 ID 防止重用，
  // 删除引用目标时默认目标保持原值，由保存校验要求重新选择；
  // 默认模型悬空置空回落排序首位。
  //
  // 先为新行分配 ID，再按每行的实际兼容阶梯校验上限；既有 ID 和有效上限不变。
  const commit = (next: AggregateRoutes) => {
    const assigned = assignSlotIds(next, value);
    return onChange({
      ...assigned,
      slots: assigned.slots.map((s) =>
        s.maxEffort && effortLevelsFor(s.routeId).includes(s.maxEffort)
          ? s
          : { ...s, maxEffort: undefined },
      ),
    });
  };

  /** 提交编辑后的卡片列表：有行的卡展平回 slots，空卡（选了供应商还没映射
   *  任何档位）存进 pendingProviders。 */
  const commitCards = (next: ProviderTierRows[]) => {
    const hasRows = (card: ProviderTierRows) =>
      TIER_ROW_ORDER.some((tier) => card.rows[tier]?.length);
    setPendingProviders(
      next.filter((card) => !hasRows(card)).map((c) => c.providerId),
    );
    commit({
      ...value,
      slots: flattenProviderGroups(next.filter(hasRows)),
    });
  };

  const setCardProvider = (cardIndex: number, providerId: string) => {
    const next = cloneCards(cards);
    const card = next[cardIndex];
    card.providerId = providerId;
    // 行内的槽位各自带着 providerId（扁平存储的冗余），换卡头时同步改写
    for (const tier of TIER_ROW_ORDER) {
      const slots = card.rows[tier];
      if (slots)
        card.rows[tier] = slots.map((slot) => ({ ...slot, providerId }));
    }
    commitCards(next);
  };

  const patchRow = (
    cardIndex: number,
    tier: AggregateTier,
    rowIndex: number,
    patch: Partial<AggregateRouteSlot>,
  ) => {
    const next = cloneCards(cards);
    const slots = next[cardIndex].rows[tier];
    if (!slots?.[rowIndex]) return;
    next[cardIndex].rows[tier] = slots.map((slot, i) =>
      i === rowIndex ? { ...slot, ...patch } : slot,
    );
    commitCards(next);
  };

  const removeRow = (
    cardIndex: number,
    tier: AggregateTier,
    rowIndex: number,
  ) => {
    const next = cloneCards(cards);
    const remaining = (next[cardIndex].rows[tier] ?? []).filter(
      (_, i) => i !== rowIndex,
    );
    if (remaining.length) next[cardIndex].rows[tier] = remaining;
    else delete next[cardIndex].rows[tier];
    commitCards(next);
  };

  /** 每个档位可以添加多个独立模型。 */
  const addRow = (cardIndex: number, tier: AggregateTier) => {
    const next = cloneCards(cards);
    next[cardIndex].rows[tier] = [
      ...(next[cardIndex].rows[tier] ?? []),
      {
        routeId: "",
        tier,
        providerId: next[cardIndex].providerId,
        upstreamModel: "",
        supports1m: false,
      },
    ];
    // 新行自动展开（用户要立刻填它）
    const cardId = next[cardIndex].providerId;
    setExpandedIds((prev) => new Set(prev).add(cardId));
    commitCards(next);
  };

  const removeCard = (cardIndex: number) =>
    commitCards(cards.filter((_, i) => i !== cardIndex));

  /** 别名规则改动不改变槽位身份；按实际 ID 校验有效上限。 */
  const patchAliasRule = (
    index: number,
    patch: Partial<AggregateAliasRule>,
  ) => {
    const next = [...(value.aliasRules ?? [])];
    next[index] = { ...next[index], ...patch };
    commit({ ...value, aliasRules: next });
  };
  const addAliasRule = () =>
    commit({
      ...value,
      aliasRules: [...(value.aliasRules ?? []), { prefix: "", slotId: "" }],
    });
  const removeAliasRule = (index: number) =>
    commit({
      ...value,
      aliasRules: (value.aliasRules ?? []).filter((_, i) => i !== index),
    });

  const addCard = () => {
    const used = new Set(cards.map((card) => card.providerId));
    const free = candidates.find((p) => !used.has(p.id));
    if (!free) return;
    setExpandedIds((prev) => new Set(prev).add(free.id)); // 新卡自动展开
    commitCards([...cards, { providerId: free.id, rows: {} }]);
  };

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const from = cards.findIndex((card) => card.providerId === active.id);
    const to = cards.findIndex((card) => card.providerId === over.id);
    if (from < 0 || to < 0) return;
    commitCards(arrayMove(cards, from, to));
  };

  /** 已映射（上游模型非空）的槽位——默认模型下拉与「生效默认」判定都只认它们。 */
  const mappedSlots = useMemo(
    () => value.slots.filter((slot) => slot.upstreamModel.trim() !== ""),
    [value.slots],
  );
  // 生效默认：显式设置且仍指向已映射槽 → 用它；否则排序首位
  const effectiveDefault =
    value.defaultModel &&
    mappedSlots.some((slot) => slot.routeId === value.defaultModel)
      ? value.defaultModel
      : (mappedSlots[0]?.routeId ?? "");

  const toggleCard = (id: string) =>
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });

  const allExpanded =
    cards.length > 0 && cards.every((card) => expandedIds.has(card.providerId));

  return (
    <section className="space-y-4">
      <header className="space-y-1">
        <h3 className="text-sm font-medium">{t("aggregate.title")}</h3>
        <p className="text-xs text-muted-foreground">{t("aggregate.hint")}</p>
      </header>

      {needsRouteIdMigration(value) && (
        <div className="space-y-2 rounded-md border p-3 text-xs">
          <p>
            {t("aggregate.migrationHint", {
              defaultValue:
                "存量路由 ID 不兼容或重复。普通编辑保留原 ID；转换前请备份，旧会话可能需要重新选择模型。",
            })}
          </p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              setMigrationPreview(migrateIncompatibleRouteIds(value));
              setMigrationBackup(false);
            }}
          >
            {t("aggregate.migrationPreview", {
              defaultValue: "预览旧路由转换",
            })}
          </Button>
          {migrationPreview && (
            <>
              <pre className="whitespace-pre-wrap">
                {value.slots
                  .map(
                    (slot, i) =>
                      `${slot.routeId} → ${migrationPreview.slots[i]?.routeId}；${t("aggregate.migrationLimits", { defaultValue: "上限" })} ${slot.maxEffort ?? t("aggregate.migrationUnlimited", { defaultValue: "不限制" })} → ${migrationPreview.slots[i]?.maxEffort ?? t("aggregate.migrationUnlimited", { defaultValue: "不限制" })}`,
                  )
                  .join("\n")}
              </pre>
              <p>
                {t("aggregate.defaultTarget", { defaultValue: "兜底目标" })}:{" "}
                {value.defaultTarget.value} →{" "}
                {migrationPreview.defaultTarget.value}
              </p>
              <p>
                {t("aggregate.defaultModel", { defaultValue: "默认模型" })}:{" "}
                {value.defaultModel ?? "—"} →{" "}
                {migrationPreview.defaultModel ?? "—"}
              </p>
              {(value.aliasRules ?? []).map((rule, i) => (
                <p key={i}>
                  {rule.prefix}: {rule.slotId || "—"} →{" "}
                  {migrationPreview.aliasRules?.[i]?.slotId || "—"}
                </p>
              ))}
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={downloadMigrationBackup}
              >
                {t("aggregate.migrationBackup", {
                  defaultValue: "下载路由备份",
                })}
              </Button>
              <Button
                type="button"
                size="sm"
                disabled={!migrationBackup}
                onClick={() => {
                  onChange(migrationPreview);
                  setMigrationPreview(undefined);
                  setMigrationBackup(false);
                }}
              >
                {t("aggregate.migrationConfirm", {
                  defaultValue: "确认转换路由 ID",
                })}
              </Button>
            </>
          )}
        </div>
      )}

      {!canSaveAggregateRoutes(value) && (
        <p className="text-xs text-destructive">{t("aggregate.notSaveable")}</p>
      )}

      {/* 兜底目标与默认模型并排（v3）。兜底目标是必填的路由安全网；默认模型
          决定 Claude Desktop 新会话的起点（写 profile 时置顶到第一条）。 */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label className="text-xs">{t("aggregate.defaultTarget")}</Label>
          <Select
            value={
              value.defaultTarget.kind === "providerId"
                ? `provider:${value.defaultTarget.value}`
                : `slot:${value.defaultTarget.value}`
            }
            onValueChange={(v) => {
              const [kind, ...rest] = v.split(":");
              const target: DefaultTarget =
                kind === "provider"
                  ? { kind: "providerId", value: rest.join(":") }
                  : { kind: "slotId", value: rest.join(":") };
              onChange({ ...value, defaultTarget: target });
            }}
          >
            <SelectTrigger className="h-8">
              <SelectValue
                placeholder={t("aggregate.defaultTargetPlaceholder", {
                  defaultValue: "必选：未命中槽位的请求回落到这里",
                })}
              />
            </SelectTrigger>
            <SelectContent>
              {candidates.map((p) => (
                <SelectItem key={p.id} value={`provider:${p.id}`}>
                  {p.name}
                </SelectItem>
              ))}
              {value.slots.map((s, index) => (
                <SelectItem
                  key={s.routeId || `slot-${index}`}
                  value={`slot:${s.routeId}`}
                >
                  {labelOf(s)} ({s.routeId})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {t("aggregate.defaultTargetHint")}
          </p>
        </div>

        <div className="space-y-1">
          <Label className="text-xs">{t("aggregate.defaultModel")}</Label>
          <Select
            value={value.defaultModel ?? UNSET}
            onValueChange={(v) =>
              onChange({
                ...value,
                defaultModel: v === UNSET ? undefined : v,
              })
            }
          >
            <SelectTrigger className="h-8">
              <SelectValue
                placeholder={t("aggregate.defaultModelPlaceholder", {
                  defaultValue: "未设置：跟随排序首位",
                })}
              />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={UNSET}>
                {t("aggregate.defaultModelPlaceholder", {
                  defaultValue: "未设置：跟随排序首位",
                })}
              </SelectItem>
              {mappedSlots.map((slot) => (
                <SelectItem key={slot.routeId} value={slot.routeId}>
                  {labelOf(slot)} ({slot.routeId})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {t("aggregate.defaultModelHint", {
              defaultValue: "启动新会话时使用的模型；未设置时取排序第一条",
            })}
          </p>
        </div>
      </div>

      {/* 别名路由规则：槽位未命中时按前缀转投。按序先赢，运行时小写化匹配。 */}
      <div className="space-y-2 rounded-md border border-border-default p-3">
        <p
          className="text-xs text-muted-foreground"
          title={t("aggregate.aliasTip", {
            defaultValue:
              "前缀过宽（如 claude-）会吞掉所有未命中槽位的请求名，注意范围",
          })}
        >
          {t("aggregate.aliasRouting", {
            defaultValue: "别名路由（槽位未命中时按前缀转投，先匹配先赢）",
          })}
        </p>
        {(value.aliasRules ?? []).map((rule, index) => (
          <div key={index} className="flex items-center gap-2">
            <Input
              className="h-8 w-56 shrink-0"
              value={rule.prefix}
              placeholder={t("aggregate.aliasPrefixPlaceholder", {
                defaultValue: "如 claude-sonnet",
              })}
              title={t("aggregate.aliasPrefix", { defaultValue: "请求名前缀" })}
              onChange={(e) =>
                patchAliasRule(index, { prefix: e.target.value })
              }
            />
            <span className="text-xs text-muted-foreground">→</span>
            <Select
              value={rule.slotId || UNSET}
              onValueChange={(v) =>
                patchAliasRule(index, { slotId: v === UNSET ? "" : v })
              }
            >
              <SelectTrigger
                className="h-8 flex-1"
                aria-label={t("aggregate.aliasTarget", {
                  defaultValue: "目标槽位",
                })}
              >
                <SelectValue
                  placeholder={t("aggregate.aliasTargetPlaceholder", {
                    defaultValue: "选择槽位",
                  })}
                />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={UNSET}>
                  {t("aggregate.aliasTargetPlaceholder", {
                    defaultValue: "选择槽位",
                  })}
                </SelectItem>
                {value.slots.map((slot) => (
                  <SelectItem key={slot.routeId} value={slot.routeId}>
                    {labelOf(slot)} ({slot.routeId})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-7 w-6 shrink-0 text-muted-foreground hover:text-destructive"
              title={t("aggregate.removeAliasRule", {
                defaultValue: "删除该规则",
              })}
              onClick={() => removeAliasRule(index)}
            >
              <X className="h-3.5 w-3.5" />
            </Button>
          </div>
        ))}
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 gap-1 text-xs text-muted-foreground"
          onClick={addAliasRule}
        >
          <Plus className="h-3.5 w-3.5" />
          {t("aggregate.addAliasRule", { defaultValue: "添加规则" })}
        </Button>
      </div>

      {/* 全部展开 / 全部折叠（折叠状态不持久化，每次打开表单重置为全折叠） */}
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-xs"
          disabled={allExpanded}
          onClick={() =>
            setExpandedIds(new Set(cards.map((card) => card.providerId)))
          }
        >
          {t("aggregate.expandAll", { defaultValue: "全部展开" })}
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-xs"
          disabled={expandedIds.size === 0}
          onClick={() => setExpandedIds(new Set())}
        >
          {t("aggregate.collapseAll", { defaultValue: "全部折叠" })}
        </Button>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={cards.map((card) => card.providerId)}
          strategy={verticalListSortingStrategy}
        >
          <div className="space-y-3">
            {cards.map((card, cardIndex) => {
              const usedElsewhere = new Set(
                cards
                  .filter((_, i) => i !== cardIndex)
                  .map((c) => c.providerId),
              );
              const selectable = candidates.filter(
                (p) => !usedElsewhere.has(p.id),
              );
              const target = candidates.find((p) => p.id === card.providerId);
              const fetched = modelsForProvider(card.providerId);
              const mappedRows = TIER_ROW_ORDER.flatMap((tier) =>
                (card.rows[tier] ?? []).map((slot, rowIndex) => ({
                  tier,
                  slot,
                  rowIndex,
                })),
              );
              const availableTiers = TIER_ROW_ORDER;
              const expanded = expandedIds.has(card.providerId);
              // routeId 恒非空（每次 commit 都经 assignSlotIds 赋真 ID），无已映射
              // 槽位时 effectiveDefault 为 ""，恒不命中，无需再挡空值。
              const isDefaultCard = mappedRows.some(
                ({ slot }) => slot.routeId === effectiveDefault,
              );
              return (
                <SortableCard key={card.providerId} id={card.providerId}>
                  {(handle) => (
                    <div className="space-y-2 rounded-md border border-border-default p-3">
                      {/* 卡头：拖拽把手 + 供应商 + 拉模型 + 删卡 + 折叠开关。
                          模型列表按供应商拉一次，卡内各档位共用缓存。 */}
                      <div className="flex items-center gap-2">
                        {handle}
                        <Select
                          value={card.providerId}
                          onValueChange={(v) => setCardProvider(cardIndex, v)}
                        >
                          <SelectTrigger className="h-8 flex-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {selectable.map((p) => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name}
                              </SelectItem>
                            ))}
                            {/* 存量数据可能引用已被删除/被其他卡占用的供应商：
                                保底显示，避免选择器空白让用户误以为没配置 */}
                            {!selectable.some(
                              (p) => p.id === card.providerId,
                            ) && (
                              <SelectItem value={card.providerId}>
                                {nameOf(card.providerId)}
                              </SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                        {isDefaultCard && (
                          <Badge
                            variant="secondary"
                            className="shrink-0 text-[10px]"
                          >
                            {t("aggregate.defaultBadge", {
                              defaultValue: "默认",
                            })}
                          </Badge>
                        )}
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="h-8 shrink-0 gap-1"
                          disabled={!target || fetchingProviderId !== null}
                          onClick={() => target && onFetchModels(target)}
                        >
                          {fetchingProviderId === card.providerId ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Download className="h-3.5 w-3.5" />
                          )}
                          {t("providerForm.fetchModels", {
                            defaultValue: "获取模型列表",
                          })}
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 shrink-0"
                          onClick={() => removeCard(cardIndex)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                        <button
                          type="button"
                          className="shrink-0 text-muted-foreground hover:text-foreground"
                          aria-expanded={expanded}
                          onClick={() => toggleCard(card.providerId)}
                        >
                          {expanded ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </button>
                      </div>

                      {expanded ? (
                        <>
                          {/* 列头：紧贴供应商行（2026-09-23 用户确认的草图） */}
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span className="w-14 shrink-0">
                              {t("aggregate.tier")}
                            </span>
                            <span className="w-16 shrink-0">
                              {t("aggregate.effortBadgeHeader")}
                            </span>
                            <span className="min-w-0 flex-1">
                              {t("aggregate.upstreamModel")}
                            </span>
                            <span className="min-w-0 flex-1">
                              {t("aggregate.displayName")}
                            </span>
                            <span className="w-24 shrink-0 text-right">
                              {t("aggregate.maxEffort")}
                            </span>
                            <span className="w-20 shrink-0 text-right">
                              {t("aggregate.supports1m")}
                            </span>
                            <span className="w-6 shrink-0" />
                          </div>

                          {/* 已映射档位的行（v3：增量添加，不再固定四行）。行尾 ×
                              删除该槽；行内不支持改档位（删了重加）。 */}
                          {mappedRows.map(({ tier, slot, rowIndex }) => {
                            const isEffectiveDefault =
                              slot.routeId === effectiveDefault;
                            const switchId = `agg-1m-${slot.routeId || `${cardIndex}-${tier}-${rowIndex}`}`;
                            return (
                              <div
                                key={slot.routeId || `${tier}-${rowIndex}`}
                                className="flex items-center gap-2"
                                // 槽位 ID 不占版面，悬停可查——排查代理日志里的
                                // request_model 时用得上
                                title={slot.routeId || undefined}
                              >
                                <span className="w-14 shrink-0 text-xs text-muted-foreground">
                                  {tier}
                                </span>
                                <EffortBadge routeId={slot.routeId} />
                                <div className="flex min-w-0 flex-1 gap-1">
                                  {/* 上游模型只改值，不再承担行的生死——删行走
                                    行尾 × 按钮（v3 语义）。 */}
                                  <Input
                                    className="h-8 min-w-0 flex-1"
                                    value={slot.upstreamModel}
                                    placeholder={t(
                                      "aggregate.upstreamModelPlaceholder",
                                      { defaultValue: "上游模型名" },
                                    )}
                                    onChange={(e) =>
                                      patchRow(cardIndex, tier, rowIndex, {
                                        upstreamModel: e.target.value,
                                      })
                                    }
                                  />
                                  {fetched.length > 0 && (
                                    <ModelDropdown
                                      models={fetched}
                                      onSelect={(id) =>
                                        patchRow(cardIndex, tier, rowIndex, {
                                          upstreamModel: id,
                                        })
                                      }
                                    />
                                  )}
                                </div>
                                <div className="relative min-w-0 flex-1">
                                  <ImeSafeInput
                                    className="h-8 w-full pr-14"
                                    placeholder={labelOf(slot)}
                                    value={slot.label ?? ""}
                                    // 留空则不落库；提交时由表单统一补成「供应商 · 上游模型」
                                    onValueChange={(v) =>
                                      patchRow(cardIndex, tier, rowIndex, {
                                        label: v.trim() ? v : undefined,
                                      })
                                    }
                                  />
                                  {isEffectiveDefault && (
                                    <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">
                                      {t("aggregate.defaultBadge", {
                                        defaultValue: "默认",
                                      })}
                                    </span>
                                  )}
                                </div>
                                <MaxEffortSelect
                                  routeId={slot.routeId}
                                  value={slot.maxEffort}
                                  onChange={(v) =>
                                    patchRow(cardIndex, tier, rowIndex, {
                                      maxEffort: v,
                                    })
                                  }
                                />
                                <div className="flex w-20 shrink-0 items-center justify-end gap-1.5">
                                  <Switch
                                    id={switchId}
                                    checked={Boolean(slot.supports1m)}
                                    onCheckedChange={(v) =>
                                      patchRow(cardIndex, tier, rowIndex, {
                                        supports1m: v,
                                      })
                                    }
                                  />
                                  <Label
                                    htmlFor={switchId}
                                    className="text-xs text-muted-foreground"
                                  >
                                    1M
                                  </Label>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-6 shrink-0 text-muted-foreground hover:text-destructive"
                                  title={t("aggregate.removeModel", {
                                    defaultValue: "删除该模型",
                                  })}
                                  onClick={() =>
                                    removeRow(cardIndex, tier, rowIndex)
                                  }
                                >
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            );
                          })}

                          {/* 新增模型：各档位允许多行，不覆盖既有模型 */}
                          {availableTiers.length > 0 && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 gap-1 text-xs text-muted-foreground"
                                >
                                  <Plus className="h-3.5 w-3.5" />
                                  {t("aggregate.addModel", {
                                    defaultValue: "新增模型",
                                  })}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="start">
                                {availableTiers.map((tier) => (
                                  <DropdownMenuItem
                                    key={tier}
                                    onClick={() => addRow(cardIndex, tier)}
                                  >
                                    {tier}
                                  </DropdownMenuItem>
                                ))}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </>
                      ) : (
                        /* 折叠态摘要：N 个模型 · M 强度 */
                        <p className="text-xs text-muted-foreground">
                          {t("aggregate.modelsSummaryLadder", {
                            count: mappedRows.length,
                            ladder: mappedRows.filter(
                              ({ slot }) =>
                                effortCapability(slot.routeId) === "ladder",
                            ).length,
                            defaultValue: "{{count}} 个模型 · {{ladder}} 强度",
                          })}
                        </p>
                      )}
                    </div>
                  )}
                </SortableCard>
              );
            })}
          </div>
        </SortableContext>
      </DndContext>

      <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-8 gap-1.5"
        disabled={
          candidates.length > 0 &&
          new Set(cards.map((card) => card.providerId)).size >=
            candidates.length
        }
        onClick={addCard}
      >
        <Plus className="h-3.5 w-3.5" />
        {t("aggregate.addProvider")}
      </Button>
    </section>
  );
}

function EffortBadge({ routeId }: { routeId: string }) {
  const { t } = useTranslation();
  // 测试环境 i18n 是空资源：t() 必须带 defaultValue，否则返回键名本身、组件测试必挂
  const conf = {
    ladder: {
      key: "effortLadder",
      tipKey: "effortLadderTip",
      cls: "text-emerald-600 dark:text-emerald-400",
      text: "强度✓",
      tip: "完整思考强度阶梯（low…max），来自真模型 ID",
    },
    extended: {
      key: "effortToggle",
      tipKey: "effortToggleTip",
      cls: "text-muted-foreground",
      text: "思考开关",
      tip: "仅扩展思考开/关，无强度档位",
    },
    none: {
      key: "effortNone",
      tipKey: "effortNoneTip",
      cls: "text-muted-foreground/50",
      text: "✗",
      tip: "溢出 ID：Claude Desktop 不认识，无思考控件",
    },
  }[effortCapability(routeId)];
  return (
    <span
      className={`w-16 shrink-0 text-[10px] ${conf.cls}`}
      title={t(`aggregate.${conf.tipKey}`, { defaultValue: conf.tip })}
    >
      {t(`aggregate.${conf.key}`, { defaultValue: conf.text })}
    </span>
  );
}

/** 槽位行的思考强度上限下拉：只有完整阶梯 ID 有档位可选，其余禁用并给出原因。 */
function MaxEffortSelect({
  routeId,
  value,
  onChange,
}: {
  routeId: string;
  value: AggregateMaxEffort | undefined;
  onChange: (v: AggregateMaxEffort | undefined) => void;
}) {
  const { t } = useTranslation();
  const disabled = effortCapability(routeId) !== "ladder";
  return (
    <Select
      value={value ?? UNSET}
      disabled={disabled}
      onValueChange={(v) =>
        onChange(v === UNSET ? undefined : (v as AggregateMaxEffort))
      }
    >
      <SelectTrigger
        className="h-7 w-24 shrink-0 text-xs"
        title={
          disabled
            ? t("aggregate.effortNoneTip", {
                defaultValue: "溢出 ID：Claude Desktop 不认识，无思考控件",
              })
            : undefined
        }
      >
        <SelectValue
          placeholder={t("aggregate.maxEffort", { defaultValue: "上限" })}
        />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={UNSET}>
          {t("aggregate.maxEffortOff", { defaultValue: "不限制" })}
        </SelectItem>
        {effortLevelsFor(routeId).map((lv) => (
          <SelectItem key={lv} value={lv}>
            {lv}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}


## Full source: tests/components/AggregateProviderFields.aliasRules.test.tsx
import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

const value: AggregateRoutes = {
  slots: [
    {
      routeId: "claude-sonnet-4",
      tier: "sonnet",
      providerId: "p1",
      upstreamModel: "space-bunny-free",
      label: "OC · space-bunny-free",
      supports1m: false,
    },
  ],
  defaultTarget: { kind: "providerId", value: "p1" },
  aliasRules: [
    { prefix: "claude-sonnet", slotId: "claude-sonnet-4" },
    { prefix: "claude-", slotId: "" },
  ],
};

const props = {
  value,
  onChange: vi.fn(),
  candidates: [{ id: "p1", name: "OC" } as unknown as Provider],
  modelsForProvider: () => [],
  fetchingProviderId: null,
  onFetchModels: vi.fn(),
};

describe("别名路由区块", () => {
  it("渲染既有规则行（含悬空行），悬空行显示占位而非崩", () => {
    render(<AggregateProviderFields {...props} />);
    const prefixInput = screen.getByDisplayValue("claude-sonnet");
    expect(prefixInput).toBeInTheDocument();
    // 第二行 slotId 为空 → Select 显示占位（存在第二个 combobox 即可）
    expect(screen.getAllByRole("combobox").length).toBeGreaterThanOrEqual(2);
  });

  it("添加规则产生空行并回调 onChange", async () => {
    const user = userEvent.setup();
    render(<AggregateProviderFields {...props} />);
    await user.click(screen.getByRole("button", { name: "添加规则" }));
    expect(props.onChange).toHaveBeenCalled();
    const calls = props.onChange.mock.calls;
    const last = calls[calls.length - 1][0] as AggregateRoutes;
    expect(last.aliasRules).toHaveLength(3);
    expect(last.aliasRules?.[2]).toEqual({ prefix: "", slotId: "" });
  });

  it("删除规则行回调 onChange 且不残留", async () => {
    const user = userEvent.setup();
    render(<AggregateProviderFields {...props} />);
    const dels = screen.getAllByRole("button", { name: "删除该规则" });
    await user.click(dels[0]);
    const calls = props.onChange.mock.calls;
    const last = calls[calls.length - 1][0] as AggregateRoutes;
    expect(last.aliasRules).toEqual([{ prefix: "claude-", slotId: "" }]);
  });

  it("编辑前缀回调 onChange 且带上新前缀", async () => {
    const user = userEvent.setup();
    // 受控组件：值必须回灌，否则 clear 之后 React 把 DOM 重置回旧前缀，
    // 逐字输入会追加在旧值后面（真实使用中父组件正是回灌的）
    const Controlled = () => {
      const [current, setCurrent] = useState(value);
      return (
        <AggregateProviderFields
          {...props}
          value={current}
          onChange={(v) => {
            props.onChange(v);
            setCurrent(v);
          }}
        />
      );
    };
    render(<Controlled />);
    const input = screen.getByDisplayValue("claude-sonnet");
    await user.clear(input);
    await user.type(input, "claude-opus");
    const calls = props.onChange.mock.calls;
    const last = calls[calls.length - 1][0] as AggregateRoutes;
    // 修改前缀不改变既有槽位身份。
    expect(last.aliasRules?.[0]).toEqual({
      prefix: "claude-opus",
      slotId: "claude-sonnet-4",
    });
    // 第二条规则不受影响（patch 只改被编辑的行）
    expect(last.aliasRules?.[1]).toEqual({ prefix: "claude-", slotId: "" });
  });
});


## Full source: tests/components/AggregateProviderFields.effortBadge.test.tsx
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

function makeRoutes(
  pairs: Array<[string, "sonnet" | "haiku"]>,
): AggregateRoutes {
  return {
    slots: pairs.map(([routeId, tier], i) => ({
      routeId,
      tier,
      providerId: "p1",
      upstreamModel: `m${i}`,
      supports1m: false,
    })),
    defaultTarget: { kind: "providerId", value: "p1" },
  };
}

function renderEditor(value: AggregateRoutes) {
  return render(
    <AggregateProviderFields
      value={value}
      onChange={vi.fn()}
      candidates={[{ id: "p1", name: "P1" } as unknown as Provider]}
      modelsForProvider={() => []}
      fetchingProviderId={null}
      onFetchModels={vi.fn()}
    />,
  );
}

describe("聚合编辑器三态思考徽标", () => {
  it("展开卡后 ladder 槽显示 强度✓、溢出槽显示 ✗", async () => {
    const user = userEvent.setup();
    renderEditor(
      makeRoutes([
        ["claude-sonnet-5", "sonnet"],
        ["claude-haiku-3", "haiku"],
      ]),
    );
    await user.click(screen.getByRole("button", { expanded: false })); // 展开唯一的卡
    expect(screen.getByText("强度✓")).toBeInTheDocument();
    expect(screen.getByText("✗")).toBeInTheDocument();
  });

  it("extended 槽显示 思考开关", async () => {
    const user = userEvent.setup();
    renderEditor(makeRoutes([["claude-sonnet-4-5", "sonnet"]]));
    await user.click(screen.getByRole("button", { expanded: false }));
    expect(screen.getByText("思考开关")).toBeInTheDocument();
  });

  it("折叠摘要含强度计数", () => {
    renderEditor(
      makeRoutes([
        ["claude-sonnet-5", "sonnet"],
        ["claude-haiku-3", "haiku"],
      ]),
    );
    expect(screen.getByText("2 个模型 · 1 强度")).toBeInTheDocument();
  });
});

describe("聚合编辑器上限下拉", () => {
  it("上限下拉：ladder 槽可选，溢出槽禁用", async () => {
    // Radix Select 展开时会对首项调用 scrollIntoView（jsdom 未实现）
    Element.prototype.scrollIntoView = vi.fn();
    const user = userEvent.setup();
    const { container } = renderEditor(
      makeRoutes([
        ["claude-sonnet-5", "sonnet"],
        ["claude-haiku-3", "haiku"],
      ]),
    );
    await user.click(screen.getByRole("button", { expanded: false }));
    // 槽位行带 routeId title，行内只有上限下拉这一个 combobox，
    // 故按行取即得「该槽的上限触发器」（页面上还有兜底目标/默认模型/卡头下拉）
    const capTriggerOf = (routeId: string) =>
      within(
        container.querySelector(`[title="${routeId}"]`) as HTMLElement,
      ).getByRole("combobox");
    expect(capTriggerOf("claude-sonnet-5")).toBeEnabled();
    expect(capTriggerOf("claude-haiku-3")).toBeDisabled();

    // 选项来自该 ID 的实际阶梯（claude-sonnet-5 为 low…max 五档）
    await user.click(capTriggerOf("claude-sonnet-5"));
    const options = await screen.findAllByRole("option");
    expect(options.map((o) => o.textContent)).toEqual([
      "不限制",
      "low",
      "medium",
      "high",
      "xhigh",
      "max",
    ]);
  });

  it("普通提交保留每个既有模型的 ID 和有效强度上限", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    // 两张卡各一条 sonnet 行：重编号后 p1 取池内第 1 位（claude-sonnet-4-6，ladder），
    // p2 落到第 2 位（claude-sonnet-4-5，extended）。p2 的输入 ID claude-sonnet-5
    // 本身是 ladder——若在 assignSlotIds 之前判定，就会漏剥它的 maxEffort。
    render(
      <AggregateProviderFields
        value={{
          slots: [
            {
              routeId: "claude-sonnet-4-6",
              tier: "sonnet",
              providerId: "p1",
              upstreamModel: "m1",
              supports1m: false,
              maxEffort: "max",
            },
            {
              routeId: "claude-sonnet-5",
              tier: "sonnet",
              providerId: "p2",
              upstreamModel: "m2",
              supports1m: false,
              maxEffort: "xhigh",
            },
          ],
          defaultTarget: { kind: "providerId", value: "p1" },
        }}
        onChange={onChange}
        candidates={[
          { id: "p1", name: "P1" } as unknown as Provider,
          { id: "p2", name: "P2" } as unknown as Provider,
        ]}
        modelsForProvider={() => []}
        fetchingProviderId={null}
        onFetchModels={vi.fn()}
      />,
    );
    await user.click(screen.getAllByRole("button", { expanded: false })[0]);
    await user.click(screen.getAllByRole("switch")[0]); // 任意一次提交

    const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
    expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
      ["claude-sonnet-4-6", "max"], // ladder：保留
      ["claude-sonnet-5", "xhigh"], // ID 和能力均保留
    ]);
  });

  it("删除其他模型不收窄剩余模型的 ID 或强度上限", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    // 存量数据：p1 槽存的是 sonnet-5 + xhigh（删槽轮换前的旧编号）。提交必先
    // assignSlotIds 重编号——删掉 p2 的槽后，p1 槽按序号 1 重算为 claude-sonnet-4-6，
    // 同为「完整阶梯」但阶梯不含 xhigh。只判三态的实现会把它留成隐形残留
    // （Radix Select 值不在选项中只显 placeholder，用户看不见）。
    render(
      <AggregateProviderFields
        value={{
          slots: [
            {
              routeId: "claude-sonnet-5",
              tier: "sonnet",
              providerId: "p1",
              upstreamModel: "m1",
              supports1m: false,
              maxEffort: "xhigh",
            },
            {
              routeId: "claude-sonnet-4-5",
              tier: "sonnet",
              providerId: "p2",
              upstreamModel: "m2",
              supports1m: false,
            },
          ],
          defaultTarget: { kind: "providerId", value: "p1" },
        }}
        onChange={onChange}
        candidates={[
          { id: "p1", name: "P1" } as unknown as Provider,
          { id: "p2", name: "P2" } as unknown as Provider,
        ]}
        modelsForProvider={() => []}
        fetchingProviderId={null}
        onFetchModels={vi.fn()}
      />,
    );
    // 展开第二张卡，删掉它的槽 → 触发重编号
    await user.click(screen.getAllByRole("button", { expanded: false })[1]);
    await user.click(screen.getByTitle("删除该模型"));

    const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
    expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
      ["claude-sonnet-5", "xhigh"],
    ]);
  });
});


## Full source: tests/components/AggregateProviderFields.compatibility.test.tsx
import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

const initial: AggregateRoutes = {
  slots: [
    {
      routeId: "claude-sonnet-4-6",
      tier: "sonnet",
      providerId: "a",
      upstreamModel: "upstream-a",
      label: "A",
    },
    {
      routeId: "claude-sonnet-4-5",
      tier: "sonnet",
      providerId: "a",
      upstreamModel: "upstream-b",
      label: "B",
    },
  ],
  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
  defaultModel: "claude-sonnet-4-6",
};

async function setup() {
  const change = vi.fn();
  function Controlled() {
    const [value, setValue] = useState(initial);
    return (
      <AggregateProviderFields
        value={value}
        onChange={(next) => {
          change(next);
          setValue(next);
        }}
        candidates={[
          { id: "a", name: "Synthetic A", settingsConfig: {} } as Provider,
        ]}
        modelsForProvider={() => []}
        fetchingProviderId={null}
        onFetchModels={() => {}}
      />
    );
  }
  render(<Controlled />);
  await userEvent
    .setup()
    .click(screen.getByRole("button", { name: "全部展开" }));
  return change;
}

describe("lossless multi-model editing", () => {
  it("shows both existing models in the same provider/tier", async () => {
    await setup();
    expect(screen.getByDisplayValue("upstream-a")).toBeInTheDocument();
    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
  });

  it("editing one model keeps the other and preserves identities", async () => {
    const change = await setup();
    fireEvent.change(screen.getByDisplayValue("upstream-a"), {
      target: { value: "changed-a" },
    });
    const next = change.mock.lastCall?.[0] as AggregateRoutes;
    expect(next.slots).toHaveLength(2);
    expect(next.slots[1]).toEqual(initial.slots[1]);
    expect(next.defaultModel).toBe(initial.defaultModel);
  });

  it("deleting one row leaves the second model available", async () => {
    const change = await setup();
    await userEvent
      .setup()
      .click(screen.getAllByRole("button", { name: "删除该模型" })[0]);
    const next = change.mock.lastCall?.[0] as AggregateRoutes;
    expect(next.slots).toEqual([initial.slots[1]]);
    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
  });
});


## Full source: tests/components/AggregateProviderFields.migration.test.tsx
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

it("changing the source after a migration preview invalidates confirmation", async () => {
  const initial: AggregateRoutes = {
    slots: [
      {
        routeId: "claude-fable-glm",
        tier: "fable",
        providerId: "a",
        upstreamModel: "old",
      },
    ],
    defaultTarget: { kind: "providerId", value: "a" },
  };
  const common = {
    onChange: vi.fn(),
    candidates: [{ id: "a", name: "A", settingsConfig: {} } as Provider],
    modelsForProvider: () => [],
    fetchingProviderId: null,
    onFetchModels: () => {},
  };
  const { rerender } = render(
    <AggregateProviderFields {...common} value={initial} />,
  );
  await userEvent
    .setup()
    .click(screen.getByRole("button", { name: "预览旧路由转换" }));
  expect(
    screen.getByRole("button", { name: "确认转换路由 ID" }),
  ).toBeInTheDocument();
  rerender(
    <AggregateProviderFields
      {...common}
      value={{
        ...initial,
        slots: [{ ...initial.slots[0], upstreamModel: "new-edit" }],
      }}
    />,
  );
  expect(
    screen.queryByRole("button", { name: "确认转换路由 ID" }),
  ).not.toBeInTheDocument();
  expect(common.onChange).not.toHaveBeenCalled();
});

it("legacy invalid IDs change only after explicit preview, backup and confirmation", async () => {
  const oldId = "claude-fable-zhipu-glm";
  const routes: AggregateRoutes = {
    slots: [
      {
        routeId: oldId,
        tier: "fable",
        providerId: "a",
        upstreamModel: "model-a",
      },
    ],
    defaultTarget: { kind: "slotId", value: oldId },
    defaultModel: oldId,
    aliasRules: [{ prefix: "team", slotId: oldId }],
  };
  const change = vi.fn();
  render(
    <AggregateProviderFields
      value={routes}
      onChange={change}
      candidates={[{ id: "a", name: "A", settingsConfig: {} } as Provider]}
      modelsForProvider={() => []}
      fetchingProviderId={null}
      onFetchModels={() => {}}
    />,
  );
  const user = userEvent.setup();
  await user.click(screen.getByRole("button", { name: "预览旧路由转换" }));
  expect(change).not.toHaveBeenCalled();
  expect(
    screen.getByRole("button", { name: "确认转换路由 ID" }),
  ).toBeDisabled();
  class MockURL extends URL {
    static createObjectURL = vi.fn(() => "blob:synthetic");
    static revokeObjectURL = vi.fn();
  }
  vi.stubGlobal("URL", MockURL);
  const click = vi
    .spyOn(HTMLAnchorElement.prototype, "click")
    .mockImplementation(() => {});
  await user.click(screen.getByRole("button", { name: "下载路由备份" }));
  await user.click(screen.getByRole("button", { name: "确认转换路由 ID" }));
  const next = change.mock.lastCall?.[0] as AggregateRoutes;
  expect(next.slots[0].routeId).not.toBe(oldId);
  expect(next.slots[0].upstreamModel).toBe("model-a");
  expect(next.defaultTarget.value).toBe(next.slots[0].routeId);
  expect(next.defaultModel).toBe(next.slots[0].routeId);
  expect(next.aliasRules?.[0].slotId).toBe(next.slots[0].routeId);
  click.mockRestore();
  vi.unstubAllGlobals();
});


## Full source: src-tauri/src/aggregate_retirement_tests.rs
use super::*;

fn routes_json() -> serde_json::Value {
    serde_json::json!({
        "slots":[{"routeId":"claude-sonnet-4-5","tier":"sonnet","providerId":"synthetic-target","upstreamModel":"new-model"}],
        "defaultTarget":{"kind":"providerId","value":"synthetic-target"},
        "aliasRules":[{"prefix":"claude-sonnet","slotId":"claude-sonnet-4-5"}],
        "retiredRouteIds":["claude-sonnet-4-6"]
    })
}

#[test]
fn aggregate_retirement_survives_backend_serialization_roundtrip() {
    let routes: AggregateRoutes = serde_json::from_value(routes_json()).unwrap();
    let persisted = serde_json::to_value(routes).unwrap();
    assert_eq!(persisted["retiredRouteIds"], serde_json::json!(["claude-sonnet-4-6"]));
}

#[tokio::test]
async fn aggregate_retirement_old_requests_are_rejected_before_alias_or_fallback() {
    let db = crate::database::Database::memory().unwrap();
    let target = Provider::with_id("synthetic-target".into(), "Synthetic".into(), serde_json::json!({}), None);
    db.save_provider("claude-desktop", &target).unwrap();
    let mut provider = Provider::with_id("synthetic-aggregate".into(), "Synthetic Aggregate".into(), serde_json::json!({}), None);
    provider.meta = Some(crate::provider::ProviderMeta {
        aggregate_routes: Some(serde_json::from_value(routes_json()).unwrap()),
        ..Default::default()
    });
    for request in ["claude-sonnet-4-6", "claude-sonnet-4-6[1m]", "CLAUDE-SONNET-4-6"] {
        assert!(resolve_target(&db, "claude-desktop", &provider, request).is_err(),
            "Retired ID must not be redirected through the alias or default");
    }
}

#[test]
fn aggregate_retirement_legacy_absent_metadata_is_backward_compatible() {
    let mut legacy = routes_json();
    legacy.as_object_mut().unwrap().remove("retiredRouteIds");
    let parsed: AggregateRoutes = serde_json::from_value(legacy).unwrap();
    let persisted = serde_json::to_value(parsed).unwrap();
    assert!(persisted.get("retiredRouteIds").is_none());
}

#[tokio::test]
async fn aggregate_compatibility_padded_route_key_preserves_exact_mapping() {
    let db=crate::database::Database::memory().unwrap();
    db.save_provider("claude-desktop",&Provider::with_id("synthetic-target".into(),"Synthetic".into(),serde_json::json!({}),None)).unwrap();
    let mut json=routes_json();
    json["slots"][0]["routeId"]=serde_json::json!(" claude-sonnet-4-5 ");
    json["aliasRules"]=serde_json::json!([]);
    let mut provider=Provider::with_id("synthetic-aggregate".into(),"Synthetic".into(),serde_json::json!({}),None);
    provider.meta=Some(crate::provider::ProviderMeta{aggregate_routes:Some(serde_json::from_value(json).unwrap()),..Default::default()});
    let (_,upstream)=resolve_target(&db,"claude-desktop",&provider,"claude-sonnet-4-5").unwrap();
    assert_eq!(upstream.as_deref(),Some("new-model"));
}


## Rust AggregateRoutes schema
//! 聚合供应商：无端点无凭据的虚拟供应商，按模型把请求分流到其他供应商。

use crate::claude_desktop_config::{is_claude_safe_model_id, ResolvedModelRoute};
use crate::error::AppError;
use crate::provider::Provider;
use serde::{Deserialize, Serialize};

#[cfg(test)]
#[path = "aggregate_retirement_tests.rs"]
mod retirement_tests;

/// 可写入 profile 的 `maxEffort` 合法取值（与 Claude Desktop 的 low…max 阶梯一致）。
/// 白名单外丢弃——避免用户被 Desktop 静默压到最低档（cap at low，实测 2.9939.4.0）。
const AGGREGATE_MAX_EFFORTS: [&str; 5] = ["low", "medium", "high", "xhigh", "max"];

/// 档位：决定 Claude Desktop 选择器里那句描述文字来自目录中哪个角色。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum AggregateTier {
    Sonnet,
    Opus,
    Haiku,
    Fable,
}

/// 一个槽位 = 一个可被 Claude 选择的模型。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AggregateRouteSlot {
    /// 槽位 ID（**持久化**，是稳定的路由键）。
    /// 由前端在编辑时生成并随表单提交（UI 预览即提交值）；后端只校验它
    /// （非空、claude-safe、不重复），运行时不重新生成——这样重命名供应商
    /// 不会改变已生效的路由。
    pub route_id: String,
    pub tier: AggregateTier,
    /// 目标供应商 id（被引用者受删除保护）
    pub provider_id: String,
    /// 该供应商的上游模型名
    pub upstream_model: String,
    /// 选择器显示名，如 "智谱 GLM-5.3"；缺省用上游模型名
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub label: Option<String>,
    /// 勾选后该模型在选择器里会多出一行 "1M context window"
    #[serde(default)]
    pub supports_1m: bool,
    /// 思考强度上限（camelCase: maxEffort）。仅完整阶梯 ID 有意义。
    #[serde(default)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_effort: Option<String>,
}

/// 别名路由规则：请求名未命中任何槽位时，按前缀（大小写不敏感）转投目标槽位。
/// 按序先匹配先赢；空前缀/悬空槽位静默跳过（可选优化项失效，非配置性错误）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AggregateAliasRule {
    pub prefix: String,
    pub slot_id: String,
}

/// 未命中路由时的兜底目标。按槽位 ID 或供应商 id 引用（不用下标——下标会随增删重排失效）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", tag = "kind", content = "value")]
pub enum DefaultTarget {
    SlotId(String),
    ProviderId(String),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AggregateRoutes {
    pub slots: Vec<AggregateRouteSlot>,
    pub default_target: DefaultTarget,
    /// 默认模型（槽位 routeId）：写 profile 时置顶到 inferenceModels 首位
    /// —— Claude Desktop 认第一条为默认模型、启动新会话从它起步。
    /// None（含旧数据，serde default）= 跟随排序首位，行为同 v3 之前。
    #[serde(default)]
    pub default_model: Option<String>,
    /// 别名规则：槽位未命中时按序做前缀匹配（见 resolve_target）。旧数据无此键，
    /// serde default 反序列化为空列表 —— 行为等同未启用。
    #[serde(default)]
    pub alias_rules: Vec<AggregateAliasRule>,
    /// 删除的路由名称仍保留身份，禁止旧会话静默改指新模型。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub retired_route_ids: Vec<String>,
}



## Full Claude runtime resolver
pub fn resolve_target(
    db: &crate::database::Database,
    app_type: &str,
    aggregate: &Provider,
    request_model: &str,
) -> Result<(Provider, Option<String>), AppError> {
    let routes = routes_of(aggregate)?;

    let requested =
        crate::claude_desktop_config::strip_one_m_suffix_for_route_lookup(request_model);

    if routes.retired_route_ids.iter().any(|id| id.trim().eq_ignore_ascii_case(requested)) {
        return Err(AppError::localized(
            "aggregate.route_retired",
            "该聚合模型路由已删除，请重新选择模型",
            "This aggregate model route was removed; select a model again",
        ));
    }

    // 直接按持久化的槽位 ID 查表（ID 由前端编辑时生成并随表单提交，运行时不重新生成）
    for slot in &routes.slots {
        if slot.route_id.trim() == requested {
            let target = load_provider(db, app_type, &slot.provider_id)?;
            return Ok((target, Some(slot.upstream_model.clone())));
        }
    }

    // 别名层：槽位未命中时按序前缀匹配（小写化），命中且目标槽存在 → 视同命中该槽。
    // 悬空/空前缀静默跳过，不报错——别名是可选优化项，不是安全网。
    // 悬空（slot_id 非空但解析不到槽）记 info：这是用户在日志里唯一的自助线索
    // （症状是别名请求落到兜底）。半成品规则（slot_id 为空，用户正在编辑）不记，
    // 否则编辑期间的每次请求都会刷一行。
    let lowered = requested.to_lowercase();
    for rule in &routes.alias_rules {
        let prefix = rule.prefix.trim().to_lowercase();
        if prefix.is_empty() || !lowered.starts_with(&prefix) {
            continue;
        }
        let Some(slot) = routes.slots.iter().find(|s| s.route_id.trim() == rule.slot_id.trim()) else {
            if !rule.slot_id.is_empty() {
                log::info!(
                    "[aggregate] alias rule '{prefix}' -> dangling slot '{}', skipped",
                    rule.slot_id
                );
            }
            continue;
        };
        let target = load_provider(db, app_type, &slot.provider_id)?;
        return Ok((target, Some(slot.upstream_model.clone())));
    }

    // 未命中 → 默认目标
    let fallback_id = match &routes.default_target {
        DefaultTarget::ProviderId(id) => id.clone(),
        DefaultTarget::SlotId(slot_id) => routes
            .slots
            .iter()
            .find(|slot| slot.route_id.trim() == slot_id.trim())
            .map(|slot| slot.provider_id.clone())
            .ok_or_else(|| {
                AppError::localized(
                    "aggregate.default_target_slot_missing",
                    "聚合供应商的默认目标指向了不存在的槽位",
                    "Aggregate default target points to a missing slot",
                )
            })?,
    };
    let target = load_provider(db, app_type, &fallback_id)?;
    Ok((target, None))
}



## Claude route save validation
// 聚合供应商校验。槽位 ID 由前端在编辑时生成并随表单提交（后端只校验、不生成），
        // 因此这里只需保证收到的路由表自洽：至少一个槽位、目标与模型必填、禁自引用、
        // 槽位 ID 合法且唯一。
        if let Some(routes) = provider
            .meta
            .as_ref()
            .and_then(|meta| meta.aggregate_routes.as_ref())
        {
            if routes.slots.is_empty() {
                return Err(AppError::localized(
                    "aggregate.slots_empty",
                    "聚合供应商至少需要一个槽位",
                    "Aggregate provider requires at least one slot",
                ));
            }
            let mut seen: Vec<String> = Vec::new();
            for slot in &routes.slots {
                if slot.provider_id.trim().is_empty() || slot.upstream_model.trim().is_empty() {
                    return Err(AppError::localized(
                        "aggregate.slot_incomplete",
                        "槽位必须同时指定目标供应商与上游模型",
                        "Each slot must specify both a target provider and an upstream model",
                    ));
                }
                if slot.provider_id == provider.id {
                    return Err(AppError::localized(
                        "aggregate.self_reference",
                        "聚合供应商不能把自身作为目标",
                        "An aggregate provider cannot target itself",
                    ));
                }
                // 槽位 ID 由前端生成（预览即实际值），这里只做校验
                let route_id = slot.route_id.trim();
                if route_id.is_empty()
                    || !crate::claude_desktop_config::is_claude_safe_model_id(route_id)
                {
                    return Err(AppError::localized(
                        "aggregate.invalid_route_id",
                        "槽位 ID 不合法（须形如 claude-sonnet-1）；Claude Desktop 会整组拒收",
                        "Invalid slot id (expected e.g. claude-sonnet-1); Claude Desktop would reject the whole group",
                    ));
                }
                if seen.iter().any(|s| s.eq_ignore_ascii_case(route_id)) {
                    return Err(AppError::localized(
                        "aggregate.duplicate_route_id",
                        "槽位 ID 重复",
                        "Duplicate slot id",
                    ));
                }
                seen.push(route_id.to_string());
            }

            for retired in &routes.retired_route_ids {
                let id = retired.trim();
                if id.is_empty() || seen.iter().any(|active| active.eq_ignore_ascii_case(id)) {
                    return Err(AppError::localized(
                        "aggregate.retired_route_invalid",
                        "已删除的路由 ID 不得为空或与当前模型重复",
                        "Retired route IDs must be non-empty and must not overlap active models",
                    ));
                }
            }

            // 默认目标必填且必须可用：未命中槽位的请求（Claude Desktop 的内部调用，
            // 如会话标题/摘要，正是此类）会回落到它；若它缺失或指向不存在的槽位，
            // 运行时会硬失败，故保存时就拦截（设计 §8/§9）。
            match &routes.default_target {
                crate::aggregate::DefaultTarget::ProviderId(id) => {
                    if id.trim().is_empty() {
                        return Err(AppError::localized(
                            "aggregate.default_target_invalid",
                            "聚合供应商必须指定默认目标：未命中槽位的请求会回落到它",
                            "Aggregate provider must specify a default target: unmatched requests fall back to it",
                        ));
                    }
                }
                crate::aggregate::DefaultTarget::SlotId(id) => {
                    let id = id.trim();
                    if !seen.iter().any(|s| s == id) {
                        return Err(AppError::localized(
                            "aggregate.default_target_invalid",
                            "聚合供应商的默认目标缺失，或指向了不存在的槽位（可能因槽位改动而失效，请重新选择）",
                            "Aggregate default target is missing or points to a non-existent slot (it may have been invalidated by slot changes; please reselect)",
                        ));
                    }
                }
            }
        }

        

## Exact change diff: src/i18n/locales/zh.json
--- before/src/i18n/locales/zh.json
+++ after/src/i18n/locales/zh.json
@@ -3280,6 +3280,13 @@
     "refresh": "刷新"
   },
   "aggregate": {
+    "migrationHint": "存量路由 ID 不兼容或重复。普通编辑保留原 ID；转换前请备份，旧会话可能需要重新选择模型。",
+    "migrationPreview": "预览旧路由转换",
+    "migrationBackup": "下载路由备份",
+    "migrationConfirm": "确认转换路由 ID",
+    "migrationLimits": "上限",
+    "migrationUnlimited": "不限制",
+
     "enable": "启用聚合路由",
     "title": "聚合供应商",
     "hint": "自身不存端点与密钥，按模型把请求分流到其他供应商。启用后需重启 Claude Desktop 生效。",


## Exact change diff: src/i18n/locales/en.json
--- before/src/i18n/locales/en.json
+++ after/src/i18n/locales/en.json
@@ -3280,6 +3280,13 @@
     "refresh": "Refresh"
   },
   "aggregate": {
+    "migrationHint": "Existing route IDs are incompatible or duplicated. Normal edits preserve IDs. Back up before converting; existing sessions may need to select a model again.",
+    "migrationPreview": "Preview legacy route conversion",
+    "migrationBackup": "Download route backup",
+    "migrationConfirm": "Confirm route ID conversion",
+    "migrationLimits": "Effort limit",
+    "migrationUnlimited": "Unlimited",
+
     "enable": "Enable aggregate routing",
     "title": "Aggregate provider",
     "hint": "Holds no endpoint or key; routes requests to other providers by model. Restart Claude Desktop after enabling.",


## Exact change diff: src/i18n/locales/ja.json
--- before/src/i18n/locales/ja.json
+++ after/src/i18n/locales/ja.json
@@ -1,4 +1,13 @@
 {
+  "aggregate": {
+    "migrationHint": "既存のルートIDに互換性の問題または重複があります。通常の編集ではIDを保持します。変換前にバックアップしてください。既存セッションでモデルの再選択が必要になる場合があります。",
+    "migrationPreview": "旧ルート変換のプレビュー",
+    "migrationBackup": "ルートのバックアップをダウンロード",
+    "migrationConfirm": "ルートIDの変換を確認",
+    "migrationLimits": "上限",
+    "migrationUnlimited": "制限なし"
+  },
+
   "app": {
     "title": "CC Switch",
     "description": "Claude Code・Codex・Gemini CLI のためのオールインワンアシスタント"


## Exact change diff: src/types.ts
--- before/src/types.ts
+++ after/src/types.ts
@@ -162,6 +162,8 @@
   defaultModel?: string;
   /** 别名路由规则：槽位未命中时按前缀（小写化、按序先赢）转投。缺省 = 无规则。 */
   aliasRules?: AggregateAliasRule[];
+  /** 已删除的路由 ID：跨保存保留，避免旧会话的名称被新模型复用。 */
+  retiredRouteIds?: string[];
 }
 
 // Codex 聚合路由（与上面的 Claude 侧表平行、形状互不兼容：独立 meta 键


## Exact change diff: src/utils/aggregateRoutes.ts
--- before/src/utils/aggregateRoutes.ts
+++ after/src/utils/aggregateRoutes.ts
@@ -4,6 +4,7 @@
   AggregateTier,
   Provider,
 } from "@/types";
+import { effortLevelsFor } from "./claudeDesktopCapability";
 
 /**
  * 每个档位的 **Claude Desktop 认得**的真模型 ID 池，按优先级排列。
@@ -97,6 +98,78 @@
   return Boolean(provider.meta?.aggregateRoutes);
 }
 
+/** 对齐同版本后端的 Claude-safe ID 判定；保存校验仍以后端为权威。 */
+function isCompatibleRouteId(id: string): boolean {
+  const value = id.trim().toLowerCase();
+  const vendor =
+    /ark-code|astron|command-r|deepseek|doubao|gemini|gemma|glm|gpt|grok|hermes|hy3|kimi|lfm|\bling\b|llama|longcat|mimo|minimax|mistral|mixtral|moonshot|nemotron|openai|phi-|qianfan|qwen|tc-code|\bunic\b|yi-|stepfun|step-3|seed-|bytedance|hunyuan|granite|amazon\.nova|nova-|devstral|ministral|ernie|codex|arcee|trinity|abab|phi\d|\bk2\.|\bm2\.|jamba|arctic|solar|mercury|zamba|kat-coder|\bds-|dpsk/;
+  return (
+    !value.includes("[1m]") &&
+    !vendor.test(value) &&
+    /^(?:anthropic\/)?claude-(?:sonnet|opus|haiku|fable)-.+$/.test(value)
+  );
+}
+
+export function needsRouteIdMigration(routes: AggregateRoutes): boolean {
+  const seen = new Set<string>();
+  return routes.slots.some((slot) => {
+    const id = slot.routeId.trim().toLowerCase();
+    const invalid = !isCompatibleRouteId(id) || seen.has(id);
+    seen.add(id);
+    return invalid;
+  });
+}
+
+/** 仅供用户明确预览/确认迁移调用；普通编辑绝不自动转换旧 ID。 */
+export function migrateIncompatibleRouteIds(
+  routes: AggregateRoutes,
+): AggregateRoutes {
+  const counts = new Map<string, number>();
+  for (const slot of routes.slots) {
+    const id = slot.routeId.trim().toLowerCase();
+    counts.set(id, (counts.get(id) ?? 0) + 1);
+  }
+  const slots = routes.slots.map((slot) => {
+    const id = slot.routeId.trim().toLowerCase();
+    const replace = !isCompatibleRouteId(id) || (counts.get(id) ?? 0) > 1;
+    return replace ? { ...slot, routeId: "" } : slot;
+  });
+  const assigned = assignSlotIds({ ...routes, slots }, routes);
+  const remap = new Map<string, string>();
+  routes.slots.forEach((slot, i) => {
+    if (slot.routeId && !remap.has(slot.routeId))
+      remap.set(slot.routeId, assigned.slots[i].routeId);
+  });
+  return {
+    ...assigned,
+    slots: assigned.slots.map((slot) =>
+      slot.maxEffort && !effortLevelsFor(slot.routeId).includes(slot.maxEffort)
+        ? { ...slot, maxEffort: undefined }
+        : slot,
+    ),
+    defaultTarget:
+      routes.defaultTarget.kind === "slotId"
+        ? {
+            kind: "slotId",
+            value:
+              remap.get(routes.defaultTarget.value) ??
+              routes.defaultTarget.value,
+          }
+        : routes.defaultTarget,
+    defaultModel: routes.defaultModel
+      ? remap.get(routes.defaultModel)
+      : undefined,
+    ...(routes.aliasRules
+      ? {
+          aliasRules: routes.aliasRules.map((rule) => ({
+            ...rule,
+            slotId: remap.get(rule.slotId) ?? "",
+          })),
+        }
+      : {}),
+  };
+}
+
 /** 由槽位派生标签（选择器显示名）：显式填写优先，否则「供应商 · 上游模型」。
  *
  *  未填写时**必须**给出非空默认值——空值会让 profile 省略 `labelOverride`，
@@ -122,7 +195,13 @@
   routes: AggregateRoutes | undefined | null,
 ): boolean {
   return Boolean(
-    routes && routes.slots.length > 0 && routes.defaultTarget?.value.trim(),
+    routes &&
+      routes.slots.length > 0 &&
+      routes.defaultTarget?.value.trim() &&
+      (routes.defaultTarget.kind !== "slotId" ||
+        routes.slots.some(
+          (s) => s.routeId.trim() === routes.defaultTarget.value.trim(),
+        )),
   );
 }
 
@@ -140,13 +219,12 @@
 /** 供应商卡的视图形状：一家供应商 + 各档位已映射的槽位（未映射的档位无键）。 */
 export interface ProviderTierRows {
   providerId: string;
-  rows: Partial<Record<AggregateTier, AggregateRouteSlot>>;
+  rows: Partial<Record<AggregateTier, AggregateRouteSlot[]>>;
 }
 
 /**
  * 扁平槽位按供应商分组（编辑器渲染用）。卡序 = 供应商在列表里的首次出现顺序。
- * 同供应商同档位的存量重复取首个——新的固定档位行 UI 造不出这种重复，此处仅
- * 归一旧数据，编辑后保存即消失。
+ * 同供应商同档位可以有多个模型，按原出现顺序完整保留。
  */
 export function groupSlotsByProvider(
   slots: AggregateRouteSlot[],
@@ -160,9 +238,7 @@
       byProvider.set(slot.providerId, card);
       cards.push(card);
     }
-    if (!card.rows[slot.tier]) {
-      card.rows[slot.tier] = slot;
-    }
+    (card.rows[slot.tier] ??= []).push(slot);
   }
   return cards;
 }
@@ -174,71 +250,55 @@
   return cards.flatMap((card) => {
     const rows: AggregateRouteSlot[] = [];
     for (const tier of TIER_ROW_ORDER) {
-      const slot = card.rows[tier];
-      if (slot) rows.push(slot);
+      rows.push(...(card.rows[tier] ?? []));
     }
     return rows;
   });
 }
 
-/** 为所有槽位重新生成 routeId（按档位分别编号），并让默认目标、默认模型、别名规则按位置跟随。
- *
- *  在槽位增删、档位变更后调用，也可用于**迁移存量 ID**（旧方案含供应商名，
- *  会被 Claude Desktop 整组拒绝）。默认目标/默认模型若引用的是槽位 ID：以它在
- *  **本表内的位置**取新 ID；引用的槽位已被删除（旧 ID 不在本表里）时，默认目标
- *  保持原值（交由保存校验拦截，绝不静默改指到另一个槽位），默认模型置空
- *  （只影响启动默认、回落到排序首位，无需拦截），别名规则的 slotId 置空串
- *  （规则行保留，运行时按悬空跳过——别名是可选优化项，不是安全网）。 */
-export function assignSlotIds(routes: AggregateRoutes): AggregateRoutes {
-  const ordinalByTier = new Map<AggregateTier, number>();
-  const taken = new Set<string>();
-  const ids = routes.slots.map((slot) => {
-    const ordinal = (ordinalByTier.get(slot.tier) ?? 0) + 1;
-    ordinalByTier.set(slot.tier, ordinal);
-    const id = slotId(slot.tier, ordinal, taken);
-    taken.add(id);
-    return id;
-  });
-
-  const slots = routes.slots.map((slot, index) => ({
-    ...slot,
-    routeId: ids[index],
+/** 只给新槽位分配 ID；既有身份不随编辑或排序改变。删除记录跨保存保留。 */
+export function assignSlotIds(
+  routes: AggregateRoutes,
+  previous?: AggregateRoutes,
+): AggregateRoutes {
+  const activeIds = new Set(routes.slots.map((s) => s.routeId).filter(Boolean));
+  const retired = new Set([
+    ...(previous?.retiredRouteIds ?? []),
+    ...(routes.retiredRouteIds ?? []),
+  ]);
+  for (const slot of previous?.slots ?? []) {
+    if (slot.routeId && !activeIds.has(slot.routeId)) retired.add(slot.routeId);
+  }
+  const canonical = (id: string) => id.trim().toLowerCase();
+  const taken = new Set([...activeIds, ...retired].map(canonical));
+  // 悬空引用也不得被一条新行悄悄认领；默认目标留给保存校验要求重新选择。
+  if (routes.defaultTarget.kind === "slotId" && routes.defaultTarget.value)
+    taken.add(canonical(routes.defaultTarget.value));
+  if (routes.defaultModel) taken.add(canonical(routes.defaultModel));
+  for (const rule of routes.aliasRules ?? [])
+    if (rule.slotId) taken.add(canonical(rule.slotId));
+  const slots = routes.slots.map((slot) => {
+    if (slot.routeId) return { ...slot };
+    let ordinal = 1;
+    let id = slotId(slot.tier, ordinal, taken);
+    while (taken.has(canonical(id))) id = slotId(slot.tier, ++ordinal, taken);
+    taken.add(canonical(id));
+    return { ...slot, routeId: id };
+  });
+  const live = new Set(slots.map((s) => s.routeId.trim()));
+  const defaultModel =
+    routes.defaultModel && live.has(routes.defaultModel.trim())
+      ? routes.defaultModel
+      : undefined;
+  const aliasRules = routes.aliasRules?.map((rule) => ({
+    ...rule,
+    slotId: rule.slotId && live.has(rule.slotId.trim()) ? rule.slotId : "",
   }));
-
-  let defaultTarget = routes.defaultTarget;
-  if (defaultTarget.kind === "slotId") {
-    const index = routes.slots.findIndex(
-      (slot) => slot.routeId === defaultTarget.value,
-    );
-    if (index >= 0) {
-      defaultTarget = { kind: "slotId", value: ids[index] };
-    }
-  }
-
-  let defaultModel = routes.defaultModel;
-  if (defaultModel) {
-    const index = routes.slots.findIndex(
-      (slot) => slot.routeId === defaultModel,
-    );
-    defaultModel = index >= 0 ? ids[index] : undefined;
-  }
-
-  const aliasRules = routes.aliasRules?.map((rule) => {
-    // 空 slotId = 用户尚未选定目标（或已被清空），不得被 addRow 造出的
-    // routeId:"" 新行认领 —— 否则半成品规则会静默绑到无关槽位。
-    const index = rule.slotId
-      ? routes.slots.findIndex((slot) => slot.routeId === rule.slotId)
-      : -1;
-    return index >= 0
-      ? { ...rule, slotId: ids[index] }
-      : { ...rule, slotId: "" };
-  });
-
   return {
     ...routes,
     slots,
-    defaultTarget,
     defaultModel,
     ...(aliasRules ? { aliasRules } : {}),
+    ...(retired.size ? { retiredRouteIds: [...retired] } : {}),
   };
 }


## Exact change diff: src/utils/aggregateRoutes.test.ts
--- before/src/utils/aggregateRoutes.test.ts
+++ after/src/utils/aggregateRoutes.test.ts
@@ -212,7 +212,7 @@
     ]);
   });
 
-  it("档位变化会改变 ID", () => {
+  it("编辑档位元数据不隐式改变已有 ID", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -224,10 +224,10 @@
         },
       ],
     });
-    expect(next.slots[0].routeId).toBe("claude-opus-4-8");
-  });
-
-  it("重算所有槽位，旧的 routeId 不会残留", () => {
+    expect(next.slots[0].routeId).toBe("claude-sonnet-4-6");
+  });
+
+  it("重复存量 ID 不被隐式迁移，仍由后端保存校验拒绝", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -246,12 +246,12 @@
       ],
     });
     expect(next.slots.map((s) => s.routeId)).toEqual([
-      "claude-opus-4-8",
-      "claude-sonnet-4-6",
-    ]);
-  });
-
-  it("上一版序号方案（claude-opus-1）的存量 ID 会被迁移成池内 ID", () => {
+      "claude-sonnet-stale",
+      "claude-sonnet-stale",
+    ]);
+  });
+
+  it("上一版合法序号 ID 保留而不改变旧会话身份", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -270,12 +270,12 @@
       ],
     });
     expect(next.slots.map((s) => s.routeId)).toEqual([
-      "claude-opus-4-8",
-      "claude-opus-4-7",
-    ]);
-  });
-
-  it("旧方案（含供应商名）的存量 ID 会被迁移掉", () => {
+      "claude-opus-1",
+      "claude-opus-2",
+    ]);
+  });
+
+  it("不兼容存量 ID 不在普通编辑中静默迁移", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -287,10 +287,10 @@
         },
       ],
     });
-    expect(next.slots[0].routeId).toBe("claude-fable-1");
-  });
-
-  it("默认目标引用槽位 ID 时，按位置跟随重编号", () => {
+    expect(next.slots[0].routeId).toBe("claude-fable-zhipu-glm");
+  });
+
+  it("默认目标继续引用原槽位身份", () => {
     const next = assignSlotIds({
       defaultTarget: { kind: "slotId", value: "claude-fable-zhipu-glm" },
       slots: [
@@ -310,7 +310,7 @@
     });
     expect(next.defaultTarget).toEqual({
       kind: "slotId",
-      value: "claude-fable-1",
+      value: "claude-fable-zhipu-glm",
     });
   });
 
@@ -366,16 +366,16 @@
     ]);
     expect(cards.map((card) => card.providerId)).toEqual(["p-glm", "p-ds"]);
     expect(Object.keys(cards[0].rows)).toEqual(["fable", "opus"]);
-    expect(cards[1].rows.opus?.upstreamModel).toBe("deepseek-flash");
-  });
-
-  it("同供应商同档位的存量重复取首个（新 UI 固定档位行造不出重复）", () => {
+    expect(cards[1].rows.opus?.[0].upstreamModel).toBe("deepseek-flash");
+  });
+
+  it("同供应商同档位所有存量模型都保留", () => {
     const cards = groupSlotsByProvider([
       slot("keep", "opus", "p-glm", "glm-5.3"),
       slot("drop", "opus", "p-glm", "glm-5.3-flash"),
     ]);
     expect(cards).toHaveLength(1);
-    expect(cards[0].rows.opus?.routeId).toBe("keep");
+    expect(cards[0].rows.opus?.map(s => s.routeId)).toEqual(["keep", "drop"]);
   });
 
   it("空列表得空卡片数组", () => {
@@ -384,12 +384,12 @@
 
   it("展平按卡序 × 档位固定顺序重建（fable→opus→sonnet→haiku）", () => {
     const flat = flattenProviderGroups([
-      { providerId: "p-ds", rows: { opus: slot("x", "opus", "p-ds", "d1") } },
+      { providerId: "p-ds", rows: { opus: [slot("x", "opus", "p-ds", "d1")] } },
       {
         providerId: "p-glm",
         rows: {
-          haiku: slot("h", "haiku", "p-glm", "g3"),
-          fable: slot("f", "fable", "p-glm", "g1"),
+          haiku: [slot("h", "haiku", "p-glm", "g3")],
+          fable: [slot("f", "fable", "p-glm", "g1")],
         },
       },
     ]);
@@ -404,7 +404,7 @@
     const flat = flattenProviderGroups([
       {
         providerId: "p-glm",
-        rows: { fable: slot("f", "fable", "p-glm", "g1") },
+        rows: { fable: [slot("f", "fable", "p-glm", "g1")] },
       },
     ]);
     expect(flat).toHaveLength(1);
@@ -420,7 +420,7 @@
     defaultTarget: { kind: "providerId" as const, value: "p-glm" },
   };
 
-  it("引用的槽位重编号后按位置跟随", () => {
+  it("默认模型继续引用原槽位 ID", () => {
     const next = assignSlotIds({
       ...base,
       defaultModel: "claude-opus-deepseek",
@@ -439,7 +439,7 @@
         },
       ],
     });
-    expect(next.defaultModel).toBe("claude-opus-4-8");
+    expect(next.defaultModel).toBe("claude-opus-deepseek");
   });
 
   it("引用的槽位被删时置空（回落到排序首位）", () => {
@@ -495,7 +495,7 @@
     defaultTarget: { kind: "providerId" as const, value: "p1" },
   };
 
-  it("引用的槽被重编号时规则跟随到新 ID", () => {
+  it("插入新槽时别名仍引用原槽位身份", () => {
     const aliasRules: AggregateAliasRule[] = [
       { prefix: "claude-haiku", slotId: "claude-haiku-3" },
     ];
@@ -515,10 +515,10 @@
       ],
     };
     const out = assignSlotIds(inserted);
-    expect(out.slots[2].routeId).toBe("claude-haiku-2");
+    expect(out.slots[2].routeId).toBe("claude-haiku-3");
     expect(out.aliasRules?.[0]).toEqual({
       prefix: "claude-haiku",
-      slotId: "claude-haiku-2",
+      slotId: "claude-haiku-3",
     });
   });
 


## Exact change diff: src/utils/aggregateRoutes.compatibility.test.ts
--- before/src/utils/aggregateRoutes.compatibility.test.ts
+++ after/src/utils/aggregateRoutes.compatibility.test.ts
@@ -0,0 +1,155 @@
+import { describe, expect, it } from "vitest";
+import {
+  assignSlotIds,
+  flattenProviderGroups,
+  groupSlotsByProvider,
+  migrateIncompatibleRouteIds,
+  needsRouteIdMigration,
+} from "./aggregateRoutes";
+import type { AggregateRoutes } from "@/types";
+
+const initial: AggregateRoutes = {
+  slots: [
+    {
+      routeId: "claude-sonnet-4-6",
+      tier: "sonnet",
+      providerId: "a",
+      upstreamModel: "upstream-a",
+      label: "A",
+      maxEffort: "high",
+      supports1m: true,
+    },
+    {
+      routeId: "claude-sonnet-4-5",
+      tier: "sonnet",
+      providerId: "b",
+      upstreamModel: "upstream-b",
+      label: "B",
+    },
+  ],
+  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
+  defaultModel: "claude-sonnet-4-6",
+  aliasRules: [{ prefix: "team", slotId: "claude-sonnet-4-6" }],
+};
+
+describe("aggregate compatibility contract", () => {
+  it("case-variant legacy duplicates require explicit migration and retire the entire ambiguous namespace", () => {
+    const routes: AggregateRoutes = {
+      ...initial,
+      slots: [
+        initial.slots[0],
+        { ...initial.slots[1], routeId: "CLAUDE-SONNET-4-6" },
+      ],
+    };
+    expect(needsRouteIdMigration(routes)).toBe(true);
+    const next = migrateIncompatibleRouteIds(routes);
+    expect(
+      next.slots.every((s) => s.routeId.toLowerCase() !== "claude-sonnet-4-6"),
+    ).toBe(true);
+    expect(
+      next.retiredRouteIds?.some(
+        (id) => id.toLowerCase() === "claude-sonnet-4-6",
+      ),
+    ).toBe(true);
+  });
+  it("confirmed migration also normalizes an unsupported cap on an unchanged valid ID", () => {
+    const routes: AggregateRoutes = {
+      ...initial,
+      slots: [
+        { ...initial.slots[0], maxEffort: "xhigh" },
+        { ...initial.slots[1], routeId: "claude-fable-glm", tier: "fable" },
+      ],
+    };
+    const next = migrateIncompatibleRouteIds(routes);
+    expect(next.slots[0].routeId).toBe(initial.slots[0].routeId);
+    expect(next.slots[0].maxEffort).toBeUndefined();
+  });
+  it("explicit duplicate-ID migration removes a strength cap unsupported by the new ID", () => {
+    const routes: AggregateRoutes = {
+      slots: [
+        { ...initial.slots[0], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
+        { ...initial.slots[1], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
+      ],
+      defaultTarget: { kind: "providerId", value: "a" },
+    };
+    const migrated = migrateIncompatibleRouteIds(routes);
+    expect(migrated.slots[0].routeId).toBe("claude-sonnet-4-6");
+    expect(migrated.slots[0].maxEffort).toBeUndefined();
+    expect(migrated.slots[1].routeId).toBe("claude-sonnet-4-5");
+    expect(migrated.slots[1].maxEffort).toBeUndefined();
+  });
+  it("allocation does not reuse a retired ID with different letter case", () => {
+    const routes: AggregateRoutes = {
+      slots: [{ ...initial.slots[0], routeId: "" }],
+      defaultTarget: { kind: "providerId", value: "a" },
+      retiredRouteIds: ["CLAUDE-SONNET-4-6"],
+    };
+    expect(assignSlotIds(routes).slots[0].routeId).not.toBe(
+      "claude-sonnet-4-6",
+    );
+  });
+  it("reordering preserves the old model ID, mapping, default and alias", () => {
+    const next = assignSlotIds({
+      ...initial,
+      slots: [...initial.slots].reverse(),
+    });
+    expect(
+      next.slots.find((s) => s.routeId === initial.slots[0].routeId),
+    ).toEqual(initial.slots[0]);
+    expect(next.defaultTarget).toEqual(initial.defaultTarget);
+    expect(next.defaultModel).toBe(initial.defaultModel);
+    expect(next.aliasRules).toEqual(initial.aliasRules);
+  });
+
+  it("inserting a new model does not steal an existing ID", () => {
+    const next = assignSlotIds({
+      ...initial,
+      slots: [
+        {
+          ...initial.slots[0],
+          routeId: "",
+          providerId: "new",
+          upstreamModel: "new-model",
+        },
+        ...initial.slots,
+      ],
+    });
+    expect(next.slots.slice(1)).toEqual(initial.slots);
+    expect(next.slots[0].routeId).not.toBe(initial.slots[0].routeId);
+    expect(next.defaultModel).toBe(initial.defaultModel);
+  });
+
+  it("deleting then adding and reloading cannot recycle a retired model ID", () => {
+    const deleted = assignSlotIds(
+      {
+        ...initial,
+        slots: [initial.slots[1]],
+        defaultTarget: { kind: "providerId", value: "b" },
+      },
+      initial,
+    );
+    const persisted = JSON.parse(JSON.stringify(deleted)) as AggregateRoutes;
+    const added = assignSlotIds(
+      {
+        ...persisted,
+        slots: [
+          ...persisted.slots,
+          { ...initial.slots[0], routeId: "", upstreamModel: "new-model" },
+        ],
+      },
+      persisted,
+    );
+    expect(added.slots[0].routeId).toBe(initial.slots[1].routeId);
+    expect(added.slots[1].routeId).not.toBe(initial.slots[0].routeId);
+    expect(
+      (added as AggregateRoutes & { retiredRouteIds?: string[] })
+        .retiredRouteIds,
+    ).toContain(initial.slots[0].routeId);
+    expect(added.aliasRules?.[0].slotId).toBe("");
+  });
+
+  it("grouping and flattening retains every model in the same provider/tier", () => {
+    const slots = initial.slots.map((s) => ({ ...s, providerId: "a" }));
+    expect(flattenProviderGroups(groupSlotsByProvider(slots))).toEqual(slots);
+  });
+});


## Exact change diff: src/components/providers/forms/AggregateProviderFields.tsx
--- before/src/components/providers/forms/AggregateProviderFields.tsx
+++ after/src/components/providers/forms/AggregateProviderFields.tsx
@@ -1,4 +1,4 @@
-import { useMemo, useState } from "react";
+import { useEffect, useMemo, useState } from "react";
 import {
   ChevronDown,
   ChevronRight,
@@ -66,6 +66,8 @@
   slotLabel,
   TIER_ROW_ORDER,
   type ProviderTierRows,
+  needsRouteIdMigration,
+  migrateIncompatibleRouteIds,
 } from "@/utils/aggregateRoutes";
 import {
   effortCapability,
@@ -134,6 +136,24 @@
 }: Props) {
   const { t } = useTranslation();
 
+  const [migrationPreview, setMigrationPreview] = useState<AggregateRoutes>();
+  const [migrationBackup, setMigrationBackup] = useState(false);
+  useEffect(() => {
+    setMigrationPreview(undefined);
+    setMigrationBackup(false);
+  }, [value]);
+  const downloadMigrationBackup = () => {
+    const url = URL.createObjectURL(
+      new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }),
+    );
+    const link = document.createElement("a");
+    link.href = url;
+    link.download = "aggregate-routes-before-migration.json";
+    link.click();
+    URL.revokeObjectURL(url);
+    setMigrationBackup(true);
+  };
+
   // 显示名默认值要带上供应商名：同一个上游模型可能挂在两家供应商上，
   // 只写模型名仍分不清实际调用的是哪一家。
   const providerNameById = new Map(candidates.map((p) => [p.id, p.name]));
@@ -162,16 +182,14 @@
     return [...grouped, ...extras];
   }, [grouped, pendingProviders]);
 
-  // 每次变更都重算所有槽位 ID：保证「预览 = 实际提交值」。
-  // assignSlotIds 会按档位从零重编号，并让默认目标/默认模型按位置跟随，
-  // 故增删槽位后引用不会悬空（默认目标悬空保持原值交由保存校验拦截；
-  // 默认模型悬空置空回落排序首位）。
+  // 新行分配 ID；既有 ID 不因排序或编辑变化。
+  // assignSlotIds 保留既有身份，并记录删除的 ID 防止重用，
+  // 删除引用目标时默认目标保持原值，由保存校验要求重新选择；
+  // 默认模型悬空置空回落排序首位。
   //
-  // 归一化必须先 assignSlotIds 再判定：槽位增删会让序号轮换、ID 在溢出↔池内
-  // 之间变档，用旧 ID 判定会剥错方向。判定用该 ID 的具体阶梯（effortLevelsFor，
-  // 非 ladder 返回 []）而非三态——同为完整阶梯的 4-6 系不含 xhigh，越阶值同样要剥。
+  // 先为新行分配 ID，再按每行的实际兼容阶梯校验上限；既有 ID 和有效上限不变。
   const commit = (next: AggregateRoutes) => {
-    const assigned = assignSlotIds(next);
+    const assigned = assignSlotIds(next, value);
     return onChange({
       ...assigned,
       slots: assigned.slots.map((s) =>
@@ -186,7 +204,7 @@
    *  任何档位）存进 pendingProviders。 */
   const commitCards = (next: ProviderTierRows[]) => {
     const hasRows = (card: ProviderTierRows) =>
-      TIER_ROW_ORDER.some((tier) => card.rows[tier]);
+      TIER_ROW_ORDER.some((tier) => card.rows[tier]?.length);
     setPendingProviders(
       next.filter((card) => !hasRows(card)).map((c) => c.providerId),
     );
@@ -202,8 +220,9 @@
     card.providerId = providerId;
     // 行内的槽位各自带着 providerId（扁平存储的冗余），换卡头时同步改写
     for (const tier of TIER_ROW_ORDER) {
-      const slot = card.rows[tier];
-      if (slot) card.rows[tier] = { ...slot, providerId };
+      const slots = card.rows[tier];
+      if (slots)
+        card.rows[tier] = slots.map((slot) => ({ ...slot, providerId }));
     }
     commitCards(next);
   };
@@ -211,31 +230,45 @@
   const patchRow = (
     cardIndex: number,
     tier: AggregateTier,
+    rowIndex: number,
     patch: Partial<AggregateRouteSlot>,
   ) => {
     const next = cloneCards(cards);
-    const slot = next[cardIndex].rows[tier];
-    if (!slot) return;
-    next[cardIndex].rows[tier] = { ...slot, ...patch };
+    const slots = next[cardIndex].rows[tier];
+    if (!slots?.[rowIndex]) return;
+    next[cardIndex].rows[tier] = slots.map((slot, i) =>
+      i === rowIndex ? { ...slot, ...patch } : slot,
+    );
     commitCards(next);
   };
 
-  const removeRow = (cardIndex: number, tier: AggregateTier) => {
+  const removeRow = (
+    cardIndex: number,
+    tier: AggregateTier,
+    rowIndex: number,
+  ) => {
     const next = cloneCards(cards);
-    delete next[cardIndex].rows[tier];
+    const remaining = (next[cardIndex].rows[tier] ?? []).filter(
+      (_, i) => i !== rowIndex,
+    );
+    if (remaining.length) next[cardIndex].rows[tier] = remaining;
+    else delete next[cardIndex].rows[tier];
     commitCards(next);
   };
 
-  /** 新增档位行：只允许未占用的档（v3：增量添加替代固定四行）。 */
+  /** 每个档位可以添加多个独立模型。 */
   const addRow = (cardIndex: number, tier: AggregateTier) => {
     const next = cloneCards(cards);
-    next[cardIndex].rows[tier] = {
-      routeId: "",
-      tier,
-      providerId: next[cardIndex].providerId,
-      upstreamModel: "",
-      supports1m: false,
-    };
+    next[cardIndex].rows[tier] = [
+      ...(next[cardIndex].rows[tier] ?? []),
+      {
+        routeId: "",
+        tier,
+        providerId: next[cardIndex].providerId,
+        upstreamModel: "",
+        supports1m: false,
+      },
+    ];
     // 新行自动展开（用户要立刻填它）
     const cardId = next[cardIndex].providerId;
     setExpandedIds((prev) => new Set(prev).add(cardId));
@@ -245,7 +278,7 @@
   const removeCard = (cardIndex: number) =>
     commitCards(cards.filter((_, i) => i !== cardIndex));
 
-  /** 别名规则改动直接走 commit：assignSlotIds 会跟随重编号，maxEffort 归一化不受影响。 */
+  /** 别名规则改动不改变槽位身份；按实际 ID 校验有效上限。 */
   const patchAliasRule = (
     index: number,
     patch: Partial<AggregateAliasRule>,
@@ -321,6 +354,82 @@
         <h3 className="text-sm font-medium">{t("aggregate.title")}</h3>
         <p className="text-xs text-muted-foreground">{t("aggregate.hint")}</p>
       </header>
+
+      {needsRouteIdMigration(value) && (
+        <div className="space-y-2 rounded-md border p-3 text-xs">
+          <p>
+            {t("aggregate.migrationHint", {
+              defaultValue:
+                "存量路由 ID 不兼容或重复。普通编辑保留原 ID；转换前请备份，旧会话可能需要重新选择模型。",
+            })}
+          </p>
+          <Button
+            type="button"
+            variant="outline"
+            size="sm"
+            onClick={() => {
+              setMigrationPreview(migrateIncompatibleRouteIds(value));
+              setMigrationBackup(false);
+            }}
+          >
+            {t("aggregate.migrationPreview", {
+              defaultValue: "预览旧路由转换",
+            })}
+          </Button>
+          {migrationPreview && (
+            <>
+              <pre className="whitespace-pre-wrap">
+                {value.slots
+                  .map(
+                    (slot, i) =>
+                      `${slot.routeId} → ${migrationPreview.slots[i]?.routeId}；${t("aggregate.migrationLimits", { defaultValue: "上限" })} ${slot.maxEffort ?? t("aggregate.migrationUnlimited", { defaultValue: "不限制" })} → ${migrationPreview.slots[i]?.maxEffort ?? t("aggregate.migrationUnlimited", { defaultValue: "不限制" })}`,
+                  )
+                  .join("\n")}
+              </pre>
+              <p>
+                {t("aggregate.defaultTarget", { defaultValue: "兜底目标" })}:{" "}
+                {value.defaultTarget.value} →{" "}
+                {migrationPreview.defaultTarget.value}
+              </p>
+              <p>
+                {t("aggregate.defaultModel", { defaultValue: "默认模型" })}:{" "}
+                {value.defaultModel ?? "—"} →{" "}
+                {migrationPreview.defaultModel ?? "—"}
+              </p>
+              {(value.aliasRules ?? []).map((rule, i) => (
+                <p key={i}>
+                  {rule.prefix}: {rule.slotId || "—"} →{" "}
+                  {migrationPreview.aliasRules?.[i]?.slotId || "—"}
+                </p>
+              ))}
+              <Button
+                type="button"
+                variant="outline"
+                size="sm"
+                onClick={downloadMigrationBackup}
+              >
+                {t("aggregate.migrationBackup", {
+                  defaultValue: "下载路由备份",
+                })}
+              </Button>
+              <Button
+                type="button"
+                size="sm"
+                disabled={!migrationBackup}
+                onClick={() => {
+                  onChange(migrationPreview);
+                  setMigrationPreview(undefined);
+                  setMigrationBackup(false);
+                }}
+              >
+                {t("aggregate.migrationConfirm", {
+                  defaultValue: "确认转换路由 ID",
+                })}
+              </Button>
+            </>
+          )}
+        </div>
+      )}
 
       {!canSaveAggregateRoutes(value) && (
         <p className="text-xs text-destructive">{t("aggregate.notSaveable")}</p>
@@ -544,17 +653,19 @@
               );
               const target = candidates.find((p) => p.id === card.providerId);
               const fetched = modelsForProvider(card.providerId);
-              const mappedTiers = TIER_ROW_ORDER.filter(
-                (tier) => card.rows[tier],
+              const mappedRows = TIER_ROW_ORDER.flatMap((tier) =>
+                (card.rows[tier] ?? []).map((slot, rowIndex) => ({
+                  tier,
+                  slot,
+                  rowIndex,
+                })),
               );
-              const unusedTiers = TIER_ROW_ORDER.filter(
-                (tier) => !card.rows[tier],
-              );
+              const availableTiers = TIER_ROW_ORDER;
               const expanded = expandedIds.has(card.providerId);
               // routeId 恒非空（每次 commit 都经 assignSlotIds 赋真 ID），无已映射
               // 槽位时 effectiveDefault 为 ""，恒不命中，无需再挡空值。
-              const isDefaultCard = Object.values(card.rows).some(
-                (slot) => slot?.routeId === effectiveDefault,
+              const isDefaultCard = mappedRows.some(
+                ({ slot }) => slot.routeId === effectiveDefault,
               );
               return (
                 <SortableCard key={card.providerId} id={card.providerId}>
@@ -665,15 +776,13 @@
 
                           {/* 已映射档位的行（v3：增量添加，不再固定四行）。行尾 ×
                               删除该槽；行内不支持改档位（删了重加）。 */}
-                          {mappedTiers.map((tier) => {
-                            const slot = card.rows[tier];
-                            if (!slot) return null;
+                          {mappedRows.map(({ tier, slot, rowIndex }) => {
                             const isEffectiveDefault =
                               slot.routeId === effectiveDefault;
-                            const switchId = `agg-1m-${cardIndex}-${tier}`;
+                            const switchId = `agg-1m-${slot.routeId || `${cardIndex}-${tier}-${rowIndex}`}`;
                             return (
                               <div
-                                key={tier}
+                                key={slot.routeId || `${tier}-${rowIndex}`}
                                 className="flex items-center gap-2"
                                 // 槽位 ID 不占版面，悬停可查——排查代理日志里的
                                 // request_model 时用得上
@@ -684,7 +793,7 @@
                                 </span>
                                 <EffortBadge routeId={slot.routeId} />
                                 <div className="flex min-w-0 flex-1 gap-1">
-                                {/* 上游模型只改值，不再承担行的生死——删行走
+                                  {/* 上游模型只改值，不再承担行的生死——删行走
                                     行尾 × 按钮（v3 语义）。 */}
                                   <Input
                                     className="h-8 min-w-0 flex-1"
@@ -694,7 +803,7 @@
                                       { defaultValue: "上游模型名" },
                                     )}
                                     onChange={(e) =>
-                                      patchRow(cardIndex, tier, {
+                                      patchRow(cardIndex, tier, rowIndex, {
                                         upstreamModel: e.target.value,
                                       })
                                     }
@@ -703,7 +812,7 @@
                                     <ModelDropdown
                                       models={fetched}
                                       onSelect={(id) =>
-                                        patchRow(cardIndex, tier, {
+                                        patchRow(cardIndex, tier, rowIndex, {
                                           upstreamModel: id,
                                         })
                                       }
@@ -717,7 +826,7 @@
                                     value={slot.label ?? ""}
                                     // 留空则不落库；提交时由表单统一补成「供应商 · 上游模型」
                                     onValueChange={(v) =>
-                                      patchRow(cardIndex, tier, {
+                                      patchRow(cardIndex, tier, rowIndex, {
                                         label: v.trim() ? v : undefined,
                                       })
                                     }
@@ -734,7 +843,9 @@
                                   routeId={slot.routeId}
                                   value={slot.maxEffort}
                                   onChange={(v) =>
-                                    patchRow(cardIndex, tier, { maxEffort: v })
+                                    patchRow(cardIndex, tier, rowIndex, {
+                                      maxEffort: v,
+                                    })
                                   }
                                 />
                                 <div className="flex w-20 shrink-0 items-center justify-end gap-1.5">
@@ -742,7 +853,7 @@
                                     id={switchId}
                                     checked={Boolean(slot.supports1m)}
                                     onCheckedChange={(v) =>
-                                      patchRow(cardIndex, tier, {
+                                      patchRow(cardIndex, tier, rowIndex, {
                                         supports1m: v,
                                       })
                                     }
@@ -762,7 +873,9 @@
                                   title={t("aggregate.removeModel", {
                                     defaultValue: "删除该模型",
                                   })}
-                                  onClick={() => removeRow(cardIndex, tier)}
+                                  onClick={() =>
+                                    removeRow(cardIndex, tier, rowIndex)
+                                  }
                                 >
                                   <X className="h-3.5 w-3.5" />
                                 </Button>
@@ -770,8 +883,8 @@
                             );
                           })}
 
-                          {/* 新增模型：只列未占用的档位；满 4 档隐藏 */}
-                          {unusedTiers.length > 0 && (
+                          {/* 新增模型：各档位允许多行，不覆盖既有模型 */}
+                          {availableTiers.length > 0 && (
                             <DropdownMenu>
                               <DropdownMenuTrigger asChild>
                                 <Button
@@ -787,7 +900,7 @@
                                 </Button>
                               </DropdownMenuTrigger>
                               <DropdownMenuContent align="start">
-                                {unusedTiers.map((tier) => (
+                                {availableTiers.map((tier) => (
                                   <DropdownMenuItem
                                     key={tier}
                                     onClick={() => addRow(cardIndex, tier)}
@@ -803,11 +916,10 @@
                         /* 折叠态摘要：N 个模型 · M 强度 */
                         <p className="text-xs text-muted-foreground">
                           {t("aggregate.modelsSummaryLadder", {
-                            count: mappedTiers.length,
-                            ladder: mappedTiers.filter(
-                              (tier) =>
-                                effortCapability(card.rows[tier]!.routeId) ===
-                                "ladder",
+                            count: mappedRows.length,
+                            ladder: mappedRows.filter(
+                              ({ slot }) =>
+                                effortCapability(slot.routeId) === "ladder",
                             ).length,
                             defaultValue: "{{count}} 个模型 · {{ladder}} 强度",
                           })}


## Exact change diff: tests/components/AggregateProviderFields.aliasRules.test.tsx
--- before/tests/components/AggregateProviderFields.aliasRules.test.tsx
+++ after/tests/components/AggregateProviderFields.aliasRules.test.tsx
@@ -85,10 +85,10 @@
     await user.type(input, "claude-opus");
     const calls = props.onChange.mock.calls;
     const last = calls[calls.length - 1][0] as AggregateRoutes;
-    // 槽位 ID 由 commit 内的 assignSlotIds 重编号（sonnet 首位取池内真 ID）
+    // 修改前缀不改变既有槽位身份。
     expect(last.aliasRules?.[0]).toEqual({
       prefix: "claude-opus",
-      slotId: "claude-sonnet-4-6",
+      slotId: "claude-sonnet-4",
     });
     // 第二条规则不受影响（patch 只改被编辑的行）
     expect(last.aliasRules?.[1]).toEqual({ prefix: "claude-", slotId: "" });


## Exact change diff: tests/components/AggregateProviderFields.effortBadge.test.tsx
--- before/tests/components/AggregateProviderFields.effortBadge.test.tsx
+++ after/tests/components/AggregateProviderFields.effortBadge.test.tsx
@@ -98,7 +98,7 @@
     ]);
   });
 
-  it("提交归一化按重编号后的 ID 判定：变档成溢出的槽剥离 maxEffort", async () => {
+  it("普通提交保留每个既有模型的 ID 和有效强度上限", async () => {
     const user = userEvent.setup();
     const onChange = vi.fn();
     // 两张卡各一条 sonnet 行：重编号后 p1 取池内第 1 位（claude-sonnet-4-6，ladder），
@@ -143,11 +143,11 @@
     const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
     expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
       ["claude-sonnet-4-6", "max"], // ladder：保留
-      ["claude-sonnet-4-5", undefined], // extended：剥离
+      ["claude-sonnet-5", "xhigh"], // ID 和能力均保留
     ]);
   });
 
-  it("重编号后阶梯收窄（sonnet-5→4-6）的槽剥离越阶残留 maxEffort", async () => {
+  it("删除其他模型不收窄剩余模型的 ID 或强度上限", async () => {
     const user = userEvent.setup();
     const onChange = vi.fn();
     // 存量数据：p1 槽存的是 sonnet-5 + xhigh（删槽轮换前的旧编号）。提交必先
@@ -192,7 +192,7 @@
 
     const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
     expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
-      ["claude-sonnet-4-6", undefined],
+      ["claude-sonnet-5", "xhigh"],
     ]);
   });
 });


## Exact change diff: tests/components/AggregateProviderFields.compatibility.test.tsx
--- before/tests/components/AggregateProviderFields.compatibility.test.tsx
+++ after/tests/components/AggregateProviderFields.compatibility.test.tsx
@@ -0,0 +1,83 @@
+import { useState } from "react";
+import { fireEvent, render, screen } from "@testing-library/react";
+import userEvent from "@testing-library/user-event";
+import { describe, expect, it, vi } from "vitest";
+import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
+import type { AggregateRoutes, Provider } from "@/types";
+
+const initial: AggregateRoutes = {
+  slots: [
+    {
+      routeId: "claude-sonnet-4-6",
+      tier: "sonnet",
+      providerId: "a",
+      upstreamModel: "upstream-a",
+      label: "A",
+    },
+    {
+      routeId: "claude-sonnet-4-5",
+      tier: "sonnet",
+      providerId: "a",
+      upstreamModel: "upstream-b",
+      label: "B",
+    },
+  ],
+  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
+  defaultModel: "claude-sonnet-4-6",
+};
+
+async function setup() {
+  const change = vi.fn();
+  function Controlled() {
+    const [value, setValue] = useState(initial);
+    return (
+      <AggregateProviderFields
+        value={value}
+        onChange={(next) => {
+          change(next);
+          setValue(next);
+        }}
+        candidates={[
+          { id: "a", name: "Synthetic A", settingsConfig: {} } as Provider,
+        ]}
+        modelsForProvider={() => []}
+        fetchingProviderId={null}
+        onFetchModels={() => {}}
+      />
+    );
+  }
+  render(<Controlled />);
+  await userEvent
+    .setup()
+    .click(screen.getByRole("button", { name: "全部展开" }));
+  return change;
+}
+
+describe("lossless multi-model editing", () => {
+  it("shows both existing models in the same provider/tier", async () => {
+    await setup();
+    expect(screen.getByDisplayValue("upstream-a")).toBeInTheDocument();
+    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
+  });
+
+  it("editing one model keeps the other and preserves identities", async () => {
+    const change = await setup();
+    fireEvent.change(screen.getByDisplayValue("upstream-a"), {
+      target: { value: "changed-a" },
+    });
+    const next = change.mock.lastCall?.[0] as AggregateRoutes;
+    expect(next.slots).toHaveLength(2);
+    expect(next.slots[1]).toEqual(initial.slots[1]);
+    expect(next.defaultModel).toBe(initial.defaultModel);
+  });
+
+  it("deleting one row leaves the second model available", async () => {
+    const change = await setup();
+    await userEvent
+      .setup()
+      .click(screen.getAllByRole("button", { name: "删除该模型" })[0]);
+    const next = change.mock.lastCall?.[0] as AggregateRoutes;
+    expect(next.slots).toEqual([initial.slots[1]]);
+    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
+  });
+});


## Exact change diff: tests/components/AggregateProviderFields.migration.test.tsx
--- before/tests/components/AggregateProviderFields.migration.test.tsx
+++ after/tests/components/AggregateProviderFields.migration.test.tsx
@@ -0,0 +1,100 @@
+import { render, screen } from "@testing-library/react";
+import userEvent from "@testing-library/user-event";
+import { expect, it, vi } from "vitest";
+import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
+import type { AggregateRoutes, Provider } from "@/types";
+
+it("changing the source after a migration preview invalidates confirmation", async () => {
+  const initial: AggregateRoutes = {
+    slots: [
+      {
+        routeId: "claude-fable-glm",
+        tier: "fable",
+        providerId: "a",
+        upstreamModel: "old",
+      },
+    ],
+    defaultTarget: { kind: "providerId", value: "a" },
+  };
+  const common = {
+    onChange: vi.fn(),
+    candidates: [{ id: "a", name: "A", settingsConfig: {} } as Provider],
+    modelsForProvider: () => [],
+    fetchingProviderId: null,
+    onFetchModels: () => {},
+  };
+  const { rerender } = render(
+    <AggregateProviderFields {...common} value={initial} />,
+  );
+  await userEvent
+    .setup()
+    .click(screen.getByRole("button", { name: "预览旧路由转换" }));
+  expect(
+    screen.getByRole("button", { name: "确认转换路由 ID" }),
+  ).toBeInTheDocument();
+  rerender(
+    <AggregateProviderFields
+      {...common}
+      value={{
+        ...initial,
+        slots: [{ ...initial.slots[0], upstreamModel: "new-edit" }],
+      }}
+    />,
+  );
+  expect(
+    screen.queryByRole("button", { name: "确认转换路由 ID" }),
+  ).not.toBeInTheDocument();
+  expect(common.onChange).not.toHaveBeenCalled();
+});
+
+it("legacy invalid IDs change only after explicit preview, backup and confirmation", async () => {
+  const oldId = "claude-fable-zhipu-glm";
+  const routes: AggregateRoutes = {
+    slots: [
+      {
+        routeId: oldId,
+        tier: "fable",
+        providerId: "a",
+        upstreamModel: "model-a",
+      },
+    ],
+    defaultTarget: { kind: "slotId", value: oldId },
+    defaultModel: oldId,
+    aliasRules: [{ prefix: "team", slotId: oldId }],
+  };
+  const change = vi.fn();
+  render(
+    <AggregateProviderFields
+      value={routes}
+      onChange={change}
+      candidates={[{ id: "a", name: "A", settingsConfig: {} } as Provider]}
+      modelsForProvider={() => []}
+      fetchingProviderId={null}
+      onFetchModels={() => {}}
+    />,
+  );
+  const user = userEvent.setup();
+  await user.click(screen.getByRole("button", { name: "预览旧路由转换" }));
+  expect(change).not.toHaveBeenCalled();
+  expect(
+    screen.getByRole("button", { name: "确认转换路由 ID" }),
+  ).toBeDisabled();
+  class MockURL extends URL {
+    static createObjectURL = vi.fn(() => "blob:synthetic");
+    static revokeObjectURL = vi.fn();
+  }
+  vi.stubGlobal("URL", MockURL);
+  const click = vi
+    .spyOn(HTMLAnchorElement.prototype, "click")
+    .mockImplementation(() => {});
+  await user.click(screen.getByRole("button", { name: "下载路由备份" }));
+  await user.click(screen.getByRole("button", { name: "确认转换路由 ID" }));
+  const next = change.mock.lastCall?.[0] as AggregateRoutes;
+  expect(next.slots[0].routeId).not.toBe(oldId);
+  expect(next.slots[0].upstreamModel).toBe("model-a");
+  expect(next.defaultTarget.value).toBe(next.slots[0].routeId);
+  expect(next.defaultModel).toBe(next.slots[0].routeId);
+  expect(next.aliasRules?.[0].slotId).toBe(next.slots[0].routeId);
+  click.mockRestore();
+  vi.unstubAllGlobals();
+});


## Exact change diff: src-tauri/src/aggregate.rs
--- before/src-tauri/src/aggregate.rs
+++ after/src-tauri/src/aggregate.rs
@@ -80,6 +80,9 @@
     /// serde default 反序列化为空列表 —— 行为等同未启用。
     #[serde(default)]
     pub alias_rules: Vec<AggregateAliasRule>,
+    /// 删除的路由名称仍保留身份，禁止旧会话静默改指新模型。
+    #[serde(default, skip_serializing_if = "Vec::is_empty")]
+    pub retired_route_ids: Vec<String>,
 }
 
 /// Codex 聚合路由：客户端模型名（精确匹配）→ 目标 Codex 供应商 + 上游模型。
@@ -134,6 +137,7 @@
                 slots,
                 default_target: DefaultTarget::ProviderId("p-target".to_string()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -364,6 +368,7 @@
                 }],
                 default_target: DefaultTarget::ProviderId("p-glm".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -419,6 +424,7 @@
                 slots,
                 default_target,
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -1474,9 +1480,17 @@
     let requested =
         crate::claude_desktop_config::strip_one_m_suffix_for_route_lookup(request_model);
 
+    if routes.retired_route_ids.iter().any(|id| id.trim().eq_ignore_ascii_case(requested)) {
+        return Err(AppError::localized(
+            "aggregate.route_retired",
+            "该聚合模型路由已删除，请重新选择模型",
+            "This aggregate model route was removed; select a model again",
+        ));
+    }
+
     // 直接按持久化的槽位 ID 查表（ID 由前端编辑时生成并随表单提交，运行时不重新生成）
     for slot in &routes.slots {
-        if slot.route_id == requested {
+        if slot.route_id.trim() == requested {
             let target = load_provider(db, app_type, &slot.provider_id)?;
             return Ok((target, Some(slot.upstream_model.clone())));
         }
@@ -1493,7 +1507,7 @@
         if prefix.is_empty() || !lowered.starts_with(&prefix) {
             continue;
         }
-        let Some(slot) = routes.slots.iter().find(|s| s.route_id == rule.slot_id) else {
+        let Some(slot) = routes.slots.iter().find(|s| s.route_id.trim() == rule.slot_id.trim()) else {
             if !rule.slot_id.is_empty() {
                 log::info!(
                     "[aggregate] alias rule '{prefix}' -> dangling slot '{}', skipped",
@@ -1512,7 +1526,7 @@
         DefaultTarget::SlotId(slot_id) => routes
             .slots
             .iter()
-            .find(|slot| &slot.route_id == slot_id)
+            .find(|slot| slot.route_id.trim() == slot_id.trim())
             .map(|slot| slot.provider_id.clone())
             .ok_or_else(|| {
                 AppError::localized(


## Exact change diff: src-tauri/src/aggregate_retirement_tests.rs
--- before/src-tauri/src/aggregate_retirement_tests.rs
+++ after/src-tauri/src/aggregate_retirement_tests.rs
@@ -0,0 +1,55 @@
+use super::*;
+
+fn routes_json() -> serde_json::Value {
+    serde_json::json!({
+        "slots":[{"routeId":"claude-sonnet-4-5","tier":"sonnet","providerId":"synthetic-target","upstreamModel":"new-model"}],
+        "defaultTarget":{"kind":"providerId","value":"synthetic-target"},
+        "aliasRules":[{"prefix":"claude-sonnet","slotId":"claude-sonnet-4-5"}],
+        "retiredRouteIds":["claude-sonnet-4-6"]
+    })
+}
+
+#[test]
+fn aggregate_retirement_survives_backend_serialization_roundtrip() {
+    let routes: AggregateRoutes = serde_json::from_value(routes_json()).unwrap();
+    let persisted = serde_json::to_value(routes).unwrap();
+    assert_eq!(persisted["retiredRouteIds"], serde_json::json!(["claude-sonnet-4-6"]));
+}
+
+#[tokio::test]
+async fn aggregate_retirement_old_requests_are_rejected_before_alias_or_fallback() {
+    let db = crate::database::Database::memory().unwrap();
+    let target = Provider::with_id("synthetic-target".into(), "Synthetic".into(), serde_json::json!({}), None);
+    db.save_provider("claude-desktop", &target).unwrap();
+    let mut provider = Provider::with_id("synthetic-aggregate".into(), "Synthetic Aggregate".into(), serde_json::json!({}), None);
+    provider.meta = Some(crate::provider::ProviderMeta {
+        aggregate_routes: Some(serde_json::from_value(routes_json()).unwrap()),
+        ..Default::default()
+    });
+    for request in ["claude-sonnet-4-6", "claude-sonnet-4-6[1m]", "CLAUDE-SONNET-4-6"] {
+        assert!(resolve_target(&db, "claude-desktop", &provider, request).is_err(),
+            "Retired ID must not be redirected through the alias or default");
+    }
+}
+
+#[test]
+fn aggregate_retirement_legacy_absent_metadata_is_backward_compatible() {
+    let mut legacy = routes_json();
+    legacy.as_object_mut().unwrap().remove("retiredRouteIds");
+    let parsed: AggregateRoutes = serde_json::from_value(legacy).unwrap();
+    let persisted = serde_json::to_value(parsed).unwrap();
+    assert!(persisted.get("retiredRouteIds").is_none());
+}
+
+#[tokio::test]
+async fn aggregate_compatibility_padded_route_key_preserves_exact_mapping() {
+    let db=crate::database::Database::memory().unwrap();
+    db.save_provider("claude-desktop",&Provider::with_id("synthetic-target".into(),"Synthetic".into(),serde_json::json!({}),None)).unwrap();
+    let mut json=routes_json();
+    json["slots"][0]["routeId"]=serde_json::json!(" claude-sonnet-4-5 ");
+    json["aliasRules"]=serde_json::json!([]);
+    let mut provider=Provider::with_id("synthetic-aggregate".into(),"Synthetic".into(),serde_json::json!({}),None);
+    provider.meta=Some(crate::provider::ProviderMeta{aggregate_routes:Some(serde_json::from_value(json).unwrap()),..Default::default()});
+    let (_,upstream)=resolve_target(&db,"claude-desktop",&provider,"claude-sonnet-4-5").unwrap();
+    assert_eq!(upstream.as_deref(),Some("new-model"));
+}


## Exact change diff: src-tauri/src/services/provider/mod.rs
--- before/src-tauri/src/services/provider/mod.rs
+++ after/src-tauri/src/services/provider/mod.rs
@@ -1708,6 +1708,32 @@
     }
 
     #[test]
+    fn validate_aggregate_rejects_retired_active_overlap_and_empty_history_keys() {
+        for retired in ["claude-sonnet-4-5", "CLAUDE-SONNET-4-5", ""] {
+            let mut provider = Provider::with_id("synthetic-aggregate".into(), "Synthetic".into(), json!({}), None);
+            provider.meta = Some(ProviderMeta {
+                aggregate_routes: Some(serde_json::from_value(json!({
+                    "slots":[{"routeId":"claude-sonnet-4-5","tier":"sonnet","providerId":"synthetic-target","upstreamModel":"synthetic-model"}],
+                    "defaultTarget":{"kind":"providerId","value":"synthetic-target"},
+                    "retiredRouteIds":[retired]
+                })).unwrap()),
+                ..Default::default()
+            });
+            assert!(ProviderService::validate_provider_settings(&AppType::ClaudeDesktop, &provider).is_err());
+        }
+    }
+
+    #[test]
+    fn validate_aggregate_rejects_case_variant_active_duplicate_keys() {
+        let mut provider=Provider::with_id("synthetic-aggregate".into(),"Synthetic".into(),json!({}),None);
+        provider.meta=Some(ProviderMeta{aggregate_routes:Some(serde_json::from_value(json!({
+            "slots":[{"routeId":"claude-sonnet-4-6","tier":"sonnet","providerId":"a","upstreamModel":"model-a"},{"routeId":"CLAUDE-SONNET-4-6","tier":"sonnet","providerId":"a","upstreamModel":"model-b"}],
+            "defaultTarget":{"kind":"providerId","value":"a"}
+        })).unwrap()),..Default::default()});
+        assert!(ProviderService::validate_provider_settings(&AppType::ClaudeDesktop,&provider).is_err());
+    }
+
+    #[test]
     fn validate_aggregate_rejects_empty_slots() {
         let provider = aggregate_provider(
             "agg",
@@ -1715,6 +1741,7 @@
                 slots: vec![],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("x".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1731,6 +1758,7 @@
                 slots: vec![slot("claude-sonnet-agg", "agg")], // 指向自己
                 default_target: crate::aggregate::DefaultTarget::ProviderId("agg".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1747,6 +1775,7 @@
                 slots: vec![slot("claude-sonnet-a", "p1"), slot("claude-sonnet-a", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1765,6 +1794,7 @@
                 slots: vec![slot("glm-5.3", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1787,6 +1817,7 @@
                 slots: vec![bad_target],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1802,6 +1833,7 @@
                 slots: vec![bad_model],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1818,6 +1850,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1"), slot("claude-opus-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1834,6 +1867,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("   ".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1860,6 +1894,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::SlotId("claude-opus-gone".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1886,6 +1921,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::SlotId("claude-sonnet-1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1917,6 +1953,7 @@
                     slots: vec![slot("claude-sonnet-1", "p-glm")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1931,6 +1968,7 @@
                     slots: vec![slot("claude-sonnet-nested", "target-agg")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1951,6 +1989,7 @@
                         "target-agg".into(),
                     ),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1985,6 +2024,7 @@
                     slots: vec![slot("claude-sonnet-target", "target")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("target".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1998,6 +2038,7 @@
                     slots: vec![slot("claude-sonnet-other", "other")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("other".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -2043,6 +2084,7 @@
                     slots: vec![slot("claude-sonnet-target", "target")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("target".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -2079,6 +2121,7 @@
                     slots: vec![slot("claude-sonnet-target", "target")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("fallback".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -2359,6 +2402,7 @@
                     slots: vec![slot("claude-sonnet-1", "p-glm")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 }),
                 ..Default::default()
@@ -7977,7 +8021,7 @@
                         "Invalid slot id (expected e.g. claude-sonnet-1); Claude Desktop would reject the whole group",
                     ));
                 }
-                if seen.iter().any(|s| s == route_id) {
+                if seen.iter().any(|s| s.eq_ignore_ascii_case(route_id)) {
                     return Err(AppError::localized(
                         "aggregate.duplicate_route_id",
                         "槽位 ID 重复",
@@ -7985,6 +8029,17 @@
                     ));
                 }
                 seen.push(route_id.to_string());
+            }
+
+            for retired in &routes.retired_route_ids {
+                let id = retired.trim();
+                if id.is_empty() || seen.iter().any(|active| active.eq_ignore_ascii_case(id)) {
+                    return Err(AppError::localized(
+                        "aggregate.retired_route_invalid",
+                        "已删除的路由 ID 不得为空或与当前模型重复",
+                        "Retired route IDs must be non-empty and must not overlap active models",
+                    ));
+                }
             }
 
             // 默认目标必填且必须可用：未命中槽位的请求（Claude Desktop 的内部调用，


## Exact change diff: src-tauri/src/claude_desktop_config.rs
--- before/src-tauri/src/claude_desktop_config.rs
+++ after/src-tauri/src/claude_desktop_config.rs
@@ -2729,6 +2729,7 @@
             ],
             default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
             default_model: None,
+            retired_route_ids: vec![],
             alias_rules: vec![],
         });
 
@@ -2773,6 +2774,7 @@
                 }],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()


## Exact change diff: src-tauri/src/proxy/server.rs
--- before/src-tauri/src/proxy/server.rs
+++ after/src-tauri/src/proxy/server.rs
@@ -1361,6 +1361,7 @@
                     "default-target".to_string(),
                 ),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()


## Exact change diff: src-tauri/src/services/stream_check.rs
--- before/src-tauri/src/services/stream_check.rs
+++ after/src-tauri/src/services/stream_check.rs
@@ -560,6 +560,7 @@
                 }],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("target".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()


## Exact change diff: docs/reviews/2026-10-04-aggregate-route-compatibility-fix.md
--- before/docs/reviews/2026-10-04-aggregate-route-compatibility-fix.md
+++ after/docs/reviews/2026-10-04-aggregate-route-compatibility-fix.md
@@ -0,0 +1,30 @@
+# 聚合路由身份与存量无损编辑修复
+
+日期2026-10-04；任务task_cfc43aae54a58adb，原评估M01/M02。范围为Claude聚合路由；Codex表单作为兼容回归，不把其默认引用问题说成已修复。
+
+## 行为
+
+普通编辑保留已有routeId，只为新增空ID槽位分配未占用ID。排序、插入、编辑不重新编号，也不因此改变默认模型、别名、有效能力上限或上游。ID分配对退役名称按大小写不敏感处理，避免新名字与后端的退役判断冲突。
+
+新增可选retiredRouteIds。删除的ID跨保存保留且不分配给新模型；后端在精确/别名/兜底前拒绝对该ID的请求（包含1M后缀和大小写变体）。旧数据缺省空历史，空字段不序列化；活动/退役重叠或空历史键保存校验拒绝。已有带首尾空白的合法路由键，运行查找按与目录派生一致的trim规则匹配。
+
+供应商卡片每档位保存数组，不再只取第一个模型。所有同档模型显示、各行可独立编辑/删除，也可新增同档模型。删除默认兜底槽位后不会把旧名称认领给新行，需重新选择可用目标；启动默认模型被删时回落到首位。
+
+对旧不兼容/重复ID提供明确的转换预览；普通编辑不自动转换。先下载仅含路由表的备份，再确认应用新ID，默认/别名引用随确认迁移。预览显示ID和能力上限变化；替换后的ID不支持原强度时移除该上限。预览后有任何数据编辑，会使确认失效，防止旧预览覆盖新修改。
+
+## 验证与证据
+
+初始7项前端行为RED实际失败，随后转绿；后端退役保存/旧请求隔离2项失败、旧数据兼容1项通过，随后转绿。补充大小写历史、显式迁移和新ID能力上限、空白键对齐的实际失败回归及修复，均保留；迁移URL接口的jsdom缺省问题归为测试工具问题，不冒充产品失败。
+
+当前相关前端79项通过、后端aggregate相关103项通过；TypeScript tsc --noEmit通过，生产cargo check --offline --lib通过。测试范围和filtered数量来自实际日志，不宣称约3000项后端全套通过。既有测试中“自动重编号”“同档只保留首个”的断言已按批准的新契约修改，不隐藏行为变化。
+
+浏览器实际使用AggregateProviderFields及模拟数据，验证两条sonnet行显示、编辑第二条保留其余、删除后记录退役ID、同档新增使用新ID，并检查旧ID转换预览及备份前确认禁用。三张截图已视觉检查。未调用Tauri保存或真实数据库；浏览器未完成迁移下载/确认，该分支由组件测试覆盖。完整证据在D:\Sources\Code\agent-org\dist\agent-org\cc-switch-fixes-2026-10-04-1ebd221f。
+
+## 使用与回退边界
+
+日常配置按供应商添加模型，可在同一档位添加多行；排序可改变显示顺序但不改变既有ID。删除会使旧会话的被删模型明确不可用，需在客户端重新选择。新字段需使用本修复版本保存；旧版本可能丢弃退役历史且会重编号，回退必须恢复完整备份，并在旧编辑器使用前检查客户端会话/模型目录。不能把用旧编辑器改写新格式视为无损回退。
+
+尚未验收完整桌面、真实账号/上游、客户端重启或旧会话的原生恢复；没有合并、提交、发布或更改live设置。独立审查与正式交付以任务实际记录为准。M05目标熔断、M06Claude兜底模型语义及其他UI项继续保持待办。
+
+
+复审修订：原独立裁决C0M0Minor7和原始响应保留。已补齐预览的默认/别名引用变化、中文/英文/日文迁移文案、大小写重复判定及后端保存一致性，并在确认时校验所有行的能力上限。重复组整体更换ID并退役旧名称，避免保留同名活动路由时又退役该名称。修订后的独立审查以最新任务记录为准。


## Observed evidence: route-v2-frontend-check.txt
[baseline-browser-mapping] The data in this module is over two months old.  To ensure accurate Baseline data, please update: `npm i baseline-browser-mapping@latest -D`

 RUN  v2.1.9 D:/Workspace/Project/cc-switch/src

 ✓ src/utils/aggregateRoutes.compatibility.test.ts (8 tests) 21ms
 ✓ src/utils/aggregateRoutes.test.ts (36 tests) 37ms
 ✓ tests/components/AggregateProviderFields.migration.test.tsx (2 tests) 836ms
   ✓ changing the source after a migration preview invalidates confirmation 445ms
   ✓ legacy invalid IDs change only after explicit preview, backup and confirmation 383ms
 ✓ tests/components/AggregateProviderFields.compatibility.test.tsx (3 tests) 924ms
   ✓ lossless multi-model editing > shows both existing models in the same provider/tier 429ms
 ✓ tests/components/AggregateProviderFields.aliasRules.test.tsx (4 tests) 1155ms
   ✓ 别名路由区块 > 渲染既有规则行（含悬空行），悬空行显示占位而非崩 313ms
   ✓ 别名路由区块 > 编辑前缀回调 onChange 且带上新前缀 524ms
 ✓ tests/components/AggregateProviderFields.effortBadge.test.tsx (6 tests) 1342ms
   ✓ 聚合编辑器三态思考徽标 > 展开卡后 ladder 槽显示 强度✓、溢出槽显示 ✗ 439ms
   ✓ 聚合编辑器上限下拉 > 上限下拉：ladder 槽可选，溢出槽禁用 323ms
stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：开关接线与 meta 提交 > 普通非官方卡片可达开关；开启后保存写出 codexAggregateRoutes
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：开关接线与 meta 提交 > 关闭开关后保存删除 meta 键（普通供应商 JSON 不变）
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：开关接线与 meta 提交 > 已有表 + 改动显示名后保存：label 保留，槽位形状与后端 serde 一致
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：表单门禁（藏端点/凭据/配置块 + 豁免软校验） > 存量聚合卡片（无端点无 Key）保存不弹「仍要保存？」确认框
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：表单门禁（藏端点/凭据/配置块 + 豁免软校验） > 非聚合卡片缺端点时仍弹确认框（豁免不外溢）
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

 ✓ tests/components/CodexAggregateFields.test.tsx (20 tests) 4941ms
   ✓ Codex 聚合编辑器：行增删与提交形状 > 兜底目标可选槽位（slotId），默认模型可设为槽位 model 388ms
   ✓ Codex 聚合：开关接线与 meta 提交 > 普通非官方卡片可达开关；开启后保存写出 codexAggregateRoutes 963ms
   ✓ Codex 聚合：开关接线与 meta 提交 > 关闭开关后保存删除 meta 键（普通供应商 JSON 不变） 415ms
   ✓ Codex 聚合：开关接线与 meta 提交 > 已有表 + 改动显示名后保存：label 保留，槽位形状与后端 serde 一致 388ms
   ✓ Codex 聚合：表单门禁（藏端点/凭据/配置块 + 豁免软校验） > 存量聚合卡片（无端点无 Key）保存不弹「仍要保存？」确认框 537ms

 Test Files  7 passed (7)
      Tests  79 passed (79)
   Start at  20:50:40
   Duration  11.72s (transform 2.52s, setup 5.79s, collect 8.11s, tests 9.26s, environment 7.48s, prepare 1.85s)



## Observed evidence: route-v2-backend-check.txt
   Compiling cc-switch v3.20.4-local (D:\Workspace\Project\cc-switch\src\src-tauri)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 37.23s
     Running unittests src\lib.rs (target\debug\deps\cc_switch_lib-c8c28ab0cd774408.exe)

running 103 tests
test aggregate::retirement_tests::aggregate_compatibility_padded_route_key_preserves_exact_mapping ... ok
test aggregate::retirement_tests::aggregate_retirement_legacy_absent_metadata_is_backward_compatible ... ok
test aggregate::retirement_tests::aggregate_retirement_old_requests_are_rejected_before_alias_or_fallback ... ok
test aggregate::retirement_tests::aggregate_retirement_survives_backend_serialization_roundtrip ... ok
test aggregate::tests::aggregate_model_routes_carries_tier_for_ordering ... ok
test aggregate::tests::aggregate_model_routes_dedups_repeated_route_ids ... ok
test aggregate::tests::aggregate_model_routes_errors_when_all_slots_are_unusable ... ok
test aggregate::tests::aggregate_model_routes_filters_unsafe_route_ids ... ok
test aggregate::tests::aggregate_model_routes_ignores_dangling_default_model ... ok
test aggregate::tests::aggregate_model_routes_pins_default_model_to_front ... ok
test aggregate::tests::aggregate_model_routes_preserves_provider_grouped_order ... ok
test aggregate::tests::aggregate_routes_deserializes_without_default_model ... ok
test aggregate::tests::alias_dangling_slot_skipped_falls_to_default ... ok
test aggregate::tests::alias_empty_or_whitespace_prefix_skipped ... ok
test aggregate::tests::alias_first_match_wins ... ok
test aggregate::tests::alias_matching_is_case_insensitive ... ok
test aggregate::tests::alias_prefix_hits_route_to_slot_upstream ... ok
test aggregate::tests::alias_request_with_1m_suffix_still_matches ... ok
test aggregate::tests::alias_rules_absent_in_old_json_deserializes_empty ... ok
test aggregate::tests::codex_aggregate_catalog_keeps_non_empty_label_as_display_name ... ok
test aggregate::tests::codex_aggregate_catalog_preserves_slot_order_and_pins_default ... ok
test aggregate::tests::codex_aggregate_seed_toml_falls_back_to_first_slot_model ... ok
test aggregate::tests::codex_aggregate_seed_toml_places_fields_correctly ... ok
test aggregate::tests::codex_aggregate_synthesis_errors_when_all_slots_are_unusable ... ok
test aggregate::tests::codex_aggregate_synthesis_skips_half_finished_slots ... ok
test aggregate::tests::codex_routes_of_errors_when_missing ... ok
test aggregate::tests::exact_slot_match_wins_over_alias ... ok
test aggregate::tests::max_effort_absent_defaults_to_none_and_survives_roundtrip ... ok
test aggregate::tests::resolve_codex_target_dangling_default_slot_errors ... ok
test aggregate::tests::resolve_codex_target_default_slot_matches_padded_slot_model ... ok
test aggregate::tests::resolve_codex_target_default_slot_rewrites_to_slot_upstream ... ok
test aggregate::tests::resolve_codex_target_errors_when_target_provider_missing ... ok
test aggregate::tests::resolve_codex_target_exact_match_rewrites_model ... ok
test aggregate::tests::resolve_codex_target_falls_back_to_default_provider_without_rewrite ... ok
test aggregate::tests::resolve_codex_target_matches_padded_slot_model ... ok
test aggregate::tests::resolve_codex_target_requires_exact_model_match ... ok
test aggregate::tests::resolve_codex_target_strips_1m_marker_before_lookup ... ok
test aggregate::tests::resolve_codex_target_trims_upstream_model_on_the_way_out ... ok
test aggregate::tests::resolve_target_errors_when_default_target_slot_missing ... ok
test aggregate::tests::resolve_target_errors_when_target_provider_missing ... ok
test aggregate::tests::resolve_target_hits_slot_by_generated_id ... ok
test aggregate::tests::resolve_target_strips_one_m_marker_before_slot_lookup ... ok
test claude_desktop_config::tests::aggregate_provider_derives_model_routes_from_slots ... ok
test claude_desktop_config::tests::apply_aggregate_provider_without_credentials_writes_local_gateway_profile ... ok
test claude_desktop_config::tests::apply_provider_to_paths_returns_routes_only_for_aggregate_provider ... ok
test claude_desktop_config::tests::validate_direct_provider_accepts_aggregate_without_endpoint_or_credentials ... ok
test claude_desktop_config::tests::validate_proxy_provider_accepts_aggregate_without_endpoint_or_credentials ... ok
test provider::tests::codex_aggregate_routes_absent_when_unset ... ok
test provider::tests::codex_aggregate_routes_round_trip ... ok
test provider::tests::provider_meta_round_trips_aggregate_routes ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_default_account_is_preserved_without_explicit_binding ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_empty_token_or_workspace_is_rejected ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_invalid_default_identity_rejects_unrelated_login ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_no_managed_account_does_not_adopt_unselected_login ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_normal_official_and_api_key_requests_keep_their_authentication ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_provider_fallback_and_slots_forward_selected_account ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_refresh_and_transport_errors_never_change_accounts_or_echo_secrets ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_removed_binding_rejects_unrelated_live_login ... ok
test proxy::forwarder::tests::aggregate_non_official_target_auth_path_is_untouched ... ok
test proxy::forwarder::tests::aggregate_official_target_falls_back_to_default_account ... ok
test proxy::forwarder::tests::aggregate_official_target_uses_manager_token_not_proxy_managed ... ok
test proxy::forwarder::tests::aggregate_official_target_with_dangling_account_reports_login_hint ... ok
test proxy::forwarder::tests::aggregate_official_target_without_login_reports_login_hint ... ok
test proxy::forwarder::tests::official_target_without_aggregate_keeps_client_passthrough_auth ... ok
test proxy::handlers::tests::aggregated_chat_sse_round_trips_through_openai_to_anthropic ... ok
test proxy::handlers::tests::chat_sse_to_response_value_aggregates_text_finish_reason_and_usage ... ok
test proxy::providers::streaming_responses::tests::test_buffered_citations_render_fuller_aggregate_than_stale_terminal_snapshot ... ok
test proxy::providers::streaming_responses::tests::test_streamed_text_binds_output_and_item_aliases_to_one_aggregate ... ok
test proxy::server::tests::aggregate_routes_rewrite_model_and_use_target_provider ... ok
test proxy::server::tests::codex_aggregate_native_passthrough_rewrites_model_and_credentials ... ok
test proxy::server::tests::codex_aggregate_skips_apply_codex_chat_upstream_model_when_overridden ... ok
test proxy::server::tests::codex_aggregate_skips_apply_codex_upstream_model_when_overridden ... ok
test services::provider::live::tests::codex_aggregate_catalog_uses_native_responses_tool_profile ... ok
test services::provider::live::tests::codex_aggregate_effective_settings_synthesize_seed_and_catalog_for_live ... ok
test services::provider::live::tests::codex_aggregate_live_write_is_rejected_when_no_slot_is_usable ... ok
test services::provider::tests::delete_rejects_provider_referenced_by_aggregate ... ok
test services::provider::tests::delete_rejects_provider_referenced_by_codex_aggregate ... ok
test services::provider::tests::validate_aggregate_accepts_slot_default_target_present_in_slots ... ok
test services::provider::tests::validate_aggregate_accepts_valid_table ... ok
test services::provider::tests::validate_aggregate_leaves_non_aggregate_provider_untouched ... ok
test services::provider::tests::validate_aggregate_rejects_blank_provider_default_target ... ok
test services::provider::tests::validate_aggregate_rejects_case_variant_active_duplicate_keys ... ok
test services::provider::tests::validate_aggregate_rejects_default_target_naming_missing_slot ... ok
test services::provider::tests::validate_aggregate_rejects_duplicate_route_ids ... ok
test services::provider::tests::validate_aggregate_rejects_empty_slots ... ok
test services::provider::tests::validate_aggregate_rejects_incomplete_slot ... ok
test services::provider::tests::validate_aggregate_rejects_nested_aggregate ... ok
test services::provider::tests::validate_aggregate_rejects_ordinary_provider_becoming_referenced_aggregate ... ok
test services::provider::tests::validate_aggregate_rejects_retired_active_overlap_and_empty_history_keys ... ok
test services::provider::tests::validate_aggregate_rejects_self_reference ... ok
test services::provider::tests::validate_aggregate_rejects_unsafe_route_id ... ok
test services::provider::tests::validate_codex_aggregate_accepts_slot_default_target_present_in_slots ... ok
test services::provider::tests::validate_codex_aggregate_accepts_valid_table ... ok
test services::provider::tests::validate_codex_aggregate_leaves_non_aggregate_provider_untouched ... ok
test services::provider::tests::validate_codex_aggregate_rejects_blank_provider_default_target ... ok
test services::provider::tests::validate_codex_aggregate_rejects_default_target_naming_missing_slot ... ok
test services::provider::tests::validate_codex_aggregate_rejects_duplicate_slot_models ... ok
test services::provider::tests::validate_codex_aggregate_rejects_empty_slot_model ... ok
test services::provider::tests::validate_codex_aggregate_rejects_empty_slot_provider ... ok
test services::provider::tests::validate_codex_aggregate_rejects_empty_slot_upstream_model ... ok
test services::provider::tests::validate_codex_aggregate_rejects_nested_aggregate ... ok
test services::provider::tests::validate_codex_aggregate_rejects_referenced_provider_becoming_aggregate ... ok
test services::stream_check::tests::test_resolve_base_url_rejects_aggregate_provider ... ok

test result: ok. 103 passed; 0 failed; 0 ignored; 0 measured; 2935 filtered out; finished in 0.87s



## Observed evidence: route-ui-observation.json
{"surface":"Codex in-app browser","url":"http://127.0.0.1:3437","fixture":".agent-org/evidence/route-ui","actual_component":"AggregateProviderFields","data":"Synthetic providers and models only","checks":["Same-provider sonnet rows both visible","Editing second preserves three slots and old IDs","Deleting first preserves second and records retired ID","Adding sonnet chooses claude-sonnet-5 rather than retired claude-sonnet-4-6","Invalid legacy ID preview shows old/new identity and confirmation disabled before route backup"],"screenshots":["route-multi-model.png","route-retirement-and-add.png","route-migration-preview.png"],"observations_saved":["route-edited-dom.json","route-deleted-dom.json","route-added-dom.json","route-migration-preview-dom.txt"],"native_tauri_backend_executed":false,"real_account_configuration_changed":false,"migration_confirmation":"Unit test covers backup/confirm; browser verified preview and disabled state only"}
