--- before/src-tauri/src/aggregate.rs
+++ after/src-tauri/src/aggregate.rs
@@ -80,6 +80,9 @@
     /// serde default 反序列化为空列表 —— 行为等同未启用。
     #[serde(default)]
     pub alias_rules: Vec<AggregateAliasRule>,
+    /// 删除的路由名称仍保留身份，禁止旧会话静默改指新模型。
+    #[serde(default, skip_serializing_if = "Vec::is_empty")]
+    pub retired_route_ids: Vec<String>,
 }
 
 /// Codex 聚合路由：客户端模型名（精确匹配）→ 目标 Codex 供应商 + 上游模型。
@@ -134,6 +137,7 @@
                 slots,
                 default_target: DefaultTarget::ProviderId("p-target".to_string()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -364,6 +368,7 @@
                 }],
                 default_target: DefaultTarget::ProviderId("p-glm".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -419,6 +424,7 @@
                 slots,
                 default_target,
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -1474,9 +1480,17 @@
     let requested =
         crate::claude_desktop_config::strip_one_m_suffix_for_route_lookup(request_model);
 
+    if routes.retired_route_ids.iter().any(|id| id.trim().eq_ignore_ascii_case(requested)) {
+        return Err(AppError::localized(
+            "aggregate.route_retired",
+            "该聚合模型路由已删除，请重新选择模型",
+            "This aggregate model route was removed; select a model again",
+        ));
+    }
+
     // 直接按持久化的槽位 ID 查表（ID 由前端编辑时生成并随表单提交，运行时不重新生成）
     for slot in &routes.slots {
-        if slot.route_id == requested {
+        if slot.route_id.trim() == requested {
             let target = load_provider(db, app_type, &slot.provider_id)?;
             return Ok((target, Some(slot.upstream_model.clone())));
         }
@@ -1493,7 +1507,7 @@
         if prefix.is_empty() || !lowered.starts_with(&prefix) {
             continue;
         }
-        let Some(slot) = routes.slots.iter().find(|s| s.route_id == rule.slot_id) else {
+        let Some(slot) = routes.slots.iter().find(|s| s.route_id.trim() == rule.slot_id.trim()) else {
             if !rule.slot_id.is_empty() {
                 log::info!(
                     "[aggregate] alias rule '{prefix}' -> dangling slot '{}', skipped",
@@ -1512,7 +1526,7 @@
         DefaultTarget::SlotId(slot_id) => routes
             .slots
             .iter()
-            .find(|slot| &slot.route_id == slot_id)
+            .find(|slot| slot.route_id.trim() == slot_id.trim())
             .map(|slot| slot.provider_id.clone())
             .ok_or_else(|| {
                 AppError::localized(
