--- before/src-tauri/src/proxy/server.rs
+++ after/src-tauri/src/proxy/server.rs
@@ -1361,6 +1361,7 @@
                     "default-target".to_string(),
                 ),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
