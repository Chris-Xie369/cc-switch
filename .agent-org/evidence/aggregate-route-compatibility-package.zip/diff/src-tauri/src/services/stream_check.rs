--- before/src-tauri/src/services/stream_check.rs
+++ after/src-tauri/src/services/stream_check.rs
@@ -560,6 +560,7 @@
                 }],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("target".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
