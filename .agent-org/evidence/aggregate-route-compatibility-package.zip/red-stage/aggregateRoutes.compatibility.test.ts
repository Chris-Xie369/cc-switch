import { describe, expect, it } from "vitest";
import { assignSlotIds, flattenProviderGroups, groupSlotsByProvider } from "./aggregateRoutes";
import type { AggregateRoutes } from "@/types";

const initial: AggregateRoutes = {
  slots: [
    { routeId: "claude-sonnet-4-6", tier: "sonnet", providerId: "a", upstreamModel: "upstream-a", label: "A", maxEffort: "high", supports1m: true },
    { routeId: "claude-sonnet-4-5", tier: "sonnet", providerId: "b", upstreamModel: "upstream-b", label: "B" },
  ],
  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
  defaultModel: "claude-sonnet-4-6",
  aliasRules: [{ prefix: "team", slotId: "claude-sonnet-4-6" }],
};

describe("aggregate compatibility contract", () => {
  it("reordering preserves the old model ID, mapping, default and alias", () => {
    const next = assignSlotIds({ ...initial, slots: [...initial.slots].reverse() });
    expect(next.slots.find(s => s.routeId === initial.slots[0].routeId)).toEqual(initial.slots[0]);
    expect(next.defaultTarget).toEqual(initial.defaultTarget);
    expect(next.defaultModel).toBe(initial.defaultModel);
    expect(next.aliasRules).toEqual(initial.aliasRules);
  });

  it("inserting a new model does not steal an existing ID", () => {
    const next = assignSlotIds({ ...initial, slots: [{ ...initial.slots[0], routeId: "", providerId: "new", upstreamModel: "new-model" }, ...initial.slots] });
    expect(next.slots.slice(1)).toEqual(initial.slots);
    expect(next.slots[0].routeId).not.toBe(initial.slots[0].routeId);
    expect(next.defaultModel).toBe(initial.defaultModel);
  });

  it("deleting then adding and reloading cannot recycle a retired model ID", () => {
    const deleted = assignSlotIds({ ...initial, slots: [initial.slots[1]], defaultTarget: { kind: "providerId", value: "b" } }, initial);
    const persisted = JSON.parse(JSON.stringify(deleted)) as AggregateRoutes;
    const added = assignSlotIds({ ...persisted, slots: [...persisted.slots, { ...initial.slots[0], routeId: "", upstreamModel: "new-model" }] }, persisted);
    expect(added.slots[0].routeId).toBe(initial.slots[1].routeId);
    expect(added.slots[1].routeId).not.toBe(initial.slots[0].routeId);
    expect((added as AggregateRoutes & { retiredRouteIds?: string[] }).retiredRouteIds).toContain(initial.slots[0].routeId);
    expect(added.aliasRules?.[0].slotId).toBe("");
  });

  it("grouping and flattening retains every model in the same provider/tier", () => {
    const slots = initial.slots.map(s => ({ ...s, providerId: "a" }));
    expect(flattenProviderGroups(groupSlotsByProvider(slots))).toEqual(slots);
  });
});
