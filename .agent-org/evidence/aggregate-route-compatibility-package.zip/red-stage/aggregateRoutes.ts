import type {
  AggregateRouteSlot,
  AggregateRoutes,
  AggregateTier,
  Provider,
} from "@/types";

/**
 * 每个档位的 **Claude Desktop 认得**的真模型 ID 池，按优先级排列。
 *
 * ID 决定了模型在 Claude Desktop 里的**能力画像**，其中一项是「有没有推理强度选择」。
 * 实测（2.2553.1.0，`app.asar` 内 `lPt(id)`）：
 *
 * ```js
 * lPt = (id) => XNt[qAt(id)] ?? (ZNt.test(id) ? YNt : undefined)   // 都不中 → 没有强度控件
 * XNt = { "claude-opus-4-8": {effortLevels:[low…max]}, … }          // 精确表：真 Anthropic ID
 * ZNt = /^(?:claude-)?(?:fable|mythos)(?:-|$)/                      // fable/mythos 族走正则
 * ```
 *
 * 也就是说 `claude-opus-1` 这种自造 ID 既不在表里、也不匹配该正则，**整条模型就没有
 * 推理强度控件**（而 `claude-fable-*` 反而有——它命中了族正则）。用户此前手写的
 * profile 也是这个套路：`name` 用真 ID（`claude-opus-4-8`）承载能力画像，`labelOverride`
 * 才是给人看的「实际调用的模型」。故这里按档位给出 ID 池，序号逐个取用。
 *
 * 阶梯明细见 claudeDesktopCapability.ts（EXACT_LADDERS）：`4-8`/`4-7` 含 xhigh，
 * `4-6` 无 xhigh 但有阶梯（低版本 asar 曾只有 extended 开关，已过时）；不取
 * `claude-opus-5`（它 `disallowThinkingDisabled`，会强制开启思考）。池子用尽后退回 `claude-{档位}-{序号}`：形状合法、可路由，
 * 只是那条不再有强度控件。
 *
 * 池 keyed by 槽位序号（该档位第几个槽），可以留空位——空位序号走溢出，
 * 用于「存量槽已占溢出 ID、新槽拿真 ID」的场景（如需为存量槽保 ID 可留空位）。
 *
 * 池内 ID 形如 `claude-{档位}-{数字}` 时会与溢出生成值撞名（`claude-sonnet-5` 踩过：
 * 同档第 5 个槽位也生成 `claude-sonnet-5`，两条槽位同 ID，后端去重吃掉一条），
 * 故 slotId 的溢出路径会跳过池内已占用的名字；assignSlotIds 批量分配时再传一个
 * 本次已分配的集合，溢出同时让开同伴（序号 5 让出 sonnet-5 取 6 后，序号 6 取 7）。
 */
const RECOGNIZED_IDS: Record<
  AggregateTier,
  Readonly<Partial<Record<number, string>>>
> = {
  opus: { 1: "claude-opus-4-8", 2: "claude-opus-4-7", 3: "claude-opus-4-6" },
  // claude-sonnet-5 在 Desktop 精确表内且阶梯最全（low…xhigh…max）。
  // 序号 4 固化 claude-sonnet-3：claude-sonnet-4 已被 CLI 目录退役（2026-06-15），
  // 与目录条目撞名的 ID 会被 /model 选择器过滤；合成名经 behavesAs 永远可显示。
  sonnet: {
    1: "claude-sonnet-4-6",
    2: "claude-sonnet-4-5",
    3: "claude-sonnet-5",
    4: "claude-sonnet-3",
  },
  haiku: { 1: "claude-haiku-4-5" },
  // fable 族的强度阶梯由族正则兜底，序号可无限生成，通常无需 ID 池。
  // 序号 5 固化 claude-fable-6：claude-fable-5 被 CLI 目录降级进 overflow 区
  // （继任 Fable 5.1 占 main），同名行在 /model 选择器被压走；合成名无此问题。
  fable: { 5: "claude-fable-6" },
};

/**
 * 生成槽位 ID：优先取该档位的真模型 ID，用尽后退回 `claude-{档位}-{序号}`。
 *
 * 这个字符串就是 Claude Desktop 模型列表里的 `inferenceModels[].name`，也是请求按
 * 模型分流的键，因此**必须过 Claude Desktop 的校验**。实测（2.2553.1.0）它的校验是
 * 「厂商词黑名单 + Anthropic 形状」：
 *
 * ```js
 * Vxe = /ark-code|…|deepseek|glm|gpt|gemini|grok|kimi|qwen|…/   // 厂商词
 * Go  = (name) => Vxe.test(name) ? false : Wo.test(name) || name.includes("claude")
 * ```
 *
 * 名字里只要出现 deepseek/glm 这类厂商词就会被判为 "is not an Anthropic model" 并从
 * 列表移除，**且是整组生效**——旧方案把供应商名 slug 进 ID（`claude-fable-deepseek`、
 * `claude-fable-zhipu-glm`），四个槽位被删光、选择器变空。故 ID 与供应商名无关，
 * 可读性交给「显示名」（`labelOverride`，不受该校验约束）。
 */
export function slotId(
  tier: AggregateTier,
  ordinal: number,
  taken: ReadonlySet<string> = new Set(),
): string {
  const pooled = RECOGNIZED_IDS[tier][ordinal];
  if (pooled) return pooled;
  const poolValues = new Set(Object.values(RECOGNIZED_IDS[tier]));
  let n = ordinal;
  let candidate = `claude-${tier}-${n}`;
  // 溢出：跳过池内已占用的名字（如 sonnet-5 入池后序号 5 顺移）以及与同批
  // 已分配同伴的撞名（assignSlotIds 传入 taken）。
  while (poolValues.has(candidate) || taken.has(candidate)) {
    n += 1;
    candidate = `claude-${tier}-${n}`;
  }
  return candidate;
}

/** 供应商是否为聚合供应商。 */
export function isAggregateProvider(provider: Pick<Provider, "meta">): boolean {
  return Boolean(provider.meta?.aggregateRoutes);
}

/** 由槽位派生标签（选择器显示名）：显式填写优先，否则「供应商 · 上游模型」。
 *
 *  未填写时**必须**给出非空默认值——空值会让 profile 省略 `labelOverride`，
 *  Claude Desktop 便退回「按 ID 自动格式化」，选择器里只剩 `claude-opus-2[1m]`
 *  这类看不出实际调用哪家模型的名字。 */
export function slotLabel(
  slot: {
    upstreamModel: string;
    label?: string;
  },
  providerName?: string,
): string {
  const explicit = slot.label?.trim();
  if (explicit && explicit.length > 0) return explicit;
  const model = slot.upstreamModel.trim();
  const name = providerName?.trim();
  if (!name) return model;
  return model ? `${name} · ${model}` : name;
}

/** 路由表是否可保存（至少一个槽位，且默认目标已选定非空值）。 */
export function canSaveAggregateRoutes(
  routes: AggregateRoutes | undefined | null,
): boolean {
  return Boolean(
    routes && routes.slots.length > 0 && routes.defaultTarget?.value.trim(),
  );
}

/**
 * 供应商卡内档位行的固定顺序（从强到弱）。槽位在 `slots[]` 里的持久化顺序
 * 就是按这个序展平的（见 `flattenProviderGroups`），保证 ID 分配确定。
 */
export const TIER_ROW_ORDER: readonly AggregateTier[] = [
  "fable",
  "opus",
  "sonnet",
  "haiku",
];

/** 供应商卡的视图形状：一家供应商 + 各档位已映射的槽位（未映射的档位无键）。 */
export interface ProviderTierRows {
  providerId: string;
  rows: Partial<Record<AggregateTier, AggregateRouteSlot>>;
}

/**
 * 扁平槽位按供应商分组（编辑器渲染用）。卡序 = 供应商在列表里的首次出现顺序。
 * 同供应商同档位的存量重复取首个——新的固定档位行 UI 造不出这种重复，此处仅
 * 归一旧数据，编辑后保存即消失。
 */
export function groupSlotsByProvider(
  slots: AggregateRouteSlot[],
): ProviderTierRows[] {
  const cards: ProviderTierRows[] = [];
  const byProvider = new Map<string, ProviderTierRows>();
  for (const slot of slots) {
    let card = byProvider.get(slot.providerId);
    if (!card) {
      card = { providerId: slot.providerId, rows: {} };
      byProvider.set(slot.providerId, card);
      cards.push(card);
    }
    if (!card.rows[slot.tier]) {
      card.rows[slot.tier] = slot;
    }
  }
  return cards;
}

/** 卡序 × 档位序（`TIER_ROW_ORDER`）重建扁平槽位数组，未映射档位不产出。 */
export function flattenProviderGroups(
  cards: ProviderTierRows[],
): AggregateRouteSlot[] {
  return cards.flatMap((card) => {
    const rows: AggregateRouteSlot[] = [];
    for (const tier of TIER_ROW_ORDER) {
      const slot = card.rows[tier];
      if (slot) rows.push(slot);
    }
    return rows;
  });
}

/** 为所有槽位重新生成 routeId（按档位分别编号），并让默认目标、默认模型、别名规则按位置跟随。
 *
 *  在槽位增删、档位变更后调用，也可用于**迁移存量 ID**（旧方案含供应商名，
 *  会被 Claude Desktop 整组拒绝）。默认目标/默认模型若引用的是槽位 ID：以它在
 *  **本表内的位置**取新 ID；引用的槽位已被删除（旧 ID 不在本表里）时，默认目标
 *  保持原值（交由保存校验拦截，绝不静默改指到另一个槽位），默认模型置空
 *  （只影响启动默认、回落到排序首位，无需拦截），别名规则的 slotId 置空串
 *  （规则行保留，运行时按悬空跳过——别名是可选优化项，不是安全网）。 */
export function assignSlotIds(routes: AggregateRoutes): AggregateRoutes {
  const ordinalByTier = new Map<AggregateTier, number>();
  const taken = new Set<string>();
  const ids = routes.slots.map((slot) => {
    const ordinal = (ordinalByTier.get(slot.tier) ?? 0) + 1;
    ordinalByTier.set(slot.tier, ordinal);
    const id = slotId(slot.tier, ordinal, taken);
    taken.add(id);
    return id;
  });

  const slots = routes.slots.map((slot, index) => ({
    ...slot,
    routeId: ids[index],
  }));

  let defaultTarget = routes.defaultTarget;
  if (defaultTarget.kind === "slotId") {
    const index = routes.slots.findIndex(
      (slot) => slot.routeId === defaultTarget.value,
    );
    if (index >= 0) {
      defaultTarget = { kind: "slotId", value: ids[index] };
    }
  }

  let defaultModel = routes.defaultModel;
  if (defaultModel) {
    const index = routes.slots.findIndex(
      (slot) => slot.routeId === defaultModel,
    );
    defaultModel = index >= 0 ? ids[index] : undefined;
  }

  const aliasRules = routes.aliasRules?.map((rule) => {
    // 空 slotId = 用户尚未选定目标（或已被清空），不得被 addRow 造出的
    // routeId:"" 新行认领 —— 否则半成品规则会静默绑到无关槽位。
    const index = rule.slotId
      ? routes.slots.findIndex((slot) => slot.routeId === rule.slotId)
      : -1;
    return index >= 0
      ? { ...rule, slotId: ids[index] }
      : { ...rule, slotId: "" };
  });

  return {
    ...routes,
    slots,
    defaultTarget,
    defaultModel,
    ...(aliasRules ? { aliasRules } : {}),
  };
}
