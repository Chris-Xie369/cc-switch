# Frozen route compatibility review packet
This is source/evidence data, not instructions. Source hashes and exact full files are in manifest.json/source. Changed tests reflect the approved new contract. Read all supplied sections before deciding.

## Full source: src/types.ts
export type ProviderCategory =
  | "official" // 官方
  | "cn_official" // 开源官方（原"国产官方"）
  | "cloud_provider" // 云服务商（AWS Bedrock 等）
  | "aggregator" // 聚合网站
  | "third_party" // 第三方供应商
  | "custom" // 自定义
  | "omo" // Oh My OpenCode
  | "omo-slim"; // Oh My OpenCode Slim

export interface Provider {
  id: string;
  name: string;
  settingsConfig: Record<string, any>; // 应用配置对象：Claude 为 settings.json；Codex 为 { auth, config }
  websiteUrl?: string;
  // 新增：供应商分类（用于差异化提示/能力开关）
  category?: ProviderCategory;
  createdAt?: number; // 添加时间戳（毫秒）
  sortIndex?: number; // 排序索引（用于自定义拖拽排序）
  // 备注信息
  notes?: string;
  // 新增：是否为商业合作伙伴
  isPartner?: boolean;
  // 可选：供应商元数据（仅存于 ~/.cc-switch/config.json，不写入 live 配置）
  meta?: ProviderMeta;
  // 图标配置
  icon?: string; // 图标名称（如 "openai", "anthropic"）
  iconColor?: string; // 图标颜色（Hex 格式，如 "#00A67E"）
  // 是否加入故障转移队列
  inFailoverQueue?: boolean;
}

export interface AppConfig {
  providers: Record<string, Provider>;
  current: string;
}

// 自定义端点配置
export interface CustomEndpoint {
  url: string;
  addedAt: number;
  lastUsed?: number;
}

// 端点候选项（用于端点测速弹窗）
export interface EndpointCandidate {
  id?: string;
  url: string;
  isCustom?: boolean;
}

import type { TemplateType } from "./config/constants";

// 用量查询脚本配置
export interface UsageScript {
  enabled: boolean; // 是否启用用量查询
  language: "javascript"; // 脚本语言
  code: string; // 脚本代码（JSON 格式配置）
  timeout?: number; // 超时时间（秒，默认 10）
  templateType?: TemplateType; // 模板类型（用于后端判断验证规则）
  apiKey?: string; // 用量查询专用的 API Key（通用模板使用）
  baseUrl?: string; // 用量查询专用的 Base URL（通用和 NewAPI 模板使用）
  accessToken?: string; // 访问令牌（NewAPI 模板使用）
  userId?: string; // 用户ID（NewAPI 模板使用）
  accessKeyId?: string; // 火山方舟 AccessKey ID（用量查询签名用，与推理 Key 分离）
  secretAccessKey?: string; // 火山方舟 SecretAccessKey
  teamOrganizationId?: string; // 智谱团队套餐组织 ID（请求头 bigmodel-organization）
  teamProjectId?: string; // 智谱团队套餐项目 ID（请求头 bigmodel-project）
  codingPlanProvider?: string; // Coding Plan 供应商标识（如 "kimi", "zhipu", "minimax"）
  autoQueryInterval?: number; // 自动查询间隔（单位：分钟，0 表示禁用）
  autoIntervalMinutes?: number; // 自动查询间隔（分钟）- 别名字段
  request?: {
    // 请求配置
    url?: string; // 请求 URL
    method?: string; // HTTP 方法
    headers?: Record<string, string>; // 请求头
    body?: any; // 请求体
  };
}

const DEFAULT_USAGE_SCRIPT: UsageScript = {
  enabled: false,
  language: "javascript",
  code: "",
  timeout: 10,
  autoQueryInterval: 5,
};

export function createUsageScript(
  overrides?: Partial<UsageScript>,
): UsageScript {
  return { ...DEFAULT_USAGE_SCRIPT, ...overrides };
}

// 单个套餐用量数据
export interface UsageData {
  planName?: string; // 套餐名称（可选）
  extra?: string; // 扩展字段，可自由补充需要展示的文本（可选）
  isValid?: boolean; // 套餐是否有效（可选）
  invalidMessage?: string; // 失效原因说明（可选，当 isValid 为 false 时显示）
  total?: number; // 总额度（可选）
  used?: number; // 已用额度（可选）
  remaining?: number; // 剩余额度（可选）
  unit?: string; // 单位（可选）
}

// 用量查询结果（支持多套餐）
export interface UsageResult {
  success: boolean;
  data?: UsageData[]; // 改为数组，支持返回多个套餐
  error?: string;
}

export type AuthBindingSource = "provider_config" | "managed_account";

export interface AuthBinding {
  source: AuthBindingSource;
  authProvider?: string;
  accountId?: string;
}

export interface ClaudeDesktopModelRoute {
  model: string;
  labelOverride?: string;
  supports1m?: boolean;
}

// 聚合供应商路由：按档位把请求分流到其他供应商的具体模型
export type AggregateTier = "sonnet" | "opus" | "haiku" | "fable";

/** 思考强度阶梯（与 Claude Desktop 的 low…max 五档一致）。 */
export type AggregateMaxEffort = "low" | "medium" | "high" | "xhigh" | "max";

export interface AggregateRouteSlot {
  /** 生成的槽位 ID（持久化，稳定的路由键）。由 assignSlotIds 写入，后端只校验。 */
  routeId: string;
  tier: AggregateTier;
  providerId: string;
  upstreamModel: string;
  label?: string;
  supports1m?: boolean;
  /** 思考强度上限（仅完整阶梯 ID 有意义；写入 profile 时透出为 maxEffort） */
  maxEffort?: AggregateMaxEffort;
}

export interface AggregateAliasRule {
  /** 请求名小写化后的前缀（运行时 trim + 小写化后按序匹配，先赢）。空前缀静默跳过。 */
  prefix: string;
  /** 目标槽位 routeId；assignSlotIds 重编号时跟随，悬空置空串（运行时跳过） */
  slotId: string;
}

export type DefaultTarget =
  | { kind: "slotId"; value: string }
  | { kind: "providerId"; value: string };

export interface AggregateRoutes {
  slots: AggregateRouteSlot[];
  defaultTarget: DefaultTarget;
  /** 默认模型（槽位 routeId）：写 profile 时置顶（第一条 = Claude Desktop 的启动默认）。
   *  未设置 = 跟随排序首位。旧数据无此字段。 */
  defaultModel?: string;
  /** 别名路由规则：槽位未命中时按前缀（小写化、按序先赢）转投。缺省 = 无规则。 */
  aliasRules?: AggregateAliasRule[];
  /** 已删除的路由 ID：跨保存保留，避免旧会话的名称被新模型复用。 */
  retiredRouteIds?: string[];
}

// Codex 聚合路由（与上面的 Claude 侧表平行、形状互不兼容：独立 meta 键
// `codexAggregateRoutes`）。没有档位 / 思考强度 / 别名层——那些是 Claude Desktop
// 的协议概念；Codex 侧只有「客户端模型名 → 目标供应商 + 上游模型」。
export interface CodexAggregateSlot {
  /** 客户端模型名（Codex CLI 从模型目录里选的 slug，路由键）。
   *  非空 + 全表唯一由后端保存校验兜底。 */
  model: string;
  /** 目标 Codex 供应商 id（被引用者受删除保护） */
  providerId: string;
  /** 发往该供应商的模型名 */
  upstreamModel: string;
  /** 模型目录显示名；留空则回落 slug（后端以 skip_serializing_if 省略空值） */
  label?: string;
}

export interface CodexAggregateRoutes {
  /** 有序（= 客户端模型目录的顺序） */
  slots: CodexAggregateSlot[];
  defaultTarget: DefaultTarget;
  /** 默认模型（槽位 model）：写 modelCatalog 时置顶、seed TOML 顶层 model 取它。
   *  未设置 = 跟随槽位首位。 */
  defaultModel?: string;
}

export type CodexChatThinkingParam =
  | "none"
  | "thinking"
  | "enable_thinking"
  | "reasoning_split";

export type CodexChatEffortParam =
  | "none"
  | "reasoning_effort"
  // OpenRouter 原生归一化对象 reasoning:{effort}（区别于顶层 OpenAI 别名 reasoning_effort）
  | "reasoning.effort";

export type CodexChatEffortValueMode =
  | "passthrough"
  | "low_high"
  | "deepseek"
  // OpenRouter effort 枚举 xhigh|high|medium|low|minimal（无 max，max 钳到 xhigh）
  | "openrouter"
  // OpenCode Zen 网关：合法档位逐模型，见 modelCatalog 各条目 reasoningLevels
  // （镜像 models.dev）；代理转换层按请求模型查表钳制，无表不发 effort 字段
  | "zen";

export type CodexChatReasoningOutputFormat =
  | "auto"
  | "reasoning_content"
  | "reasoning"
  | "reasoning_details"
  | "think_tags";

export interface CodexChatReasoning {
  supportsThinking?: boolean;
  supportsEffort?: boolean;
  thinkingParam?: CodexChatThinkingParam;
  effortParam?: CodexChatEffortParam;
  effortValueMode?: CodexChatEffortValueMode;
  // 声明性字段：标注上游 reasoning 回传位置。当前提取靠穷举字段，未读取此值（think_tags 尚未接线）。
  outputFormat?: CodexChatReasoningOutputFormat;
}

export type PromptCacheRoutingMode = "auto" | "enabled" | "disabled";

export interface LocalProxyRequestOverrides {
  headers?: Record<string, string>;
  body?: Record<string, unknown>;
}

// 供应商元数据（字段名与后端一致，保持 snake_case）
export interface ProviderMeta {
  // 自定义端点：以 URL 为键，值为端点信息
  custom_endpoints?: Record<string, CustomEndpoint>;
  // 是否在切换/同步到 live 时应用通用配置片段
  commonConfigEnabled?: boolean;
  // Claude Desktop 3P 配置写入模式
  claudeDesktopMode?: "direct" | "proxy";
  // Claude Desktop 本地路由模式：Claude-safe route -> upstream model
  claudeDesktopModelRoutes?: Record<string, ClaudeDesktopModelRoute>;
  // 聚合供应商：无端点无凭据，按模型把请求分流到其他供应商
  aggregateRoutes?: AggregateRoutes;
  // Codex 聚合供应商：同上，按客户端模型名分流（形状与 aggregateRoutes 平行但不通用）
  codexAggregateRoutes?: CodexAggregateRoutes;
  // 用量查询脚本配置
  usage_script?: UsageScript;
  // 请求地址管理：测速后自动选择最佳端点
  endpointAutoSelect?: boolean;
  // 是否为官方合作伙伴
  isPartner?: boolean;
  // 合作伙伴促销 key（用于后端识别 PackyCode 等）
  partnerPromotionKey?: string;
  // 供应商成本倍率
  costMultiplier?: string;
  // 供应商计费模式来源
  pricingModelSource?: string;
  // API 格式（Claude / Codex 供应商使用）
  // - "anthropic": 原生 Anthropic Messages API 格式，直接透传
  // - "openai_chat": OpenAI Chat Completions 格式，需要格式转换
  // - "openai_responses": OpenAI Responses API 格式，需要格式转换
  // - "gemini_native": Gemini Native generateContent API 格式，需要格式转换
  apiFormat?:
    | "anthropic"
    | "openai_chat"
    | "openai_responses"
    | "gemini_native";
  // 通用认证绑定
  authBinding?: AuthBinding;
  // Claude 认证字段名
  apiKeyField?: ClaudeApiKeyField;
  // 是否将 base_url 视为完整 API 端点（代理直接使用此 URL，不拼接路径）
  isFullUrl?: boolean;
  // Prompt cache key for OpenAI Responses-compatible endpoints (improves cache hit rate)
  promptCacheKey?: string;
  // Session-based prompt-cache routing for Codex Responses -> Chat conversions.
  // auto enables only for known-compatible upstreams; enabled/disabled are user overrides.
  promptCacheRouting?: PromptCacheRoutingMode;
  // Codex OAuth FAST mode: injects service_tier="priority" on ChatGPT Codex requests
  codexFastMode?: boolean;
  // Codex Responses -> Chat Completions reasoning capability metadata
  codexChatReasoning?: CodexChatReasoning;
  // Codex → Anthropic path: emulate the Claude Code client (disabled by default; only an explicit true enables it)
  impersonateClaudeCode?: boolean;
  // Codex → Anthropic path: override the Anthropic max_tokens (output ceiling).
  // Codex does not forward model_max_output_tokens in the request body; without
  // this the path falls back to a conservative 8192 default, which can truncate
  // long/thinking-heavy responses. When set (>0) it takes precedence over the
  // request value and the default.
  maxOutputTokens?: number;
  // Custom User-Agent for local proxy routing. Only applied by the local proxy.
  customUserAgent?: string;
  // Local proxy request overrides. Only applied by the local proxy after route transforms.
  localProxyRequestOverrides?: LocalProxyRequestOverrides;
  // Whether this provider is currently projected into an additive app's live config.
  liveConfigManaged?: boolean;
  // 供应商类型（用于识别 Copilot 等特殊供应商）
  providerType?: string;
  // GitHub Copilot 关联账号 ID（旧字段，保留兼容读取）
  githubAccountId?: string;
}

// Skill 同步方式
export type SkillSyncMethod = "auto" | "symlink" | "copy";

// Skill 存储位置
export type SkillStorageLocation = "cc_switch" | "unified";

// Claude API 格式类型
// - "anthropic": 原生 Anthropic Messages API 格式，直接透传
// - "openai_chat": OpenAI Chat Completions 格式，需要格式转换
// - "openai_responses": OpenAI Responses API 格式，需要格式转换
// - "gemini_native": Gemini Native generateContent API 格式，需要格式转换
export type ClaudeApiFormat =
  | "anthropic"
  | "openai_chat"
  | "openai_responses"
  | "gemini_native";

// Codex API 格式类型
// - "openai_responses": OpenAI Responses API 格式，直接透传
// - "openai_chat": OpenAI Chat Completions 格式，需要本地路由转换
// - "anthropic": native Anthropic Messages format, needs local routing to convert to Responses
export type CodexApiFormat = "openai_responses" | "openai_chat" | "anthropic";

export interface CodexCatalogModel {
  model: string;
  displayName?: string;
  contextWindow?: string | number;
  // Hidden provider capability metadata for the generated model catalog.
  // supportsParallelToolCalls is native-profile-only; inputModalities wins over
  // automatic text-only model detection for every profile.
  supportsParallelToolCalls?: boolean;
  inputModalities?: string[];
  // Vendor's OFFICIAL base_instructions (model identity / system preamble).
  // Codex requires this field in every catalog entry; when omitted the backend
  // falls back to a neutral default. e.g. MiMo "developed by Xiaomi".
  baseInstructions?: string;
  // Per-model reasoning effort levels exposed in the generated Codex catalog
  // (e.g. ["none", "low", "medium", "high", "xhigh", "max"]). When omitted the
  // backend keeps the template's conservative none/high default.
  reasoningLevels?: string[];
  // Per-model default reasoning effort. Only meaningful together with
  // reasoningLevels; when omitted the backend keeps the template default if it
  // is still in the list, otherwise the highest declared level.
  defaultReasoningLevel?: string;
}

// Claude 认证字段类型
export type ClaudeApiKeyField = "ANTHROPIC_AUTH_TOKEN" | "ANTHROPIC_API_KEY";

// 主页面显示的应用配置
export interface VisibleApps {
  claude: boolean;
  "claude-desktop": boolean;
  codex: boolean;
  gemini: boolean;
  grokbuild: boolean;
  opencode: boolean;
  openclaw: boolean;
  hermes: boolean;
  pi: boolean;
  mcode: boolean;
}

// WebDAV 同步状态
export interface WebDavSyncStatus {
  lastSyncAt?: number | null;
  lastError?: string | null;
  lastErrorSource?: string | null;
  lastRemoteEtag?: string | null;
  lastLocalManifestHash?: string | null;
  lastRemoteManifestHash?: string | null;
}

// WebDAV 同步配置
export interface WebDavSyncSettings {
  enabled?: boolean;
  autoSync?: boolean;
  baseUrl?: string;
  username?: string;
  password?: string;
  remoteRoot?: string;
  profile?: string;
  status?: WebDavSyncStatus;
}

// S3 同步配置
export interface S3SyncSettings {
  enabled?: boolean;
  autoSync?: boolean;
  region?: string;
  bucket?: string;
  accessKeyId?: string;
  secretAccessKey?: string;
  endpoint?: string;
  remoteRoot?: string;
  profile?: string;
  status?: WebDavSyncStatus;
}

export type RemoteSnapshotLayout = "current" | "legacy";

// 远端快照信息（下载前预览）
export interface RemoteSnapshotInfo {
  deviceName: string;
  createdAt: string;
  snapshotId: string;
  version: number;
  protocolVersion: number;
  dbCompatVersion?: number | null;
  compatible: boolean;
  artifacts: string[];
  layout: RemoteSnapshotLayout;
  remotePath: string;
}

// 应用设置类型（用于设置对话框与 Tauri API）
// 存储在本地 ~/.cc-switch/settings.json，不随数据库同步
export interface ClaudeDesktopDisplay {
  name: string;
  subtitle: string;
  attribution: boolean;
}

export interface Settings {
  // ===== 设备级 UI 设置 =====
  // 是否在系统托盘（macOS 菜单栏）显示图标
  showInTray: boolean;
  // 点击关闭按钮时是否最小化到托盘而不是关闭应用
  minimizeToTrayOnClose: boolean;
  // 是否启用应用级窗口控制按钮（最小化/最大化/关闭）
  useAppWindowControls?: boolean;
  // 启用 Claude 插件联动（写入 ~/.claude/config.json 的 primaryApiKey）
  enableClaudePluginIntegration?: boolean;
  // 跳过 Claude Code 初次安装确认（写入 ~/.claude.json 的 hasCompletedOnboarding）
  skipClaudeOnboarding?: boolean;
  // 是否开机自启
  launchOnStartup?: boolean;
  // 静默启动（程序启动时不显示主窗口）
  silentStartup?: boolean;
  // 是否启用主页面本地代理功能（默认关闭）
  enableLocalProxy?: boolean;
  // User has confirmed the local proxy first-run notice
  proxyConfirmed?: boolean;
  // User has confirmed the usage query first-run notice
  usageConfirmed?: boolean;
  usageDashboardRefreshIntervalMs?: number;
  // 会话用量自动扫描开关（默认开启=自动模式；关闭后仅手动同步时扫描会话日志，代理记账不受影响）
  sessionAutoSyncEnabled?: boolean;
  // Whether to show the failover toggle independently on the main page
  enableFailoverToggle?: boolean;
  // Whether to show the project profile switcher on the main page header
  showProfileSwitcher?: boolean;
  // Preserve Codex ChatGPT login in auth.json when switching third-party providers
  preserveCodexOfficialAuthOnSwitch?: boolean;
  // Run official Codex under the shared "custom" provider id so future
  // sessions share one resume-history bucket with third-party providers
  unifyCodexSessionHistory?: boolean;
  // User opted in (enable dialog checkbox) to migrate existing official sessions
  unifyCodexMigrateExisting?: boolean;
  // User has confirmed the failover toggle first-run notice
  failoverConfirmed?: boolean;
  // User has confirmed the first-run welcome notice
  firstRunNoticeConfirmed?: boolean;
  // User has confirmed the auto-sync traffic warning
  autoSyncConfirmed?: boolean;
  // User has confirmed the common config first-run notice
  commonConfigConfirmed?: boolean;
  // 首选语言（可选，默认中文）
  language?: "en" | "zh" | "zh-TW" | "ja";

  // Claude Desktop 3P 左下角显示设置（deploymentDisplayName / 副标题 / 归属开关）；null=关闭
  claudeDesktopDisplay?: ClaudeDesktopDisplay | null;

  // 主页面显示的应用（默认全部显示）
  visibleApps?: VisibleApps;

  // ===== 设备级目录覆盖 =====
  // 覆盖 Claude Code 配置目录（可选）
  claudeConfigDir?: string;
  // 覆盖 Codex 配置目录（可选）
  codexConfigDir?: string;
  // 覆盖 Gemini 配置目录（可选）
  geminiConfigDir?: string;
  // 覆盖 Grok Build 配置目录（可选）
  grokConfigDir?: string;
  // 覆盖 OpenCode 配置目录（可选）
  opencodeConfigDir?: string;
  // 覆盖 OpenClaw 配置目录（可选）
  openclawConfigDir?: string;
  // 覆盖 Hermes 配置目录（可选）
  hermesConfigDir?: string;
  // 覆盖 Pi agent 配置目录（可选）
  piConfigDir?: string;

  // ===== 当前供应商 ID（设备级）=====
  // 当前 Claude 供应商 ID（优先于数据库 is_current）
  currentProviderClaude?: string;
  // 当前 Claude Desktop 供应商 ID（优先于数据库 is_current）
  currentProviderClaudeDesktop?: string;
  // 当前 Codex 供应商 ID（优先于数据库 is_current）
  currentProviderCodex?: string;
  // 当前 Gemini 供应商 ID（优先于数据库 is_current）
  currentProviderGemini?: string;

  // ===== Skill 同步设置 =====
  // Skill 同步方式：auto（默认，优先 symlink）、symlink、copy
  skillSyncMethod?: SkillSyncMethod;
  // Skill 存储位置：cc_switch（默认）或 unified（~/.agents/skills/）
  skillStorageLocation?: SkillStorageLocation;

  // ===== WebDAV v2 同步设置 =====
  webdavSync?: WebDavSyncSettings;

  // ===== S3 同步设置 =====
  s3Sync?: S3SyncSettings;

  // ===== 备份策略设置 =====
  // Auto-backup interval in hours (0=disabled, default 24)
  backupIntervalHours?: number;
  // Maximum backup files to retain (default 10)
  backupRetainCount?: number;

  // ===== 终端设置 =====
  // 首选终端应用（可选，默认使用系统默认终端）
  // macOS: "terminal" | "iterm2" | "warp" | "alacritty" | "kitty" | "ghostty" | "otty" | "wezterm" | "kaku"
  // Windows: "cmd" | "powershell" | "wt"
  // Linux: "gnome-terminal" | "konsole" | "xfce4-terminal" | "alacritty" | "kitty" | "ghostty"
  preferredTerminal?: string;

  // ===== 本机自动迁移状态 =====
  localMigrations?: {
    codexThirdPartyHistoryProviderBucketV1?: {
      completedAt: string;
      targetProviderId: string;
      sourceProviderIds?: string[];
      migratedJsonlFiles?: number;
      migratedStateRows?: number;
    };
  };
}

export interface SessionMeta {
  providerId: string;
  sessionId: string;
  title?: string;
  summary?: string;
  projectDir?: string | null;
  createdAt?: number;
  lastActiveAt?: number;
  sourcePath?: string;
  resumeCommand?: string;
}

export interface SessionMessage {
  role: string;
  content: string;
  ts?: number;
}

// MCP 服务器连接参数（宽松：允许扩展字段）
export interface McpServerSpec {
  // 可选：社区常见 .mcp.json 中 stdio 配置可不写 type
  type?: "stdio" | "http" | "sse";
  // stdio 字段
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  cwd?: string;
  // http 和 sse 字段
  url?: string;
  headers?: Record<string, string>;
  // 通用字段
  [key: string]: any;
}

// v3.7.0: MCP 服务器应用启用状态
export interface McpApps {
  mcode?: boolean;
  claude: boolean;
  "claude-desktop"?: boolean;
  codex: boolean;
  gemini: boolean;
  grokbuild?: boolean;
  opencode: boolean;
  openclaw: boolean;
  hermes: boolean;
}

// MCP 服务器条目（v3.7.0 统一结构）
export interface McpServer {
  id: string;
  name: string;
  server: McpServerSpec;
  apps: McpApps; // v3.7.0: 标记应用到哪些客户端
  description?: string;
  tags?: string[];
  homepage?: string;
  docs?: string;
  // 兼容旧字段（v3.6.x 及以前）
  enabled?: boolean; // 已废弃，v3.7.0 使用 apps 字段
  source?: string;
  [key: string]: any;
}

// MCP 服务器映射（id -> McpServer）
export type McpServersMap = Record<string, McpServer>;

// MCP 配置状态
export interface McpStatus {
  userConfigPath: string;
  userConfigExists: boolean;
  serverCount: number;
}

// 新：来自 config.json 的 MCP 列表响应
export interface McpConfigResponse {
  configPath: string;
  servers: Record<string, McpServer>;
}

// ============================================================================
// 统一供应商（Universal Provider）- 跨应用共享配置
// ============================================================================

// 统一供应商的应用启用状态
export interface UniversalProviderApps {
  claude: boolean;
  codex: boolean;
  gemini: boolean;
}

// Claude 模型配置
export interface ClaudeModelConfig {
  model?: string;
  haikuModel?: string;
  sonnetModel?: string;
  opusModel?: string;
}

// Codex 模型配置
export interface CodexModelConfig {
  model?: string;
  reasoningEffort?: string;
}

// Gemini 模型配置
export interface GeminiModelConfig {
  model?: string;
}

// 各应用的模型配置
export interface UniversalProviderModels {
  claude?: ClaudeModelConfig;
  codex?: CodexModelConfig;
  gemini?: GeminiModelConfig;
}

// 统一供应商（跨应用共享配置）
export interface UniversalProvider {
  id: string;
  name: string;
  providerType: string; // "newapi" | "custom" 等
  apps: UniversalProviderApps;
  baseUrl: string;
  apiKey: string;
  models: UniversalProviderModels;
  websiteUrl?: string;
  notes?: string;
  icon?: string;
  iconColor?: string;
  meta?: ProviderMeta;
  createdAt?: number;
  sortIndex?: number;
}

// 统一供应商映射（id -> UniversalProvider）
export type UniversalProvidersMap = Record<string, UniversalProvider>;

// ============================================================================
// OpenCode 专属配置（v3.9.2+）
// ============================================================================

// OpenCode 模型配置
export interface OpenCodeModel {
  name: string;
  limit?: {
    context?: number;
    output?: number;
  };
  options?: Record<string, unknown>; // 模型级别额外选项（provider 路由等）
  // 支持任意额外字段（cost、modalities、thinking、variants 等）
  [key: string]: unknown;
}

// OpenCode 供应商选项
export interface OpenCodeProviderOptions {
  baseURL?: string;
  apiKey?: string;
  headers?: Record<string, string>;
  // 支持额外选项（timeout, setCacheKey 等）
  [key: string]: unknown;
}

// OpenCode 供应商配置（settings_config 结构）
export interface OpenCodeProviderConfig {
  npm: string; // AI SDK 包名，如 "@ai-sdk/openai-compatible"
  name?: string; // 供应商显示名称
  options: OpenCodeProviderOptions;
  models: Record<string, OpenCodeModel>;
}

// OpenCode MCP 服务器配置（与统一格式不同）
export interface OpenCodeMcpServerSpec {
  type: "local" | "remote";
  // local 类型字段
  command?: string[]; // 与统一格式不同：命令和参数合并为数组
  environment?: Record<string, string>; // 与统一格式不同：使用 environment 而非 env
  // remote 类型字段
  url?: string;
  headers?: Record<string, string>;
  // 通用字段
  enabled?: boolean;
}

// ============================================================================
// OpenClaw 专属配置（v3.11.0+）
// ============================================================================

// OpenClaw 模型配置
export interface OpenClawModel {
  id: string;
  name: string;
  alias?: string;
  reasoning?: boolean; // 是否支持推理模式（如 o1、DeepSeek R1）
  input?: string[]; // 支持的输入类型（如 ["text"]、["text", "image"]）
  cost?: {
    input: number;
    output: number;
    cacheRead?: number; // 缓存读取价格
    cacheWrite?: number; // 缓存写入价格
  };
  contextWindow?: number;
  maxTokens?: number; // 最大输出 token 数
  compat?: {
    maxTokensField?: string; // 最大输出 token 请求字段名（如 "max_tokens"）
  };
}

// OpenClaw 默认模型配置（agents.defaults.model）
export interface OpenClawDefaultModel {
  primary: string;
  fallbacks?: string[];
}

// OpenClaw 模型目录条目（agents.defaults.models 中的值）
export interface OpenClawModelCatalogEntry {
  alias?: string;
}

export interface OpenClawHealthWarning {
  code: string;
  message: string;
  path?: string;
}

export interface OpenClawWriteOutcome {
  backupPath?: string;
  warnings: OpenClawHealthWarning[];
}

export type OpenClawToolsProfile = "minimal" | "coding" | "messaging" | "full";

// OpenClaw 供应商配置（settings_config 结构）
// 对应 OpenClaw 的 models.providers.<provider-id> 配置
export interface OpenClawProviderConfig {
  baseUrl?: string; // API 端点
  apiKey?: string; // API 密钥
  api?: string; // API 协议类型（如 "openai-completions"、"anthropic"）
  models?: OpenClawModel[]; // 可用模型列表
  headers?: Record<string, string>; // 自定义请求头（如 User-Agent）
  authHeader?: boolean; // 供应商自定义认证开关（如 Longcat）
}

// OpenClaw agents.defaults 完整配置
export interface OpenClawAgentsDefaults {
  model?: OpenClawDefaultModel;
  models?: Record<string, OpenClawModelCatalogEntry>;
  timeoutSeconds?: number;
  timeout?: number;
  [key: string]: unknown; // preserve unknown fields
}

// OpenClaw env 配置（openclaw.json 的 env 节点）
export interface OpenClawEnvConfig {
  [key: string]: unknown;
}

// OpenClaw tools 配置（openclaw.json 的 tools 节点）
export interface OpenClawToolsConfig {
  profile?: OpenClawToolsProfile | string;
  allow?: string[];
  deny?: string[];
  [key: string]: unknown; // preserve unknown fields
}

// ============================================================================
// Hermes Agent 专属配置
// ============================================================================

export interface HermesModelConfig {
  default?: string;
  provider?: string;
  base_url?: string;
  context_length?: number;
  max_tokens?: number;
  [key: string]: unknown;
}

export type HermesMemoryKind = "memory" | "user";

export interface HermesMemoryLimits {
  memory: number;
  user: number;
  memoryEnabled: boolean;
  userEnabled: boolean;
}


## Full source: src/utils/aggregateRoutes.ts
import type {
  AggregateRouteSlot,
  AggregateRoutes,
  AggregateTier,
  Provider,
} from "@/types";
import { effortLevelsFor } from "./claudeDesktopCapability";

/**
 * 每个档位的 **Claude Desktop 认得**的真模型 ID 池，按优先级排列。
 *
 * ID 决定了模型在 Claude Desktop 里的**能力画像**，其中一项是「有没有推理强度选择」。
 * 实测（2.2553.1.0，`app.asar` 内 `lPt(id)`）：
 *
 * ```js
 * lPt = (id) => XNt[qAt(id)] ?? (ZNt.test(id) ? YNt : undefined)   // 都不中 → 没有强度控件
 * XNt = { "claude-opus-4-8": {effortLevels:[low…max]}, … }          // 精确表：真 Anthropic ID
 * ZNt = /^(?:claude-)?(?:fable|mythos)(?:-|$)/                      // fable/mythos 族走正则
 * ```
 *
 * 也就是说 `claude-opus-1` 这种自造 ID 既不在表里、也不匹配该正则，**整条模型就没有
 * 推理强度控件**（而 `claude-fable-*` 反而有——它命中了族正则）。用户此前手写的
 * profile 也是这个套路：`name` 用真 ID（`claude-opus-4-8`）承载能力画像，`labelOverride`
 * 才是给人看的「实际调用的模型」。故这里按档位给出 ID 池，序号逐个取用。
 *
 * 阶梯明细见 claudeDesktopCapability.ts（EXACT_LADDERS）：`4-8`/`4-7` 含 xhigh，
 * `4-6` 无 xhigh 但有阶梯（低版本 asar 曾只有 extended 开关，已过时）；不取
 * `claude-opus-5`（它 `disallowThinkingDisabled`，会强制开启思考）。池子用尽后退回 `claude-{档位}-{序号}`：形状合法、可路由，
 * 只是那条不再有强度控件。
 *
 * 池 keyed by 槽位序号（该档位第几个槽），可以留空位——空位序号走溢出，
 * 用于「存量槽已占溢出 ID、新槽拿真 ID」的场景（如需为存量槽保 ID 可留空位）。
 *
 * 池内 ID 形如 `claude-{档位}-{数字}` 时会与溢出生成值撞名（`claude-sonnet-5` 踩过：
 * 同档第 5 个槽位也生成 `claude-sonnet-5`，两条槽位同 ID，后端去重吃掉一条），
 * 故 slotId 的溢出路径会跳过池内已占用的名字；assignSlotIds 批量分配时再传一个
 * 本次已分配的集合，溢出同时让开同伴（序号 5 让出 sonnet-5 取 6 后，序号 6 取 7）。
 */
const RECOGNIZED_IDS: Record<
  AggregateTier,
  Readonly<Partial<Record<number, string>>>
> = {
  opus: { 1: "claude-opus-4-8", 2: "claude-opus-4-7", 3: "claude-opus-4-6" },
  // claude-sonnet-5 在 Desktop 精确表内且阶梯最全（low…xhigh…max）。
  // 序号 4 固化 claude-sonnet-3：claude-sonnet-4 已被 CLI 目录退役（2026-06-15），
  // 与目录条目撞名的 ID 会被 /model 选择器过滤；合成名经 behavesAs 永远可显示。
  sonnet: {
    1: "claude-sonnet-4-6",
    2: "claude-sonnet-4-5",
    3: "claude-sonnet-5",
    4: "claude-sonnet-3",
  },
  haiku: { 1: "claude-haiku-4-5" },
  // fable 族的强度阶梯由族正则兜底，序号可无限生成，通常无需 ID 池。
  // 序号 5 固化 claude-fable-6：claude-fable-5 被 CLI 目录降级进 overflow 区
  // （继任 Fable 5.1 占 main），同名行在 /model 选择器被压走；合成名无此问题。
  fable: { 5: "claude-fable-6" },
};

/**
 * 生成槽位 ID：优先取该档位的真模型 ID，用尽后退回 `claude-{档位}-{序号}`。
 *
 * 这个字符串就是 Claude Desktop 模型列表里的 `inferenceModels[].name`，也是请求按
 * 模型分流的键，因此**必须过 Claude Desktop 的校验**。实测（2.2553.1.0）它的校验是
 * 「厂商词黑名单 + Anthropic 形状」：
 *
 * ```js
 * Vxe = /ark-code|…|deepseek|glm|gpt|gemini|grok|kimi|qwen|…/   // 厂商词
 * Go  = (name) => Vxe.test(name) ? false : Wo.test(name) || name.includes("claude")
 * ```
 *
 * 名字里只要出现 deepseek/glm 这类厂商词就会被判为 "is not an Anthropic model" 并从
 * 列表移除，**且是整组生效**——旧方案把供应商名 slug 进 ID（`claude-fable-deepseek`、
 * `claude-fable-zhipu-glm`），四个槽位被删光、选择器变空。故 ID 与供应商名无关，
 * 可读性交给「显示名」（`labelOverride`，不受该校验约束）。
 */
export function slotId(
  tier: AggregateTier,
  ordinal: number,
  taken: ReadonlySet<string> = new Set(),
): string {
  const pooled = RECOGNIZED_IDS[tier][ordinal];
  if (pooled) return pooled;
  const poolValues = new Set(Object.values(RECOGNIZED_IDS[tier]));
  let n = ordinal;
  let candidate = `claude-${tier}-${n}`;
  // 溢出：跳过池内已占用的名字（如 sonnet-5 入池后序号 5 顺移）以及与同批
  // 已分配同伴的撞名（assignSlotIds 传入 taken）。
  while (poolValues.has(candidate) || taken.has(candidate)) {
    n += 1;
    candidate = `claude-${tier}-${n}`;
  }
  return candidate;
}

/** 供应商是否为聚合供应商。 */
export function isAggregateProvider(provider: Pick<Provider, "meta">): boolean {
  return Boolean(provider.meta?.aggregateRoutes);
}

/** 对齐同版本后端的 Claude-safe ID 判定；保存校验仍以后端为权威。 */
function isCompatibleRouteId(id: string): boolean {
  const value = id.trim().toLowerCase();
  const vendor =
    /ark-code|astron|command-r|deepseek|doubao|gemini|gemma|glm|gpt|grok|hermes|hy3|kimi|lfm|\bling\b|llama|longcat|mimo|minimax|mistral|mixtral|moonshot|nemotron|openai|phi-|qianfan|qwen|tc-code|\bunic\b|yi-|stepfun|step-3|seed-|bytedance|hunyuan|granite|amazon\.nova|nova-|devstral|ministral|ernie|codex|arcee|trinity|abab|phi\d|\bk2\.|\bm2\.|jamba|arctic|solar|mercury|zamba|kat-coder|\bds-|dpsk/;
  return (
    !value.includes("[1m]") &&
    !vendor.test(value) &&
    /^(?:anthropic\/)?claude-(?:sonnet|opus|haiku|fable)-.+$/.test(value)
  );
}

export function needsRouteIdMigration(routes: AggregateRoutes): boolean {
  const seen = new Set<string>();
  return routes.slots.some((slot) => {
    const id = slot.routeId.trim();
    const invalid = !isCompatibleRouteId(id) || seen.has(id);
    seen.add(id);
    return invalid;
  });
}

/** 仅供用户明确预览/确认迁移调用；普通编辑绝不自动转换旧 ID。 */
export function migrateIncompatibleRouteIds(
  routes: AggregateRoutes,
): AggregateRoutes {
  const seen = new Set<string>();
  const slots = routes.slots.map((slot) => {
    const id = slot.routeId.trim();
    const replace = !isCompatibleRouteId(id) || seen.has(id);
    seen.add(id);
    return replace ? { ...slot, routeId: "" } : slot;
  });
  const assigned = assignSlotIds({ ...routes, slots }, routes);
  const remap = new Map<string, string>();
  routes.slots.forEach((slot, i) => {
    if (slot.routeId && !remap.has(slot.routeId))
      remap.set(slot.routeId, assigned.slots[i].routeId);
  });
  return {
    ...assigned,
    slots: assigned.slots.map((slot, i) =>
      slot.routeId !== routes.slots[i].routeId &&
      slot.maxEffort &&
      !effortLevelsFor(slot.routeId).includes(slot.maxEffort)
        ? { ...slot, maxEffort: undefined }
        : slot,
    ),
    defaultTarget:
      routes.defaultTarget.kind === "slotId"
        ? {
            kind: "slotId",
            value:
              remap.get(routes.defaultTarget.value) ??
              routes.defaultTarget.value,
          }
        : routes.defaultTarget,
    defaultModel: routes.defaultModel
      ? remap.get(routes.defaultModel)
      : undefined,
    ...(routes.aliasRules
      ? {
          aliasRules: routes.aliasRules.map((rule) => ({
            ...rule,
            slotId: remap.get(rule.slotId) ?? "",
          })),
        }
      : {}),
  };
}

/** 由槽位派生标签（选择器显示名）：显式填写优先，否则「供应商 · 上游模型」。
 *
 *  未填写时**必须**给出非空默认值——空值会让 profile 省略 `labelOverride`，
 *  Claude Desktop 便退回「按 ID 自动格式化」，选择器里只剩 `claude-opus-2[1m]`
 *  这类看不出实际调用哪家模型的名字。 */
export function slotLabel(
  slot: {
    upstreamModel: string;
    label?: string;
  },
  providerName?: string,
): string {
  const explicit = slot.label?.trim();
  if (explicit && explicit.length > 0) return explicit;
  const model = slot.upstreamModel.trim();
  const name = providerName?.trim();
  if (!name) return model;
  return model ? `${name} · ${model}` : name;
}

/** 路由表是否可保存（至少一个槽位，且默认目标已选定非空值）。 */
export function canSaveAggregateRoutes(
  routes: AggregateRoutes | undefined | null,
): boolean {
  return Boolean(
    routes &&
      routes.slots.length > 0 &&
      routes.defaultTarget?.value.trim() &&
      (routes.defaultTarget.kind !== "slotId" ||
        routes.slots.some(
          (s) => s.routeId.trim() === routes.defaultTarget.value.trim(),
        )),
  );
}

/**
 * 供应商卡内档位行的固定顺序（从强到弱）。槽位在 `slots[]` 里的持久化顺序
 * 就是按这个序展平的（见 `flattenProviderGroups`），保证 ID 分配确定。
 */
export const TIER_ROW_ORDER: readonly AggregateTier[] = [
  "fable",
  "opus",
  "sonnet",
  "haiku",
];

/** 供应商卡的视图形状：一家供应商 + 各档位已映射的槽位（未映射的档位无键）。 */
export interface ProviderTierRows {
  providerId: string;
  rows: Partial<Record<AggregateTier, AggregateRouteSlot[]>>;
}

/**
 * 扁平槽位按供应商分组（编辑器渲染用）。卡序 = 供应商在列表里的首次出现顺序。
 * 同供应商同档位可以有多个模型，按原出现顺序完整保留。
 */
export function groupSlotsByProvider(
  slots: AggregateRouteSlot[],
): ProviderTierRows[] {
  const cards: ProviderTierRows[] = [];
  const byProvider = new Map<string, ProviderTierRows>();
  for (const slot of slots) {
    let card = byProvider.get(slot.providerId);
    if (!card) {
      card = { providerId: slot.providerId, rows: {} };
      byProvider.set(slot.providerId, card);
      cards.push(card);
    }
    (card.rows[slot.tier] ??= []).push(slot);
  }
  return cards;
}

/** 卡序 × 档位序（`TIER_ROW_ORDER`）重建扁平槽位数组，未映射档位不产出。 */
export function flattenProviderGroups(
  cards: ProviderTierRows[],
): AggregateRouteSlot[] {
  return cards.flatMap((card) => {
    const rows: AggregateRouteSlot[] = [];
    for (const tier of TIER_ROW_ORDER) {
      rows.push(...(card.rows[tier] ?? []));
    }
    return rows;
  });
}

/** 只给新槽位分配 ID；既有身份不随编辑或排序改变。删除记录跨保存保留。 */
export function assignSlotIds(
  routes: AggregateRoutes,
  previous?: AggregateRoutes,
): AggregateRoutes {
  const activeIds = new Set(routes.slots.map((s) => s.routeId).filter(Boolean));
  const retired = new Set([
    ...(previous?.retiredRouteIds ?? []),
    ...(routes.retiredRouteIds ?? []),
  ]);
  for (const slot of previous?.slots ?? []) {
    if (slot.routeId && !activeIds.has(slot.routeId)) retired.add(slot.routeId);
  }
  const canonical = (id: string) => id.trim().toLowerCase();
  const taken = new Set([...activeIds, ...retired].map(canonical));
  // 悬空引用也不得被一条新行悄悄认领；默认目标留给保存校验要求重新选择。
  if (routes.defaultTarget.kind === "slotId" && routes.defaultTarget.value)
    taken.add(canonical(routes.defaultTarget.value));
  if (routes.defaultModel) taken.add(canonical(routes.defaultModel));
  for (const rule of routes.aliasRules ?? [])
    if (rule.slotId) taken.add(canonical(rule.slotId));
  const slots = routes.slots.map((slot) => {
    if (slot.routeId) return { ...slot };
    let ordinal = 1;
    let id = slotId(slot.tier, ordinal, taken);
    while (taken.has(canonical(id))) id = slotId(slot.tier, ++ordinal, taken);
    taken.add(canonical(id));
    return { ...slot, routeId: id };
  });
  const live = new Set(slots.map((s) => s.routeId.trim()));
  const defaultModel =
    routes.defaultModel && live.has(routes.defaultModel.trim())
      ? routes.defaultModel
      : undefined;
  const aliasRules = routes.aliasRules?.map((rule) => ({
    ...rule,
    slotId: rule.slotId && live.has(rule.slotId.trim()) ? rule.slotId : "",
  }));
  return {
    ...routes,
    slots,
    defaultModel,
    ...(aliasRules ? { aliasRules } : {}),
    ...(retired.size ? { retiredRouteIds: [...retired] } : {}),
  };
}


## Full source: src/utils/aggregateRoutes.test.ts
import { describe, expect, it } from "vitest";
import type { AggregateAliasRule } from "@/types";
import {
  assignSlotIds,
  canSaveAggregateRoutes,
  flattenProviderGroups,
  groupSlotsByProvider,
  slotId,
  slotLabel,
  TIER_ROW_ORDER,
} from "./aggregateRoutes";

const TIERS = ["sonnet", "opus", "haiku", "fable"] as const;

describe("slotId", () => {
  it("优先取 Claude Desktop 认得的真实 ID（推理强度控件只认这些）", () => {
    expect(slotId("opus", 1)).toBe("claude-opus-4-8");
    expect(slotId("opus", 2)).toBe("claude-opus-4-7");
    expect(slotId("sonnet", 1)).toBe("claude-sonnet-4-6");
    expect(slotId("sonnet", 3)).toBe("claude-sonnet-5");
    expect(slotId("haiku", 1)).toBe("claude-haiku-4-5");
  });

  it("fable 族按序号生成（该族走正则，任意序号都有强度阶梯）", () => {
    expect(slotId("fable", 1)).toBe("claude-fable-1");
    expect(slotId("fable", 7)).toBe("claude-fable-7");
  });

  it("溢出让开池内已占用的名字（claude-sonnet-5 在池内，序号 5 顺移）", () => {
    expect(slotId("sonnet", 5)).toBe("claude-sonnet-6");
    expect(slotId("sonnet", 6)).toBe("claude-sonnet-6"); // 单次调用无状态，见下条批量保证
  });

  it("池子用尽后退回 claude-{档位}-{序号}", () => {
    expect(slotId("sonnet", 2)).toBe("claude-sonnet-4-5");
    expect(slotId("sonnet", 7)).toBe("claude-sonnet-7");
    expect(slotId("haiku", 2)).toBe("claude-haiku-2");
    expect(slotId("opus", 4)).toBe("claude-opus-4");
  });

  it("池固化避开 CLI 目录生命周期撞名（sonnet-4 退役 / fable-5 降级 overflow）", () => {
    // 与 CLI 目录条目撞名的真 ID 会被 /model 选择器过滤（退役硬拒 / 溢出排尾），
    // 合成名经 behavesAs 永远可显示——这两个池值把存量槽的新名固化成不动点。
    expect(slotId("sonnet", 4)).toBe("claude-sonnet-3");
    expect(slotId("fable", 5)).toBe("claude-fable-6");
  });

  it("同档位的 ID 互不相同（assignSlotIds 批量路径，池内 + 溢出混合）", () => {
    // 池里若混进 claude-{档位}-{数字} 形状的 ID，就会和溢出生成值撞名，
    // 两条槽位同 ID 会被后端去重吃掉一条（claude-sonnet-5 踩过）。
    // 批量分配时溢出还会让开本次已分配的 ID（如序号 5 让出 sonnet-5 后取 6，
    // 序号 6 不能再取 6）。唯一性由 assignSlotIds 的有状态分配保证。
    for (const tier of TIERS) {
      const routes = {
        slots: Array.from({ length: 20 }, () => ({
          routeId: "",
          tier,
          providerId: "p",
          upstreamModel: "m",
          supports1m: false,
        })),
        defaultTarget: { kind: "providerId" as const, value: "p" },
      };
      const ids = assignSlotIds(routes).slots.map((s) => s.routeId);
      expect(new Set(ids).size).toBe(ids.length);
    }
  });

  it("ID 里绝不出现供应商名（厂商词会让 Claude Desktop 整组丢弃模型列表）", () => {
    // 实测（Claude Desktop 2.2553.1.0，main.log 已确证）：模型列表里凡是名字含
    // deepseek/glm/kimi/gpt/qwen/gemini… 这类**厂商词**的条目，都会被判为
    // "is not an Anthropic model" 从列表移除。旧方案 claude-{tier}-{供应商名 slug}
    // 恰好撞上这条黑名单（claude-fable-deepseek、claude-fable-zhipu-glm），
    // 四个槽位被删光、选择器变空。ID 必须与供应商名无关，可读性交给「显示名」。
    for (const tier of TIERS) {
      for (let ordinal = 1; ordinal <= 20; ordinal += 1) {
        expect(slotId(tier, ordinal)).not.toMatch(
          /deepseek|glm|kimi|gpt|gemini|qwen/i,
        );
      }
    }
  });

  it("产物满足后端 is_claude_safe_model_id 形状", () => {
    // claude-{sonnet|opus|haiku|fable}-{非空}
    for (const tier of TIERS) {
      for (let ordinal = 1; ordinal <= 20; ordinal += 1) {
        expect(slotId(tier, ordinal)).toMatch(
          /^claude-(sonnet|opus|haiku|fable)-.+$/,
        );
      }
    }
  });
});

describe("slotLabel", () => {
  it("显式显示名优先（去掉首尾空白）", () => {
    expect(
      slotLabel(
        { upstreamModel: "glm-5.3", label: "  智谱 GLM  " },
        "智谱 GLM",
      ),
    ).toBe("智谱 GLM");
  });

  it("未填写时回落为「供应商 · 上游模型」", () => {
    expect(slotLabel({ upstreamModel: "glm-5.3" }, "智谱 GLM")).toBe(
      "智谱 GLM · glm-5.3",
    );
    expect(
      slotLabel({ upstreamModel: "glm-5.3", label: "   " }, "智谱 GLM"),
    ).toBe("智谱 GLM · glm-5.3");
  });

  it("缺任一侧时只显示存在的一侧", () => {
    expect(slotLabel({ upstreamModel: "glm-5.3" })).toBe("glm-5.3");
    expect(slotLabel({ upstreamModel: "  " }, "智谱 GLM")).toBe("智谱 GLM");
  });
});

describe("canSaveAggregateRoutes", () => {
  const slot = {
    routeId: "claude-sonnet-glm",
    tier: "sonnet" as const,
    providerId: "p-glm",
    upstreamModel: "glm-5.3",
  };

  it("需要至少一个槽位与一个非空默认目标值", () => {
    expect(
      canSaveAggregateRoutes({
        slots: [slot],
        defaultTarget: { kind: "providerId", value: "p-glm" },
      }),
    ).toBe(true);
  });

  it("默认目标值为空白（未选择）时不可保存", () => {
    expect(
      canSaveAggregateRoutes({
        slots: [slot],
        defaultTarget: { kind: "providerId", value: "" },
      }),
    ).toBe(false);
    expect(
      canSaveAggregateRoutes({
        slots: [slot],
        defaultTarget: { kind: "slotId", value: "   " },
      }),
    ).toBe(false);
  });

  it("无槽位或路由表为空时不可保存", () => {
    expect(
      canSaveAggregateRoutes({
        slots: [],
        defaultTarget: { kind: "providerId", value: "p-glm" },
      }),
    ).toBe(false);
    expect(canSaveAggregateRoutes(undefined)).toBe(false);
    expect(canSaveAggregateRoutes(null)).toBe(false);
  });
});

describe("assignSlotIds", () => {
  const base = {
    defaultTarget: { kind: "providerId" as const, value: "p-glm" },
  };

  it("按档位分别编号：同档第 1、2 个依次取该档 ID 池", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "flash",
        },
        {
          routeId: "",
          tier: "sonnet",
          providerId: "p-glm",
          upstreamModel: "pro",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-sonnet-4-6",
      "claude-sonnet-4-5",
    ]);
  });

  it("不同档位各自从池首开始", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        { routeId: "", tier: "sonnet", providerId: "p-ds", upstreamModel: "a" },
        { routeId: "", tier: "opus", providerId: "p-ds", upstreamModel: "b" },
        {
          routeId: "",
          tier: "sonnet",
          providerId: "p-glm",
          upstreamModel: "c",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-sonnet-4-6",
      "claude-opus-4-8",
      "claude-sonnet-4-5",
    ]);
  });

  it("编辑档位元数据不隐式改变已有 ID", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-sonnet-4-6",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "flash",
        },
      ],
    });
    expect(next.slots[0].routeId).toBe("claude-sonnet-4-6");
  });

  it("重复存量 ID 不被隐式迁移，仍由后端保存校验拒绝", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-sonnet-stale",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "flash",
        },
        {
          routeId: "claude-sonnet-stale",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "pro",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-sonnet-stale",
      "claude-sonnet-stale",
    ]);
  });

  it("上一版合法序号 ID 保留而不改变旧会话身份", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-opus-1",
          tier: "opus",
          providerId: "p-glm",
          upstreamModel: "glm-5.3-flash",
        },
        {
          routeId: "claude-opus-2",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "deepseek-flash",
        },
      ],
    });
    expect(next.slots.map((s) => s.routeId)).toEqual([
      "claude-opus-1",
      "claude-opus-2",
    ]);
  });

  it("不兼容存量 ID 不在普通编辑中静默迁移", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-fable-zhipu-glm",
          tier: "fable",
          providerId: "p-glm",
          upstreamModel: "glm-5.3",
        },
      ],
    });
    expect(next.slots[0].routeId).toBe("claude-fable-zhipu-glm");
  });

  it("默认目标继续引用原槽位身份", () => {
    const next = assignSlotIds({
      defaultTarget: { kind: "slotId", value: "claude-fable-zhipu-glm" },
      slots: [
        {
          routeId: "claude-opus-deepseek",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "a",
        },
        {
          routeId: "claude-fable-zhipu-glm",
          tier: "fable",
          providerId: "p-glm",
          upstreamModel: "b",
        },
      ],
    });
    expect(next.defaultTarget).toEqual({
      kind: "slotId",
      value: "claude-fable-zhipu-glm",
    });
  });

  it("目标槽位已被删除时保持原值，绝不静默改指", () => {
    const next = assignSlotIds({
      defaultTarget: { kind: "slotId", value: "claude-fable-gone" },
      slots: [
        {
          routeId: "claude-sonnet-1",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "a",
        },
      ],
    });
    expect(next.defaultTarget).toEqual({
      kind: "slotId",
      value: "claude-fable-gone",
    });
  });

  it("assignSlotIds 保留 maxEffort 字段", () => {
    const routes = {
      slots: [
        {
          routeId: "claude-sonnet-5",
          tier: "sonnet" as const,
          providerId: "p",
          upstreamModel: "m",
          supports1m: false,
          maxEffort: "xhigh" as const,
        },
      ],
      defaultTarget: { kind: "providerId" as const, value: "p" },
    };
    expect(assignSlotIds(routes).slots[0].maxEffort).toBe("xhigh");
  });
});

describe("groupSlotsByProvider / flattenProviderGroups", () => {
  const slot = (
    routeId: string,
    tier: "fable" | "opus" | "sonnet" | "haiku",
    providerId: string,
    upstreamModel: string,
  ) => ({ routeId, tier, providerId, upstreamModel });

  it("卡序 = 供应商在扁平列表里的首次出现顺序（槽位交错也不乱）", () => {
    const cards = groupSlotsByProvider([
      slot("a", "fable", "p-glm", "glm-5.3"),
      slot("b", "opus", "p-ds", "deepseek-flash"),
      slot("c", "opus", "p-glm", "glm-5.3-flash"),
    ]);
    expect(cards.map((card) => card.providerId)).toEqual(["p-glm", "p-ds"]);
    expect(Object.keys(cards[0].rows)).toEqual(["fable", "opus"]);
    expect(cards[1].rows.opus?.[0].upstreamModel).toBe("deepseek-flash");
  });

  it("同供应商同档位所有存量模型都保留", () => {
    const cards = groupSlotsByProvider([
      slot("keep", "opus", "p-glm", "glm-5.3"),
      slot("drop", "opus", "p-glm", "glm-5.3-flash"),
    ]);
    expect(cards).toHaveLength(1);
    expect(cards[0].rows.opus?.map(s => s.routeId)).toEqual(["keep", "drop"]);
  });

  it("空列表得空卡片数组", () => {
    expect(groupSlotsByProvider([])).toEqual([]);
  });

  it("展平按卡序 × 档位固定顺序重建（fable→opus→sonnet→haiku）", () => {
    const flat = flattenProviderGroups([
      { providerId: "p-ds", rows: { opus: [slot("x", "opus", "p-ds", "d1")] } },
      {
        providerId: "p-glm",
        rows: {
          haiku: [slot("h", "haiku", "p-glm", "g3")],
          fable: [slot("f", "fable", "p-glm", "g1")],
        },
      },
    ]);
    expect(flat.map((s) => [s.providerId, s.tier])).toEqual([
      ["p-ds", "opus"],
      ["p-glm", "fable"],
      ["p-glm", "haiku"],
    ]);
  });

  it("未映射的档位不产生槽位（映射几个就有几个）", () => {
    const flat = flattenProviderGroups([
      {
        providerId: "p-glm",
        rows: { fable: [slot("f", "fable", "p-glm", "g1")] },
      },
    ]);
    expect(flat).toHaveLength(1);
  });

  it("档位行序常量与卡片渲染一致", () => {
    expect(TIER_ROW_ORDER).toEqual(["fable", "opus", "sonnet", "haiku"]);
  });
});

describe("assignSlotIds · defaultModel 跟随", () => {
  const base = {
    defaultTarget: { kind: "providerId" as const, value: "p-glm" },
  };

  it("默认模型继续引用原槽位 ID", () => {
    const next = assignSlotIds({
      ...base,
      defaultModel: "claude-opus-deepseek",
      slots: [
        {
          routeId: "claude-fable-zhipu-glm",
          tier: "fable",
          providerId: "p-glm",
          upstreamModel: "glm-5.3",
        },
        {
          routeId: "claude-opus-deepseek",
          tier: "opus",
          providerId: "p-ds",
          upstreamModel: "deepseek-flash",
        },
      ],
    });
    expect(next.defaultModel).toBe("claude-opus-deepseek");
  });

  it("引用的槽位被删时置空（回落到排序首位）", () => {
    const next = assignSlotIds({
      ...base,
      defaultModel: "claude-fable-gone",
      slots: [
        {
          routeId: "claude-sonnet-1",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "a",
        },
      ],
    });
    expect(next.defaultModel).toBeUndefined();
  });

  it("未设置时保持未设置", () => {
    const next = assignSlotIds({
      ...base,
      slots: [
        {
          routeId: "claude-sonnet-1",
          tier: "sonnet",
          providerId: "p-ds",
          upstreamModel: "a",
        },
      ],
    });
    expect(next.defaultModel).toBeUndefined();
  });
});

describe("assignSlotIds aliasRules 跟随", () => {
  const base = {
    slots: [
      {
        routeId: "claude-sonnet-5",
        tier: "sonnet" as const,
        providerId: "p1",
        upstreamModel: "m1",
        supports1m: false,
      },
      {
        routeId: "claude-haiku-3",
        tier: "haiku" as const,
        providerId: "p1",
        upstreamModel: "m2",
        supports1m: false,
      },
    ],
    defaultTarget: { kind: "providerId" as const, value: "p1" },
  };

  it("插入新槽时别名仍引用原槽位身份", () => {
    const aliasRules: AggregateAliasRule[] = [
      { prefix: "claude-haiku", slotId: "claude-haiku-3" },
    ];
    const routes = { ...base, aliasRules };
    // 在最前插入一个 haiku 槽：新槽拿池首 claude-haiku-4-5，原 haiku-3 槽序号 2 溢出为 claude-haiku-2
    const inserted = {
      ...routes,
      slots: [
        {
          routeId: "",
          tier: "haiku" as const,
          providerId: "p1",
          upstreamModel: "m0",
          supports1m: false,
        },
        ...routes.slots,
      ],
    };
    const out = assignSlotIds(inserted);
    expect(out.slots[2].routeId).toBe("claude-haiku-3");
    expect(out.aliasRules?.[0]).toEqual({
      prefix: "claude-haiku",
      slotId: "claude-haiku-3",
    });
  });

  it("引用的槽已删时 slotId 清空、行保留", () => {
    const routes = {
      ...base,
      slots: base.slots.slice(0, 1), // 删掉 haiku 槽
      aliasRules: [{ prefix: "claude-haiku", slotId: "claude-haiku-3" }],
    };
    const out = assignSlotIds(routes);
    expect(out.aliasRules).toEqual([{ prefix: "claude-haiku", slotId: "" }]);
  });

  it("空 slotId 的规则不被 routeId 为空的新行认领", () => {
    const routes = {
      slots: [
        {
          routeId: "claude-sonnet-4",
          tier: "sonnet" as const,
          providerId: "p1",
          upstreamModel: "m1",
          supports1m: false,
        },
        {
          routeId: "",
          tier: "sonnet" as const,
          providerId: "p1",
          upstreamModel: "",
          supports1m: false,
        },
      ],
      defaultTarget: { kind: "providerId" as const, value: "p1" },
      aliasRules: [{ prefix: "claude-sonnet", slotId: "" }],
    };
    expect(assignSlotIds(routes).aliasRules).toEqual([
      { prefix: "claude-sonnet", slotId: "" },
    ]);
  });

  it("无 aliasRules 的旧数据往返后仍为 undefined", () => {
    expect(assignSlotIds(base).aliasRules).toBeUndefined();
  });
});


## Full source: src/utils/aggregateRoutes.compatibility.test.ts
import { describe, expect, it } from "vitest";
import {
  assignSlotIds,
  flattenProviderGroups,
  groupSlotsByProvider,
  migrateIncompatibleRouteIds,
} from "./aggregateRoutes";
import type { AggregateRoutes } from "@/types";

const initial: AggregateRoutes = {
  slots: [
    {
      routeId: "claude-sonnet-4-6",
      tier: "sonnet",
      providerId: "a",
      upstreamModel: "upstream-a",
      label: "A",
      maxEffort: "high",
      supports1m: true,
    },
    {
      routeId: "claude-sonnet-4-5",
      tier: "sonnet",
      providerId: "b",
      upstreamModel: "upstream-b",
      label: "B",
    },
  ],
  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
  defaultModel: "claude-sonnet-4-6",
  aliasRules: [{ prefix: "team", slotId: "claude-sonnet-4-6" }],
};

describe("aggregate compatibility contract", () => {
  it("explicit duplicate-ID migration removes a strength cap unsupported by the new ID", () => {
    const routes: AggregateRoutes = {
      slots: [
        { ...initial.slots[0], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
        { ...initial.slots[1], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
      ],
      defaultTarget: { kind: "providerId", value: "a" },
    };
    const migrated = migrateIncompatibleRouteIds(routes);
    expect(migrated.slots[0].maxEffort).toBe("xhigh");
    expect(migrated.slots[1].routeId).toBe("claude-sonnet-4-6");
    expect(migrated.slots[1].maxEffort).toBeUndefined();
  });
  it("allocation does not reuse a retired ID with different letter case", () => {
    const routes: AggregateRoutes = {
      slots: [{ ...initial.slots[0], routeId: "" }],
      defaultTarget: { kind: "providerId", value: "a" },
      retiredRouteIds: ["CLAUDE-SONNET-4-6"],
    };
    expect(assignSlotIds(routes).slots[0].routeId).not.toBe(
      "claude-sonnet-4-6",
    );
  });
  it("reordering preserves the old model ID, mapping, default and alias", () => {
    const next = assignSlotIds({
      ...initial,
      slots: [...initial.slots].reverse(),
    });
    expect(
      next.slots.find((s) => s.routeId === initial.slots[0].routeId),
    ).toEqual(initial.slots[0]);
    expect(next.defaultTarget).toEqual(initial.defaultTarget);
    expect(next.defaultModel).toBe(initial.defaultModel);
    expect(next.aliasRules).toEqual(initial.aliasRules);
  });

  it("inserting a new model does not steal an existing ID", () => {
    const next = assignSlotIds({
      ...initial,
      slots: [
        {
          ...initial.slots[0],
          routeId: "",
          providerId: "new",
          upstreamModel: "new-model",
        },
        ...initial.slots,
      ],
    });
    expect(next.slots.slice(1)).toEqual(initial.slots);
    expect(next.slots[0].routeId).not.toBe(initial.slots[0].routeId);
    expect(next.defaultModel).toBe(initial.defaultModel);
  });

  it("deleting then adding and reloading cannot recycle a retired model ID", () => {
    const deleted = assignSlotIds(
      {
        ...initial,
        slots: [initial.slots[1]],
        defaultTarget: { kind: "providerId", value: "b" },
      },
      initial,
    );
    const persisted = JSON.parse(JSON.stringify(deleted)) as AggregateRoutes;
    const added = assignSlotIds(
      {
        ...persisted,
        slots: [
          ...persisted.slots,
          { ...initial.slots[0], routeId: "", upstreamModel: "new-model" },
        ],
      },
      persisted,
    );
    expect(added.slots[0].routeId).toBe(initial.slots[1].routeId);
    expect(added.slots[1].routeId).not.toBe(initial.slots[0].routeId);
    expect(
      (added as AggregateRoutes & { retiredRouteIds?: string[] })
        .retiredRouteIds,
    ).toContain(initial.slots[0].routeId);
    expect(added.aliasRules?.[0].slotId).toBe("");
  });

  it("grouping and flattening retains every model in the same provider/tier", () => {
    const slots = initial.slots.map((s) => ({ ...s, providerId: "a" }));
    expect(flattenProviderGroups(groupSlotsByProvider(slots))).toEqual(slots);
  });
});


## Full source: src/components/providers/forms/AggregateProviderFields.tsx
import { useEffect, useMemo, useState } from "react";
import {
  ChevronDown,
  ChevronRight,
  Download,
  GripVertical,
  Loader2,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import type { CSSProperties, ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ImeSafeInput } from "@/components/ui/ime-safe-input";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ModelDropdown } from "./shared/ModelDropdown";
import type { FetchedModel } from "@/lib/api/model-fetch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useTranslation } from "react-i18next";
import type {
  AggregateAliasRule,
  AggregateMaxEffort,
  AggregateRouteSlot,
  AggregateRoutes,
  AggregateTier,
  DefaultTarget,
  Provider,
} from "@/types";
import {
  assignSlotIds,
  canSaveAggregateRoutes,
  flattenProviderGroups,
  groupSlotsByProvider,
  slotLabel,
  TIER_ROW_ORDER,
  type ProviderTierRows,
  needsRouteIdMigration,
  migrateIncompatibleRouteIds,
} from "@/utils/aggregateRoutes";
import {
  effortCapability,
  effortLevelsFor,
} from "@/utils/claudeDesktopCapability";

interface Props {
  value: AggregateRoutes;
  onChange: (next: AggregateRoutes) => void;
  /** 可作目标的常规供应商（不含聚合供应商自身与官方供应商，防止嵌套/无凭据目标） */
  candidates: Provider[];
  /** 该目标供应商已拉取到的模型列表；按供应商 id 缓存，同卡各档位共用 */
  modelsForProvider: (providerId: string) => FetchedModel[];
  /** 正在拉取的供应商 id；非 null 时所有拉取按钮进入 loading */
  fetchingProviderId: string | null;
  onFetchModels: (provider: Provider) => void;
}

/** 深拷贝卡片数组（行对象只读不改、整体替换，浅拷贝两层即可）。 */
const cloneCards = (cards: ProviderTierRows[]): ProviderTierRows[] =>
  cards.map((card) => ({
    providerId: card.providerId,
    rows: { ...card.rows },
  }));

const UNSET = "__unset__";

/** 卡片可拖拽包装：把手 props 通过 render-prop 交给卡头。 */
function SortableCard({
  id,
  children,
}: {
  id: string;
  children: (handle: ReactNode) => ReactNode;
}) {
  const { setNodeRef, attributes, listeners, transform, transition } =
    useSortable({ id });
  const style: CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };
  return (
    <div ref={setNodeRef} style={style}>
      {children(
        <button
          type="button"
          className="shrink-0 cursor-grab touch-none text-muted-foreground/60 hover:text-foreground"
          aria-label="drag"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </button>,
      )}
    </div>
  );
}

export function AggregateProviderFields({
  value,
  onChange,
  candidates,
  modelsForProvider,
  fetchingProviderId,
  onFetchModels,
}: Props) {
  const { t } = useTranslation();

  const [migrationPreview, setMigrationPreview] = useState<AggregateRoutes>();
  const [migrationBackup, setMigrationBackup] = useState(false);
  useEffect(() => {
    setMigrationPreview(undefined);
    setMigrationBackup(false);
  }, [value]);
  const downloadMigrationBackup = () => {
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "aggregate-routes-before-migration.json";
    link.click();
    URL.revokeObjectURL(url);
    setMigrationBackup(true);
  };

  // 显示名默认值要带上供应商名：同一个上游模型可能挂在两家供应商上，
  // 只写模型名仍分不清实际调用的是哪一家。
  const providerNameById = new Map(candidates.map((p) => [p.id, p.name]));
  const labelOf = (slot: AggregateRouteSlot) =>
    slotLabel(slot, providerNameById.get(slot.providerId));
  const nameOf = (id: string) => providerNameById.get(id) ?? id;

  // 编辑器按「供应商卡」渲染，存储仍是扁平 slots[]（分组是纯视图概念，
  // 后端与持久化零改动）。供应商被选了但还没映射任何档位时，slots 里没有
  // 它的痕迹，用 pendingProviders 记住这张空卡，否则它会在重渲染时消失。
  const [pendingProviders, setPendingProviders] = useState<string[]>([]);

  // 折叠状态：expandedIds 里的卡展开，其余（含新卡）默认折叠。
  // 用「展开集合」而非「折叠集合」：新增卡无需手动登记即默认折叠。
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  const grouped = useMemo(
    () => groupSlotsByProvider(value.slots),
    [value.slots],
  );
  const cards = useMemo(() => {
    const groupedIds = new Set(grouped.map((card) => card.providerId));
    const extras = pendingProviders
      .filter((id) => !groupedIds.has(id))
      .map((id): ProviderTierRows => ({ providerId: id, rows: {} }));
    return [...grouped, ...extras];
  }, [grouped, pendingProviders]);

  // 新行分配 ID；既有 ID 不因排序或编辑变化。
  // assignSlotIds 保留既有身份，并记录删除的 ID 防止重用，
  // 删除引用目标时默认目标保持原值，由保存校验要求重新选择；
  // 默认模型悬空置空回落排序首位。
  //
  // 先为新行分配 ID，再按每行的实际兼容阶梯校验上限；既有 ID 和有效上限不变。
  const commit = (next: AggregateRoutes) => {
    const assigned = assignSlotIds(next, value);
    return onChange({
      ...assigned,
      slots: assigned.slots.map((s) =>
        s.maxEffort && effortLevelsFor(s.routeId).includes(s.maxEffort)
          ? s
          : { ...s, maxEffort: undefined },
      ),
    });
  };

  /** 提交编辑后的卡片列表：有行的卡展平回 slots，空卡（选了供应商还没映射
   *  任何档位）存进 pendingProviders。 */
  const commitCards = (next: ProviderTierRows[]) => {
    const hasRows = (card: ProviderTierRows) =>
      TIER_ROW_ORDER.some((tier) => card.rows[tier]?.length);
    setPendingProviders(
      next.filter((card) => !hasRows(card)).map((c) => c.providerId),
    );
    commit({
      ...value,
      slots: flattenProviderGroups(next.filter(hasRows)),
    });
  };

  const setCardProvider = (cardIndex: number, providerId: string) => {
    const next = cloneCards(cards);
    const card = next[cardIndex];
    card.providerId = providerId;
    // 行内的槽位各自带着 providerId（扁平存储的冗余），换卡头时同步改写
    for (const tier of TIER_ROW_ORDER) {
      const slots = card.rows[tier];
      if (slots)
        card.rows[tier] = slots.map((slot) => ({ ...slot, providerId }));
    }
    commitCards(next);
  };

  const patchRow = (
    cardIndex: number,
    tier: AggregateTier,
    rowIndex: number,
    patch: Partial<AggregateRouteSlot>,
  ) => {
    const next = cloneCards(cards);
    const slots = next[cardIndex].rows[tier];
    if (!slots?.[rowIndex]) return;
    next[cardIndex].rows[tier] = slots.map((slot, i) =>
      i === rowIndex ? { ...slot, ...patch } : slot,
    );
    commitCards(next);
  };

  const removeRow = (
    cardIndex: number,
    tier: AggregateTier,
    rowIndex: number,
  ) => {
    const next = cloneCards(cards);
    const remaining = (next[cardIndex].rows[tier] ?? []).filter(
      (_, i) => i !== rowIndex,
    );
    if (remaining.length) next[cardIndex].rows[tier] = remaining;
    else delete next[cardIndex].rows[tier];
    commitCards(next);
  };

  /** 每个档位可以添加多个独立模型。 */
  const addRow = (cardIndex: number, tier: AggregateTier) => {
    const next = cloneCards(cards);
    next[cardIndex].rows[tier] = [
      ...(next[cardIndex].rows[tier] ?? []),
      {
        routeId: "",
        tier,
        providerId: next[cardIndex].providerId,
        upstreamModel: "",
        supports1m: false,
      },
    ];
    // 新行自动展开（用户要立刻填它）
    const cardId = next[cardIndex].providerId;
    setExpandedIds((prev) => new Set(prev).add(cardId));
    commitCards(next);
  };

  const removeCard = (cardIndex: number) =>
    commitCards(cards.filter((_, i) => i !== cardIndex));

  /** 别名规则改动不改变槽位身份；按实际 ID 校验有效上限。 */
  const patchAliasRule = (
    index: number,
    patch: Partial<AggregateAliasRule>,
  ) => {
    const next = [...(value.aliasRules ?? [])];
    next[index] = { ...next[index], ...patch };
    commit({ ...value, aliasRules: next });
  };
  const addAliasRule = () =>
    commit({
      ...value,
      aliasRules: [...(value.aliasRules ?? []), { prefix: "", slotId: "" }],
    });
  const removeAliasRule = (index: number) =>
    commit({
      ...value,
      aliasRules: (value.aliasRules ?? []).filter((_, i) => i !== index),
    });

  const addCard = () => {
    const used = new Set(cards.map((card) => card.providerId));
    const free = candidates.find((p) => !used.has(p.id));
    if (!free) return;
    setExpandedIds((prev) => new Set(prev).add(free.id)); // 新卡自动展开
    commitCards([...cards, { providerId: free.id, rows: {} }]);
  };

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const from = cards.findIndex((card) => card.providerId === active.id);
    const to = cards.findIndex((card) => card.providerId === over.id);
    if (from < 0 || to < 0) return;
    commitCards(arrayMove(cards, from, to));
  };

  /** 已映射（上游模型非空）的槽位——默认模型下拉与「生效默认」判定都只认它们。 */
  const mappedSlots = useMemo(
    () => value.slots.filter((slot) => slot.upstreamModel.trim() !== ""),
    [value.slots],
  );
  // 生效默认：显式设置且仍指向已映射槽 → 用它；否则排序首位
  const effectiveDefault =
    value.defaultModel &&
    mappedSlots.some((slot) => slot.routeId === value.defaultModel)
      ? value.defaultModel
      : (mappedSlots[0]?.routeId ?? "");

  const toggleCard = (id: string) =>
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });

  const allExpanded =
    cards.length > 0 && cards.every((card) => expandedIds.has(card.providerId));

  return (
    <section className="space-y-4">
      <header className="space-y-1">
        <h3 className="text-sm font-medium">{t("aggregate.title")}</h3>
        <p className="text-xs text-muted-foreground">{t("aggregate.hint")}</p>
      </header>

      {needsRouteIdMigration(value) && (
        <div className="space-y-2 rounded-md border p-3 text-xs">
          <p>
            存量路由 ID 不兼容或重复。普通编辑保留原
            ID；转换前请备份，旧会话可能需要重新选择模型。
          </p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              setMigrationPreview(migrateIncompatibleRouteIds(value));
              setMigrationBackup(false);
            }}
          >
            预览旧路由转换
          </Button>
          {migrationPreview && (
            <>
              <pre className="whitespace-pre-wrap">
                {value.slots
                  .map(
                    (slot, i) =>
                      `${slot.routeId} → ${migrationPreview.slots[i]?.routeId}；上限 ${slot.maxEffort ?? "不限制"} → ${migrationPreview.slots[i]?.maxEffort ?? "不限制"}`,
                  )
                  .join("\n")}
              </pre>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={downloadMigrationBackup}
              >
                下载路由备份
              </Button>
              <Button
                type="button"
                size="sm"
                disabled={!migrationBackup}
                onClick={() => {
                  onChange(migrationPreview);
                  setMigrationPreview(undefined);
                  setMigrationBackup(false);
                }}
              >
                确认转换路由 ID
              </Button>
            </>
          )}
        </div>
      )}

      {!canSaveAggregateRoutes(value) && (
        <p className="text-xs text-destructive">{t("aggregate.notSaveable")}</p>
      )}

      {/* 兜底目标与默认模型并排（v3）。兜底目标是必填的路由安全网；默认模型
          决定 Claude Desktop 新会话的起点（写 profile 时置顶到第一条）。 */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1">
          <Label className="text-xs">{t("aggregate.defaultTarget")}</Label>
          <Select
            value={
              value.defaultTarget.kind === "providerId"
                ? `provider:${value.defaultTarget.value}`
                : `slot:${value.defaultTarget.value}`
            }
            onValueChange={(v) => {
              const [kind, ...rest] = v.split(":");
              const target: DefaultTarget =
                kind === "provider"
                  ? { kind: "providerId", value: rest.join(":") }
                  : { kind: "slotId", value: rest.join(":") };
              onChange({ ...value, defaultTarget: target });
            }}
          >
            <SelectTrigger className="h-8">
              <SelectValue
                placeholder={t("aggregate.defaultTargetPlaceholder", {
                  defaultValue: "必选：未命中槽位的请求回落到这里",
                })}
              />
            </SelectTrigger>
            <SelectContent>
              {candidates.map((p) => (
                <SelectItem key={p.id} value={`provider:${p.id}`}>
                  {p.name}
                </SelectItem>
              ))}
              {value.slots.map((s, index) => (
                <SelectItem
                  key={s.routeId || `slot-${index}`}
                  value={`slot:${s.routeId}`}
                >
                  {labelOf(s)} ({s.routeId})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {t("aggregate.defaultTargetHint")}
          </p>
        </div>

        <div className="space-y-1">
          <Label className="text-xs">{t("aggregate.defaultModel")}</Label>
          <Select
            value={value.defaultModel ?? UNSET}
            onValueChange={(v) =>
              onChange({
                ...value,
                defaultModel: v === UNSET ? undefined : v,
              })
            }
          >
            <SelectTrigger className="h-8">
              <SelectValue
                placeholder={t("aggregate.defaultModelPlaceholder", {
                  defaultValue: "未设置：跟随排序首位",
                })}
              />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={UNSET}>
                {t("aggregate.defaultModelPlaceholder", {
                  defaultValue: "未设置：跟随排序首位",
                })}
              </SelectItem>
              {mappedSlots.map((slot) => (
                <SelectItem key={slot.routeId} value={slot.routeId}>
                  {labelOf(slot)} ({slot.routeId})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {t("aggregate.defaultModelHint", {
              defaultValue: "启动新会话时使用的模型；未设置时取排序第一条",
            })}
          </p>
        </div>
      </div>

      {/* 别名路由规则：槽位未命中时按前缀转投。按序先赢，运行时小写化匹配。 */}
      <div className="space-y-2 rounded-md border border-border-default p-3">
        <p
          className="text-xs text-muted-foreground"
          title={t("aggregate.aliasTip", {
            defaultValue:
              "前缀过宽（如 claude-）会吞掉所有未命中槽位的请求名，注意范围",
          })}
        >
          {t("aggregate.aliasRouting", {
            defaultValue: "别名路由（槽位未命中时按前缀转投，先匹配先赢）",
          })}
        </p>
        {(value.aliasRules ?? []).map((rule, index) => (
          <div key={index} className="flex items-center gap-2">
            <Input
              className="h-8 w-56 shrink-0"
              value={rule.prefix}
              placeholder={t("aggregate.aliasPrefixPlaceholder", {
                defaultValue: "如 claude-sonnet",
              })}
              title={t("aggregate.aliasPrefix", { defaultValue: "请求名前缀" })}
              onChange={(e) =>
                patchAliasRule(index, { prefix: e.target.value })
              }
            />
            <span className="text-xs text-muted-foreground">→</span>
            <Select
              value={rule.slotId || UNSET}
              onValueChange={(v) =>
                patchAliasRule(index, { slotId: v === UNSET ? "" : v })
              }
            >
              <SelectTrigger
                className="h-8 flex-1"
                aria-label={t("aggregate.aliasTarget", {
                  defaultValue: "目标槽位",
                })}
              >
                <SelectValue
                  placeholder={t("aggregate.aliasTargetPlaceholder", {
                    defaultValue: "选择槽位",
                  })}
                />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={UNSET}>
                  {t("aggregate.aliasTargetPlaceholder", {
                    defaultValue: "选择槽位",
                  })}
                </SelectItem>
                {value.slots.map((slot) => (
                  <SelectItem key={slot.routeId} value={slot.routeId}>
                    {labelOf(slot)} ({slot.routeId})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-7 w-6 shrink-0 text-muted-foreground hover:text-destructive"
              title={t("aggregate.removeAliasRule", {
                defaultValue: "删除该规则",
              })}
              onClick={() => removeAliasRule(index)}
            >
              <X className="h-3.5 w-3.5" />
            </Button>
          </div>
        ))}
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 gap-1 text-xs text-muted-foreground"
          onClick={addAliasRule}
        >
          <Plus className="h-3.5 w-3.5" />
          {t("aggregate.addAliasRule", { defaultValue: "添加规则" })}
        </Button>
      </div>

      {/* 全部展开 / 全部折叠（折叠状态不持久化，每次打开表单重置为全折叠） */}
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-xs"
          disabled={allExpanded}
          onClick={() =>
            setExpandedIds(new Set(cards.map((card) => card.providerId)))
          }
        >
          {t("aggregate.expandAll", { defaultValue: "全部展开" })}
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-7 px-2 text-xs"
          disabled={expandedIds.size === 0}
          onClick={() => setExpandedIds(new Set())}
        >
          {t("aggregate.collapseAll", { defaultValue: "全部折叠" })}
        </Button>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext
          items={cards.map((card) => card.providerId)}
          strategy={verticalListSortingStrategy}
        >
          <div className="space-y-3">
            {cards.map((card, cardIndex) => {
              const usedElsewhere = new Set(
                cards
                  .filter((_, i) => i !== cardIndex)
                  .map((c) => c.providerId),
              );
              const selectable = candidates.filter(
                (p) => !usedElsewhere.has(p.id),
              );
              const target = candidates.find((p) => p.id === card.providerId);
              const fetched = modelsForProvider(card.providerId);
              const mappedRows = TIER_ROW_ORDER.flatMap((tier) =>
                (card.rows[tier] ?? []).map((slot, rowIndex) => ({
                  tier,
                  slot,
                  rowIndex,
                })),
              );
              const availableTiers = TIER_ROW_ORDER;
              const expanded = expandedIds.has(card.providerId);
              // routeId 恒非空（每次 commit 都经 assignSlotIds 赋真 ID），无已映射
              // 槽位时 effectiveDefault 为 ""，恒不命中，无需再挡空值。
              const isDefaultCard = mappedRows.some(
                ({ slot }) => slot.routeId === effectiveDefault,
              );
              return (
                <SortableCard key={card.providerId} id={card.providerId}>
                  {(handle) => (
                    <div className="space-y-2 rounded-md border border-border-default p-3">
                      {/* 卡头：拖拽把手 + 供应商 + 拉模型 + 删卡 + 折叠开关。
                          模型列表按供应商拉一次，卡内各档位共用缓存。 */}
                      <div className="flex items-center gap-2">
                        {handle}
                        <Select
                          value={card.providerId}
                          onValueChange={(v) => setCardProvider(cardIndex, v)}
                        >
                          <SelectTrigger className="h-8 flex-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {selectable.map((p) => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name}
                              </SelectItem>
                            ))}
                            {/* 存量数据可能引用已被删除/被其他卡占用的供应商：
                                保底显示，避免选择器空白让用户误以为没配置 */}
                            {!selectable.some(
                              (p) => p.id === card.providerId,
                            ) && (
                              <SelectItem value={card.providerId}>
                                {nameOf(card.providerId)}
                              </SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                        {isDefaultCard && (
                          <Badge
                            variant="secondary"
                            className="shrink-0 text-[10px]"
                          >
                            {t("aggregate.defaultBadge", {
                              defaultValue: "默认",
                            })}
                          </Badge>
                        )}
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="h-8 shrink-0 gap-1"
                          disabled={!target || fetchingProviderId !== null}
                          onClick={() => target && onFetchModels(target)}
                        >
                          {fetchingProviderId === card.providerId ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Download className="h-3.5 w-3.5" />
                          )}
                          {t("providerForm.fetchModels", {
                            defaultValue: "获取模型列表",
                          })}
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 shrink-0"
                          onClick={() => removeCard(cardIndex)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                        <button
                          type="button"
                          className="shrink-0 text-muted-foreground hover:text-foreground"
                          aria-expanded={expanded}
                          onClick={() => toggleCard(card.providerId)}
                        >
                          {expanded ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </button>
                      </div>

                      {expanded ? (
                        <>
                          {/* 列头：紧贴供应商行（2026-09-23 用户确认的草图） */}
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <span className="w-14 shrink-0">
                              {t("aggregate.tier")}
                            </span>
                            <span className="w-16 shrink-0">
                              {t("aggregate.effortBadgeHeader")}
                            </span>
                            <span className="min-w-0 flex-1">
                              {t("aggregate.upstreamModel")}
                            </span>
                            <span className="min-w-0 flex-1">
                              {t("aggregate.displayName")}
                            </span>
                            <span className="w-24 shrink-0 text-right">
                              {t("aggregate.maxEffort")}
                            </span>
                            <span className="w-20 shrink-0 text-right">
                              {t("aggregate.supports1m")}
                            </span>
                            <span className="w-6 shrink-0" />
                          </div>

                          {/* 已映射档位的行（v3：增量添加，不再固定四行）。行尾 ×
                              删除该槽；行内不支持改档位（删了重加）。 */}
                          {mappedRows.map(({ tier, slot, rowIndex }) => {
                            const isEffectiveDefault =
                              slot.routeId === effectiveDefault;
                            const switchId = `agg-1m-${slot.routeId || `${cardIndex}-${tier}-${rowIndex}`}`;
                            return (
                              <div
                                key={slot.routeId || `${tier}-${rowIndex}`}
                                className="flex items-center gap-2"
                                // 槽位 ID 不占版面，悬停可查——排查代理日志里的
                                // request_model 时用得上
                                title={slot.routeId || undefined}
                              >
                                <span className="w-14 shrink-0 text-xs text-muted-foreground">
                                  {tier}
                                </span>
                                <EffortBadge routeId={slot.routeId} />
                                <div className="flex min-w-0 flex-1 gap-1">
                                  {/* 上游模型只改值，不再承担行的生死——删行走
                                    行尾 × 按钮（v3 语义）。 */}
                                  <Input
                                    className="h-8 min-w-0 flex-1"
                                    value={slot.upstreamModel}
                                    placeholder={t(
                                      "aggregate.upstreamModelPlaceholder",
                                      { defaultValue: "上游模型名" },
                                    )}
                                    onChange={(e) =>
                                      patchRow(cardIndex, tier, rowIndex, {
                                        upstreamModel: e.target.value,
                                      })
                                    }
                                  />
                                  {fetched.length > 0 && (
                                    <ModelDropdown
                                      models={fetched}
                                      onSelect={(id) =>
                                        patchRow(cardIndex, tier, rowIndex, {
                                          upstreamModel: id,
                                        })
                                      }
                                    />
                                  )}
                                </div>
                                <div className="relative min-w-0 flex-1">
                                  <ImeSafeInput
                                    className="h-8 w-full pr-14"
                                    placeholder={labelOf(slot)}
                                    value={slot.label ?? ""}
                                    // 留空则不落库；提交时由表单统一补成「供应商 · 上游模型」
                                    onValueChange={(v) =>
                                      patchRow(cardIndex, tier, rowIndex, {
                                        label: v.trim() ? v : undefined,
                                      })
                                    }
                                  />
                                  {isEffectiveDefault && (
                                    <span className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">
                                      {t("aggregate.defaultBadge", {
                                        defaultValue: "默认",
                                      })}
                                    </span>
                                  )}
                                </div>
                                <MaxEffortSelect
                                  routeId={slot.routeId}
                                  value={slot.maxEffort}
                                  onChange={(v) =>
                                    patchRow(cardIndex, tier, rowIndex, {
                                      maxEffort: v,
                                    })
                                  }
                                />
                                <div className="flex w-20 shrink-0 items-center justify-end gap-1.5">
                                  <Switch
                                    id={switchId}
                                    checked={Boolean(slot.supports1m)}
                                    onCheckedChange={(v) =>
                                      patchRow(cardIndex, tier, rowIndex, {
                                        supports1m: v,
                                      })
                                    }
                                  />
                                  <Label
                                    htmlFor={switchId}
                                    className="text-xs text-muted-foreground"
                                  >
                                    1M
                                  </Label>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-6 shrink-0 text-muted-foreground hover:text-destructive"
                                  title={t("aggregate.removeModel", {
                                    defaultValue: "删除该模型",
                                  })}
                                  onClick={() =>
                                    removeRow(cardIndex, tier, rowIndex)
                                  }
                                >
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            );
                          })}

                          {/* 新增模型：各档位允许多行，不覆盖既有模型 */}
                          {availableTiers.length > 0 && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 gap-1 text-xs text-muted-foreground"
                                >
                                  <Plus className="h-3.5 w-3.5" />
                                  {t("aggregate.addModel", {
                                    defaultValue: "新增模型",
                                  })}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="start">
                                {availableTiers.map((tier) => (
                                  <DropdownMenuItem
                                    key={tier}
                                    onClick={() => addRow(cardIndex, tier)}
                                  >
                                    {tier}
                                  </DropdownMenuItem>
                                ))}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </>
                      ) : (
                        /* 折叠态摘要：N 个模型 · M 强度 */
                        <p className="text-xs text-muted-foreground">
                          {t("aggregate.modelsSummaryLadder", {
                            count: mappedRows.length,
                            ladder: mappedRows.filter(
                              ({ slot }) =>
                                effortCapability(slot.routeId) === "ladder",
                            ).length,
                            defaultValue: "{{count}} 个模型 · {{ladder}} 强度",
                          })}
                        </p>
                      )}
                    </div>
                  )}
                </SortableCard>
              );
            })}
          </div>
        </SortableContext>
      </DndContext>

      <Button
        type="button"
        variant="outline"
        size="sm"
        className="h-8 gap-1.5"
        disabled={
          candidates.length > 0 &&
          new Set(cards.map((card) => card.providerId)).size >=
            candidates.length
        }
        onClick={addCard}
      >
        <Plus className="h-3.5 w-3.5" />
        {t("aggregate.addProvider")}
      </Button>
    </section>
  );
}

function EffortBadge({ routeId }: { routeId: string }) {
  const { t } = useTranslation();
  // 测试环境 i18n 是空资源：t() 必须带 defaultValue，否则返回键名本身、组件测试必挂
  const conf = {
    ladder: {
      key: "effortLadder",
      tipKey: "effortLadderTip",
      cls: "text-emerald-600 dark:text-emerald-400",
      text: "强度✓",
      tip: "完整思考强度阶梯（low…max），来自真模型 ID",
    },
    extended: {
      key: "effortToggle",
      tipKey: "effortToggleTip",
      cls: "text-muted-foreground",
      text: "思考开关",
      tip: "仅扩展思考开/关，无强度档位",
    },
    none: {
      key: "effortNone",
      tipKey: "effortNoneTip",
      cls: "text-muted-foreground/50",
      text: "✗",
      tip: "溢出 ID：Claude Desktop 不认识，无思考控件",
    },
  }[effortCapability(routeId)];
  return (
    <span
      className={`w-16 shrink-0 text-[10px] ${conf.cls}`}
      title={t(`aggregate.${conf.tipKey}`, { defaultValue: conf.tip })}
    >
      {t(`aggregate.${conf.key}`, { defaultValue: conf.text })}
    </span>
  );
}

/** 槽位行的思考强度上限下拉：只有完整阶梯 ID 有档位可选，其余禁用并给出原因。 */
function MaxEffortSelect({
  routeId,
  value,
  onChange,
}: {
  routeId: string;
  value: AggregateMaxEffort | undefined;
  onChange: (v: AggregateMaxEffort | undefined) => void;
}) {
  const { t } = useTranslation();
  const disabled = effortCapability(routeId) !== "ladder";
  return (
    <Select
      value={value ?? UNSET}
      disabled={disabled}
      onValueChange={(v) =>
        onChange(v === UNSET ? undefined : (v as AggregateMaxEffort))
      }
    >
      <SelectTrigger
        className="h-7 w-24 shrink-0 text-xs"
        title={
          disabled
            ? t("aggregate.effortNoneTip", {
                defaultValue: "溢出 ID：Claude Desktop 不认识，无思考控件",
              })
            : undefined
        }
      >
        <SelectValue
          placeholder={t("aggregate.maxEffort", { defaultValue: "上限" })}
        />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={UNSET}>
          {t("aggregate.maxEffortOff", { defaultValue: "不限制" })}
        </SelectItem>
        {effortLevelsFor(routeId).map((lv) => (
          <SelectItem key={lv} value={lv}>
            {lv}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}


## Full source: tests/components/AggregateProviderFields.aliasRules.test.tsx
import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

const value: AggregateRoutes = {
  slots: [
    {
      routeId: "claude-sonnet-4",
      tier: "sonnet",
      providerId: "p1",
      upstreamModel: "space-bunny-free",
      label: "OC · space-bunny-free",
      supports1m: false,
    },
  ],
  defaultTarget: { kind: "providerId", value: "p1" },
  aliasRules: [
    { prefix: "claude-sonnet", slotId: "claude-sonnet-4" },
    { prefix: "claude-", slotId: "" },
  ],
};

const props = {
  value,
  onChange: vi.fn(),
  candidates: [{ id: "p1", name: "OC" } as unknown as Provider],
  modelsForProvider: () => [],
  fetchingProviderId: null,
  onFetchModels: vi.fn(),
};

describe("别名路由区块", () => {
  it("渲染既有规则行（含悬空行），悬空行显示占位而非崩", () => {
    render(<AggregateProviderFields {...props} />);
    const prefixInput = screen.getByDisplayValue("claude-sonnet");
    expect(prefixInput).toBeInTheDocument();
    // 第二行 slotId 为空 → Select 显示占位（存在第二个 combobox 即可）
    expect(screen.getAllByRole("combobox").length).toBeGreaterThanOrEqual(2);
  });

  it("添加规则产生空行并回调 onChange", async () => {
    const user = userEvent.setup();
    render(<AggregateProviderFields {...props} />);
    await user.click(screen.getByRole("button", { name: "添加规则" }));
    expect(props.onChange).toHaveBeenCalled();
    const calls = props.onChange.mock.calls;
    const last = calls[calls.length - 1][0] as AggregateRoutes;
    expect(last.aliasRules).toHaveLength(3);
    expect(last.aliasRules?.[2]).toEqual({ prefix: "", slotId: "" });
  });

  it("删除规则行回调 onChange 且不残留", async () => {
    const user = userEvent.setup();
    render(<AggregateProviderFields {...props} />);
    const dels = screen.getAllByRole("button", { name: "删除该规则" });
    await user.click(dels[0]);
    const calls = props.onChange.mock.calls;
    const last = calls[calls.length - 1][0] as AggregateRoutes;
    expect(last.aliasRules).toEqual([{ prefix: "claude-", slotId: "" }]);
  });

  it("编辑前缀回调 onChange 且带上新前缀", async () => {
    const user = userEvent.setup();
    // 受控组件：值必须回灌，否则 clear 之后 React 把 DOM 重置回旧前缀，
    // 逐字输入会追加在旧值后面（真实使用中父组件正是回灌的）
    const Controlled = () => {
      const [current, setCurrent] = useState(value);
      return (
        <AggregateProviderFields
          {...props}
          value={current}
          onChange={(v) => {
            props.onChange(v);
            setCurrent(v);
          }}
        />
      );
    };
    render(<Controlled />);
    const input = screen.getByDisplayValue("claude-sonnet");
    await user.clear(input);
    await user.type(input, "claude-opus");
    const calls = props.onChange.mock.calls;
    const last = calls[calls.length - 1][0] as AggregateRoutes;
    // 修改前缀不改变既有槽位身份。
    expect(last.aliasRules?.[0]).toEqual({
      prefix: "claude-opus",
      slotId: "claude-sonnet-4",
    });
    // 第二条规则不受影响（patch 只改被编辑的行）
    expect(last.aliasRules?.[1]).toEqual({ prefix: "claude-", slotId: "" });
  });
});


## Full source: tests/components/AggregateProviderFields.effortBadge.test.tsx
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

function makeRoutes(
  pairs: Array<[string, "sonnet" | "haiku"]>,
): AggregateRoutes {
  return {
    slots: pairs.map(([routeId, tier], i) => ({
      routeId,
      tier,
      providerId: "p1",
      upstreamModel: `m${i}`,
      supports1m: false,
    })),
    defaultTarget: { kind: "providerId", value: "p1" },
  };
}

function renderEditor(value: AggregateRoutes) {
  return render(
    <AggregateProviderFields
      value={value}
      onChange={vi.fn()}
      candidates={[{ id: "p1", name: "P1" } as unknown as Provider]}
      modelsForProvider={() => []}
      fetchingProviderId={null}
      onFetchModels={vi.fn()}
    />,
  );
}

describe("聚合编辑器三态思考徽标", () => {
  it("展开卡后 ladder 槽显示 强度✓、溢出槽显示 ✗", async () => {
    const user = userEvent.setup();
    renderEditor(
      makeRoutes([
        ["claude-sonnet-5", "sonnet"],
        ["claude-haiku-3", "haiku"],
      ]),
    );
    await user.click(screen.getByRole("button", { expanded: false })); // 展开唯一的卡
    expect(screen.getByText("强度✓")).toBeInTheDocument();
    expect(screen.getByText("✗")).toBeInTheDocument();
  });

  it("extended 槽显示 思考开关", async () => {
    const user = userEvent.setup();
    renderEditor(makeRoutes([["claude-sonnet-4-5", "sonnet"]]));
    await user.click(screen.getByRole("button", { expanded: false }));
    expect(screen.getByText("思考开关")).toBeInTheDocument();
  });

  it("折叠摘要含强度计数", () => {
    renderEditor(
      makeRoutes([
        ["claude-sonnet-5", "sonnet"],
        ["claude-haiku-3", "haiku"],
      ]),
    );
    expect(screen.getByText("2 个模型 · 1 强度")).toBeInTheDocument();
  });
});

describe("聚合编辑器上限下拉", () => {
  it("上限下拉：ladder 槽可选，溢出槽禁用", async () => {
    // Radix Select 展开时会对首项调用 scrollIntoView（jsdom 未实现）
    Element.prototype.scrollIntoView = vi.fn();
    const user = userEvent.setup();
    const { container } = renderEditor(
      makeRoutes([
        ["claude-sonnet-5", "sonnet"],
        ["claude-haiku-3", "haiku"],
      ]),
    );
    await user.click(screen.getByRole("button", { expanded: false }));
    // 槽位行带 routeId title，行内只有上限下拉这一个 combobox，
    // 故按行取即得「该槽的上限触发器」（页面上还有兜底目标/默认模型/卡头下拉）
    const capTriggerOf = (routeId: string) =>
      within(
        container.querySelector(`[title="${routeId}"]`) as HTMLElement,
      ).getByRole("combobox");
    expect(capTriggerOf("claude-sonnet-5")).toBeEnabled();
    expect(capTriggerOf("claude-haiku-3")).toBeDisabled();

    // 选项来自该 ID 的实际阶梯（claude-sonnet-5 为 low…max 五档）
    await user.click(capTriggerOf("claude-sonnet-5"));
    const options = await screen.findAllByRole("option");
    expect(options.map((o) => o.textContent)).toEqual([
      "不限制",
      "low",
      "medium",
      "high",
      "xhigh",
      "max",
    ]);
  });

  it("普通提交保留每个既有模型的 ID 和有效强度上限", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    // 两张卡各一条 sonnet 行：重编号后 p1 取池内第 1 位（claude-sonnet-4-6，ladder），
    // p2 落到第 2 位（claude-sonnet-4-5，extended）。p2 的输入 ID claude-sonnet-5
    // 本身是 ladder——若在 assignSlotIds 之前判定，就会漏剥它的 maxEffort。
    render(
      <AggregateProviderFields
        value={{
          slots: [
            {
              routeId: "claude-sonnet-4-6",
              tier: "sonnet",
              providerId: "p1",
              upstreamModel: "m1",
              supports1m: false,
              maxEffort: "max",
            },
            {
              routeId: "claude-sonnet-5",
              tier: "sonnet",
              providerId: "p2",
              upstreamModel: "m2",
              supports1m: false,
              maxEffort: "xhigh",
            },
          ],
          defaultTarget: { kind: "providerId", value: "p1" },
        }}
        onChange={onChange}
        candidates={[
          { id: "p1", name: "P1" } as unknown as Provider,
          { id: "p2", name: "P2" } as unknown as Provider,
        ]}
        modelsForProvider={() => []}
        fetchingProviderId={null}
        onFetchModels={vi.fn()}
      />,
    );
    await user.click(screen.getAllByRole("button", { expanded: false })[0]);
    await user.click(screen.getAllByRole("switch")[0]); // 任意一次提交

    const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
    expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
      ["claude-sonnet-4-6", "max"], // ladder：保留
      ["claude-sonnet-5", "xhigh"], // ID 和能力均保留
    ]);
  });

  it("删除其他模型不收窄剩余模型的 ID 或强度上限", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    // 存量数据：p1 槽存的是 sonnet-5 + xhigh（删槽轮换前的旧编号）。提交必先
    // assignSlotIds 重编号——删掉 p2 的槽后，p1 槽按序号 1 重算为 claude-sonnet-4-6，
    // 同为「完整阶梯」但阶梯不含 xhigh。只判三态的实现会把它留成隐形残留
    // （Radix Select 值不在选项中只显 placeholder，用户看不见）。
    render(
      <AggregateProviderFields
        value={{
          slots: [
            {
              routeId: "claude-sonnet-5",
              tier: "sonnet",
              providerId: "p1",
              upstreamModel: "m1",
              supports1m: false,
              maxEffort: "xhigh",
            },
            {
              routeId: "claude-sonnet-4-5",
              tier: "sonnet",
              providerId: "p2",
              upstreamModel: "m2",
              supports1m: false,
            },
          ],
          defaultTarget: { kind: "providerId", value: "p1" },
        }}
        onChange={onChange}
        candidates={[
          { id: "p1", name: "P1" } as unknown as Provider,
          { id: "p2", name: "P2" } as unknown as Provider,
        ]}
        modelsForProvider={() => []}
        fetchingProviderId={null}
        onFetchModels={vi.fn()}
      />,
    );
    // 展开第二张卡，删掉它的槽 → 触发重编号
    await user.click(screen.getAllByRole("button", { expanded: false })[1]);
    await user.click(screen.getByTitle("删除该模型"));

    const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
    expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
      ["claude-sonnet-5", "xhigh"],
    ]);
  });
});


## Full source: tests/components/AggregateProviderFields.compatibility.test.tsx
import { useState } from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

const initial: AggregateRoutes = {
  slots: [
    {
      routeId: "claude-sonnet-4-6",
      tier: "sonnet",
      providerId: "a",
      upstreamModel: "upstream-a",
      label: "A",
    },
    {
      routeId: "claude-sonnet-4-5",
      tier: "sonnet",
      providerId: "a",
      upstreamModel: "upstream-b",
      label: "B",
    },
  ],
  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
  defaultModel: "claude-sonnet-4-6",
};

async function setup() {
  const change = vi.fn();
  function Controlled() {
    const [value, setValue] = useState(initial);
    return (
      <AggregateProviderFields
        value={value}
        onChange={(next) => {
          change(next);
          setValue(next);
        }}
        candidates={[
          { id: "a", name: "Synthetic A", settingsConfig: {} } as Provider,
        ]}
        modelsForProvider={() => []}
        fetchingProviderId={null}
        onFetchModels={() => {}}
      />
    );
  }
  render(<Controlled />);
  await userEvent
    .setup()
    .click(screen.getByRole("button", { name: "全部展开" }));
  return change;
}

describe("lossless multi-model editing", () => {
  it("shows both existing models in the same provider/tier", async () => {
    await setup();
    expect(screen.getByDisplayValue("upstream-a")).toBeInTheDocument();
    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
  });

  it("editing one model keeps the other and preserves identities", async () => {
    const change = await setup();
    fireEvent.change(screen.getByDisplayValue("upstream-a"), {
      target: { value: "changed-a" },
    });
    const next = change.mock.lastCall?.[0] as AggregateRoutes;
    expect(next.slots).toHaveLength(2);
    expect(next.slots[1]).toEqual(initial.slots[1]);
    expect(next.defaultModel).toBe(initial.defaultModel);
  });

  it("deleting one row leaves the second model available", async () => {
    const change = await setup();
    await userEvent
      .setup()
      .click(screen.getAllByRole("button", { name: "删除该模型" })[0]);
    const next = change.mock.lastCall?.[0] as AggregateRoutes;
    expect(next.slots).toEqual([initial.slots[1]]);
    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
  });
});


## Full source: tests/components/AggregateProviderFields.migration.test.tsx
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { expect, it, vi } from "vitest";
import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
import type { AggregateRoutes, Provider } from "@/types";

it("changing the source after a migration preview invalidates confirmation", async () => {
  const initial: AggregateRoutes = {
    slots: [
      {
        routeId: "claude-fable-glm",
        tier: "fable",
        providerId: "a",
        upstreamModel: "old",
      },
    ],
    defaultTarget: { kind: "providerId", value: "a" },
  };
  const common = {
    onChange: vi.fn(),
    candidates: [{ id: "a", name: "A", settingsConfig: {} } as Provider],
    modelsForProvider: () => [],
    fetchingProviderId: null,
    onFetchModels: () => {},
  };
  const { rerender } = render(
    <AggregateProviderFields {...common} value={initial} />,
  );
  await userEvent
    .setup()
    .click(screen.getByRole("button", { name: "预览旧路由转换" }));
  expect(
    screen.getByRole("button", { name: "确认转换路由 ID" }),
  ).toBeInTheDocument();
  rerender(
    <AggregateProviderFields
      {...common}
      value={{
        ...initial,
        slots: [{ ...initial.slots[0], upstreamModel: "new-edit" }],
      }}
    />,
  );
  expect(
    screen.queryByRole("button", { name: "确认转换路由 ID" }),
  ).not.toBeInTheDocument();
  expect(common.onChange).not.toHaveBeenCalled();
});

it("legacy invalid IDs change only after explicit preview, backup and confirmation", async () => {
  const oldId = "claude-fable-zhipu-glm";
  const routes: AggregateRoutes = {
    slots: [
      {
        routeId: oldId,
        tier: "fable",
        providerId: "a",
        upstreamModel: "model-a",
      },
    ],
    defaultTarget: { kind: "slotId", value: oldId },
    defaultModel: oldId,
    aliasRules: [{ prefix: "team", slotId: oldId }],
  };
  const change = vi.fn();
  render(
    <AggregateProviderFields
      value={routes}
      onChange={change}
      candidates={[{ id: "a", name: "A", settingsConfig: {} } as Provider]}
      modelsForProvider={() => []}
      fetchingProviderId={null}
      onFetchModels={() => {}}
    />,
  );
  const user = userEvent.setup();
  await user.click(screen.getByRole("button", { name: "预览旧路由转换" }));
  expect(change).not.toHaveBeenCalled();
  expect(
    screen.getByRole("button", { name: "确认转换路由 ID" }),
  ).toBeDisabled();
  class MockURL extends URL {
    static createObjectURL = vi.fn(() => "blob:synthetic");
    static revokeObjectURL = vi.fn();
  }
  vi.stubGlobal("URL", MockURL);
  const click = vi
    .spyOn(HTMLAnchorElement.prototype, "click")
    .mockImplementation(() => {});
  await user.click(screen.getByRole("button", { name: "下载路由备份" }));
  await user.click(screen.getByRole("button", { name: "确认转换路由 ID" }));
  const next = change.mock.lastCall?.[0] as AggregateRoutes;
  expect(next.slots[0].routeId).not.toBe(oldId);
  expect(next.slots[0].upstreamModel).toBe("model-a");
  expect(next.defaultTarget.value).toBe(next.slots[0].routeId);
  expect(next.defaultModel).toBe(next.slots[0].routeId);
  expect(next.aliasRules?.[0].slotId).toBe(next.slots[0].routeId);
  click.mockRestore();
  vi.unstubAllGlobals();
});


## Full source: src-tauri/src/aggregate_retirement_tests.rs
use super::*;

fn routes_json() -> serde_json::Value {
    serde_json::json!({
        "slots":[{"routeId":"claude-sonnet-4-5","tier":"sonnet","providerId":"synthetic-target","upstreamModel":"new-model"}],
        "defaultTarget":{"kind":"providerId","value":"synthetic-target"},
        "aliasRules":[{"prefix":"claude-sonnet","slotId":"claude-sonnet-4-5"}],
        "retiredRouteIds":["claude-sonnet-4-6"]
    })
}

#[test]
fn aggregate_retirement_survives_backend_serialization_roundtrip() {
    let routes: AggregateRoutes = serde_json::from_value(routes_json()).unwrap();
    let persisted = serde_json::to_value(routes).unwrap();
    assert_eq!(persisted["retiredRouteIds"], serde_json::json!(["claude-sonnet-4-6"]));
}

#[tokio::test]
async fn aggregate_retirement_old_requests_are_rejected_before_alias_or_fallback() {
    let db = crate::database::Database::memory().unwrap();
    let target = Provider::with_id("synthetic-target".into(), "Synthetic".into(), serde_json::json!({}), None);
    db.save_provider("claude-desktop", &target).unwrap();
    let mut provider = Provider::with_id("synthetic-aggregate".into(), "Synthetic Aggregate".into(), serde_json::json!({}), None);
    provider.meta = Some(crate::provider::ProviderMeta {
        aggregate_routes: Some(serde_json::from_value(routes_json()).unwrap()),
        ..Default::default()
    });
    for request in ["claude-sonnet-4-6", "claude-sonnet-4-6[1m]", "CLAUDE-SONNET-4-6"] {
        assert!(resolve_target(&db, "claude-desktop", &provider, request).is_err(),
            "Retired ID must not be redirected through the alias or default");
    }
}

#[test]
fn aggregate_retirement_legacy_absent_metadata_is_backward_compatible() {
    let mut legacy = routes_json();
    legacy.as_object_mut().unwrap().remove("retiredRouteIds");
    let parsed: AggregateRoutes = serde_json::from_value(legacy).unwrap();
    let persisted = serde_json::to_value(parsed).unwrap();
    assert!(persisted.get("retiredRouteIds").is_none());
}

#[tokio::test]
async fn aggregate_compatibility_padded_route_key_preserves_exact_mapping() {
    let db=crate::database::Database::memory().unwrap();
    db.save_provider("claude-desktop",&Provider::with_id("synthetic-target".into(),"Synthetic".into(),serde_json::json!({}),None)).unwrap();
    let mut json=routes_json();
    json["slots"][0]["routeId"]=serde_json::json!(" claude-sonnet-4-5 ");
    json["aliasRules"]=serde_json::json!([]);
    let mut provider=Provider::with_id("synthetic-aggregate".into(),"Synthetic".into(),serde_json::json!({}),None);
    provider.meta=Some(crate::provider::ProviderMeta{aggregate_routes:Some(serde_json::from_value(json).unwrap()),..Default::default()});
    let (_,upstream)=resolve_target(&db,"claude-desktop",&provider,"claude-sonnet-4-5").unwrap();
    assert_eq!(upstream.as_deref(),Some("new-model"));
}


## Rust AggregateRoutes schema
//! 聚合供应商：无端点无凭据的虚拟供应商，按模型把请求分流到其他供应商。

use crate::claude_desktop_config::{is_claude_safe_model_id, ResolvedModelRoute};
use crate::error::AppError;
use crate::provider::Provider;
use serde::{Deserialize, Serialize};

#[cfg(test)]
#[path = "aggregate_retirement_tests.rs"]
mod retirement_tests;

/// 可写入 profile 的 `maxEffort` 合法取值（与 Claude Desktop 的 low…max 阶梯一致）。
/// 白名单外丢弃——避免用户被 Desktop 静默压到最低档（cap at low，实测 2.9939.4.0）。
const AGGREGATE_MAX_EFFORTS: [&str; 5] = ["low", "medium", "high", "xhigh", "max"];

/// 档位：决定 Claude Desktop 选择器里那句描述文字来自目录中哪个角色。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum AggregateTier {
    Sonnet,
    Opus,
    Haiku,
    Fable,
}

/// 一个槽位 = 一个可被 Claude 选择的模型。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AggregateRouteSlot {
    /// 槽位 ID（**持久化**，是稳定的路由键）。
    /// 由前端在编辑时生成并随表单提交（UI 预览即提交值）；后端只校验它
    /// （非空、claude-safe、不重复），运行时不重新生成——这样重命名供应商
    /// 不会改变已生效的路由。
    pub route_id: String,
    pub tier: AggregateTier,
    /// 目标供应商 id（被引用者受删除保护）
    pub provider_id: String,
    /// 该供应商的上游模型名
    pub upstream_model: String,
    /// 选择器显示名，如 "智谱 GLM-5.3"；缺省用上游模型名
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub label: Option<String>,
    /// 勾选后该模型在选择器里会多出一行 "1M context window"
    #[serde(default)]
    pub supports_1m: bool,
    /// 思考强度上限（camelCase: maxEffort）。仅完整阶梯 ID 有意义。
    #[serde(default)]
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_effort: Option<String>,
}

/// 别名路由规则：请求名未命中任何槽位时，按前缀（大小写不敏感）转投目标槽位。
/// 按序先匹配先赢；空前缀/悬空槽位静默跳过（可选优化项失效，非配置性错误）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AggregateAliasRule {
    pub prefix: String,
    pub slot_id: String,
}

/// 未命中路由时的兜底目标。按槽位 ID 或供应商 id 引用（不用下标——下标会随增删重排失效）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", tag = "kind", content = "value")]
pub enum DefaultTarget {
    SlotId(String),
    ProviderId(String),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AggregateRoutes {
    pub slots: Vec<AggregateRouteSlot>,
    pub default_target: DefaultTarget,
    /// 默认模型（槽位 routeId）：写 profile 时置顶到 inferenceModels 首位
    /// —— Claude Desktop 认第一条为默认模型、启动新会话从它起步。
    /// None（含旧数据，serde default）= 跟随排序首位，行为同 v3 之前。
    #[serde(default)]
    pub default_model: Option<String>,
    /// 别名规则：槽位未命中时按序做前缀匹配（见 resolve_target）。旧数据无此键，
    /// serde default 反序列化为空列表 —— 行为等同未启用。
    #[serde(default)]
    pub alias_rules: Vec<AggregateAliasRule>,
    /// 删除的路由名称仍保留身份，禁止旧会话静默改指新模型。
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub retired_route_ids: Vec<String>,
}



## Full Claude runtime resolver
pub fn resolve_target(
    db: &crate::database::Database,
    app_type: &str,
    aggregate: &Provider,
    request_model: &str,
) -> Result<(Provider, Option<String>), AppError> {
    let routes = routes_of(aggregate)?;

    let requested =
        crate::claude_desktop_config::strip_one_m_suffix_for_route_lookup(request_model);

    if routes.retired_route_ids.iter().any(|id| id.trim().eq_ignore_ascii_case(requested)) {
        return Err(AppError::localized(
            "aggregate.route_retired",
            "该聚合模型路由已删除，请重新选择模型",
            "This aggregate model route was removed; select a model again",
        ));
    }

    // 直接按持久化的槽位 ID 查表（ID 由前端编辑时生成并随表单提交，运行时不重新生成）
    for slot in &routes.slots {
        if slot.route_id.trim() == requested {
            let target = load_provider(db, app_type, &slot.provider_id)?;
            return Ok((target, Some(slot.upstream_model.clone())));
        }
    }

    // 别名层：槽位未命中时按序前缀匹配（小写化），命中且目标槽存在 → 视同命中该槽。
    // 悬空/空前缀静默跳过，不报错——别名是可选优化项，不是安全网。
    // 悬空（slot_id 非空但解析不到槽）记 info：这是用户在日志里唯一的自助线索
    // （症状是别名请求落到兜底）。半成品规则（slot_id 为空，用户正在编辑）不记，
    // 否则编辑期间的每次请求都会刷一行。
    let lowered = requested.to_lowercase();
    for rule in &routes.alias_rules {
        let prefix = rule.prefix.trim().to_lowercase();
        if prefix.is_empty() || !lowered.starts_with(&prefix) {
            continue;
        }
        let Some(slot) = routes.slots.iter().find(|s| s.route_id.trim() == rule.slot_id.trim()) else {
            if !rule.slot_id.is_empty() {
                log::info!(
                    "[aggregate] alias rule '{prefix}' -> dangling slot '{}', skipped",
                    rule.slot_id
                );
            }
            continue;
        };
        let target = load_provider(db, app_type, &slot.provider_id)?;
        return Ok((target, Some(slot.upstream_model.clone())));
    }

    // 未命中 → 默认目标
    let fallback_id = match &routes.default_target {
        DefaultTarget::ProviderId(id) => id.clone(),
        DefaultTarget::SlotId(slot_id) => routes
            .slots
            .iter()
            .find(|slot| slot.route_id.trim() == slot_id.trim())
            .map(|slot| slot.provider_id.clone())
            .ok_or_else(|| {
                AppError::localized(
                    "aggregate.default_target_slot_missing",
                    "聚合供应商的默认目标指向了不存在的槽位",
                    "Aggregate default target points to a missing slot",
                )
            })?,
    };
    let target = load_provider(db, app_type, &fallback_id)?;
    Ok((target, None))
}



## Claude route save validation
// 聚合供应商校验。槽位 ID 由前端在编辑时生成并随表单提交（后端只校验、不生成），
        // 因此这里只需保证收到的路由表自洽：至少一个槽位、目标与模型必填、禁自引用、
        // 槽位 ID 合法且唯一。
        if let Some(routes) = provider
            .meta
            .as_ref()
            .and_then(|meta| meta.aggregate_routes.as_ref())
        {
            if routes.slots.is_empty() {
                return Err(AppError::localized(
                    "aggregate.slots_empty",
                    "聚合供应商至少需要一个槽位",
                    "Aggregate provider requires at least one slot",
                ));
            }
            let mut seen: Vec<String> = Vec::new();
            for slot in &routes.slots {
                if slot.provider_id.trim().is_empty() || slot.upstream_model.trim().is_empty() {
                    return Err(AppError::localized(
                        "aggregate.slot_incomplete",
                        "槽位必须同时指定目标供应商与上游模型",
                        "Each slot must specify both a target provider and an upstream model",
                    ));
                }
                if slot.provider_id == provider.id {
                    return Err(AppError::localized(
                        "aggregate.self_reference",
                        "聚合供应商不能把自身作为目标",
                        "An aggregate provider cannot target itself",
                    ));
                }
                // 槽位 ID 由前端生成（预览即实际值），这里只做校验
                let route_id = slot.route_id.trim();
                if route_id.is_empty()
                    || !crate::claude_desktop_config::is_claude_safe_model_id(route_id)
                {
                    return Err(AppError::localized(
                        "aggregate.invalid_route_id",
                        "槽位 ID 不合法（须形如 claude-sonnet-1）；Claude Desktop 会整组拒收",
                        "Invalid slot id (expected e.g. claude-sonnet-1); Claude Desktop would reject the whole group",
                    ));
                }
                if seen.iter().any(|s| s == route_id) {
                    return Err(AppError::localized(
                        "aggregate.duplicate_route_id",
                        "槽位 ID 重复",
                        "Duplicate slot id",
                    ));
                }
                seen.push(route_id.to_string());
            }

            for retired in &routes.retired_route_ids {
                let id = retired.trim();
                if id.is_empty() || seen.iter().any(|active| active.eq_ignore_ascii_case(id)) {
                    return Err(AppError::localized(
                        "aggregate.retired_route_invalid",
                        "已删除的路由 ID 不得为空或与当前模型重复",
                        "Retired route IDs must be non-empty and must not overlap active models",
                    ));
                }
            }

            // 默认目标必填且必须可用：未命中槽位的请求（Claude Desktop 的内部调用，
            // 如会话标题/摘要，正是此类）会回落到它；若它缺失或指向不存在的槽位，
            // 运行时会硬失败，故保存时就拦截（设计 §8/§9）。
            match &routes.default_target {
                crate::aggregate::DefaultTarget::ProviderId(id) => {
                    if id.trim().is_empty() {
                        return Err(AppError::localized(
                            "aggregate.default_target_invalid",
                            "聚合供应商必须指定默认目标：未命中槽位的请求会回落到它",
                            "Aggregate provider must specify a default target: unmatched requests fall back to it",
                        ));
                    }
                }
                crate::aggregate::DefaultTarget::SlotId(id) => {
                    let id = id.trim();
                    if !seen.iter().any(|s| s == id) {
                        return Err(AppError::localized(
                            "aggregate.default_target_invalid",
                            "聚合供应商的默认目标缺失，或指向了不存在的槽位（可能因槽位改动而失效，请重新选择）",
                            "Aggregate default target is missing or points to a non-existent slot (it may have been invalidated by slot changes; please reselect)",
                        ));
                    }
                }
            }
        }

        

## Exact change diff: src/types.ts
--- before/src/types.ts
+++ after/src/types.ts
@@ -162,6 +162,8 @@
   defaultModel?: string;
   /** 别名路由规则：槽位未命中时按前缀（小写化、按序先赢）转投。缺省 = 无规则。 */
   aliasRules?: AggregateAliasRule[];
+  /** 已删除的路由 ID：跨保存保留，避免旧会话的名称被新模型复用。 */
+  retiredRouteIds?: string[];
 }
 
 // Codex 聚合路由（与上面的 Claude 侧表平行、形状互不兼容：独立 meta 键


## Exact change diff: src/utils/aggregateRoutes.ts
--- before/src/utils/aggregateRoutes.ts
+++ after/src/utils/aggregateRoutes.ts
@@ -4,6 +4,7 @@
   AggregateTier,
   Provider,
 } from "@/types";
+import { effortLevelsFor } from "./claudeDesktopCapability";
 
 /**
  * 每个档位的 **Claude Desktop 认得**的真模型 ID 池，按优先级排列。
@@ -97,6 +98,77 @@
   return Boolean(provider.meta?.aggregateRoutes);
 }
 
+/** 对齐同版本后端的 Claude-safe ID 判定；保存校验仍以后端为权威。 */
+function isCompatibleRouteId(id: string): boolean {
+  const value = id.trim().toLowerCase();
+  const vendor =
+    /ark-code|astron|command-r|deepseek|doubao|gemini|gemma|glm|gpt|grok|hermes|hy3|kimi|lfm|\bling\b|llama|longcat|mimo|minimax|mistral|mixtral|moonshot|nemotron|openai|phi-|qianfan|qwen|tc-code|\bunic\b|yi-|stepfun|step-3|seed-|bytedance|hunyuan|granite|amazon\.nova|nova-|devstral|ministral|ernie|codex|arcee|trinity|abab|phi\d|\bk2\.|\bm2\.|jamba|arctic|solar|mercury|zamba|kat-coder|\bds-|dpsk/;
+  return (
+    !value.includes("[1m]") &&
+    !vendor.test(value) &&
+    /^(?:anthropic\/)?claude-(?:sonnet|opus|haiku|fable)-.+$/.test(value)
+  );
+}
+
+export function needsRouteIdMigration(routes: AggregateRoutes): boolean {
+  const seen = new Set<string>();
+  return routes.slots.some((slot) => {
+    const id = slot.routeId.trim();
+    const invalid = !isCompatibleRouteId(id) || seen.has(id);
+    seen.add(id);
+    return invalid;
+  });
+}
+
+/** 仅供用户明确预览/确认迁移调用；普通编辑绝不自动转换旧 ID。 */
+export function migrateIncompatibleRouteIds(
+  routes: AggregateRoutes,
+): AggregateRoutes {
+  const seen = new Set<string>();
+  const slots = routes.slots.map((slot) => {
+    const id = slot.routeId.trim();
+    const replace = !isCompatibleRouteId(id) || seen.has(id);
+    seen.add(id);
+    return replace ? { ...slot, routeId: "" } : slot;
+  });
+  const assigned = assignSlotIds({ ...routes, slots }, routes);
+  const remap = new Map<string, string>();
+  routes.slots.forEach((slot, i) => {
+    if (slot.routeId && !remap.has(slot.routeId))
+      remap.set(slot.routeId, assigned.slots[i].routeId);
+  });
+  return {
+    ...assigned,
+    slots: assigned.slots.map((slot, i) =>
+      slot.routeId !== routes.slots[i].routeId &&
+      slot.maxEffort &&
+      !effortLevelsFor(slot.routeId).includes(slot.maxEffort)
+        ? { ...slot, maxEffort: undefined }
+        : slot,
+    ),
+    defaultTarget:
+      routes.defaultTarget.kind === "slotId"
+        ? {
+            kind: "slotId",
+            value:
+              remap.get(routes.defaultTarget.value) ??
+              routes.defaultTarget.value,
+          }
+        : routes.defaultTarget,
+    defaultModel: routes.defaultModel
+      ? remap.get(routes.defaultModel)
+      : undefined,
+    ...(routes.aliasRules
+      ? {
+          aliasRules: routes.aliasRules.map((rule) => ({
+            ...rule,
+            slotId: remap.get(rule.slotId) ?? "",
+          })),
+        }
+      : {}),
+  };
+}
+
 /** 由槽位派生标签（选择器显示名）：显式填写优先，否则「供应商 · 上游模型」。
  *
  *  未填写时**必须**给出非空默认值——空值会让 profile 省略 `labelOverride`，
@@ -122,7 +194,13 @@
   routes: AggregateRoutes | undefined | null,
 ): boolean {
   return Boolean(
-    routes && routes.slots.length > 0 && routes.defaultTarget?.value.trim(),
+    routes &&
+      routes.slots.length > 0 &&
+      routes.defaultTarget?.value.trim() &&
+      (routes.defaultTarget.kind !== "slotId" ||
+        routes.slots.some(
+          (s) => s.routeId.trim() === routes.defaultTarget.value.trim(),
+        )),
   );
 }
 
@@ -140,13 +218,12 @@
 /** 供应商卡的视图形状：一家供应商 + 各档位已映射的槽位（未映射的档位无键）。 */
 export interface ProviderTierRows {
   providerId: string;
-  rows: Partial<Record<AggregateTier, AggregateRouteSlot>>;
+  rows: Partial<Record<AggregateTier, AggregateRouteSlot[]>>;
 }
 
 /**
  * 扁平槽位按供应商分组（编辑器渲染用）。卡序 = 供应商在列表里的首次出现顺序。
- * 同供应商同档位的存量重复取首个——新的固定档位行 UI 造不出这种重复，此处仅
- * 归一旧数据，编辑后保存即消失。
+ * 同供应商同档位可以有多个模型，按原出现顺序完整保留。
  */
 export function groupSlotsByProvider(
   slots: AggregateRouteSlot[],
@@ -160,9 +237,7 @@
       byProvider.set(slot.providerId, card);
       cards.push(card);
     }
-    if (!card.rows[slot.tier]) {
-      card.rows[slot.tier] = slot;
-    }
+    (card.rows[slot.tier] ??= []).push(slot);
   }
   return cards;
 }
@@ -174,71 +249,55 @@
   return cards.flatMap((card) => {
     const rows: AggregateRouteSlot[] = [];
     for (const tier of TIER_ROW_ORDER) {
-      const slot = card.rows[tier];
-      if (slot) rows.push(slot);
+      rows.push(...(card.rows[tier] ?? []));
     }
     return rows;
   });
 }
 
-/** 为所有槽位重新生成 routeId（按档位分别编号），并让默认目标、默认模型、别名规则按位置跟随。
- *
- *  在槽位增删、档位变更后调用，也可用于**迁移存量 ID**（旧方案含供应商名，
- *  会被 Claude Desktop 整组拒绝）。默认目标/默认模型若引用的是槽位 ID：以它在
- *  **本表内的位置**取新 ID；引用的槽位已被删除（旧 ID 不在本表里）时，默认目标
- *  保持原值（交由保存校验拦截，绝不静默改指到另一个槽位），默认模型置空
- *  （只影响启动默认、回落到排序首位，无需拦截），别名规则的 slotId 置空串
- *  （规则行保留，运行时按悬空跳过——别名是可选优化项，不是安全网）。 */
-export function assignSlotIds(routes: AggregateRoutes): AggregateRoutes {
-  const ordinalByTier = new Map<AggregateTier, number>();
-  const taken = new Set<string>();
-  const ids = routes.slots.map((slot) => {
-    const ordinal = (ordinalByTier.get(slot.tier) ?? 0) + 1;
-    ordinalByTier.set(slot.tier, ordinal);
-    const id = slotId(slot.tier, ordinal, taken);
-    taken.add(id);
-    return id;
-  });
-
-  const slots = routes.slots.map((slot, index) => ({
-    ...slot,
-    routeId: ids[index],
+/** 只给新槽位分配 ID；既有身份不随编辑或排序改变。删除记录跨保存保留。 */
+export function assignSlotIds(
+  routes: AggregateRoutes,
+  previous?: AggregateRoutes,
+): AggregateRoutes {
+  const activeIds = new Set(routes.slots.map((s) => s.routeId).filter(Boolean));
+  const retired = new Set([
+    ...(previous?.retiredRouteIds ?? []),
+    ...(routes.retiredRouteIds ?? []),
+  ]);
+  for (const slot of previous?.slots ?? []) {
+    if (slot.routeId && !activeIds.has(slot.routeId)) retired.add(slot.routeId);
+  }
+  const canonical = (id: string) => id.trim().toLowerCase();
+  const taken = new Set([...activeIds, ...retired].map(canonical));
+  // 悬空引用也不得被一条新行悄悄认领；默认目标留给保存校验要求重新选择。
+  if (routes.defaultTarget.kind === "slotId" && routes.defaultTarget.value)
+    taken.add(canonical(routes.defaultTarget.value));
+  if (routes.defaultModel) taken.add(canonical(routes.defaultModel));
+  for (const rule of routes.aliasRules ?? [])
+    if (rule.slotId) taken.add(canonical(rule.slotId));
+  const slots = routes.slots.map((slot) => {
+    if (slot.routeId) return { ...slot };
+    let ordinal = 1;
+    let id = slotId(slot.tier, ordinal, taken);
+    while (taken.has(canonical(id))) id = slotId(slot.tier, ++ordinal, taken);
+    taken.add(canonical(id));
+    return { ...slot, routeId: id };
+  });
+  const live = new Set(slots.map((s) => s.routeId.trim()));
+  const defaultModel =
+    routes.defaultModel && live.has(routes.defaultModel.trim())
+      ? routes.defaultModel
+      : undefined;
+  const aliasRules = routes.aliasRules?.map((rule) => ({
+    ...rule,
+    slotId: rule.slotId && live.has(rule.slotId.trim()) ? rule.slotId : "",
   }));
-
-  let defaultTarget = routes.defaultTarget;
-  if (defaultTarget.kind === "slotId") {
-    const index = routes.slots.findIndex(
-      (slot) => slot.routeId === defaultTarget.value,
-    );
-    if (index >= 0) {
-      defaultTarget = { kind: "slotId", value: ids[index] };
-    }
-  }
-
-  let defaultModel = routes.defaultModel;
-  if (defaultModel) {
-    const index = routes.slots.findIndex(
-      (slot) => slot.routeId === defaultModel,
-    );
-    defaultModel = index >= 0 ? ids[index] : undefined;
-  }
-
-  const aliasRules = routes.aliasRules?.map((rule) => {
-    // 空 slotId = 用户尚未选定目标（或已被清空），不得被 addRow 造出的
-    // routeId:"" 新行认领 —— 否则半成品规则会静默绑到无关槽位。
-    const index = rule.slotId
-      ? routes.slots.findIndex((slot) => slot.routeId === rule.slotId)
-      : -1;
-    return index >= 0
-      ? { ...rule, slotId: ids[index] }
-      : { ...rule, slotId: "" };
-  });
-
   return {
     ...routes,
     slots,
-    defaultTarget,
     defaultModel,
     ...(aliasRules ? { aliasRules } : {}),
+    ...(retired.size ? { retiredRouteIds: [...retired] } : {}),
   };
 }


## Exact change diff: src/utils/aggregateRoutes.test.ts
--- before/src/utils/aggregateRoutes.test.ts
+++ after/src/utils/aggregateRoutes.test.ts
@@ -212,7 +212,7 @@
     ]);
   });
 
-  it("档位变化会改变 ID", () => {
+  it("编辑档位元数据不隐式改变已有 ID", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -224,10 +224,10 @@
         },
       ],
     });
-    expect(next.slots[0].routeId).toBe("claude-opus-4-8");
-  });
-
-  it("重算所有槽位，旧的 routeId 不会残留", () => {
+    expect(next.slots[0].routeId).toBe("claude-sonnet-4-6");
+  });
+
+  it("重复存量 ID 不被隐式迁移，仍由后端保存校验拒绝", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -246,12 +246,12 @@
       ],
     });
     expect(next.slots.map((s) => s.routeId)).toEqual([
-      "claude-opus-4-8",
-      "claude-sonnet-4-6",
-    ]);
-  });
-
-  it("上一版序号方案（claude-opus-1）的存量 ID 会被迁移成池内 ID", () => {
+      "claude-sonnet-stale",
+      "claude-sonnet-stale",
+    ]);
+  });
+
+  it("上一版合法序号 ID 保留而不改变旧会话身份", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -270,12 +270,12 @@
       ],
     });
     expect(next.slots.map((s) => s.routeId)).toEqual([
-      "claude-opus-4-8",
-      "claude-opus-4-7",
-    ]);
-  });
-
-  it("旧方案（含供应商名）的存量 ID 会被迁移掉", () => {
+      "claude-opus-1",
+      "claude-opus-2",
+    ]);
+  });
+
+  it("不兼容存量 ID 不在普通编辑中静默迁移", () => {
     const next = assignSlotIds({
       ...base,
       slots: [
@@ -287,10 +287,10 @@
         },
       ],
     });
-    expect(next.slots[0].routeId).toBe("claude-fable-1");
-  });
-
-  it("默认目标引用槽位 ID 时，按位置跟随重编号", () => {
+    expect(next.slots[0].routeId).toBe("claude-fable-zhipu-glm");
+  });
+
+  it("默认目标继续引用原槽位身份", () => {
     const next = assignSlotIds({
       defaultTarget: { kind: "slotId", value: "claude-fable-zhipu-glm" },
       slots: [
@@ -310,7 +310,7 @@
     });
     expect(next.defaultTarget).toEqual({
       kind: "slotId",
-      value: "claude-fable-1",
+      value: "claude-fable-zhipu-glm",
     });
   });
 
@@ -366,16 +366,16 @@
     ]);
     expect(cards.map((card) => card.providerId)).toEqual(["p-glm", "p-ds"]);
     expect(Object.keys(cards[0].rows)).toEqual(["fable", "opus"]);
-    expect(cards[1].rows.opus?.upstreamModel).toBe("deepseek-flash");
-  });
-
-  it("同供应商同档位的存量重复取首个（新 UI 固定档位行造不出重复）", () => {
+    expect(cards[1].rows.opus?.[0].upstreamModel).toBe("deepseek-flash");
+  });
+
+  it("同供应商同档位所有存量模型都保留", () => {
     const cards = groupSlotsByProvider([
       slot("keep", "opus", "p-glm", "glm-5.3"),
       slot("drop", "opus", "p-glm", "glm-5.3-flash"),
     ]);
     expect(cards).toHaveLength(1);
-    expect(cards[0].rows.opus?.routeId).toBe("keep");
+    expect(cards[0].rows.opus?.map(s => s.routeId)).toEqual(["keep", "drop"]);
   });
 
   it("空列表得空卡片数组", () => {
@@ -384,12 +384,12 @@
 
   it("展平按卡序 × 档位固定顺序重建（fable→opus→sonnet→haiku）", () => {
     const flat = flattenProviderGroups([
-      { providerId: "p-ds", rows: { opus: slot("x", "opus", "p-ds", "d1") } },
+      { providerId: "p-ds", rows: { opus: [slot("x", "opus", "p-ds", "d1")] } },
       {
         providerId: "p-glm",
         rows: {
-          haiku: slot("h", "haiku", "p-glm", "g3"),
-          fable: slot("f", "fable", "p-glm", "g1"),
+          haiku: [slot("h", "haiku", "p-glm", "g3")],
+          fable: [slot("f", "fable", "p-glm", "g1")],
         },
       },
     ]);
@@ -404,7 +404,7 @@
     const flat = flattenProviderGroups([
       {
         providerId: "p-glm",
-        rows: { fable: slot("f", "fable", "p-glm", "g1") },
+        rows: { fable: [slot("f", "fable", "p-glm", "g1")] },
       },
     ]);
     expect(flat).toHaveLength(1);
@@ -420,7 +420,7 @@
     defaultTarget: { kind: "providerId" as const, value: "p-glm" },
   };
 
-  it("引用的槽位重编号后按位置跟随", () => {
+  it("默认模型继续引用原槽位 ID", () => {
     const next = assignSlotIds({
       ...base,
       defaultModel: "claude-opus-deepseek",
@@ -439,7 +439,7 @@
         },
       ],
     });
-    expect(next.defaultModel).toBe("claude-opus-4-8");
+    expect(next.defaultModel).toBe("claude-opus-deepseek");
   });
 
   it("引用的槽位被删时置空（回落到排序首位）", () => {
@@ -495,7 +495,7 @@
     defaultTarget: { kind: "providerId" as const, value: "p1" },
   };
 
-  it("引用的槽被重编号时规则跟随到新 ID", () => {
+  it("插入新槽时别名仍引用原槽位身份", () => {
     const aliasRules: AggregateAliasRule[] = [
       { prefix: "claude-haiku", slotId: "claude-haiku-3" },
     ];
@@ -515,10 +515,10 @@
       ],
     };
     const out = assignSlotIds(inserted);
-    expect(out.slots[2].routeId).toBe("claude-haiku-2");
+    expect(out.slots[2].routeId).toBe("claude-haiku-3");
     expect(out.aliasRules?.[0]).toEqual({
       prefix: "claude-haiku",
-      slotId: "claude-haiku-2",
+      slotId: "claude-haiku-3",
     });
   });
 


## Exact change diff: src/utils/aggregateRoutes.compatibility.test.ts
--- before/src/utils/aggregateRoutes.compatibility.test.ts
+++ after/src/utils/aggregateRoutes.compatibility.test.ts
@@ -0,0 +1,122 @@
+import { describe, expect, it } from "vitest";
+import {
+  assignSlotIds,
+  flattenProviderGroups,
+  groupSlotsByProvider,
+  migrateIncompatibleRouteIds,
+} from "./aggregateRoutes";
+import type { AggregateRoutes } from "@/types";
+
+const initial: AggregateRoutes = {
+  slots: [
+    {
+      routeId: "claude-sonnet-4-6",
+      tier: "sonnet",
+      providerId: "a",
+      upstreamModel: "upstream-a",
+      label: "A",
+      maxEffort: "high",
+      supports1m: true,
+    },
+    {
+      routeId: "claude-sonnet-4-5",
+      tier: "sonnet",
+      providerId: "b",
+      upstreamModel: "upstream-b",
+      label: "B",
+    },
+  ],
+  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
+  defaultModel: "claude-sonnet-4-6",
+  aliasRules: [{ prefix: "team", slotId: "claude-sonnet-4-6" }],
+};
+
+describe("aggregate compatibility contract", () => {
+  it("explicit duplicate-ID migration removes a strength cap unsupported by the new ID", () => {
+    const routes: AggregateRoutes = {
+      slots: [
+        { ...initial.slots[0], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
+        { ...initial.slots[1], routeId: "claude-sonnet-5", maxEffort: "xhigh" },
+      ],
+      defaultTarget: { kind: "providerId", value: "a" },
+    };
+    const migrated = migrateIncompatibleRouteIds(routes);
+    expect(migrated.slots[0].maxEffort).toBe("xhigh");
+    expect(migrated.slots[1].routeId).toBe("claude-sonnet-4-6");
+    expect(migrated.slots[1].maxEffort).toBeUndefined();
+  });
+  it("allocation does not reuse a retired ID with different letter case", () => {
+    const routes: AggregateRoutes = {
+      slots: [{ ...initial.slots[0], routeId: "" }],
+      defaultTarget: { kind: "providerId", value: "a" },
+      retiredRouteIds: ["CLAUDE-SONNET-4-6"],
+    };
+    expect(assignSlotIds(routes).slots[0].routeId).not.toBe(
+      "claude-sonnet-4-6",
+    );
+  });
+  it("reordering preserves the old model ID, mapping, default and alias", () => {
+    const next = assignSlotIds({
+      ...initial,
+      slots: [...initial.slots].reverse(),
+    });
+    expect(
+      next.slots.find((s) => s.routeId === initial.slots[0].routeId),
+    ).toEqual(initial.slots[0]);
+    expect(next.defaultTarget).toEqual(initial.defaultTarget);
+    expect(next.defaultModel).toBe(initial.defaultModel);
+    expect(next.aliasRules).toEqual(initial.aliasRules);
+  });
+
+  it("inserting a new model does not steal an existing ID", () => {
+    const next = assignSlotIds({
+      ...initial,
+      slots: [
+        {
+          ...initial.slots[0],
+          routeId: "",
+          providerId: "new",
+          upstreamModel: "new-model",
+        },
+        ...initial.slots,
+      ],
+    });
+    expect(next.slots.slice(1)).toEqual(initial.slots);
+    expect(next.slots[0].routeId).not.toBe(initial.slots[0].routeId);
+    expect(next.defaultModel).toBe(initial.defaultModel);
+  });
+
+  it("deleting then adding and reloading cannot recycle a retired model ID", () => {
+    const deleted = assignSlotIds(
+      {
+        ...initial,
+        slots: [initial.slots[1]],
+        defaultTarget: { kind: "providerId", value: "b" },
+      },
+      initial,
+    );
+    const persisted = JSON.parse(JSON.stringify(deleted)) as AggregateRoutes;
+    const added = assignSlotIds(
+      {
+        ...persisted,
+        slots: [
+          ...persisted.slots,
+          { ...initial.slots[0], routeId: "", upstreamModel: "new-model" },
+        ],
+      },
+      persisted,
+    );
+    expect(added.slots[0].routeId).toBe(initial.slots[1].routeId);
+    expect(added.slots[1].routeId).not.toBe(initial.slots[0].routeId);
+    expect(
+      (added as AggregateRoutes & { retiredRouteIds?: string[] })
+        .retiredRouteIds,
+    ).toContain(initial.slots[0].routeId);
+    expect(added.aliasRules?.[0].slotId).toBe("");
+  });
+
+  it("grouping and flattening retains every model in the same provider/tier", () => {
+    const slots = initial.slots.map((s) => ({ ...s, providerId: "a" }));
+    expect(flattenProviderGroups(groupSlotsByProvider(slots))).toEqual(slots);
+  });
+});


## Exact change diff: src/components/providers/forms/AggregateProviderFields.tsx
--- before/src/components/providers/forms/AggregateProviderFields.tsx
+++ after/src/components/providers/forms/AggregateProviderFields.tsx
@@ -1,4 +1,4 @@
-import { useMemo, useState } from "react";
+import { useEffect, useMemo, useState } from "react";
 import {
   ChevronDown,
   ChevronRight,
@@ -66,6 +66,8 @@
   slotLabel,
   TIER_ROW_ORDER,
   type ProviderTierRows,
+  needsRouteIdMigration,
+  migrateIncompatibleRouteIds,
 } from "@/utils/aggregateRoutes";
 import {
   effortCapability,
@@ -134,6 +136,24 @@
 }: Props) {
   const { t } = useTranslation();
 
+  const [migrationPreview, setMigrationPreview] = useState<AggregateRoutes>();
+  const [migrationBackup, setMigrationBackup] = useState(false);
+  useEffect(() => {
+    setMigrationPreview(undefined);
+    setMigrationBackup(false);
+  }, [value]);
+  const downloadMigrationBackup = () => {
+    const url = URL.createObjectURL(
+      new Blob([JSON.stringify(value, null, 2)], { type: "application/json" }),
+    );
+    const link = document.createElement("a");
+    link.href = url;
+    link.download = "aggregate-routes-before-migration.json";
+    link.click();
+    URL.revokeObjectURL(url);
+    setMigrationBackup(true);
+  };
+
   // 显示名默认值要带上供应商名：同一个上游模型可能挂在两家供应商上，
   // 只写模型名仍分不清实际调用的是哪一家。
   const providerNameById = new Map(candidates.map((p) => [p.id, p.name]));
@@ -162,16 +182,14 @@
     return [...grouped, ...extras];
   }, [grouped, pendingProviders]);
 
-  // 每次变更都重算所有槽位 ID：保证「预览 = 实际提交值」。
-  // assignSlotIds 会按档位从零重编号，并让默认目标/默认模型按位置跟随，
-  // 故增删槽位后引用不会悬空（默认目标悬空保持原值交由保存校验拦截；
-  // 默认模型悬空置空回落排序首位）。
+  // 新行分配 ID；既有 ID 不因排序或编辑变化。
+  // assignSlotIds 保留既有身份，并记录删除的 ID 防止重用，
+  // 删除引用目标时默认目标保持原值，由保存校验要求重新选择；
+  // 默认模型悬空置空回落排序首位。
   //
-  // 归一化必须先 assignSlotIds 再判定：槽位增删会让序号轮换、ID 在溢出↔池内
-  // 之间变档，用旧 ID 判定会剥错方向。判定用该 ID 的具体阶梯（effortLevelsFor，
-  // 非 ladder 返回 []）而非三态——同为完整阶梯的 4-6 系不含 xhigh，越阶值同样要剥。
+  // 先为新行分配 ID，再按每行的实际兼容阶梯校验上限；既有 ID 和有效上限不变。
   const commit = (next: AggregateRoutes) => {
-    const assigned = assignSlotIds(next);
+    const assigned = assignSlotIds(next, value);
     return onChange({
       ...assigned,
       slots: assigned.slots.map((s) =>
@@ -186,7 +204,7 @@
    *  任何档位）存进 pendingProviders。 */
   const commitCards = (next: ProviderTierRows[]) => {
     const hasRows = (card: ProviderTierRows) =>
-      TIER_ROW_ORDER.some((tier) => card.rows[tier]);
+      TIER_ROW_ORDER.some((tier) => card.rows[tier]?.length);
     setPendingProviders(
       next.filter((card) => !hasRows(card)).map((c) => c.providerId),
     );
@@ -202,8 +220,9 @@
     card.providerId = providerId;
     // 行内的槽位各自带着 providerId（扁平存储的冗余），换卡头时同步改写
     for (const tier of TIER_ROW_ORDER) {
-      const slot = card.rows[tier];
-      if (slot) card.rows[tier] = { ...slot, providerId };
+      const slots = card.rows[tier];
+      if (slots)
+        card.rows[tier] = slots.map((slot) => ({ ...slot, providerId }));
     }
     commitCards(next);
   };
@@ -211,31 +230,45 @@
   const patchRow = (
     cardIndex: number,
     tier: AggregateTier,
+    rowIndex: number,
     patch: Partial<AggregateRouteSlot>,
   ) => {
     const next = cloneCards(cards);
-    const slot = next[cardIndex].rows[tier];
-    if (!slot) return;
-    next[cardIndex].rows[tier] = { ...slot, ...patch };
+    const slots = next[cardIndex].rows[tier];
+    if (!slots?.[rowIndex]) return;
+    next[cardIndex].rows[tier] = slots.map((slot, i) =>
+      i === rowIndex ? { ...slot, ...patch } : slot,
+    );
     commitCards(next);
   };
 
-  const removeRow = (cardIndex: number, tier: AggregateTier) => {
+  const removeRow = (
+    cardIndex: number,
+    tier: AggregateTier,
+    rowIndex: number,
+  ) => {
     const next = cloneCards(cards);
-    delete next[cardIndex].rows[tier];
+    const remaining = (next[cardIndex].rows[tier] ?? []).filter(
+      (_, i) => i !== rowIndex,
+    );
+    if (remaining.length) next[cardIndex].rows[tier] = remaining;
+    else delete next[cardIndex].rows[tier];
     commitCards(next);
   };
 
-  /** 新增档位行：只允许未占用的档（v3：增量添加替代固定四行）。 */
+  /** 每个档位可以添加多个独立模型。 */
   const addRow = (cardIndex: number, tier: AggregateTier) => {
     const next = cloneCards(cards);
-    next[cardIndex].rows[tier] = {
-      routeId: "",
-      tier,
-      providerId: next[cardIndex].providerId,
-      upstreamModel: "",
-      supports1m: false,
-    };
+    next[cardIndex].rows[tier] = [
+      ...(next[cardIndex].rows[tier] ?? []),
+      {
+        routeId: "",
+        tier,
+        providerId: next[cardIndex].providerId,
+        upstreamModel: "",
+        supports1m: false,
+      },
+    ];
     // 新行自动展开（用户要立刻填它）
     const cardId = next[cardIndex].providerId;
     setExpandedIds((prev) => new Set(prev).add(cardId));
@@ -245,7 +278,7 @@
   const removeCard = (cardIndex: number) =>
     commitCards(cards.filter((_, i) => i !== cardIndex));
 
-  /** 别名规则改动直接走 commit：assignSlotIds 会跟随重编号，maxEffort 归一化不受影响。 */
+  /** 别名规则改动不改变槽位身份；按实际 ID 校验有效上限。 */
   const patchAliasRule = (
     index: number,
     patch: Partial<AggregateAliasRule>,
@@ -321,6 +354,58 @@
         <h3 className="text-sm font-medium">{t("aggregate.title")}</h3>
         <p className="text-xs text-muted-foreground">{t("aggregate.hint")}</p>
       </header>
+
+      {needsRouteIdMigration(value) && (
+        <div className="space-y-2 rounded-md border p-3 text-xs">
+          <p>
+            存量路由 ID 不兼容或重复。普通编辑保留原
+            ID；转换前请备份，旧会话可能需要重新选择模型。
+          </p>
+          <Button
+            type="button"
+            variant="outline"
+            size="sm"
+            onClick={() => {
+              setMigrationPreview(migrateIncompatibleRouteIds(value));
+              setMigrationBackup(false);
+            }}
+          >
+            预览旧路由转换
+          </Button>
+          {migrationPreview && (
+            <>
+              <pre className="whitespace-pre-wrap">
+                {value.slots
+                  .map(
+                    (slot, i) =>
+                      `${slot.routeId} → ${migrationPreview.slots[i]?.routeId}；上限 ${slot.maxEffort ?? "不限制"} → ${migrationPreview.slots[i]?.maxEffort ?? "不限制"}`,
+                  )
+                  .join("\n")}
+              </pre>
+              <Button
+                type="button"
+                variant="outline"
+                size="sm"
+                onClick={downloadMigrationBackup}
+              >
+                下载路由备份
+              </Button>
+              <Button
+                type="button"
+                size="sm"
+                disabled={!migrationBackup}
+                onClick={() => {
+                  onChange(migrationPreview);
+                  setMigrationPreview(undefined);
+                  setMigrationBackup(false);
+                }}
+              >
+                确认转换路由 ID
+              </Button>
+            </>
+          )}
+        </div>
+      )}
 
       {!canSaveAggregateRoutes(value) && (
         <p className="text-xs text-destructive">{t("aggregate.notSaveable")}</p>
@@ -544,17 +629,19 @@
               );
               const target = candidates.find((p) => p.id === card.providerId);
               const fetched = modelsForProvider(card.providerId);
-              const mappedTiers = TIER_ROW_ORDER.filter(
-                (tier) => card.rows[tier],
+              const mappedRows = TIER_ROW_ORDER.flatMap((tier) =>
+                (card.rows[tier] ?? []).map((slot, rowIndex) => ({
+                  tier,
+                  slot,
+                  rowIndex,
+                })),
               );
-              const unusedTiers = TIER_ROW_ORDER.filter(
-                (tier) => !card.rows[tier],
-              );
+              const availableTiers = TIER_ROW_ORDER;
               const expanded = expandedIds.has(card.providerId);
               // routeId 恒非空（每次 commit 都经 assignSlotIds 赋真 ID），无已映射
               // 槽位时 effectiveDefault 为 ""，恒不命中，无需再挡空值。
-              const isDefaultCard = Object.values(card.rows).some(
-                (slot) => slot?.routeId === effectiveDefault,
+              const isDefaultCard = mappedRows.some(
+                ({ slot }) => slot.routeId === effectiveDefault,
               );
               return (
                 <SortableCard key={card.providerId} id={card.providerId}>
@@ -665,15 +752,13 @@
 
                           {/* 已映射档位的行（v3：增量添加，不再固定四行）。行尾 ×
                               删除该槽；行内不支持改档位（删了重加）。 */}
-                          {mappedTiers.map((tier) => {
-                            const slot = card.rows[tier];
-                            if (!slot) return null;
+                          {mappedRows.map(({ tier, slot, rowIndex }) => {
                             const isEffectiveDefault =
                               slot.routeId === effectiveDefault;
-                            const switchId = `agg-1m-${cardIndex}-${tier}`;
+                            const switchId = `agg-1m-${slot.routeId || `${cardIndex}-${tier}-${rowIndex}`}`;
                             return (
                               <div
-                                key={tier}
+                                key={slot.routeId || `${tier}-${rowIndex}`}
                                 className="flex items-center gap-2"
                                 // 槽位 ID 不占版面，悬停可查——排查代理日志里的
                                 // request_model 时用得上
@@ -684,7 +769,7 @@
                                 </span>
                                 <EffortBadge routeId={slot.routeId} />
                                 <div className="flex min-w-0 flex-1 gap-1">
-                                {/* 上游模型只改值，不再承担行的生死——删行走
+                                  {/* 上游模型只改值，不再承担行的生死——删行走
                                     行尾 × 按钮（v3 语义）。 */}
                                   <Input
                                     className="h-8 min-w-0 flex-1"
@@ -694,7 +779,7 @@
                                       { defaultValue: "上游模型名" },
                                     )}
                                     onChange={(e) =>
-                                      patchRow(cardIndex, tier, {
+                                      patchRow(cardIndex, tier, rowIndex, {
                                         upstreamModel: e.target.value,
                                       })
                                     }
@@ -703,7 +788,7 @@
                                     <ModelDropdown
                                       models={fetched}
                                       onSelect={(id) =>
-                                        patchRow(cardIndex, tier, {
+                                        patchRow(cardIndex, tier, rowIndex, {
                                           upstreamModel: id,
                                         })
                                       }
@@ -717,7 +802,7 @@
                                     value={slot.label ?? ""}
                                     // 留空则不落库；提交时由表单统一补成「供应商 · 上游模型」
                                     onValueChange={(v) =>
-                                      patchRow(cardIndex, tier, {
+                                      patchRow(cardIndex, tier, rowIndex, {
                                         label: v.trim() ? v : undefined,
                                       })
                                     }
@@ -734,7 +819,9 @@
                                   routeId={slot.routeId}
                                   value={slot.maxEffort}
                                   onChange={(v) =>
-                                    patchRow(cardIndex, tier, { maxEffort: v })
+                                    patchRow(cardIndex, tier, rowIndex, {
+                                      maxEffort: v,
+                                    })
                                   }
                                 />
                                 <div className="flex w-20 shrink-0 items-center justify-end gap-1.5">
@@ -742,7 +829,7 @@
                                     id={switchId}
                                     checked={Boolean(slot.supports1m)}
                                     onCheckedChange={(v) =>
-                                      patchRow(cardIndex, tier, {
+                                      patchRow(cardIndex, tier, rowIndex, {
                                         supports1m: v,
                                       })
                                     }
@@ -762,7 +849,9 @@
                                   title={t("aggregate.removeModel", {
                                     defaultValue: "删除该模型",
                                   })}
-                                  onClick={() => removeRow(cardIndex, tier)}
+                                  onClick={() =>
+                                    removeRow(cardIndex, tier, rowIndex)
+                                  }
                                 >
                                   <X className="h-3.5 w-3.5" />
                                 </Button>
@@ -770,8 +859,8 @@
                             );
                           })}
 
-                          {/* 新增模型：只列未占用的档位；满 4 档隐藏 */}
-                          {unusedTiers.length > 0 && (
+                          {/* 新增模型：各档位允许多行，不覆盖既有模型 */}
+                          {availableTiers.length > 0 && (
                             <DropdownMenu>
                               <DropdownMenuTrigger asChild>
                                 <Button
@@ -787,7 +876,7 @@
                                 </Button>
                               </DropdownMenuTrigger>
                               <DropdownMenuContent align="start">
-                                {unusedTiers.map((tier) => (
+                                {availableTiers.map((tier) => (
                                   <DropdownMenuItem
                                     key={tier}
                                     onClick={() => addRow(cardIndex, tier)}
@@ -803,11 +892,10 @@
                         /* 折叠态摘要：N 个模型 · M 强度 */
                         <p className="text-xs text-muted-foreground">
                           {t("aggregate.modelsSummaryLadder", {
-                            count: mappedTiers.length,
-                            ladder: mappedTiers.filter(
-                              (tier) =>
-                                effortCapability(card.rows[tier]!.routeId) ===
-                                "ladder",
+                            count: mappedRows.length,
+                            ladder: mappedRows.filter(
+                              ({ slot }) =>
+                                effortCapability(slot.routeId) === "ladder",
                             ).length,
                             defaultValue: "{{count}} 个模型 · {{ladder}} 强度",
                           })}


## Exact change diff: tests/components/AggregateProviderFields.aliasRules.test.tsx
--- before/tests/components/AggregateProviderFields.aliasRules.test.tsx
+++ after/tests/components/AggregateProviderFields.aliasRules.test.tsx
@@ -85,10 +85,10 @@
     await user.type(input, "claude-opus");
     const calls = props.onChange.mock.calls;
     const last = calls[calls.length - 1][0] as AggregateRoutes;
-    // 槽位 ID 由 commit 内的 assignSlotIds 重编号（sonnet 首位取池内真 ID）
+    // 修改前缀不改变既有槽位身份。
     expect(last.aliasRules?.[0]).toEqual({
       prefix: "claude-opus",
-      slotId: "claude-sonnet-4-6",
+      slotId: "claude-sonnet-4",
     });
     // 第二条规则不受影响（patch 只改被编辑的行）
     expect(last.aliasRules?.[1]).toEqual({ prefix: "claude-", slotId: "" });


## Exact change diff: tests/components/AggregateProviderFields.effortBadge.test.tsx
--- before/tests/components/AggregateProviderFields.effortBadge.test.tsx
+++ after/tests/components/AggregateProviderFields.effortBadge.test.tsx
@@ -98,7 +98,7 @@
     ]);
   });
 
-  it("提交归一化按重编号后的 ID 判定：变档成溢出的槽剥离 maxEffort", async () => {
+  it("普通提交保留每个既有模型的 ID 和有效强度上限", async () => {
     const user = userEvent.setup();
     const onChange = vi.fn();
     // 两张卡各一条 sonnet 行：重编号后 p1 取池内第 1 位（claude-sonnet-4-6，ladder），
@@ -143,11 +143,11 @@
     const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
     expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
       ["claude-sonnet-4-6", "max"], // ladder：保留
-      ["claude-sonnet-4-5", undefined], // extended：剥离
+      ["claude-sonnet-5", "xhigh"], // ID 和能力均保留
     ]);
   });
 
-  it("重编号后阶梯收窄（sonnet-5→4-6）的槽剥离越阶残留 maxEffort", async () => {
+  it("删除其他模型不收窄剩余模型的 ID 或强度上限", async () => {
     const user = userEvent.setup();
     const onChange = vi.fn();
     // 存量数据：p1 槽存的是 sonnet-5 + xhigh（删槽轮换前的旧编号）。提交必先
@@ -192,7 +192,7 @@
 
     const next = onChange.mock.calls.at(-1)?.[0] as AggregateRoutes;
     expect(next.slots.map((s) => [s.routeId, s.maxEffort])).toEqual([
-      ["claude-sonnet-4-6", undefined],
+      ["claude-sonnet-5", "xhigh"],
     ]);
   });
 });


## Exact change diff: tests/components/AggregateProviderFields.compatibility.test.tsx
--- before/tests/components/AggregateProviderFields.compatibility.test.tsx
+++ after/tests/components/AggregateProviderFields.compatibility.test.tsx
@@ -0,0 +1,83 @@
+import { useState } from "react";
+import { fireEvent, render, screen } from "@testing-library/react";
+import userEvent from "@testing-library/user-event";
+import { describe, expect, it, vi } from "vitest";
+import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
+import type { AggregateRoutes, Provider } from "@/types";
+
+const initial: AggregateRoutes = {
+  slots: [
+    {
+      routeId: "claude-sonnet-4-6",
+      tier: "sonnet",
+      providerId: "a",
+      upstreamModel: "upstream-a",
+      label: "A",
+    },
+    {
+      routeId: "claude-sonnet-4-5",
+      tier: "sonnet",
+      providerId: "a",
+      upstreamModel: "upstream-b",
+      label: "B",
+    },
+  ],
+  defaultTarget: { kind: "slotId", value: "claude-sonnet-4-6" },
+  defaultModel: "claude-sonnet-4-6",
+};
+
+async function setup() {
+  const change = vi.fn();
+  function Controlled() {
+    const [value, setValue] = useState(initial);
+    return (
+      <AggregateProviderFields
+        value={value}
+        onChange={(next) => {
+          change(next);
+          setValue(next);
+        }}
+        candidates={[
+          { id: "a", name: "Synthetic A", settingsConfig: {} } as Provider,
+        ]}
+        modelsForProvider={() => []}
+        fetchingProviderId={null}
+        onFetchModels={() => {}}
+      />
+    );
+  }
+  render(<Controlled />);
+  await userEvent
+    .setup()
+    .click(screen.getByRole("button", { name: "全部展开" }));
+  return change;
+}
+
+describe("lossless multi-model editing", () => {
+  it("shows both existing models in the same provider/tier", async () => {
+    await setup();
+    expect(screen.getByDisplayValue("upstream-a")).toBeInTheDocument();
+    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
+  });
+
+  it("editing one model keeps the other and preserves identities", async () => {
+    const change = await setup();
+    fireEvent.change(screen.getByDisplayValue("upstream-a"), {
+      target: { value: "changed-a" },
+    });
+    const next = change.mock.lastCall?.[0] as AggregateRoutes;
+    expect(next.slots).toHaveLength(2);
+    expect(next.slots[1]).toEqual(initial.slots[1]);
+    expect(next.defaultModel).toBe(initial.defaultModel);
+  });
+
+  it("deleting one row leaves the second model available", async () => {
+    const change = await setup();
+    await userEvent
+      .setup()
+      .click(screen.getAllByRole("button", { name: "删除该模型" })[0]);
+    const next = change.mock.lastCall?.[0] as AggregateRoutes;
+    expect(next.slots).toEqual([initial.slots[1]]);
+    expect(screen.getByDisplayValue("upstream-b")).toBeInTheDocument();
+  });
+});


## Exact change diff: tests/components/AggregateProviderFields.migration.test.tsx
--- before/tests/components/AggregateProviderFields.migration.test.tsx
+++ after/tests/components/AggregateProviderFields.migration.test.tsx
@@ -0,0 +1,100 @@
+import { render, screen } from "@testing-library/react";
+import userEvent from "@testing-library/user-event";
+import { expect, it, vi } from "vitest";
+import { AggregateProviderFields } from "@/components/providers/forms/AggregateProviderFields";
+import type { AggregateRoutes, Provider } from "@/types";
+
+it("changing the source after a migration preview invalidates confirmation", async () => {
+  const initial: AggregateRoutes = {
+    slots: [
+      {
+        routeId: "claude-fable-glm",
+        tier: "fable",
+        providerId: "a",
+        upstreamModel: "old",
+      },
+    ],
+    defaultTarget: { kind: "providerId", value: "a" },
+  };
+  const common = {
+    onChange: vi.fn(),
+    candidates: [{ id: "a", name: "A", settingsConfig: {} } as Provider],
+    modelsForProvider: () => [],
+    fetchingProviderId: null,
+    onFetchModels: () => {},
+  };
+  const { rerender } = render(
+    <AggregateProviderFields {...common} value={initial} />,
+  );
+  await userEvent
+    .setup()
+    .click(screen.getByRole("button", { name: "预览旧路由转换" }));
+  expect(
+    screen.getByRole("button", { name: "确认转换路由 ID" }),
+  ).toBeInTheDocument();
+  rerender(
+    <AggregateProviderFields
+      {...common}
+      value={{
+        ...initial,
+        slots: [{ ...initial.slots[0], upstreamModel: "new-edit" }],
+      }}
+    />,
+  );
+  expect(
+    screen.queryByRole("button", { name: "确认转换路由 ID" }),
+  ).not.toBeInTheDocument();
+  expect(common.onChange).not.toHaveBeenCalled();
+});
+
+it("legacy invalid IDs change only after explicit preview, backup and confirmation", async () => {
+  const oldId = "claude-fable-zhipu-glm";
+  const routes: AggregateRoutes = {
+    slots: [
+      {
+        routeId: oldId,
+        tier: "fable",
+        providerId: "a",
+        upstreamModel: "model-a",
+      },
+    ],
+    defaultTarget: { kind: "slotId", value: oldId },
+    defaultModel: oldId,
+    aliasRules: [{ prefix: "team", slotId: oldId }],
+  };
+  const change = vi.fn();
+  render(
+    <AggregateProviderFields
+      value={routes}
+      onChange={change}
+      candidates={[{ id: "a", name: "A", settingsConfig: {} } as Provider]}
+      modelsForProvider={() => []}
+      fetchingProviderId={null}
+      onFetchModels={() => {}}
+    />,
+  );
+  const user = userEvent.setup();
+  await user.click(screen.getByRole("button", { name: "预览旧路由转换" }));
+  expect(change).not.toHaveBeenCalled();
+  expect(
+    screen.getByRole("button", { name: "确认转换路由 ID" }),
+  ).toBeDisabled();
+  class MockURL extends URL {
+    static createObjectURL = vi.fn(() => "blob:synthetic");
+    static revokeObjectURL = vi.fn();
+  }
+  vi.stubGlobal("URL", MockURL);
+  const click = vi
+    .spyOn(HTMLAnchorElement.prototype, "click")
+    .mockImplementation(() => {});
+  await user.click(screen.getByRole("button", { name: "下载路由备份" }));
+  await user.click(screen.getByRole("button", { name: "确认转换路由 ID" }));
+  const next = change.mock.lastCall?.[0] as AggregateRoutes;
+  expect(next.slots[0].routeId).not.toBe(oldId);
+  expect(next.slots[0].upstreamModel).toBe("model-a");
+  expect(next.defaultTarget.value).toBe(next.slots[0].routeId);
+  expect(next.defaultModel).toBe(next.slots[0].routeId);
+  expect(next.aliasRules?.[0].slotId).toBe(next.slots[0].routeId);
+  click.mockRestore();
+  vi.unstubAllGlobals();
+});


## Exact change diff: src-tauri/src/aggregate.rs
--- before/src-tauri/src/aggregate.rs
+++ after/src-tauri/src/aggregate.rs
@@ -80,6 +80,9 @@
     /// serde default 反序列化为空列表 —— 行为等同未启用。
     #[serde(default)]
     pub alias_rules: Vec<AggregateAliasRule>,
+    /// 删除的路由名称仍保留身份，禁止旧会话静默改指新模型。
+    #[serde(default, skip_serializing_if = "Vec::is_empty")]
+    pub retired_route_ids: Vec<String>,
 }
 
 /// Codex 聚合路由：客户端模型名（精确匹配）→ 目标 Codex 供应商 + 上游模型。
@@ -134,6 +137,7 @@
                 slots,
                 default_target: DefaultTarget::ProviderId("p-target".to_string()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -364,6 +368,7 @@
                 }],
                 default_target: DefaultTarget::ProviderId("p-glm".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -419,6 +424,7 @@
                 slots,
                 default_target,
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()
@@ -1474,9 +1480,17 @@
     let requested =
         crate::claude_desktop_config::strip_one_m_suffix_for_route_lookup(request_model);
 
+    if routes.retired_route_ids.iter().any(|id| id.trim().eq_ignore_ascii_case(requested)) {
+        return Err(AppError::localized(
+            "aggregate.route_retired",
+            "该聚合模型路由已删除，请重新选择模型",
+            "This aggregate model route was removed; select a model again",
+        ));
+    }
+
     // 直接按持久化的槽位 ID 查表（ID 由前端编辑时生成并随表单提交，运行时不重新生成）
     for slot in &routes.slots {
-        if slot.route_id == requested {
+        if slot.route_id.trim() == requested {
             let target = load_provider(db, app_type, &slot.provider_id)?;
             return Ok((target, Some(slot.upstream_model.clone())));
         }
@@ -1493,7 +1507,7 @@
         if prefix.is_empty() || !lowered.starts_with(&prefix) {
             continue;
         }
-        let Some(slot) = routes.slots.iter().find(|s| s.route_id == rule.slot_id) else {
+        let Some(slot) = routes.slots.iter().find(|s| s.route_id.trim() == rule.slot_id.trim()) else {
             if !rule.slot_id.is_empty() {
                 log::info!(
                     "[aggregate] alias rule '{prefix}' -> dangling slot '{}', skipped",
@@ -1512,7 +1526,7 @@
         DefaultTarget::SlotId(slot_id) => routes
             .slots
             .iter()
-            .find(|slot| &slot.route_id == slot_id)
+            .find(|slot| slot.route_id.trim() == slot_id.trim())
             .map(|slot| slot.provider_id.clone())
             .ok_or_else(|| {
                 AppError::localized(


## Exact change diff: src-tauri/src/aggregate_retirement_tests.rs
--- before/src-tauri/src/aggregate_retirement_tests.rs
+++ after/src-tauri/src/aggregate_retirement_tests.rs
@@ -0,0 +1,55 @@
+use super::*;
+
+fn routes_json() -> serde_json::Value {
+    serde_json::json!({
+        "slots":[{"routeId":"claude-sonnet-4-5","tier":"sonnet","providerId":"synthetic-target","upstreamModel":"new-model"}],
+        "defaultTarget":{"kind":"providerId","value":"synthetic-target"},
+        "aliasRules":[{"prefix":"claude-sonnet","slotId":"claude-sonnet-4-5"}],
+        "retiredRouteIds":["claude-sonnet-4-6"]
+    })
+}
+
+#[test]
+fn aggregate_retirement_survives_backend_serialization_roundtrip() {
+    let routes: AggregateRoutes = serde_json::from_value(routes_json()).unwrap();
+    let persisted = serde_json::to_value(routes).unwrap();
+    assert_eq!(persisted["retiredRouteIds"], serde_json::json!(["claude-sonnet-4-6"]));
+}
+
+#[tokio::test]
+async fn aggregate_retirement_old_requests_are_rejected_before_alias_or_fallback() {
+    let db = crate::database::Database::memory().unwrap();
+    let target = Provider::with_id("synthetic-target".into(), "Synthetic".into(), serde_json::json!({}), None);
+    db.save_provider("claude-desktop", &target).unwrap();
+    let mut provider = Provider::with_id("synthetic-aggregate".into(), "Synthetic Aggregate".into(), serde_json::json!({}), None);
+    provider.meta = Some(crate::provider::ProviderMeta {
+        aggregate_routes: Some(serde_json::from_value(routes_json()).unwrap()),
+        ..Default::default()
+    });
+    for request in ["claude-sonnet-4-6", "claude-sonnet-4-6[1m]", "CLAUDE-SONNET-4-6"] {
+        assert!(resolve_target(&db, "claude-desktop", &provider, request).is_err(),
+            "Retired ID must not be redirected through the alias or default");
+    }
+}
+
+#[test]
+fn aggregate_retirement_legacy_absent_metadata_is_backward_compatible() {
+    let mut legacy = routes_json();
+    legacy.as_object_mut().unwrap().remove("retiredRouteIds");
+    let parsed: AggregateRoutes = serde_json::from_value(legacy).unwrap();
+    let persisted = serde_json::to_value(parsed).unwrap();
+    assert!(persisted.get("retiredRouteIds").is_none());
+}
+
+#[tokio::test]
+async fn aggregate_compatibility_padded_route_key_preserves_exact_mapping() {
+    let db=crate::database::Database::memory().unwrap();
+    db.save_provider("claude-desktop",&Provider::with_id("synthetic-target".into(),"Synthetic".into(),serde_json::json!({}),None)).unwrap();
+    let mut json=routes_json();
+    json["slots"][0]["routeId"]=serde_json::json!(" claude-sonnet-4-5 ");
+    json["aliasRules"]=serde_json::json!([]);
+    let mut provider=Provider::with_id("synthetic-aggregate".into(),"Synthetic".into(),serde_json::json!({}),None);
+    provider.meta=Some(crate::provider::ProviderMeta{aggregate_routes:Some(serde_json::from_value(json).unwrap()),..Default::default()});
+    let (_,upstream)=resolve_target(&db,"claude-desktop",&provider,"claude-sonnet-4-5").unwrap();
+    assert_eq!(upstream.as_deref(),Some("new-model"));
+}


## Exact change diff: src-tauri/src/services/provider/mod.rs
--- before/src-tauri/src/services/provider/mod.rs
+++ after/src-tauri/src/services/provider/mod.rs
@@ -1708,6 +1708,22 @@
     }
 
     #[test]
+    fn validate_aggregate_rejects_retired_active_overlap_and_empty_history_keys() {
+        for retired in ["claude-sonnet-4-5", "CLAUDE-SONNET-4-5", ""] {
+            let mut provider = Provider::with_id("synthetic-aggregate".into(), "Synthetic".into(), json!({}), None);
+            provider.meta = Some(ProviderMeta {
+                aggregate_routes: Some(serde_json::from_value(json!({
+                    "slots":[{"routeId":"claude-sonnet-4-5","tier":"sonnet","providerId":"synthetic-target","upstreamModel":"synthetic-model"}],
+                    "defaultTarget":{"kind":"providerId","value":"synthetic-target"},
+                    "retiredRouteIds":[retired]
+                })).unwrap()),
+                ..Default::default()
+            });
+            assert!(ProviderService::validate_provider_settings(&AppType::ClaudeDesktop, &provider).is_err());
+        }
+    }
+
+    #[test]
     fn validate_aggregate_rejects_empty_slots() {
         let provider = aggregate_provider(
             "agg",
@@ -1715,6 +1731,7 @@
                 slots: vec![],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("x".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1731,6 +1748,7 @@
                 slots: vec![slot("claude-sonnet-agg", "agg")], // 指向自己
                 default_target: crate::aggregate::DefaultTarget::ProviderId("agg".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1747,6 +1765,7 @@
                 slots: vec![slot("claude-sonnet-a", "p1"), slot("claude-sonnet-a", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1765,6 +1784,7 @@
                 slots: vec![slot("glm-5.3", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1787,6 +1807,7 @@
                 slots: vec![bad_target],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1802,6 +1823,7 @@
                 slots: vec![bad_model],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1818,6 +1840,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1"), slot("claude-opus-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1834,6 +1857,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("   ".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1860,6 +1884,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::SlotId("claude-opus-gone".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1886,6 +1911,7 @@
                 slots: vec![slot("claude-sonnet-1", "p1")],
                 default_target: crate::aggregate::DefaultTarget::SlotId("claude-sonnet-1".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             },
         );
@@ -1917,6 +1943,7 @@
                     slots: vec![slot("claude-sonnet-1", "p-glm")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1931,6 +1958,7 @@
                     slots: vec![slot("claude-sonnet-nested", "target-agg")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1951,6 +1979,7 @@
                         "target-agg".into(),
                     ),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1985,6 +2014,7 @@
                     slots: vec![slot("claude-sonnet-target", "target")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("target".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -1998,6 +2028,7 @@
                     slots: vec![slot("claude-sonnet-other", "other")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("other".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -2043,6 +2074,7 @@
                     slots: vec![slot("claude-sonnet-target", "target")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("target".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -2079,6 +2111,7 @@
                     slots: vec![slot("claude-sonnet-target", "target")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("fallback".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 },
             );
@@ -2359,6 +2392,7 @@
                     slots: vec![slot("claude-sonnet-1", "p-glm")],
                     default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                     default_model: None,
+                    retired_route_ids: vec![],
                     alias_rules: vec![],
                 }),
                 ..Default::default()
@@ -7987,6 +8021,17 @@
                 seen.push(route_id.to_string());
             }
 
+            for retired in &routes.retired_route_ids {
+                let id = retired.trim();
+                if id.is_empty() || seen.iter().any(|active| active.eq_ignore_ascii_case(id)) {
+                    return Err(AppError::localized(
+                        "aggregate.retired_route_invalid",
+                        "已删除的路由 ID 不得为空或与当前模型重复",
+                        "Retired route IDs must be non-empty and must not overlap active models",
+                    ));
+                }
+            }
+
             // 默认目标必填且必须可用：未命中槽位的请求（Claude Desktop 的内部调用，
             // 如会话标题/摘要，正是此类）会回落到它；若它缺失或指向不存在的槽位，
             // 运行时会硬失败，故保存时就拦截（设计 §8/§9）。


## Exact change diff: src-tauri/src/claude_desktop_config.rs
--- before/src-tauri/src/claude_desktop_config.rs
+++ after/src-tauri/src/claude_desktop_config.rs
@@ -2729,6 +2729,7 @@
             ],
             default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
             default_model: None,
+            retired_route_ids: vec![],
             alias_rules: vec![],
         });
 
@@ -2773,6 +2774,7 @@
                 }],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("p-glm".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()


## Exact change diff: src-tauri/src/proxy/server.rs
--- before/src-tauri/src/proxy/server.rs
+++ after/src-tauri/src/proxy/server.rs
@@ -1361,6 +1361,7 @@
                     "default-target".to_string(),
                 ),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()


## Exact change diff: src-tauri/src/services/stream_check.rs
--- before/src-tauri/src/services/stream_check.rs
+++ after/src-tauri/src/services/stream_check.rs
@@ -560,6 +560,7 @@
                 }],
                 default_target: crate::aggregate::DefaultTarget::ProviderId("target".into()),
                 default_model: None,
+                retired_route_ids: vec![],
                 alias_rules: vec![],
             }),
             ..Default::default()


## Exact change diff: docs/reviews/2026-10-04-aggregate-route-compatibility-fix.md
--- before/docs/reviews/2026-10-04-aggregate-route-compatibility-fix.md
+++ after/docs/reviews/2026-10-04-aggregate-route-compatibility-fix.md
@@ -0,0 +1,27 @@
+# 聚合路由身份与存量无损编辑修复
+
+日期2026-10-04；任务task_cfc43aae54a58adb，原评估M01/M02。范围为Claude聚合路由；Codex表单作为兼容回归，不把其默认引用问题说成已修复。
+
+## 行为
+
+普通编辑保留已有routeId，只为新增空ID槽位分配未占用ID。排序、插入、编辑不重新编号，也不因此改变默认模型、别名、有效能力上限或上游。ID分配对退役名称按大小写不敏感处理，避免新名字与后端的退役判断冲突。
+
+新增可选retiredRouteIds。删除的ID跨保存保留且不分配给新模型；后端在精确/别名/兜底前拒绝对该ID的请求（包含1M后缀和大小写变体）。旧数据缺省空历史，空字段不序列化；活动/退役重叠或空历史键保存校验拒绝。已有带首尾空白的合法路由键，运行查找按与目录派生一致的trim规则匹配。
+
+供应商卡片每档位保存数组，不再只取第一个模型。所有同档模型显示、各行可独立编辑/删除，也可新增同档模型。删除默认兜底槽位后不会把旧名称认领给新行，需重新选择可用目标；启动默认模型被删时回落到首位。
+
+对旧不兼容/重复ID提供明确的转换预览；普通编辑不自动转换。先下载仅含路由表的备份，再确认应用新ID，默认/别名引用随确认迁移。预览显示ID和能力上限变化；替换后的ID不支持原强度时移除该上限。预览后有任何数据编辑，会使确认失效，防止旧预览覆盖新修改。
+
+## 验证与证据
+
+初始7项前端行为RED实际失败，随后转绿；后端退役保存/旧请求隔离2项失败、旧数据兼容1项通过，随后转绿。补充大小写历史、显式迁移和新ID能力上限、空白键对齐的实际失败回归及修复，均保留；迁移URL接口的jsdom缺省问题归为测试工具问题，不冒充产品失败。
+
+当前相关前端77项通过、后端aggregate相关102项通过；TypeScript tsc --noEmit通过，生产cargo check --offline --lib通过。测试范围和filtered数量来自实际日志，不宣称约3000项后端全套通过。既有测试中“自动重编号”“同档只保留首个”的断言已按批准的新契约修改，不隐藏行为变化。
+
+浏览器实际使用AggregateProviderFields及模拟数据，验证两条sonnet行显示、编辑第二条保留其余、删除后记录退役ID、同档新增使用新ID，并检查旧ID转换预览及备份前确认禁用。三张截图已视觉检查。未调用Tauri保存或真实数据库；浏览器未完成迁移下载/确认，该分支由组件测试覆盖。完整证据在D:\Sources\Code\agent-org\dist\agent-org\cc-switch-fixes-2026-10-04-1ebd221f。
+
+## 使用与回退边界
+
+日常配置按供应商添加模型，可在同一档位添加多行；排序可改变显示顺序但不改变既有ID。删除会使旧会话的被删模型明确不可用，需在客户端重新选择。新字段需使用本修复版本保存；旧版本可能丢弃退役历史且会重编号，回退必须恢复完整备份，并在旧编辑器使用前检查客户端会话/模型目录。不能把用旧编辑器改写新格式视为无损回退。
+
+尚未验收完整桌面、真实账号/上游、客户端重启或旧会话的原生恢复；没有合并、提交、发布或更改live设置。独立审查与正式交付以任务实际记录为准。M05目标熔断、M06Claude兜底模型语义及其他UI项继续保持待办。


## Observed evidence: route-final-frontend-check.txt
[baseline-browser-mapping] The data in this module is over two months old.  To ensure accurate Baseline data, please update: `npm i baseline-browser-mapping@latest -D`

 RUN  v2.1.9 D:/Workspace/Project/cc-switch/src

 ✓ src/utils/aggregateRoutes.compatibility.test.ts (6 tests) 23ms
 ✓ src/utils/aggregateRoutes.test.ts (36 tests) 46ms
 ✓ tests/components/AggregateProviderFields.migration.test.tsx (2 tests) 959ms
   ✓ changing the source after a migration preview invalidates confirmation 567ms
   ✓ legacy invalid IDs change only after explicit preview, backup and confirmation 384ms
 ✓ tests/components/AggregateProviderFields.compatibility.test.tsx (3 tests) 1096ms
   ✓ lossless multi-model editing > shows both existing models in the same provider/tier 528ms
 ✓ tests/components/AggregateProviderFields.aliasRules.test.tsx (4 tests) 1296ms
   ✓ 别名路由区块 > 渲染既有规则行（含悬空行），悬空行显示占位而非崩 380ms
   ✓ 别名路由区块 > 编辑前缀回调 onChange 且带上新前缀 524ms
 ✓ tests/components/AggregateProviderFields.effortBadge.test.tsx (6 tests) 1512ms
   ✓ 聚合编辑器三态思考徽标 > 展开卡后 ladder 槽显示 强度✓、溢出槽显示 ✗ 504ms
   ✓ 聚合编辑器上限下拉 > 上限下拉：ladder 槽可选，溢出槽禁用 331ms
stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：开关接线与 meta 提交 > 普通非官方卡片可达开关；开启后保存写出 codexAggregateRoutes
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：开关接线与 meta 提交 > 关闭开关后保存删除 meta 键（普通供应商 JSON 不变）
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：开关接线与 meta 提交 > 已有表 + 改动显示名后保存：label 保留，槽位形状与后端 serde 一致
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：表单门禁（藏端点/凭据/配置块 + 豁免软校验） > 存量聚合卡片（无端点无 Key）保存不弹「仍要保存？」确认框
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

stderr | tests/components/CodexAggregateFields.test.tsx > Codex 聚合：表单门禁（藏端点/凭据/配置块 + 豁免软校验） > 非聚合卡片缺端点时仍弹确认框（豁免不外溢）
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"codex"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: {"appType":"gemini"}

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests
[MSW] Warning: intercepted a request without a matching request handler:

  • POST http://tauri.local/get_common_config_snippet

  • Request body: [object ReadableStream]

If you still wish to intercept this unhandled request, please create a request handler for it.
Read more: https://mswjs.io/docs/http/intercepting-requests

 ✓ tests/components/CodexAggregateFields.test.tsx (20 tests) 4820ms
   ✓ Codex 聚合编辑器：行增删与提交形状 > 兜底目标可选槽位（slotId），默认模型可设为槽位 model 387ms
   ✓ Codex 聚合：开关接线与 meta 提交 > 普通非官方卡片可达开关；开启后保存写出 codexAggregateRoutes 976ms
   ✓ Codex 聚合：开关接线与 meta 提交 > 关闭开关后保存删除 meta 键（普通供应商 JSON 不变） 473ms
   ✓ Codex 聚合：开关接线与 meta 提交 > 已有表 + 改动显示名后保存：label 保留，槽位形状与后端 serde 一致 375ms
   ✓ Codex 聚合：表单门禁（藏端点/凭据/配置块 + 豁免软校验） > 存量聚合卡片（无端点无 Key）保存不弹「仍要保存？」确认框 530ms
   ✓ Codex 聚合：表单门禁（藏端点/凭据/配置块 + 豁免软校验） > 非聚合卡片缺端点时仍弹确认框（豁免不外溢） 346ms

 Test Files  7 passed (7)
      Tests  77 passed (77)
   Start at  20:23:25
   Duration  11.96s (transform 2.62s, setup 5.69s, collect 8.49s, tests 9.75s, environment 8.18s, prepare 1.92s)



## Observed evidence: route-backend-pre-review.txt
   Compiling cc-switch v3.20.4-local (D:\Workspace\Project\cc-switch\src\src-tauri)
    Finished `test` profile [unoptimized + debuginfo] target(s) in 44.43s
     Running unittests src\lib.rs (target\debug\deps\cc_switch_lib-c8c28ab0cd774408.exe)

running 102 tests
test aggregate::retirement_tests::aggregate_compatibility_padded_route_key_preserves_exact_mapping ... ok
test aggregate::retirement_tests::aggregate_retirement_legacy_absent_metadata_is_backward_compatible ... ok
test aggregate::retirement_tests::aggregate_retirement_old_requests_are_rejected_before_alias_or_fallback ... ok
test aggregate::retirement_tests::aggregate_retirement_survives_backend_serialization_roundtrip ... ok
test aggregate::tests::aggregate_model_routes_carries_tier_for_ordering ... ok
test aggregate::tests::aggregate_model_routes_dedups_repeated_route_ids ... ok
test aggregate::tests::aggregate_model_routes_errors_when_all_slots_are_unusable ... ok
test aggregate::tests::aggregate_model_routes_filters_unsafe_route_ids ... ok
test aggregate::tests::aggregate_model_routes_ignores_dangling_default_model ... ok
test aggregate::tests::aggregate_model_routes_pins_default_model_to_front ... ok
test aggregate::tests::aggregate_model_routes_preserves_provider_grouped_order ... ok
test aggregate::tests::aggregate_routes_deserializes_without_default_model ... ok
test aggregate::tests::alias_dangling_slot_skipped_falls_to_default ... ok
test aggregate::tests::alias_empty_or_whitespace_prefix_skipped ... ok
test aggregate::tests::alias_first_match_wins ... ok
test aggregate::tests::alias_matching_is_case_insensitive ... ok
test aggregate::tests::alias_prefix_hits_route_to_slot_upstream ... ok
test aggregate::tests::alias_request_with_1m_suffix_still_matches ... ok
test aggregate::tests::alias_rules_absent_in_old_json_deserializes_empty ... ok
test aggregate::tests::codex_aggregate_catalog_keeps_non_empty_label_as_display_name ... ok
test aggregate::tests::codex_aggregate_catalog_preserves_slot_order_and_pins_default ... ok
test aggregate::tests::codex_aggregate_seed_toml_falls_back_to_first_slot_model ... ok
test aggregate::tests::codex_aggregate_seed_toml_places_fields_correctly ... ok
test aggregate::tests::codex_aggregate_synthesis_errors_when_all_slots_are_unusable ... ok
test aggregate::tests::codex_aggregate_synthesis_skips_half_finished_slots ... ok
test aggregate::tests::codex_routes_of_errors_when_missing ... ok
test aggregate::tests::exact_slot_match_wins_over_alias ... ok
test aggregate::tests::max_effort_absent_defaults_to_none_and_survives_roundtrip ... ok
test aggregate::tests::resolve_codex_target_dangling_default_slot_errors ... ok
test aggregate::tests::resolve_codex_target_default_slot_matches_padded_slot_model ... ok
test aggregate::tests::resolve_codex_target_default_slot_rewrites_to_slot_upstream ... ok
test aggregate::tests::resolve_codex_target_errors_when_target_provider_missing ... ok
test aggregate::tests::resolve_codex_target_exact_match_rewrites_model ... ok
test aggregate::tests::resolve_codex_target_falls_back_to_default_provider_without_rewrite ... ok
test aggregate::tests::resolve_codex_target_matches_padded_slot_model ... ok
test aggregate::tests::resolve_codex_target_requires_exact_model_match ... ok
test aggregate::tests::resolve_codex_target_strips_1m_marker_before_lookup ... ok
test aggregate::tests::resolve_codex_target_trims_upstream_model_on_the_way_out ... ok
test aggregate::tests::resolve_target_errors_when_default_target_slot_missing ... ok
test aggregate::tests::resolve_target_errors_when_target_provider_missing ... ok
test aggregate::tests::resolve_target_hits_slot_by_generated_id ... ok
test aggregate::tests::resolve_target_strips_one_m_marker_before_slot_lookup ... ok
test claude_desktop_config::tests::aggregate_provider_derives_model_routes_from_slots ... ok
test claude_desktop_config::tests::apply_aggregate_provider_without_credentials_writes_local_gateway_profile ... ok
test claude_desktop_config::tests::apply_provider_to_paths_returns_routes_only_for_aggregate_provider ... ok
test claude_desktop_config::tests::validate_direct_provider_accepts_aggregate_without_endpoint_or_credentials ... ok
test claude_desktop_config::tests::validate_proxy_provider_accepts_aggregate_without_endpoint_or_credentials ... ok
test provider::tests::codex_aggregate_routes_absent_when_unset ... ok
test provider::tests::codex_aggregate_routes_round_trip ... ok
test provider::tests::provider_meta_round_trips_aggregate_routes ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_default_account_is_preserved_without_explicit_binding ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_empty_token_or_workspace_is_rejected ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_invalid_default_identity_rejects_unrelated_login ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_no_managed_account_does_not_adopt_unselected_login ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_normal_official_and_api_key_requests_keep_their_authentication ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_provider_fallback_and_slots_forward_selected_account ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_refresh_and_transport_errors_never_change_accounts_or_echo_secrets ... ok
test proxy::forwarder::aggregate_auth_regression_tests::aggregate_auth_removed_binding_rejects_unrelated_live_login ... ok
test proxy::forwarder::tests::aggregate_non_official_target_auth_path_is_untouched ... ok
test proxy::forwarder::tests::aggregate_official_target_falls_back_to_default_account ... ok
test proxy::forwarder::tests::aggregate_official_target_uses_manager_token_not_proxy_managed ... ok
test proxy::forwarder::tests::aggregate_official_target_with_dangling_account_reports_login_hint ... ok
test proxy::forwarder::tests::aggregate_official_target_without_login_reports_login_hint ... ok
test proxy::forwarder::tests::official_target_without_aggregate_keeps_client_passthrough_auth ... ok
test proxy::handlers::tests::aggregated_chat_sse_round_trips_through_openai_to_anthropic ... ok
test proxy::handlers::tests::chat_sse_to_response_value_aggregates_text_finish_reason_and_usage ... ok
test proxy::providers::streaming_responses::tests::test_buffered_citations_render_fuller_aggregate_than_stale_terminal_snapshot ... ok
test proxy::providers::streaming_responses::tests::test_streamed_text_binds_output_and_item_aliases_to_one_aggregate ... ok
test proxy::server::tests::aggregate_routes_rewrite_model_and_use_target_provider ... ok
test proxy::server::tests::codex_aggregate_native_passthrough_rewrites_model_and_credentials ... ok
test proxy::server::tests::codex_aggregate_skips_apply_codex_chat_upstream_model_when_overridden ... ok
test proxy::server::tests::codex_aggregate_skips_apply_codex_upstream_model_when_overridden ... ok
test services::provider::live::tests::codex_aggregate_catalog_uses_native_responses_tool_profile ... ok
test services::provider::live::tests::codex_aggregate_effective_settings_synthesize_seed_and_catalog_for_live ... ok
test services::provider::live::tests::codex_aggregate_live_write_is_rejected_when_no_slot_is_usable ... ok
test services::provider::tests::delete_rejects_provider_referenced_by_aggregate ... ok
test services::provider::tests::delete_rejects_provider_referenced_by_codex_aggregate ... ok
test services::provider::tests::validate_aggregate_accepts_slot_default_target_present_in_slots ... ok
test services::provider::tests::validate_aggregate_accepts_valid_table ... ok
test services::provider::tests::validate_aggregate_leaves_non_aggregate_provider_untouched ... ok
test services::provider::tests::validate_aggregate_rejects_blank_provider_default_target ... ok
test services::provider::tests::validate_aggregate_rejects_default_target_naming_missing_slot ... ok
test services::provider::tests::validate_aggregate_rejects_duplicate_route_ids ... ok
test services::provider::tests::validate_aggregate_rejects_empty_slots ... ok
test services::provider::tests::validate_aggregate_rejects_incomplete_slot ... ok
test services::provider::tests::validate_aggregate_rejects_nested_aggregate ... ok
test services::provider::tests::validate_aggregate_rejects_ordinary_provider_becoming_referenced_aggregate ... ok
test services::provider::tests::validate_aggregate_rejects_retired_active_overlap_and_empty_history_keys ... ok
test services::provider::tests::validate_aggregate_rejects_self_reference ... ok
test services::provider::tests::validate_aggregate_rejects_unsafe_route_id ... ok
test services::provider::tests::validate_codex_aggregate_accepts_slot_default_target_present_in_slots ... ok
test services::provider::tests::validate_codex_aggregate_accepts_valid_table ... ok
test services::provider::tests::validate_codex_aggregate_leaves_non_aggregate_provider_untouched ... ok
test services::provider::tests::validate_codex_aggregate_rejects_blank_provider_default_target ... ok
test services::provider::tests::validate_codex_aggregate_rejects_default_target_naming_missing_slot ... ok
test services::provider::tests::validate_codex_aggregate_rejects_duplicate_slot_models ... ok
test services::provider::tests::validate_codex_aggregate_rejects_empty_slot_model ... ok
test services::provider::tests::validate_codex_aggregate_rejects_empty_slot_provider ... ok
test services::provider::tests::validate_codex_aggregate_rejects_empty_slot_upstream_model ... ok
test services::provider::tests::validate_codex_aggregate_rejects_nested_aggregate ... ok
test services::provider::tests::validate_codex_aggregate_rejects_referenced_provider_becoming_aggregate ... ok
test services::stream_check::tests::test_resolve_base_url_rejects_aggregate_provider ... ok

test result: ok. 102 passed; 0 failed; 0 ignored; 0 measured; 2935 filtered out; finished in 0.86s



## Observed evidence: route-ui-observation.json
{"surface":"Codex in-app browser","url":"http://127.0.0.1:3437","fixture":".agent-org/evidence/route-ui","actual_component":"AggregateProviderFields","data":"Synthetic providers and models only","checks":["Same-provider sonnet rows both visible","Editing second preserves three slots and old IDs","Deleting first preserves second and records retired ID","Adding sonnet chooses claude-sonnet-5 rather than retired claude-sonnet-4-6","Invalid legacy ID preview shows old/new identity and confirmation disabled before route backup"],"screenshots":["route-multi-model.png","route-retirement-and-add.png","route-migration-preview.png"],"observations_saved":["route-edited-dom.json","route-deleted-dom.json","route-added-dom.json","route-migration-preview-dom.txt"],"native_tauri_backend_executed":false,"real_account_configuration_changed":false,"migration_confirmation":"Unit test covers backup/confirm; browser verified preview and disabled state only"}
